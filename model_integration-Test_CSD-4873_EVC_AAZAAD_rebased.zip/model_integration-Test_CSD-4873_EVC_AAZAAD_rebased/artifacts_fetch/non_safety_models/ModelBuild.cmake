function(model_static model_name)

  # Important
  set(CMAKE_POSITION_INDEPENDENT_CODE ON)

  set(MODEL_SRC_DIR ${model_name}/code/${model_name}_ert_rtw)
  set(MODEL_UTILS_DIR ${model_name}/code/slprj/ert/_sharedutils)
  set(OTHERS_DIR ${model_name}/otherFiles)

  file(GLOB MODEL_SRCS ${MODEL_SRC_DIR}/*.cpp)
  file(GLOB UTILS_SRCS ${MODEL_UTILS_DIR}/*.cpp)

  file(GLOB MODEL_H ${MODEL_SRC_DIR}/*.h)
  file(GLOB MODEL_HPP ${MODEL_SRC_DIR}/*.hpp)
  file(GLOB UTILS_H ${MODEL_UTILS_DIR}/*.h)
  file(GLOB UTILS_HPP ${MODEL_UTILS_DIR}/*.hpp)
  file(GLOB OTHER_H ${OTHERS_DIR}/*.h)
  file(GLOB OTHER_HPP ${OTHERS_DIR}/*.hpp)

  set(HEADERS_PUBLIC ${MODEL_H})
  list(APPEND HEADERS_PUBLIC ${MODEL_HPP})
  list(APPEND HEADERS_PUBLIC ${UTILS_H})
  list(APPEND HEADERS_PUBLIC ${UTILS_HPP})
  list(APPEND HEADERS_PUBLIC ${OTHER_H})
  list(APPEND HEADERS_PUBLIC ${OTHER_HPP})

  set(TARGET_NAME "${model_name}Model")

  add_library(${TARGET_NAME} STATIC ${MODEL_SRCS} ${UTILS_SRCS})

  target_include_directories(
    ${TARGET_NAME}
    PUBLIC ${MODEL_SRC_DIR}
    PUBLIC ${MODEL_UTILS_DIR}
    PUBLIC ${OTHERS_DIR})

  set_target_properties(${TARGET_NAME} PROPERTIES PUBLIC_HEADER
                                                  "${HEADERS_PUBLIC}")

  set(MODEL_CONFIG
      ${CMAKE_CURRENT_LIST_DIR}/${model_name}/code/modelConfig/${model_name}.json
  )

  install(
    TARGETS ${TARGET_NAME}
    PUBLIC_HEADER DESTINATION ${model_name}/include
    ARCHIVE DESTINATION ${model_name}/lib)

  install(FILES ${MODEL_CONFIG} DESTINATION modelConfig)

endfunction()
