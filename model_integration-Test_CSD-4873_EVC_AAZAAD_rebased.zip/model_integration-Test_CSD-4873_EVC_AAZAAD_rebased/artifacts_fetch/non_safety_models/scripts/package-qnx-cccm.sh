#!/bin/bash
# run this script from artifacts_fetch/non_safety_models folder
set -e

PROJECT_DIR=$(cd "$(dirname "$0")/../../.."; pwd)
echo "PROJECT_DIR=$PROJECT_DIR"

if [ "$#" -ne 1 ]
then
    version=23.24.0
else
    version=$1
fi

package="non_safety_models_static_libs/${version}@jlrcccm/dev"

# environment setup
git submodule update --init --recursive

if [[ -z $CI ]]
then
   QNX_BASE=${PROJECT_DIR}/sdp
fi

source "${QNX_BASE}/qnxsdp-env.sh"

# create and upload package 
${PROJECT_DIR}/common-infrastructure/scripts/init-build-dir
conan create ${PROJECT_DIR}/artifacts_fetch/non_safety_models ${package} \
    --profile:host=${PROJECT_DIR}/common-infrastructure/conan/profile/qnx-7.1-release \
    --profile:build=default 

conan create ${PROJECT_DIR}/artifacts_fetch/non_safety_models ${package} \
    --profile:host=${PROJECT_DIR}/common-infrastructure/conan/profile/qnx-7.1-debug \
    --profile:build=default 


conan upload ${package} --all -r jlr-cccm -c --force
