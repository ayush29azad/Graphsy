#!/bin/bash
# run this script from artifacts_fetch/non_safety_models folder
set -e

PROJECT_DIR=$(cd "$(dirname "$0")/../../.."; pwd)
echo "PROJECT_DIR=$PROJECT_DIR"

if [ "$#" -ne 1 ]
then
    version=23.24.0
else
    version=$1
fi

package="non_safety_models_static_libs/${version}@jlrcccm/dev"
echo "Creating package: $package"

# create and upload package 
${PROJECT_DIR}/common-infrastructure/scripts/init-build-dir

conan create ${PROJECT_DIR}/artifacts_fetch/non_safety_models $package \
    --profile=${PROJECT_DIR}/common-infrastructure/conan/profile/linux-x86_64-release

conan create ${PROJECT_DIR}/artifacts_fetch/non_safety_models $package \
    --profile=${PROJECT_DIR}/common-infrastructure/conan/profile/linux-x86_64-debug

conan upload $package --all -r jlr-cccm -c --force
