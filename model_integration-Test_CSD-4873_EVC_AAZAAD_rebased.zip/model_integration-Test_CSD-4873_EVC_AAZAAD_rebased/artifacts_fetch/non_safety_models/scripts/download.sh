#!/bin/bash

# $1 is artifactory path
# $2 is destination path
if [[ -n $CI ]]
then
    jfrog rt dl --access-token=${ARTIFACTORY_ACCESS_TOKEN} --url=${ARTIFACTORY_URL} --flat $1 "$2.tar.gz"
else
    jfrog rt dl --flat $1 "$2.tar.gz"
fi

tar -xvf "$2.tar.gz"
model_config_folder="$2/modelConfig"

for file in $model_config_folder/*.json; do
    model_name=$(basename "$file" .json)
    echo "model_name:$model_name"
    
    unzip "$2/${model_name}_Code.zip" -d $model_name
    unzip "${model_name}/sDirFiles.zip" -d ${model_name}/code

done
