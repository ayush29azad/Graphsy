#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from conans import CMake, ConanFile, tools
from conan.tools.cmake import CMake, CMakeToolchain, CMakeDeps
import os
from conan.tools.files import collect_libs, unzip
import json
import subprocess

class NonSafetyModelsStaticLibs(ConanFile):
    name = "non_safety_models_static_libs"

    description = "Non safety models static library generation from models generated code"
    license = "Copyright © Jaguar Land Rover 2023"

    settings = "os", "compiler", "build_type", "arch"
    generators = "cmake_find_package", "CMakeToolchain", "cmake_paths"

    options = {
        "shared": [True, False]
    }
    
    default_options = {
        "shared": False
    }

    exports = "ModelBuild.cmake"

    def build_requirements(self):
        self.tool_requires(f"non_safety_models/{self.version}@function/main")

    def generate(self):
        tc = CMakeToolchain(self)
        tc.variables["BUILD_SHARED_LIBS"] = self.options.shared
        tc.generate()

        deps = CMakeDeps(self)
        deps.generate()


    def build(self):
        if "non_safety_models" in self.deps_cpp_info.deps:
            nsm_package_path = self.deps_cpp_info["non_safety_models"].rootpath
        else:
            non_safety_models_package = f"non_safety_models/{self.version}@function/main"
            tmp = os.path.join(self.build_folder, "pkg_path.txt")
            self.run(f'conan info {non_safety_models_package} --paths --only package_folder > {tmp}')
            with open(tmp) as f:
                for line in f:
                    if line.strip().startswith("package_folder:"):
                        nsm_package_path = line.split(":", 1)[1].strip()

        print("non safety models package path: ", nsm_package_path)
        ModelCodeFolder = os.path.join(nsm_package_path, "Code Generation", "Generated Code")
        models_list = []
        for filename in os.listdir(ModelCodeFolder):
            if filename.endswith("_Code.zip"):
                zip_path = os.path.join(ModelCodeFolder, filename)
                model_name = filename.replace("_Code.zip", "")
                models_list.append(model_name)
                target_folder = os.path.join(self.build_folder, model_name)
                unzip(self, zip_path, target_folder)
                unzip(self, os.path.join(target_folder, "sDirFiles.zip"), os.path.join(target_folder, "code"))

        cmake_content = "cmake_minimum_required(VERSION 3.5)" + "\n"
        cmake_content += f"project({self.name})" + "\n\n"
        cmake_content += "include(${CMAKE_CURRENT_LIST_DIR}/ModelBuild.cmake)" + "\n"
        
        for model_name in models_list:
            print("model_name : " + model_name)
            cmake_content += f"model_static({model_name})" + "\n"

        cmakelist = open("CMakeLists.txt", "w")
        cmakelist.write(cmake_content)
        cmakelist.close()

        cmake = CMake(self)
        cmake.verbose = False
        cmake.configure()
        cmake.build()


    def package(self):
        cmake = CMake(self)
        cmake.install()   


    def package_info(self):
        configs = os.listdir("modelConfig")
        self.cpp_info.set_property("cmake_file_name", "non_safety_models")
        for file in configs:
            model_name, ext = file.split(".")
            if ext == "json":
                target_name = model_name + "Model"
                self.model_config_dir = "model_config"
                self.cpp_info.components[model_name].libs = [target_name]
                self.cpp_info.components[model_name].set_property("cmake_target_name", target_name)
                self.cpp_info.components[model_name].includedirs = [model_name + '/include']
                self.cpp_info.components[model_name].libdirs = [model_name + '/lib']
