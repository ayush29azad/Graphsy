#!/bin/bash
set -e

artifact_version=$1

# Function to download kanzi_app artifacts from jfrog
dl_kanzi_app_release_artifacts() {
	echo "function: dl_kanzi_app_release_artifacts -----------------"
	artifact_name=kanzi_app

	artifact_location="cccm-di-mvn-dev-local/end-artifacts/kanzi_app/releases"

	artifact_dl_path=${artifact_location}/${artifact_name}:${artifact_version}.tar.gz

	echo "Downloading kanzi_app artifacts version - ${artifact_version} release -----------------"
	echo "Path: $artifact_dl_path"

	if [[ "$CI" == true ]]; then
		rt_download --flat $artifact_dl_path $ROOTPATH/out/artifacts.tar.gz --props version=$artifact_version
	else
		jfrog rt dl --flat --props version=$artifact_version $artifact_dl_path artifacts.tar.gz
	fi
	mkdir -p kanzi_app_artifacts
	tar -xzf artifacts.tar.gz --directory kanzi_app_artifacts
	rm -rf artifacts.tar.gz

	rm -rf kanzi_app_artifacts/application/bin/platform/{linux,win}

	# Remove dds_manager (libjlrdds.so) as we get this from model_integration
	echo "--remove libjlrdds.so from kanzi_app_artifacts ----------"
	rm -rf kanzi_app_artifacts/application/bin/platform/qnx/release/lib/libjlrdds.so
}

dl_kanzi_app_release_artifacts

echo "-----copy kanzi_app_artifacts to kanzi_app ---------"
mkdir -p kanzi_app/{bin,lib}

# Copy all the kzb, cfg, xml files from kanzi_app/bin/
cp kanzi_app_artifacts/application/bin/* kanzi_app/bin/ || echo "Warning: get_kanzi_app_release_artifacts: failed to copy kanzi_app_artifacts/app/bin"

# Copy the application_*.cfg files
cp kanzi_app_artifacts/application/bin/platform/qnx/application_*.cfg kanzi_app/bin/ || echo "Warning: get_kanzi_app_release_artifacts: failed to copy kanzi_app_artifacts/app/bin/platform/qnx/application_*.cfg"

# Copy the hmi_app binary
cp kanzi_app_artifacts/application/bin/platform/qnx/release/hmi_app kanzi_app/bin/ || echo "Warning: get_kanzi_app_release_artifacts: failed to copy kanzi_app_artifacts/app/bin/platform/qnx/release/hmi_app"

# Copy all the libraries (lib*.so)
find kanzi_app_artifacts/application/bin/platform/qnx/release -name "lib*.so" -type f -exec cp {} kanzi_app/lib/ \;

rm -rf kanzi_app_artifacts
