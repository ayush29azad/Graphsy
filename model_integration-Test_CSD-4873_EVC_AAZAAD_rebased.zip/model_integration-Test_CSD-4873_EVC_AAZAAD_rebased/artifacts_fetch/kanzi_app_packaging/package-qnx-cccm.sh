#!/bin/bash

set -e

PROJECT_DIR=$(cd "$(dirname "$0")/../.."; pwd)
echo "PROJECT_DIR=$PROJECT_DIR"

kanzi_version="3.18.0"
./get_kanzi_app_release_artifacts.sh $kanzi_version

conan export-pkg -f . kanzi_app/${kanzi_version}@jlrcccm/testing --package-folder kanzi_app \
  --profile:host=${PROJECT_DIR}/common-infrastructure/conan/profile/qnx-7.1-release

conan export-pkg -f . kanzi_app/${kanzi_version}@jlrcccm/testing --package-folder kanzi_app \
  --profile:host=${PROJECT_DIR}/common-infrastructure/conan/profile/qnx-7.1-debug


conan upload kanzi_app/${kanzi_version}@jlrcccm/testing --all -r jlr-cccm -c --force
