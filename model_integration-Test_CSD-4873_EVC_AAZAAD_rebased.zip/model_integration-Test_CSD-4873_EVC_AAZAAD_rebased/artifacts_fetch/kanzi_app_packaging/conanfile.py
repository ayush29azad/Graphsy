#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from conans import CMake, ConanFile
from conan.tools.cmake import CMake, CMakeToolchain, CMakeDeps
import os
from conan.tools.files import collect_libs

class KanziAppConan(ConanFile):
    name = "kanzi_app"
    description = "Kanzi app packaging for QNX release profile"
    settings = "os", "compiler", "arch"


    def package_info(self):
        self.cpp_info.libs = collect_libs(self)
