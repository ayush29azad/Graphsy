## 1. Overview
### Description
<!-- Description of the change. The more information given here the better. Assume the reviewer knows nothing about the ticket -->
Description of the change.

#### JIRA Issues : 

[DIN-9999](https://jira.devops.jlr-apps.com/browse/DIN-16326)


<!-- Mention all the models deployed using simulink_models_artifact_config.json -->
#### Models Deployed: 
[ "gaugeSpeedometer", "batteryStateOfChargeDisp", "messageCentre"]

### Justification
<!-- Reason why change was implemented. Include background for why we need the change, as well why the change has been implemented the way it has -->
Reason why change was implemented.

## 2. Developer Checklist
MR Author: Complete these before seeking approval

### MR Guidelines
<!-- Refer the latest git tag -->
- [ ] Ensure model_grouping_strategy is updated as per the changes in models or release
- [ ] Ensure that merge strategy is set to fast-forward merge and commits to main are not squashed

### Integration - Smoke Testing
- [ ] Tested the QNX build on Target platform with GUI (B Sample Hardware)
- Notes:
  <!-- Comment on testing/runtime issues here -->
  <!-- Comment on working of GUI  -->

### Unit Test Coverage (GTest)
- [ ] Unit tests created for all code in src folder of repo
- [ ] GTest Report: Unit test coverage above 90%


### Code Quality
#### Static Analysis (Klocworks)
- [ ] Reports generated properly

#### Vulnerability Scanning (snyk tool)
- [ ] No software vulnerabilities found

#### Code Commenting (Doxygen tool)
- [ ] Doxygen reports generated successfully

#### Linters Validation (pre-commit)
- [ ] Executed the pre-commit linter validation before pushing the code to remote branch or make sure the linter stage is passing in the feature branch pipeline before raising merge request.


#### Submodule check
<!--  Check submodule_config.js for below; the branch should be main and commit_id should be a tag, for ex. v1.2.3 -->
- [ ] Ensure that common-infrastructure submodule (submodule_config.js) and project include reference (.gitlab-ci.yaml) point to the same version tag

## 3. Approver Checklist

- [ ] Relevant MR Title
- [ ] Relevant MR Description
- [ ] MR pipeline completed (100%) after pipeline check
- [ ] Code review comments are closed and documented.
- [ ] Ensure the whole Developer checklist is satisfied
