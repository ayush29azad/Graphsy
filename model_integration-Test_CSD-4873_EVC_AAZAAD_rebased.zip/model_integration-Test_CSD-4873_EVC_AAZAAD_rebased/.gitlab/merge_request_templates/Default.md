## 1. Overview
### Description
<!-- Description of the change. The more information given here the better. Assume the reviewer knows nothing about the ticket -->
Description of the change.


Models Deployed: 
<!-- Mention all the models that are deployed in this MR and models version being used -->
<!-- Get this information from simulink_models_artifact_config.json -->

### Justification
<!-- Reason why change was implemented. Include background for why we need the change, as well why the change has been implemented the way it has -->
Reason why change was implemented.

## 2. Developer Checklist
MR Author: Complete these before seeking approval

### Integration - Smoke Testing
- [ ] Tested the Linux build on Linux local docker with GUI
- [ ] Tested the QNX build on Target platform with GUI (B Sample Hardware)

- Notes:
<!-- Comment on testing/runtime issues here -->
<!-- Comment on working of GUI  -->

### Unit Test Coverage (GTest)
- [ ] Unit tests created for all code in src folder of repo
- [ ] GTest Report: Unit test coverage above 90%


### Code Quality
#### Static Analysis (Klocworks)
- [ ] Reports generated properly


#### Vulnerability Scanning (snyk tool)
- [ ] No software vulnerabilities found

#### Code Commenting (Doxygen tool)
- [ ] Doxygen reports generated successfully

#### Linters Validation (pre-commit)
- [ ] Executed the pre-commit linter validation before pushing the code to remote branch or make sure the linter stage is passing in the feature branch pipeline before raising merge request.

#### Submodule check
<!--  Check submodule_config.js for below; the branch should be main and commit_id should be a tag, for ex. v1.2.3 -->
- [ ] Ensure that common-infrastructure submodule (submodule_config.js) and project include reference (.gitlab-ci.yaml) point to the same version tag


## 3. Approver Checklist
- [ ] Relevant MR Title
- [ ] Relevant MR Description
- [ ] MR pipeline completed (100%) after pipeline check
- [ ] Code review comments are closed and documented.
- [ ] Ensure the whole Developer checklist is satisfied
