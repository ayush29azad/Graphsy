from string import Template

model_to_json_template = Template('''
    static void create_json($data_type const* const model_data, Json::Value &obj){
$conversion_statements
    }
''')

playback_data_converter_template = Template('''

#ifndef MODEL_DATA_CONVERTER_HEADER_H
#define MODEL_DATA_CONVERTER_HEADER_H
                                  
#include <cstdint>                                
$includes
                                   
namespace jlr{
namespace cccm{
namespace di{
class PlaybackDataConverter$model_name{
  public:
  $conversion_funs

};
}   // namespace di
}   // namespace cccm
}   // namespace jlr
#endif
''')                    
