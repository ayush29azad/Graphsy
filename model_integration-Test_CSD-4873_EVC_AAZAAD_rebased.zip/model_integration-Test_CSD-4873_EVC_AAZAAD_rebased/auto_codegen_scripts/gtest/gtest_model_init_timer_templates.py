from string import Template

offerService = Template('''
  EXPECT_CALL(*${appName}, offer_service(_,_,_)).Times(${offerServices});
''')
requestService = Template('''
  EXPECT_CALL(*${appName}, request_service(_,_)).Times(${requestServies});
''')
registerMessageHanlder = Template('''
  EXPECT_CALL(*${appName}, register_message_handler_fake(_,_,_,_)).Times(${registerMessageHanlder});
''')

registerAvailabilityHanlder = Template('''
  
''')
offerEvent = Template('''
  EXPECT_CALL(*${appName}, offer_event(_,_,_,_,_)).Times(${offerEvent});
''')

modelInitWithTimerFixture = Template('''
#include <iostream>
#include <gtest/gtest.h>
#include <gmock/gmock.h>
#include "${ModelWrapperHeader}"
#include <vsomeip/vsomeip.hpp>
#include "WorkExecutor.h"
#include <DDSEntityFactory.hpp>

#include <thread>
#include <chrono>                                     

using ::testing::_;
using ::testing::Eq;
using ::testing::Matcher;
using ::testing::Pointee;
using ::testing::Return;

using DDSEntityFactoryInterface = jlr::cccm::di::dds::DDSEntityFactoryInterface;
using DDSEntityFactory = jlr::cccm::di::dds::DDSEntityFactory;
using DDSManager = jlr::cccm::di::dds::DDSManager;
using DDSManagerInterface = jlr::cccm::di::dds::DDSManagerInterface;

class ${TestFixtureName} : public ::testing::Test
{
  void SetUp()
  { 
    $vsomeipApp_definitions

    context = std::make_shared<cccm::di::launcher::LauncherContext>();

    std::unordered_map<std::string, std::shared_ptr<vsomeip::application>> someipApp_map;
     $someipApp_map
    context->someipApp_map = someipApp_map;
    context->workExecutor = nullptr;
    context->ddsFactory = std::make_shared<DDSEntityFactory>(jlr::cccm::di::dds::SHARED_MEM);

    ${offerService}
                            
    ${requestService}
                              
    ${registerAvailabilityHanlder}
                              
    ${registerMessageHanlder}
    
    ${offerEvent}
  }

  void TearDown()
  {
  }

  public:

    std::string mWorkExecutorName = "workExecutor";

    $vsomeipApp_declarations
    
    std::shared_ptr<${modelClass}> model_ptr
      = std::make_shared<${modelClass}>();

    std::shared_ptr<cccm::di::ModelLibInterface> modelWrapperPtr
      = std::make_shared<
          cccm::di::models::Wrapper${model_name}<${modelClass}>
          >(model_ptr);

    std::shared_ptr<cccm::di::launcher::LauncherContext> context = nullptr;

};

''')

availibilityFuncs = Template('''
  auto availibilityFuncs_${vid} = $appName->availibilityHandler;
  availibilityFuncs_${vid}(1,1,1);
''')

modelInitNoMapping = Template('''
TEST_F(${TestFixtureName}, model_init_no_mapping)
{
  context->someipMappingFilename = "dummyMapping.json";


  // This will set the default return value for any mock function returning bool to true
  // Since the dds_manager is a hidden dependency, there's no way to control the mock.
  // So, below line prevents all the DDSManager api's to return false as default value
  ::testing::DefaultValue<bool>::Set(true);

  modelWrapperPtr->init(context);

  ::testing::DefaultValue<bool>::Clear();

  // Doesn't call with right service ID and instance ID, but makes sure 
  // that the lambda registered works correctly 
  ${availibilityFuncs}
  
  
  std::this_thread::sleep_for(std::chrono::seconds(1));

  modelWrapperPtr->terminate();
}
''')

modelInitWithMapping = Template('''
TEST_F(${TestFixtureName}, model_init_with_mapping)
{
  // This will set the default return value for any mock function returning bool to true
  // Since the dds_manager is a hidden dependency, there's no way to control the mock.
  // So, below line prevents all the DDSManager api's to return false as default value
  ::testing::DefaultValue<bool>::Set(true);

  modelWrapperPtr->init(context);

  ::testing::DefaultValue<bool>::Clear();

  // Doesn't call with right service ID and instance ID, but makes sure 
  // that the lambda registered works correctly 
  ${availibilityFuncs}
  
  std::this_thread::sleep_for(std::chrono::seconds(1));

  modelWrapperPtr->terminate();
}
''')
