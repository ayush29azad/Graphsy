import os
import sys
# sys.path.insert(1, '../')
current_dir = os.path.dirname(os.path.abspath(__file__))
autocodegen_dir = os.path.join(current_dir, '..') 

# Add autocodegen to the Python path
sys.path.append(autocodegen_dir)

import model_json_parser
import class_definition
import utils
import filepaths
import global_data
import input_testing
import argparse

from gtest_model_init_gen import GtestModelInit
from gtest_model_init_nomapping_gen import GtestModelInitNoMapping
from gtest_model_out_gen import GtestModelOut
from gtest_notifychannel_gen import GtestNotifyChannel
from gtest_message_channel_gen import GtestMessageChannel
from gtest_someipserviceprovider_gen import GtestSomeipServiceProvider
from gtest_model_init_timer_gen import GtestModelInitTimer

class GTest_Code_Generation:

    def __init__(self, filepaths_instance):
        self.filepaths_instance = filepaths_instance

    def gen(self):
            
        model_data = model_json_parser.JsonParser.read_json(self.filepaths_instance.getModelConfigFilepath())
        # Test all our input files (including ModelConfig, IPC_Mapping and Proto Files)
        if input_testing.Test(model_data, self.filepaths_instance).validate_and_combine_input_data():
            #If we have valid input data
            print("[Info]: Input Testing and Combining Done")
            model_object = class_definition.Model(model_data)
            print("[Info]: Initialized an object of class Model with the combined input data")
            self.model_code_gen(model_object)
        else:
            print("[Error]: Gtest Code Generation stopped due to invalid inputs")
                

    def model_code_gen(self, model_object):

        gtestModelInit = GtestModelInit(model_object).substitute()
        utils.Utils.write_to_file(self.filepaths_instance.getModelGtestInitMappingFilepath(), gtestModelInit)

        gtestModelInitNoMapping = GtestModelInitNoMapping(model_object).substitute()
        utils.Utils.write_to_file(self.filepaths_instance.getModelGtestInitNoMappingFilepath(), gtestModelInitNoMapping)

        gtestModelOut = GtestModelOut(model_object).substitute()
        utils.Utils.write_to_file(self.filepaths_instance.getModelGtestOutFilepath(), gtestModelOut)

        gtestNotifyChannel = GtestNotifyChannel(model_object).substitute()
        utils.Utils.write_to_file(self.filepaths_instance.getModelGtestNotifyFilepath(), gtestNotifyChannel)

        gtestMessageChannel = GtestMessageChannel(model_object).substitute()
        utils.Utils.write_to_file(self.filepaths_instance.getModelGtestMessageFilepath(), gtestMessageChannel)
        
        gtestModelInitTimer = GtestModelInitTimer(model_object).substitute()
        utils.Utils.write_to_file(self.filepaths_instance.getModelGtestInitTimerFilepath(), gtestModelInitTimer)


    def cmake_code_gen(model_object):

        gtestCmakeList = CMakeListGen(model_object).substitute()
        utils.Utils.write_to_file(self.filepaths_instance.getModelGtestCmakeListFilepath(), gtestCmakeList)

        

    
if __name__ == "__main__":
    print("---------------------Gtest Main---------------------")

    parser = argparse.ArgumentParser()

    parser.add_argument("--modelname", help="name of the model you want to generate code for", required=True)
    parser.add_argument("--modelconfig", help="path to the model config json file", required=True)
    parser.add_argument("--codegendir", help="path to directory you want to generate the code", required=True)
    parser.add_argument("--servicemapping", help="path to someip service mapping json file", required=True)
    parser.add_argument("--servicedefdir", help="path to someip service definition json files dir", required=True)
    parser.add_argument("--ipcmappingdir", help="path to ipcmapping files dir", required=True)

    args = parser.parse_args()

    GTest_Code_Generation(filepaths.Filepaths(args)).gen()
