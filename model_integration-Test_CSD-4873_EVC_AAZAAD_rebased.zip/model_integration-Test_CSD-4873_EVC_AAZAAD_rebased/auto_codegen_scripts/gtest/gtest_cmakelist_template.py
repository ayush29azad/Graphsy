from string import Template


cmakeList = Template('''
cmake_minimum_required(VERSION 3.5)

add_definitions(-DENABLE_GTEST=ON)
set(CMAKE_CXX_OUTPUT_EXTENSION_REPLACE ON)

file(GLOB SRC_DIR "$ENV{ROOTPATH}/model_ipc/ipc_wrapper_utils/*.hpp" "$ENV{ROOTPATH}/model_ipc/ipc_wrapper_utils/*.cpp")
file(GLOB VSOMEIP_MOCK "$ENV{ROOTPATH}/utils/Mock/vsomeip/*.h" "$ENV{ROOTPATH}/utils/Mock/vsomeip/*.cpp")
file(GLOB DDSMANAGER_MOCK "$ENV{ROOTPATH}/utils/Mock/ddsabs/*.h" "$ENV{ROOTPATH}/utils/Mock/ddsabs/*.cpp")
file(GLOB GTEST_SRC_DIR "$ENV{ROOTPATH}/model_ipc/models/$modelDirName/gtest/*.h" "$ENV{ROOTPATH}/model_ipc/models/$modelDirName/gtest/*.cpp")

file(
  GLOB
  TEST_WITH_MAPPING_SRC
  "$ENV{ROOTPATH}/model_ipc/models/$modelDirName/gtest/*Channel.cpp"
  "$ENV{ROOTPATH}/model_ipc/models/$modelDirName/gtest/*Init.cpp"
  "$ENV{ROOTPATH}/model_ipc/models/$modelDirName/gtest/*InitNoMapping.cpp"
  "$ENV{ROOTPATH}/model_ipc/models/$modelDirName/gtest/*Out.cpp"
  "$ENV{ROOTPATH}/model_ipc/models/$modelDirName/gtest/*Provider.cpp"
  "$ENV{ROOTPATH}/model_ipc/models/$modelDirName/gtest/*Consumer.cpp"
)

file(
  GLOB
  TEST_WITH_TIMER
  "$ENV{ROOTPATH}/model_ipc/models/$modelDirName/gtest/*InitTimer.cpp"
)

set(sources_with_mapping
  ${SRC_DIR}
  ${VSOMEIP_MOCK}
  ${DDSMANAGER_MOCK}
  ${TEST_WITH_MAPPING_SRC}
  "$ENV{ROOTPATH}/utils/ProtoRandomGen/ProtoRandomGen.cpp"
  $modelSources
)

set(sources_with_timer
  ${SRC_DIR}
  ${VSOMEIP_MOCK}
  ${DDSMANAGER_MOCK}
  ${TEST_WITH_TIMER}
  "$ENV{ROOTPATH}/utils/ProtoRandomGen/ProtoRandomGen.cpp"
  $modelSources
)
                     
add_executable($modelNameTestsWithMapping ${sources_with_mapping})
add_executable($modelNameTestsWithTimer ${sources_with_timer})

target_include_directories($modelNameTestsWithMapping PUBLIC
  $ENV{ROOTPATH}/utils/Mock/
  $ENV{ROOTPATH}/utils/Mock/jlrdds
  $ENV{ROOTPATH}/utils/Mock/workexecutorthread
  $ENV{ROOTPATH}/utils/Mock/ipc_wrapper_utils_timer_handler
  $ENV{ROOTPATH}/model_ipc/models/$modelDirName/gtest
  $ENV{ROOTPATH}/model_ipc/ipc_wrapper_utils
  $include_dirs
  $ENV{ROOTPATH}/interface
  $ENV{ROOTPATH}/include/workerthread
  $ENV{ROOTPATH}/model_ipc/include/jlrdds
  $ENV{ROOTPATH}/model_ipc/include/proto_files/
  $ENV{ROOTPATH}/model_ipc/include/dds_topics_idls
  /usr/include/jsoncpp
  "$ENV{ROOTPATH}/utils/ProtoRandomGen"
)

target_include_directories($modelNameTestsWithTimer PUBLIC
  $ENV{ROOTPATH}/utils/Mock/
  $ENV{ROOTPATH}/utils/Mock/jlrdds
  $ENV{ROOTPATH}/utils/Mock/workexecutorthread
  $ENV{ROOTPATH}/model_ipc/models/$modelDirName/gtest
  $ENV{ROOTPATH}/model_ipc/ipc_wrapper_utils
  $include_dirs
  $ENV{ROOTPATH}/interface
  $ENV{ROOTPATH}/include/workerthread
  $ENV{ROOTPATH}/model_ipc/include/jlrdds
  $ENV{ROOTPATH}/model_ipc/include/proto_files/
  $ENV{ROOTPATH}/model_ipc/include/dds_topics_idls
  /usr/include/jsoncpp
  "$ENV{ROOTPATH}/utils/ProtoRandomGen"
)

target_link_directories($modelNameTestsWithMapping PUBLIC
  $ENV{ROOTPATH}/lib/jlrdds
	$ENV{ROOTPATH}/out/lib/dds_topics
	$ENV{ROOTPATH}/out/lib/proto_libs
	$ENV{ROOTPATH}/build
	$ENV{ROOTPATH}/out/lib/model_vsomeip_clients
)

target_link_directories($modelNameTestsWithTimer PUBLIC
  $ENV{ROOTPATH}/lib/jlrdds
	$ENV{ROOTPATH}/out/lib/dds_topics
	$ENV{ROOTPATH}/out/lib/proto_libs
	$ENV{ROOTPATH}/build
	$ENV{ROOTPATH}/out/lib/model_vsomeip_clients
)

target_compile_definitions($modelNameTestsWithMapping PRIVATE INSTANCE_ID_MAPPING=ON)
target_compile_definitions($modelNameTestsWithTimer PRIVATE INSTANCE_ID_MAPPING=ON)

target_link_libraries(
  $modelNameTestsWithMapping PRIVATE
  someip_interface
  $link_libs
  jsoncpp
  protobuf
  jlrdds
  pthread
  gtest
  gtest_main
  gmock
  fastrtps
  fastcdr
  vsomeip3
)

target_link_libraries(
  $modelNameTestsWithTimer PRIVATE
  someip_interface
  $link_libs
  jsoncpp
  protobuf
  jlrdds
  pthread
  gtest
  gtest_main
  gmock
  fastrtps
  fastcdr
  vsomeip3
)

add_test(NAME $modelNameTestsWithMapping COMMAND ${CMAKE_CURRENT_BINARY_DIR}/$modelNameTestsWithMapping --gtest_output=json:jsonreports/$model_name.json)
add_test(NAME $modelNameTestsWithTimer COMMAND ${CMAKE_CURRENT_BINARY_DIR}/$modelNameTestsWithTimer)
''')
