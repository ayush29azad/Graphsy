from string import Template

NotifyChannel = Template('''
#include <iostream>
#include <gtest/gtest.h>
#include <gmock/gmock.h>
#include "${ModelWrapperHeaderFileName}"
#include <NotifyChannel.hpp>
#include <SomeipChannel.hpp>
#include <vsomeip/vsomeip.hpp>
#include <vector>
#include <DDSEntityFactory.hpp>
#include "ProtoRandomGen.hpp"
#include <arpa/inet.h>
#include <cstring>

using DDSEntityFactoryInterface = jlr::cccm::di::dds::DDSEntityFactoryInterface;
using DDSEntityFactory = jlr::cccm::di::dds::DDSEntityFactory;
using DDSManager = jlr::cccm::di::dds::DDSManager;
using DDSManagerInterface = jlr::cccm::di::dds::DDSManagerInterface;

using ::testing::Return;
using ::testing::_;
using ::testing::Matcher;
using ::testing::Eq;
using ::testing::Matcher;
using ::testing::Pointee;
using ::testing::StrictMock;
using ::testing::Mock;
using ::testing::AtLeast;

class $NotifyChannel : public ::testing::Test
{
  void SetUp()
  { 
    context = std::make_shared<cccm::di::launcher::LauncherContext>();
    $vsomeipApp_definitions
    std::unordered_map<std::string, std::shared_ptr<vsomeip::application>> someipApp_map;
    $someipApp_map
    context->someipApp_map = someipApp_map;
    context->workExecutor = nullptr;
    context->ddsFactory = std::make_shared<DDSEntityFactory>(jlr::cccm::di::dds::SHARED_MEM);

    modelWrapperPtr->init(context);
  }
  void TearDown()
  {
    modelWrapperPtr->terminate();
    
  }

public:
  static std::vector<uint8_t> add_length_header(const std::string& data){
    std::vector<uint8_t> output{};
    output.reserve(sizeof(uint16_t) +  data.size());  
    uint16_t const length_header = htons(static_cast<uint16_t>(data.size()));
    output.resize(sizeof(length_header));
    std::memcpy(output.data(), &length_header, sizeof(length_header));
    output.insert(output.end(), data.begin(), data.end());
    return output;
  }
  int n;
  std::string mWorkExecutorName = "workExecutor";
  $vsomeipApp_declarations
private:
  std::shared_ptr<${modelClass}> model_ptr
    = std::make_shared<${modelClass}>();

  std::shared_ptr<cccm::di::ModelLibInterface> modelWrapperPtr
    = std::make_shared<
        cccm::di::models::Wrapper${model_name}<${modelClass}>
        >(model_ptr);

  std::shared_ptr<cccm::di::launcher::LauncherContext> context{};

};
''')

onEventNullData = Template('''
TEST_F($NotifyChannel, OnEvent_NullData_$NotifyEvent)
{
  std::shared_ptr<vsomeip::message> msg =  std::make_shared<vsomeip::message>();
  std::shared_ptr<vsomeip::payload> payload = std::make_shared<vsomeip::payload>();
  EXPECT_CALL(*msg, get_payload()).Times(1).WillOnce(Return(payload));
  consumer::NotifyChannel<$package_name::$NotifyEvent>::get_instance().onEvent(msg);
}

''')

onEventNonNullData = Template('''
TEST_F($NotifyChannel, OnEvent_Non_NullData_$NotifyEvent)
{
  std::shared_ptr<vsomeip::message> msg =  std::make_shared<vsomeip::message>();
  std::shared_ptr<vsomeip::payload> payload = std::make_shared<vsomeip::payload>();

  std::vector<uint8_t> data{};
  {
    std::string serialised_data{};
    ${package_name}::${NotifyEvent} proto{};
    populateMessage(&proto);
    proto.SerializeToString(&serialised_data);
    data = add_length_header(serialised_data);
  }

  EXPECT_CALL(*payload, get_data()).WillRepeatedly(Return(data.data()));
  EXPECT_CALL(*payload, get_length()).WillRepeatedly(Return(data.size()));
  EXPECT_CALL(*msg, get_payload()).Times(1).WillOnce(Return(payload));
  consumer::NotifyChannel<$package_name::$NotifyEvent>::get_instance().onEvent(msg);
}

''')
