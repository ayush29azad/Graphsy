import gtest_notifychannel_template as gnt
import class_definition

class GtestNotifyChannel:
  gtest = ""
  def __init__(self, model_object):
    self.gtest += self.constructNotifyChannenl(model_object) + self.constructonEventNullData(model_object) + self.constructonEventNonNullData(model_object)

  def constructSomeipApp(self, model_object):
    vsomeipApp_declarations = ""
    vsomeipApp_definitions = ""
    someipApp_mapItems = ""
    all_vids = model_object.getAllvIdsForModel();
    for vid in all_vids:
      vsomeipApp_declarations += f'\t\tstd::shared_ptr<vsomeip::application> mApp_vid{str(vid)} = nullptr;\n'
      vsomeipApp_definitions += f'\t\tmApp_vid{str(vid)} = std::make_shared<vsomeip::application>();\n'
      someipApp_mapItems += f'someipApp_map[\"vid{str(vid)}\"] = mApp_vid{str(vid)};\n'
    return vsomeipApp_declarations, vsomeipApp_definitions, someipApp_mapItems

  def constructNotifyChannenl(self, model_object):
    values_dict = {}
    modelName = model_object.getModelName()
    values_dict["NotifyChannel"] = f"GtestNotifyChannel{modelName}"
    values_dict["dataConverter"] = f"DataConverter{modelName}.hpp"
    values_dict["model_name"] = modelName
    values_dict["modelClass"] =  model_object.getModelClassName()
    values_dict["ModelWrapperHeaderFileName"] = f"Wrapper{modelName}.h"
    values_dict["vsomeipApp_declarations"], values_dict["vsomeipApp_definitions"], values_dict["someipApp_map"] = self.constructSomeipApp(model_object)
    return gnt.NotifyChannel.substitute(values_dict)
  
  def constructonEventNullData(self, model_object):
    values_dict = {}
    modelName = model_object.getModelName()
    values_dict["NotifyChannel"] = f"GtestNotifyChannel{modelName}"
    res = model_object.getAllSomeipNotifyIns()
    if(len(res) == 0):
      return ""

    gen_text = ""
    for event in res:
      eventName = event.getMessage()
      values_dict["NotifyEvent"] = eventName
      values_dict["package_name"] = event.getPackageName()
      gen_text += gnt.onEventNullData.substitute(values_dict)

    return gen_text
  
  def constructonEventNonNullData(self, model_object):
    values_dict = {}
    modelName = model_object.getModelName()
    values_dict["NotifyChannel"] = f"GtestNotifyChannel{modelName}"
    res = model_object.getAllSomeipNotifyIns()
    if(len(res) == 0):
      return ""

    gen_text = ""
    for event in res:
      eventName = event.getMessage()
      values_dict["NotifyEvent"] = eventName
      values_dict["package_name"] = event.getPackageName()
      gen_text += gnt.onEventNonNullData.substitute(values_dict)

    return gen_text
  
  def substitute(self):
    return self.gtest
  
