import gtest_model_init_nomapping_templates as gmint
import class_definition
class GtestModelInitNoMapping:
  gtest = ""
  
  def __init__(self, model_object):
    self.gtest += self.constructModelInitClass(model_object) + self.constructModelInitSuccess(model_object) + self.constructModelOnDataAvailable(model_object)

  def constructModelInitClass(self, model_object):
    values_dict = {}
    modelName = model_object.getModelName()
    fixtureClass = f'Gtest{modelName}InitNoMapping'
    values_dict["model_name"] = modelName
    values_dict["model_name_init"] = f'{fixtureClass}'
    values_dict["ModelWrapperHeader"] = f"Wrapper{modelName}.h"
    values_dict["modelClass"] =  model_object.getModelClassName()
    values_dict["dataConverter"] = "DataConverter" + model_object.getModelName()
    values_dict["vsomeipApp_declarations"], values_dict["vsomeipApp_definitions"], values_dict["someipApp_map"] = self.createApps(model_object)
    return gmint.modelInitNoMappingClass.substitute(values_dict)
  
  def createApps(self, model_object):
    vsomeipApp_declarations = ""
    vsomeipApp_definitions = ""
    someipApp_mapItems = ""
    all_vids = model_object.getAllvIdsForModel();
    for vid in all_vids:
      vsomeipApp_declarations += f'\t\tstd::shared_ptr<vsomeip::application> mApp_vid{str(vid)} = nullptr;\n'
      vsomeipApp_definitions += f'\t\tmApp_vid{str(vid)} = std::make_shared<vsomeip::application>();\n'
      someipApp_mapItems += f'someipApp_map[\"vid{str(vid)}\"] = mApp_vid{str(vid)};\n'
    return vsomeipApp_declarations, vsomeipApp_definitions, someipApp_mapItems
    # someipApp_map.insert({"vid10", mApp});
  def constructAvailibilityHandlerFuncs(self, model_object):
    res = ""
    all_vids = model_object.getAllvIdsForModel();
    for vid in all_vids:
      values_dict = {}
      values_dict["appName"] = f'mApp_vid{str(vid)}'
      values_dict["vid"] = str(vid)
      res += gmint.availibilityFuncs.substitute(values_dict)
    return res
  def constructModelOnDataAvailable(self, model_object):
    res = ""
    modelName = model_object.getModelName()
    fixtureClass = f'Gtest{modelName}InitNoMapping'
    
    values_dict = {}
    values_dict["model_name_init"] = f'{fixtureClass}'
    values_dict["modelClass"] =  model_object.getModelClassName()
    values_dict["dataConverter"] = "DataConverter" + model_object.getModelName()
    
    test_ddsRxTopics = []
    dds_ins = model_object.getAllDdsIn()
    
    for model_method in dds_ins:
      test_ddsRxTopic = model_method.getTopicName()
      values_dict["ddsRxTestName"] = f"on_{test_ddsRxTopic}_available"
      values_dict["topic_name"] = "dds_ipc::"+ test_ddsRxTopic
      values_dict["topic_pubsub_type"] = "dds_ipc::"+ test_ddsRxTopic + "PubSubType()"
      res += gmint.modelNoMappingOnDataAvailable.substitute(values_dict)
    
    return res

  
  def constructModelInitSuccess(self, model_object):
    values_dict = {}
    values_dict["modelClass"] =  model_object.getModelClassName()
    values_dict["dataConverter"] = "DataConverter" + model_object.getModelName()
    values_dict["model_init"] = "model_init_" + model_object.getModelName()
    modelName = model_object.getModelName()
    fixtureClass = f'Gtest{modelName}InitNoMapping'
    values_dict["model_name_init"] = f'{fixtureClass}'
    values_dict["offerService"] = ""
    model_as_server = model_object.getAllServicesForModelAsServer()
    for vid, services in model_as_server.items():
      _values_dict = {}
      _values_dict["appName"] = "mApp_vid" + str(vid) 
      _values_dict["offerServices"] = len(services)
      values_dict["offerService"] += gmint.offerService.substitute(_values_dict)

    values_dict["registerAvailabilityHanlder"] = ""
    values_dict["requestService"] = ""
    model_as_client = model_object.getAllServicesForModelAsClient()
    for vid, services in model_as_client.items():
      _values_dict = {}
      _values_dict["appName"] = "mApp_vid" + str(vid) 
      _values_dict["requestServies"] = len(services)
      _values_dict["registerAvailabilityHanlder"] = len(services)

      values_dict["registerAvailabilityHanlder"] += gmint.registerAvailabilityHanlder.substitute(_values_dict)
      values_dict["requestService"] += gmint.requestService.substitute(_values_dict)

    values_dict["registerMessageHanlder"] = ""
    allSomeip_ins = model_object.AllModelSomeipIns()
    for vid, model_methods in allSomeip_ins.items():
      _values_dict = {}
      _values_dict["appName"] = "mApp_vid" + str(vid) 
      _values_dict["registerMessageHanlder"] = len(model_methods)
      values_dict["registerMessageHanlder"] += gmint.registerMessageHanlder.substitute(_values_dict)
    
    values_dict["offerEvent"]  = ""
    notify_outs = model_object.getAllSomeipNotifyOuts()
    for vid, notify_out in notify_outs.items():
      offerEvent = 0
      for item in notify_out:
        offerEvent += len(item.getAllEventGroupIDs())  
      _values_dict = {}
      _values_dict["appName"] = "mApp_vid" + str(vid) 
      _values_dict["offerEvent"] = offerEvent
      values_dict["offerEvent"] += gmint.offerEvent.substitute(_values_dict)
      
    values_dict["availibilityFuncs"] = ""
    if len(model_as_client) > 0:
      values_dict["availibilityFuncs"] = self.constructAvailibilityHandlerFuncs(model_object)
    return gmint.modelInitNoMappingSuccess.substitute(values_dict)
  
  def substitute(self):
    return self.gtest
