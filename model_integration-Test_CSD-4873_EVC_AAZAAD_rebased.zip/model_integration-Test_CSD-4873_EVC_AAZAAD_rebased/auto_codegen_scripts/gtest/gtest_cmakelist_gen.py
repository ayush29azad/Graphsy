import os
import sys
sys.path.append(os.path.abspath('auto_codegen_scripts'))
import model_json_parser
import utils
import filepaths
import gtest_cmakelist_template as gct
import config_getter
#import environment_utils
import global_data



class CMakeListGen:
  mTemplate = gct.cmakeList
  mValuesDict = {}
  def __init__(self, model_object):
    modelName = model_object.getModelName()
    self.mValuesDict["modelDirName"] = modelName + "_ert_rtw"
    self.mValuesDict["link_libs"] = self.constructLinkLibs(model_object)
    self.mValuesDict["include_dirs"] = self.constructIncludeDirs(model_object)
    self.mValuesDict["modelSources"] = self.constructSources(model_object)
    self.mValuesDict["captureDir"] = self.constructCaptureDir(modelName)
    self.mValuesDict["removeFiles"] = self.constructRemoveFile(modelName)
    self.mValuesDict["modelNameTestsWithMapping"] = modelName + "TestsWithMapping"
    self.mValuesDict["modelNameTestsWithTimer"] = modelName + "TestsWithTimer"
    self.mValuesDict["model_name"] = modelName
    
  def constructLinkLibs(self, model_object):
    linkLibs = ""

    idl_files = model_object.getAllModelTopics()
    for idlFile in idl_files:
      linkLibs += idlFile + "\n"
    return linkLibs
  
  def constructSources(self, model_object):
    sources = ""
    modelName = model_object.getModelName()
    files = os.listdir(filepaths.getModelSharedUtilsDirPath(model_object))
    for file in files:
        if file.endswith(".cpp") and not file.endswith("init.cpp") and not file.endswith("out.cpp"):
            sources +=  filepaths.getModelSharedUtilsDirPath(model_object) + file + '\n'

    modelCppPath = filepaths.getModelCodeDirPath(model_object)
    files = os.listdir(modelCppPath)
    for file in files:
      if file.endswith(".cpp"):
        sources += modelCppPath + file + "\n"
    return sources

  def constructIncludeDirs(self, model_object):
    includeDirs = ""
    
    includeDirs += filepaths.getModelSharedUtilsDirPath(model_object) + "\n"
    includeDirs += filepaths.getModelCodeDirPath(model_object) + "\n"
    return includeDirs
  
  def constructCaptureDir(self, modelName):
    captureDirs = ""
    captureDirs += f"COMMAND lcov --e lcoverage/main_coverage.info -o lcoverage/main_coverage.info "
    captureDirs += "\"$ENV{ROOTPATH}/model_ipc/models/"
    captureDirs += f"{modelName}_ert_rtw/*\" \"$ENV"
    captureDirs += "{ROOTPATH}/model_ipc/ipc_wrapper_utils/*\" \"$ENV"
    captureDirs += "{ROOTPATH}/model_ipc/ipc_wrapper_utils/*\""
    captureDirs += ' -rc lcov_branch_coverage=1\n'
    captureDirs += '\n'
    return captureDirs
  
  def constructRemoveFile(self, modelName):
    removeFiles = ""

    removeFiles += "COMMAND lcov --remove lcoverage/main_coverage.info -o lcoverage/main_coverage.info "
    removeFiles += "\"$ENV{ROOTPATH}/model_ipc/models/"
    removeFiles += f"{modelName}_ert_rtw/{modelName}.cpp\"" 
    removeFiles += ' -rc lcov_branch_coverage=1\n'
    removeFiles += "COMMAND lcov --remove lcoverage/main_coverage.info -o lcoverage/main_coverage.info "
    removeFiles += "\"$ENV{ROOTPATH}/model_ipc/models/"
    removeFiles += f"{modelName}_ert_rtw/DataConverter{modelName}.hpp\"" 
    removeFiles += ' -rc lcov_branch_coverage=1\n'
    return removeFiles
  
  def substitute(self):
    return self.mTemplate.safe_substitute(self.mValuesDict)
  
