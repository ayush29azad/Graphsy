import gtest_message_channel_template as gmct
import class_definition

class GtestMessageChannel:
  gtest  = ""
  requestType = ""
  responseType = ""
  def __init__(self, model_object):
    self.gtest += self.constructMessageChannelClass(model_object)

    responselistIn = model_object.getAllSomeipResponseIns()
    requestlistIn = model_object.getAllSomeipRequestIns()

    for el in requestlistIn : 
      self.requestType = el.getMessage()
      package_name = el.getPackageName()
      self.responseType = str(self.requestType[:-7]) + "Response"
      print("requestType=", self.requestType)
      self.gtest += self.constructOnRequestNullPayload(model_object, self.requestType, self.responseType, package_name) + self.constructOnRequestNullData(model_object, self.requestType, self.responseType, package_name) + self.constructOnRequestNonNullData(model_object, self.requestType, self.responseType, package_name)

    for el in responselistIn :
      self.responseType = el.getMessage()
      package_name = el.getPackageName()
      self.requestType = str(self.responseType[:-8]) + "Request"
      print("responseType=", self.responseType)
      self.gtest += self.constructOnResponseNullPayload(model_object, self.requestType, self.responseType, package_name) + self.constructOnResponseNullData(model_object, self.requestType, self.responseType, package_name) + self.constructOnResponseNonNullData(model_object, self.requestType, self.responseType, package_name)

  def constructSomeipApp(self, model_object):
    vsomeipApp_declarations = ""
    vsomeipApp_definitions = ""
    someipApp_mapItems = ""
    all_vids = model_object.getAllvIdsForModel();
    for vid in all_vids:
      vsomeipApp_declarations += f'\t\tstd::shared_ptr<vsomeip::application> mApp_vid{str(vid)} = nullptr;\n'
      vsomeipApp_definitions += f'\t\tmApp_vid{str(vid)} = std::make_shared<vsomeip::application>();\n'
      someipApp_mapItems += f'someipApp_map[\"vid{str(vid)}\"] = mApp_vid{str(vid)};\n'
    return vsomeipApp_declarations, vsomeipApp_definitions, someipApp_mapItems

  def constructMessageChannelClass(self, model_object):
    values_dict = {}
    modelName = model_object.getModelName()
    values_dict["messageChannelClass"] = f"Gtest{modelName}MessageChannel"
    values_dict["DataConverter"] =  f"DataConverter{modelName}.hpp"
    values_dict["model_name"] = modelName
    values_dict["modelClass"] =  model_object.getModelClassName()
    values_dict["ModelWrapperHeaderFileName"] = f"Wrapper{modelName}.h"
    values_dict["vsomeipApp_declarations"], values_dict["vsomeipApp_definitions"], values_dict["someipApp_map"] = self.constructSomeipApp(model_object)
    return gmct.messageChannelClass.substitute(values_dict)
  
  def constructOnRequestNullPayload(self, model_object, requestType, responseType, package_name):
    values_dict = {}
    modelName = model_object.getModelName()
    values_dict["package_name"] = package_name
    values_dict["messageChannelClass"] = f"Gtest{modelName}MessageChannel"
    values_dict["requestType"] = requestType
    values_dict["responseType"] = responseType
    signal_name = self.requestType[:-7]
    values_dict["signalName"] = f"{signal_name}"
    # values_dict["dummyRequestCallBack"] = f"dummy{signal_name}RequestCallBack"
    # values_dict["dummyResponseCallBack"] = f"dummy{signal_name}ResponseCallBack"
    # values_dict["dummyRequestCallBackInt"] = f"dummy{signal_name}RequestCallBackInt"
    # values_dict["dummyResponseCallBackInt"] = f"dummy{signal_name}ResponseCallBackInt"
    return gmct.onRequestNullPayload.substitute(values_dict)
  
  def constructOnRequestNullData(self, model_object, requestType, responseType, package_name):
    values_dict = {}
    modelName = model_object.getModelName()
    values_dict["package_name"] = package_name
    values_dict["messageChannelClass"] = f"Gtest{modelName}MessageChannel"
    values_dict["requestType"] = requestType
    values_dict["responseType"] = responseType
    signal_name = self.requestType[:-7]
    values_dict["signalName"] = f"{signal_name}"
    # values_dict["dummyRequestCallBackInt"] = f"dummy{signal_name}RequestCallBackInt"
    # values_dict["dummyResponseCallBackInt"] = f"dummy{signal_name}ResponseCallBackInt"
    return gmct.onRequestNullData.substitute(values_dict)
  
  def constructOnRequestNonNullData(self, model_object, requestType, responseType, package_name):
    values_dict = {}
    modelName = model_object.getModelName()
    values_dict["package_name"] = package_name
    values_dict["messageChannelClass"] = f"Gtest{modelName}MessageChannel"
    values_dict["requestType"] = requestType
    values_dict["responseType"] = responseType
    signal_name = self.requestType[:-7]
    values_dict["signalName"] = f"{signal_name}"
    # values_dict["dummyRequestCallBack"] = f"dummy{signal_name}RequestCallBack"
    # values_dict["dummyRequestCallBackInt"] = f"dummy{signal_name}RequestCallBackInt"
    # values_dict["dummyResponseCallBackInt"] = f"dummy{signal_name}ResponseCallBackInt"
    return gmct.onRequestNonNullData.substitute(values_dict)
  
  def constructOnResponseNullPayload(self, model_object, requestType, responseType, package_name):
    values_dict = {}
    modelName = model_object.getModelName()
    values_dict["package_name"] = package_name
    values_dict["messageChannelClass"] = f"Gtest{modelName}MessageChannel"
    values_dict["requestType"] = requestType
    values_dict["responseType"] = responseType
    signal_name = self.requestType[:-7]
    values_dict["signalName"] = f"{signal_name}"
    # values_dict["dummyRequestCallBack"] = f"dummy{signal_name}RequestCallBack"
    # values_dict["dummyRequestCallBackInt"] = f"dummy{signal_name}RequestCallBackInt"
    # values_dict["dummyResponseCallBackInt"] = f"dummy{signal_name}ResponseCallBackInt"
    return gmct.onResponseNullPayload.substitute(values_dict)
  
  def constructOnResponseNullData(self, model_object, requestType, responseType, package_name):
    values_dict = {}
    modelName = model_object.getModelName()
    values_dict["package_name"] = package_name
    values_dict["messageChannelClass"] = f"Gtest{modelName}MessageChannel"
    values_dict["requestType"] = requestType
    values_dict["responseType"] = responseType
    signal_name = self.requestType[:-7]
    values_dict["signalName"] = f"{signal_name}"
    # values_dict["dummyRequestCallBack"] = f"dummy{signal_name}RequestCallBack"
    # values_dict["dummyRequestCallBackInt"] = f"dummy{signal_name}RequestCallBackInt"
    # values_dict["dummyResponseCallBackInt"] = f"dummy{signal_name}ResponseCallBackInt"
    return gmct.onResponseNullData.substitute(values_dict)
  
  def constructOnResponseNonNullData(self, model_object, requestType, responseType, package_name):
    values_dict = {}
    modelName = model_object.getModelName()
    values_dict["package_name"] = package_name
    values_dict["messageChannelClass"] = f"Gtest{modelName}MessageChannel"
    values_dict["requestType"] = requestType
    values_dict["responseType"] = responseType
    signal_name = self.requestType[:-7]
    values_dict["signalName"] = f"{signal_name}"
    # values_dict["dummyRequestCallBack"] = f"dummy{signal_name}RequestCallBack"
    # values_dict["dummyResponseCallBack"] = f"dummy{signal_name}ResponseCallBack"
    # values_dict["dummyRequestCallBackInt"] = f"dummy{signal_name}RequestCallBackInt"
    # values_dict["dummyResponseCallBackInt"] = f"dummy{signal_name}ResponseCallBackInt"
    return gmct.onResponseNonNullData.substitute(values_dict)
  
  def substitute(self):
    return self.gtest
