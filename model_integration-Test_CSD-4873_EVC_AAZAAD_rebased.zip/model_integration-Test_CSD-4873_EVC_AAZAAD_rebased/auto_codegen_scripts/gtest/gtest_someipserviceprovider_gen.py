import gtest_someipserviceprovider_template as gst
import config_getter

from class_definition import Model, VSOMEIP_Event, VSOMEIP_Method



class GtestSomeipServiceProvider:

    def __init__(self, model: Model):

        self.model: Model = model
        self.protoPackageNames: set[str] = set()
        self.protoHeaderFilenames: set[str] = set()

        notify_event_test = self.constructNotifyEvent()
        request_event_test = self.constructRequestResponse()
        
        # the following function needs to be called after the 
        # above functions... Ideally, this should be designed better
        valuesDict: dict[str,str] = {}
        valuesDict["include_directives"] = self.constructIncludeDirectives() 
        valuesDict["using_statements"] = self.constructUsingStatements()


        self.gtest = (
                gst.someipServiceProvider.substitute(valuesDict)
                + notify_event_test
                + request_event_test
                )

    def constructNotifyEvent(self) -> str:
        # This method updates internal state of class
        valuesDict: dict[str,str] = {}

        eventOuts: list[VSOMEIP_Event] = self.model.getAllSomeipNotifyOuts()
        eventIns: list[VSOMEIP_Event] = self.model.getAllSomeipNotifyIns()

        if(len(eventOuts)!=0):
            event: VSOMEIP_Event = eventOuts[0]
            valuesDict["notifyEvent"] =  event.getMessage()
            self.protoPackageNames.add(event.getPackageName())
            self.protoHeaderFilenames.add(event.getProtoHeaderFilename())

        elif(len(eventIns)!=0):
            event: VSOMEIP_Event = eventIns[0]
            valuesDict["notifyEvent"] =  event.getMessage()
            self.protoPackageNames.add(event.getPackageName())
            self.protoHeaderFilenames.add(event.getProtoHeaderFilename())
        else:
            return ""

        return (
              gst.addNotifyChannel.substitute(valuesDict)
              + gst.sendNotifyEvent.substitute(valuesDict)
              )

    def constructRequestResponse(self) -> str:
        # This method updates internal state of class
        valuesDict: dict[str,str] = {}
        requestOuts: list[VSOMEIP_Method] = self.model.getAllSomeipRequestOuts()
        requestIns: list[VSOMEIP_Method] = self.model.getAllSomeipRequestIns()

        if(len(requestOuts)!=0):
            request: VSOMEIP_Method = requestOuts[0]
            valuesDict["requestType"] =  request.getMessage()
            # TODO: Make this more OOPS 
            valuesDict["responseType"] =  request.getMessage().replace("Request", "Response")
            self.protoPackageNames.add(request.getPackageName())
            self.protoHeaderFilenames.add(request.getProtoHeaderFilename())
        elif(len(requestIns)!=0):
            request: VSOMEIP_Method = requestIns[0]
            valuesDict["requestType"] =  request.getMessage()
            # TODO: Make this more OOPS 
            valuesDict["responseType"] =  request.getMessage().replace("Request", "Response")
            self.protoPackageNames.add(request.getPackageName())
            self.protoHeaderFilenames.add(request.getProtoHeaderFilename())
        else:
            return ""
        return gst.addMessageChannel.substitute(valuesDict) 

    def constructUsingStatements(self) -> str:
        res:str = ""
        for package_name in self.protoPackageNames:
            res += f'using namespace {package_name};\n'
        return res
    
    def constructIncludeDirectives(self) -> str:
        res = ""
        for proto_header_filename in self.protoHeaderFilenames:
            include_directive = f'#include "{proto_header_filename}"\n'
            res += include_directive

        return res
    
    def substitute(self):
        return self.gtest
