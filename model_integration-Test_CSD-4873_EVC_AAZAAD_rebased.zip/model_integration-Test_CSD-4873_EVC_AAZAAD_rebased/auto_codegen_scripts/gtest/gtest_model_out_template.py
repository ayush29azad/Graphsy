from string import Template

modelOutClass = Template('''

#include <iostream>
#include <gtest/gtest.h>
#include <gmock/gmock.h>
#include "WorkExecutor.h"
#include "MessageChannel.hpp"
#include <vsomeip/vsomeip.hpp>
#include <DDSEntityFactory.hpp>
#include "${ModelWrapperHeader}"

using DDSEntityFactoryInterface = jlr::cccm::di::dds::DDSEntityFactoryInterface;
using DDSEntityFactory = jlr::cccm::di::dds::DDSEntityFactory;
using DDSManager = jlr::cccm::di::dds::DDSManager;
using DDSManagerInterface = jlr::cccm::di::dds::DDSManagerInterface;
using ModelController = jlr::cccm::di::ModelController<$model_class>;
using ::testing::Return;
using ::testing::_;
using ::testing::Matcher;
using ::testing::Eq;
using ::testing::Matcher;
using ::testing::Pointee;
using ::testing::StrictMock;
using ::testing::Mock;
using ::testing::AtLeast;

class $modelOutClass : public ::testing::Test
{
  void SetUp()
  { 
    $vsomeipApp_definitions
    $someipChannel_definitions
    
    context = std::make_shared<cccm::di::launcher::LauncherContext>();

    std::unordered_map<std::string, std::shared_ptr<vsomeip::application>> someipApp_map;
    $someipApp_map
    context->someipApp_map = someipApp_map;
    context->workExecutor = nullptr;
    context->ddsFactory = std::make_shared<DDSEntityFactory>(jlr::cccm::di::dds::SHARED_MEM);
  }
  void TearDown()
  {
  }

public:
  int n;
  std::string mWorkExecutorName = "workExecutor";
  $vsomeipApp_declarations
  $someipChannel_declarations
  
  std::shared_ptr<${model_class}> model_ptr
    = std::make_shared<${model_class}>();

  std::shared_ptr<cccm::di::ModelLibInterface> modelWrapperPtr
    = std::make_shared<
        cccm::di::models::Wrapper${model_name}<${model_class}>
        >(model_ptr);

  std::shared_ptr<cccm::di::launcher::LauncherContext> context{};

};
''')

someipRequestOutEmpty =  Template('''

TEST_F($modelOutClass, $funName)
{
  std::shared_ptr<vsomeip::message> someip_request = std::make_shared<vsomeip::message>();
  std::shared_ptr<vsomeip::payload> payload = std::make_shared<vsomeip::payload>();
  consumer::MessageChannel<$package_name::$proto_request, $package_name::$proto_response>::get_instance().initMessageChannel(mSomeipChannel_vid${vid}, 0x002);
  EXPECT_CALL(*vsomeip::runtime::get(), create_request()).Times(1).WillOnce(Return(someip_request));
  EXPECT_CALL(*vsomeip::runtime::get(), create_payload()).Times(1).WillOnce(Return(payload));
  EXPECT_CALL(*someip_request, set_service(_));
  EXPECT_CALL(*someip_request, set_instance(_));
  EXPECT_CALL(*someip_request, set_method(_));
  EXPECT_CALL(*payload, set_data(Matcher<std::vector<vsomeip::byte_t>&&>(_)));
  EXPECT_CALL(*someip_request, set_payload(_));
  EXPECT_CALL(*$appName, send(_)).Times(1);

  $funName();
}
''')

someipRequestOutNonempty =  Template('''

TEST_F($modelOutClass, $funName)
{
  const $model_struct* model_data = new $model_struct();
  std::shared_ptr<vsomeip::message> someip_request = std::make_shared<vsomeip::message>();
  std::shared_ptr<vsomeip::payload> payload = std::make_shared<vsomeip::payload>();
  consumer::MessageChannel<$package_name::$proto_request, $package_name::$proto_response>::get_instance().initMessageChannel(mSomeipChannel_vid${vid}, 0x002);
  EXPECT_CALL(*vsomeip::runtime::get(), create_request()).Times(1).WillOnce(Return(someip_request));
  EXPECT_CALL(*vsomeip::runtime::get(), create_payload()).Times(1).WillOnce(Return(payload));
  EXPECT_CALL(*someip_request, set_service(_));
  EXPECT_CALL(*someip_request, set_instance(_));
  EXPECT_CALL(*someip_request, set_method(_));
  EXPECT_CALL(*payload, set_data(Matcher<std::vector<vsomeip::byte_t>&&>(_)));
  EXPECT_CALL(*someip_request, set_payload(_));
  EXPECT_CALL(*$appName, send(_)).Times(1);

  $funName(model_data);
}
''')

someipNotifyOut = Template('''
TEST_F($modelOutClass, $funName)
{
  const $model_struct *model_data = new $model_struct();
  std::shared_ptr<vsomeip::message> someip_request = std::make_shared<vsomeip::message>();
  std::shared_ptr<vsomeip::payload> payload = std::make_shared<vsomeip::payload>();
  provider::NotifyChannel<$package_name::$proto_notify>::get_instance().initNotifyChannel(mSomeipChannel_vid${vid}, 0x002, {});
  EXPECT_CALL(*vsomeip::runtime::get(), create_payload()).Times(1).WillOnce(Return(payload));
  EXPECT_CALL(*payload, set_data(Matcher<std::vector<vsomeip::byte_t>&&>(_))).Times(1);
  EXPECT_CALL(*$appName, notify(_,_,_,_)).Times(1);

  $funName(model_data);
}
''')

someipResponseOut = Template('''
TEST_F($modelOutClass, $funName)
{
  const std::shared_ptr<vsomeip::message> request_message = std::make_shared<vsomeip::message>();
  // EXPECT_CALL(*request_message, get_payload()).Times(1);
  provider::MessageChannel<$package_name::$proto_request, $package_name::$proto_response>::get_instance().setLastRequest(request_message);
  const $model_struct *model_data = new $model_struct();
  std::shared_ptr<vsomeip::message> someip_response_msg = std::make_shared<vsomeip::message>();
  std::shared_ptr<vsomeip::payload> payload = std::make_shared<vsomeip::payload>();
  provider::MessageChannel<$package_name::$proto_request, $package_name::$proto_response>::get_instance().initMessageChannel(mSomeipChannel_vid${vid}, 0x002);
  EXPECT_CALL(*vsomeip::runtime::get(), create_response(_)).Times(1).WillOnce(Return(someip_response_msg));
  EXPECT_CALL(*vsomeip::runtime::get(), create_payload()).Times(1).WillOnce(Return(payload));
  EXPECT_CALL(*someip_response_msg, set_payload(_)).Times(1);
  EXPECT_CALL(*payload, set_data(Matcher<std::vector<vsomeip::byte_t>&&>(_))).Times(1);
  EXPECT_CALL(*$appName, send(_)).Times(1);
  $funName(model_data);
}
''')

ddsOutFail = Template('''
TEST_F($modelOutClass, ${method_name}_Fail)
{
  const $model_struct model_data{};

  {
    // simulate case when g_model_controller is not set yet
    $funName(&model_data);
  }
  
  {
    // simulate case when g_model_controller is not init yet with dds handler
    auto model_controller = std::make_shared<ModelController>();
    jlr::cccm::di::set_model_controller(model_controller);
    $funName(&model_data);
  }
  
  {
    // simulate case when g_model_controller is initialised with dds handler, 
    // but dds handler send does not work
    modelWrapperPtr->init(context);
    auto dds_handler = jlr::cccm::di::get_model_controller().lock()->get_dds_handler();
    std::shared_ptr<DDSManager> manager = std::dynamic_pointer_cast<DDSManager>(
      dds_handler->get_manager()
    );
    EXPECT_CALL(*manager, send_data(_,_)).Times(1).WillOnce(Return(false));
    $funName(&model_data);    
  }
  
  modelWrapperPtr->terminate();
}
''')

ddsOutSuccess = Template('''
TEST_F($modelOutClass, ${method_name}_Success)
{
  
  modelWrapperPtr->init(context);

  const $model_struct model_data{};

  auto dds_handler = jlr::cccm::di::get_model_controller().lock()->get_dds_handler();
  
  std::shared_ptr<DDSManager> manager = std::dynamic_pointer_cast<DDSManager>(
    dds_handler->get_manager()
  );
  EXPECT_CALL(*manager, send_data(_,_)).Times(1).WillOnce(Return(true));

  $funName(&model_data);

  modelWrapperPtr->terminate();
}
''')
