from string import Template

someipServiceProvider = Template('''
#include <iostream>
#include <gtest/gtest.h>
#include <gmock/gmock.h>
#include <SomeipServiceProvider.hpp>
#include <vsomeip/vsomeip.hpp>
#include "WorkExecutor.h"
$include_directives
$using_statements
using ::testing::_;
using ::testing::Eq;
using ::testing::Matcher;
using ::testing::Pointee;
using ::testing::Return;
class GtestSomeipServiceProvider : public ::testing::Test
{
  void SetUp()
  { 
  }
  void TearDown()
  {
  }

  public:
  int n;
  std::string mWorkExecutorName = "workExecutor";
  std::shared_ptr<vsomeip::application> mApp = std::make_shared<vsomeip::application>();
  std::shared_ptr<SomeipChannel> mSomeipChannel = std::make_shared<SomeipChannel>(mApp, 0x001, 0x002);
  


  //std::shared_ptr<WorkExecutor> mWorkExecutor = std::make_shared<WorkExecutor>(mWorkExecutorName);
};
int dummySomeipServiceProviderInt = 0;
void dummySomeipServiceProviderFunc(std::shared_ptr<SomeipChannel> someipChannel, bool flag) {
  if(flag)
  {
    dummySomeipServiceProviderInt = 1;
  }else{
    dummySomeipServiceProviderInt = 0;
  }
}

TEST_F(GtestSomeipServiceProvider, offerService_Failure)
{
  EXPECT_CALL(*mApp, offer_service(_,_,_)).Times(0);
  SomeipServiceProvider* someipServiceProvider = new SomeipServiceProvider(nullptr, nullptr);
  delete someipServiceProvider;
}
TEST_F(GtestSomeipServiceProvider, offerService_Success)
{
  EXPECT_CALL(*mApp, offer_service(_,_,_)).Times(1);
  SomeipServiceProvider* someipServiceProvider = new SomeipServiceProvider(mSomeipChannel, nullptr);
  delete someipServiceProvider;
}
TEST_F(GtestSomeipServiceProvider, getSomeipChannel)
{
  EXPECT_CALL(*mApp, offer_service(_,_,_)).Times(1);
  SomeipServiceProvider* someipServiceProvider = new SomeipServiceProvider(mSomeipChannel, nullptr);
  auto someipChannel = someipServiceProvider->getSomeipChannel();
  EXPECT_EQ(mSomeipChannel, someipChannel);
  delete someipServiceProvider;
}
TEST_F(GtestSomeipServiceProvider, setSomeipChannel)
{
  EXPECT_CALL(*mApp, offer_service(_,_,_)).Times(1);
  SomeipServiceProvider* someipServiceProvider = new SomeipServiceProvider(mSomeipChannel, nullptr);
  auto someipChannel = someipServiceProvider->getSomeipChannel();
  EXPECT_EQ(mSomeipChannel, someipChannel);
  std::shared_ptr<SomeipChannel> NewSomeipChannel = std::make_shared<SomeipChannel>(mApp, 0x001);
  someipServiceProvider->setSomeipChannel(NewSomeipChannel);
  someipChannel = someipServiceProvider->getSomeipChannel();
  EXPECT_EQ(NewSomeipChannel, someipChannel);
  delete someipServiceProvider;
}
TEST_F(GtestSomeipServiceProvider, setOnAvailableCallback)
{
  EXPECT_CALL(*mApp, offer_service(_,_,_)).Times(1);
  SomeipServiceProvider* someipServiceProvider = new SomeipServiceProvider(mSomeipChannel, nullptr);
  someipServiceProvider->setOnAvailableCallback(dummySomeipServiceProviderFunc);
  (someipServiceProvider->getOnAvailableCallback())(mSomeipChannel, true);
  int result = dummySomeipServiceProviderInt;
  EXPECT_EQ(1, result);
  delete someipServiceProvider;
}'''
)
addNotifyChannel = Template('''TEST_F(GtestSomeipServiceProvider, addNotifyChannel)
{
  EXPECT_CALL(*mApp, offer_service(_,_,_)).Times(1);
  EXPECT_CALL(*mApp, offer_event(_,_,_,_,_)).Times(1);
  SomeipServiceProvider* someipServiceProvider = new SomeipServiceProvider(mSomeipChannel, nullptr);
  someipServiceProvider->addNotifyChannel<$notifyEvent>(0x01, {0x02, 0x03});
  delete someipServiceProvider;
}
''')
sendNotifyEvent = Template('''TEST_F(GtestSomeipServiceProvider, sendNotifyEvent)
{

  EXPECT_CALL(*mApp, offer_service(_,_,_)).Times(1);
  EXPECT_CALL(*mApp, notify(_,_,_,_)).Times(1);
  std::shared_ptr<vsomeip::message> someip_request = std::make_shared<vsomeip::message>();
  std::shared_ptr<vsomeip::payload> payload = std::make_shared<vsomeip::payload>();
  EXPECT_CALL(*vsomeip::runtime::get(), create_payload()).Times(1).WillOnce(Return(payload));
  EXPECT_CALL(*payload, set_data(Matcher<std::vector<vsomeip::byte_t>&&>(_) ));
  SomeipServiceProvider* someipServiceProvider = new SomeipServiceProvider(mSomeipChannel, nullptr);
  provider::NotifyChannel<$notifyEvent>::get_instance().initNotifyChannel(mSomeipChannel, 0x001, {0x002,0x003});
  $notifyEvent* dummyNotifyType = new $notifyEvent();
  someipServiceProvider->sendNotifyEvent<$notifyEvent>(*dummyNotifyType);
  delete someipServiceProvider;
  delete dummyNotifyType;
}
''')
addMessageChannel =  Template('''TEST_F(GtestSomeipServiceProvider, addMessageChannel)
{
  EXPECT_CALL(*mApp, offer_service(_,_,_)).Times(1);
  EXPECT_CALL(*mApp, register_message_handler_fake(_,_,_,_)).Times(1);
  
  SomeipServiceProvider* someipServiceProvider = new SomeipServiceProvider(mSomeipChannel, nullptr);
  someipServiceProvider->addMessageChannel<$requestType, $responseType>(0x01);
  delete someipServiceProvider;
}
''')
