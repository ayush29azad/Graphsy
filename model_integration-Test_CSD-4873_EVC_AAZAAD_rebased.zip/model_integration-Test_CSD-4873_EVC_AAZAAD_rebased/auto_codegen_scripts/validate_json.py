import jsonschema
import os
import json
    
def _load_json_schema_from_file(filename):
    script_dir = os.path.dirname(os.path.abspath(__file__))
    file_path = os.path.join(
            script_dir,
            filename
            )

    with open(file_path) as f:
        return json.load(f)

class validateJsonSchema:

    def __init__(self):

        self.model_config_schema = _load_json_schema_from_file("modelConfig_schema.json")

        self.ipc_mapping_schema = _load_json_schema_from_file("IPCMapping_schema.json")

        self.service_json_schema = _load_json_schema_from_file("serviceJSON_schema.json")

        self.topics_mapping_schema = _load_json_schema_from_file("topicsMapping_schema.json")

        self.simulink_artifacts_schema = _load_json_schema_from_file("simulinkArtifacts_schema.json")




    # Validates the JSON Schema of the Model Config file.
    def validate_modelConfig(self,data):
        """Validates a JSON file against the given schema."""

        try:
            jsonschema.validate(instance=data, schema=self.model_config_schema)
            return True
        except jsonschema.ValidationError as e:
            error_path = list(e.path)  
            if error_path and error_path[0] == '__root__':
                error_path.pop(0)
            print(f"[Error]: {e.message} (Path: {'.'.join(map(str, error_path))})")
            return False
        
        
    # Validates the JSON Schema of the IPC Mapping file.
    def validate_ipc_mapping(self, data):
        """Validates a JSON file against the given schema."""

        try:
            jsonschema.validate(instance=data, schema=self.ipc_mapping_schema)
            return True
        except jsonschema.ValidationError as e:
            error_path = list(e.path)  
            if error_path and error_path[0] == '__root__':
                error_path.pop(0)
            print(f"[Error]: {e.message} (Path: {'.'.join(map(str, error_path))})")
            return False
        
        
    # Validates the JSON Schema of the Service JSON file.
    def validate_serviceJson(self, data):
        """Validates a JSON file against the given schema."""

        try:
            jsonschema.validate(instance=data, schema=self.service_json_schema)
            return True
        except jsonschema.ValidationError as e:
            error_path = list(e.path)  
            if error_path and error_path[0] == '__root__':
                error_path.pop(0)
            print(f"[Error]: {e.message} (Path: {'.'.join(map(str, error_path))})")
            return False
        

    # Validates the JSON Schema of the Topics Mapping file.
    def validate_topicsMapping(self, data):
        """Validates a JSON file against the given schema."""

        try:
            jsonschema.validate(instance=data, schema=self.topics_mapping_schema)
            return True
        except jsonschema.ValidationError as e:
            error_path = list(e.path)  
            if error_path and error_path[0] == '__root__':
                error_path.pop(0)
            print(f"[Error]: {e.message} (Path: {'.'.join(map(str, error_path))})")
            return False
        

    # Validates the JSON Schema of the Siulink Models Artifact Config Json file.
    def validate_simulink_artifact(self, data):
        """Validates a JSON file against the given schema."""
        
        try:
            jsonschema.validate(instance=data, schema=self.simulink_artifacts_schema)
            return True
        except jsonschema.ValidationError as e:
            error_path = list(e.path)  
            if error_path and error_path[0] == '__root__':
                error_path.pop(0)
            print(f"[Error]: {e.message} (Path: {'.'.join(map(str, error_path))})")
            return False
        
        
