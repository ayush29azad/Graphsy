import utils
import config_getter

from typing import Union

class Model:

    def __init__(self, model_data):
        self.model_name = model_data["model_name"]
        self.model_main_class = model_data["model_main_class"]

        self.vsomeip_methods = []
        self.vsomeip_events = []
        self.dds_methods = []
        self.ml_api_methods = []  #  NEW: ML_API support
        self.someip_qos_method = []
        self.clock_methods = []
        self.methods_count = 0

        for method in model_data["model_methods"]:
            if method["ipc_type"] == "vsomeip":
                self.methods_count += 1
                if method["ipc_info"]["event_type"] == "event":
                    self.vsomeip_events.append(VSOMEIP_Event(method))
                else:
                    self.vsomeip_methods.append(VSOMEIP_Method(method))

            elif method["ipc_type"] == "ml_API":  # NEW: ML_API handler
                self.methods_count += 1
                self.ml_api_methods.append(ML_API_Method(method))

            elif method["ipc_type"] == "someip-qos":
                self.someip_qos_method.append(SOMEIP_QOS(method))

            elif method["ipc_type"] == "dds":
                self.methods_count += 1
                self.dds_methods.append(FastDDS_Method(method))

            elif method["ipc_type"] == "clock":
                self.clock_methods.append(Clock_Method(method))

        if self.methods_count == 0:
            print("[Warning]: There should be atleast one VSOMEIP/FastDDS/ML_API Method present in modelConfig file: " + self.model_name)
    
    def getModelName(self):
        return self.model_name
    
    def getModelClassName(self):
        return self.model_main_class
    
    def get_vsomeip_methods(self):
        return self.vsomeip_methods
    
    def get_vsomeip_events(self):
        return self.vsomeip_events
    
    def get_dds_methods(self):
        return self.dds_methods
    
    def get_ml_api_methods(self):  #  NEW
        """Returns all ML_API methods"""
        return self.ml_api_methods
    
    def getAllModelMethods(self):  #  NEW
        """Returns all methods (VSOMEIP + DDS + ML_API)"""
        all_methods = []
        all_methods.extend(self.vsomeip_methods)
        all_methods.extend(self.vsomeip_events)
        all_methods.extend(self.dds_methods)
        all_methods.extend(self.ml_api_methods)
        return all_methods
    
    def getAllPackageNamesForModel(self):
        res = set()

        for method in self.vsomeip_methods:
            res.add(method.getPackageName())

        for event in self.vsomeip_events:
            res.add(event.getPackageName())

        return sorted(list(res))
    
    def getAllServicesForModel(self):
        res = set()

        for method in self.vsomeip_methods:
            res.add(method.getServiceName())

        for event in self.vsomeip_events:
            res.add(event.getServiceName())

        return sorted(list(res))
    
    def getAllProtoIncludesForModel(self):
        res = set()

        for method in self.vsomeip_methods:
            res.add(method.getProtoHeaderFilename())

        for event in self.vsomeip_events:
            res.add(event.getProtoHeaderFilename())

        return sorted(list(res))

    def getAllvIdsForModel(self):
        res = set()
        for method in self.vsomeip_methods:
            res.add(method.getvId())

        for event in self.vsomeip_events:
            res.add(event.getvId()) 

        return list(res)
    
    def serviceDefinitionFileNameFromServiceName(self, service_name):
        for method in self.vsomeip_methods:
            if method.getServiceName() == service_name:
                return method.getServiceDefinitionFile()

        for event in self.vsomeip_events:
            if event.getServiceName() == service_name:
                return event.getServiceDefinitionFile()


    def getAllServicesForModelAsServer(self):
        res = {}

        for method in self.vsomeip_methods:
            if method.modelIsServer():
                if method.getvId() not in res.keys():
                    res[method.getvId()] = set()
                res[method.getvId()].add(method.getServiceName())
        for event in self.vsomeip_events:
            if event.modelIsServer():
                if event.getvId() not in res.keys():
                    res[event.getvId()] = set()
                res[event.getvId()].add(event.getServiceName())
        return res
    
    def getAllServicesForModelAsClient(self):
        res = {}

        for method in self.vsomeip_methods:
            if not method.modelIsServer():
                if method.getvId() not in res.keys():
                    res[method.getvId()] = set()
                res[method.getvId()].add(method.getServiceName())
        for event in self.vsomeip_events:
            if not event.modelIsServer():
                if event.getvId() not in res.keys():
                    res[event.getvId()] = set()
                res[event.getvId()].add(event.getServiceName())
        return res

    def getServiceIDfromServiceName(self, service_name):
        for method in self.vsomeip_methods:
            if method.getServiceName() == service_name:
                return method.getServiceID()
            
        for event in self.vsomeip_events:
            if event.getServiceName() == service_name:
                return event.getServiceID()
            
        print(f"[Error]: Service name: {service_name} not found for any method in the model: {self.model_name}")
        return None

    def getvIdFromServiceName(self, service_name):
        for method in self.vsomeip_methods:
            if method.getServiceName() == service_name:
                return method.getvId()
            
        for event in self.vsomeip_events:
            if event.getServiceName() == service_name:
                return event.getvId()
            
        print(f"[Error]: getvId not found for Service name: {service_name} : {self.model_name}")
        return None
            
    def getInstanceIDforService(self, service_name):
        return "1"

    def getServiceNameIPCMapping(self):
        res = []
        for method in self.vsomeip_methods:
            tuple = (method.getServiceName(), method.getIPCMappingFileName())
            res.append(tuple)
        for method in self.vsomeip_events:
            tuple = (method.getServiceName(), method.getIPCMappingFileName())
            res.append(tuple)

        return utils.Utils.unique(res)
    
    def getAllModelSomeipIns(self) -> list[Union['VSOMEIP_Event', 'VSOMEIP_Method']]:
        res = []
        for method in self.vsomeip_methods:
            if method.getIntent() == "in":
                res.append(method)
        
        for method in self.vsomeip_events:
            if method.getIntent() == "in":
                res.append(method)

        return res
    
    def getAllModelSomeipOuts(self) -> list[Union['VSOMEIP_Event', 'VSOMEIP_Method']]:
        res = []
        for method in self.vsomeip_methods:
            if method.getIntent() == "out":
                res.append(method)
        
        for method in self.vsomeip_events:
            if method.getIntent() == "out":
                res.append(method)

        return res


    def get_dds_ipc_mapping_files(self):
        res = []
        for method in self.dds_methods:
            res.append(method.getIPCMappingFileName())

        return utils.Utils.unique(res)
    
    def findMessage(self, message):
        for method in self.vsomeip_methods:
            if method.getMessage() == message:
                return True
        return False
    def getAllModelOuts(self):
        res = []

        for method in self.vsomeip_methods:
            if method.getIntent() == "out":
                res.append(method)
        
        for event in self.vsomeip_events:
            if event.getIntent() == "out":
                res.append(event)

        for method in self.dds_methods:
            if method.getIntent() == "out":
                res.append(method)
        
        # NEW: Add ML_API outs
        for method in self.ml_api_methods:
            if method.getIntent() == "out":
                res.append(method)
                
        return utils.Utils.unique(res)
    
    def AllModelSomeipIns(self):
        res = {}
        for event in self.vsomeip_events:
            if event.isNotifyIn():
                if event.getvId() not in res.keys():
                    res[event.getvId()] = set()
                res[event.getvId()].add(event)
        for method in self.vsomeip_methods:
            if method.isResponseIn():
                if method.getvId() not in res.keys():
                    res[method.getvId()] = set()
                res[method.getvId()].add(method)
        for method in self.vsomeip_methods:
            if method.isRequestIn():
                if method.getvId() not in res.keys():
                    res[method.getvId()] = set()
                res[method.getvId()].add(method)

        request_out_msgs = []
        response_ins = self.getAllSomeipResponseIns()

        for model_method in response_ins:
            response_msg = model_method.getMessage()
            request_msg = self.getCorrespondingRequestForResponse(model_method)
            request_out_msgs.append(request_msg)

        request_outs = self.getAllSomeipRequestOuts()

        for _, model_methods in request_outs.items():
            for model_method in model_methods:
                request_msg = model_method.getMessage()
                if request_msg not in request_out_msgs:
                    if model_method.getvId() not in res.keys():
                        res[model_method.getvId()] = set()
                    res[model_method.getvId()].add(model_method)
        return res
    def getAllSomeipNotifyIns(self):
        res = []

        for event in self.vsomeip_events:
            if event.isNotifyIn():
                res.append(event)
                
        return utils.Utils.unique(res)
    
    def getAllSomeipResponseIns(self):
        res = []

        for method in self.vsomeip_methods:
            if method.isResponseIn():
                res.append(method)
                
        return utils.Utils.unique(res)

    def getAllSomeipRequestOuts(self):
        res = {}

        for method in self.vsomeip_methods:
            if method.isRequestOut():
                if method.getvId() not in res.keys():
                    res[method.getvId()] = set()
                res[method.getvId()].add(method)
                
        return res
    
    def getAllSomeipNotifyOuts(self):
        res = {}

        for event in self.vsomeip_events:
            if event.isNotifyOut():
                if event.getvId() not in res.keys():
                    res[event.getvId()] = set()
                res[event.getvId()].add(event)
                
        return res
    
    def getAllSomeipResponseOuts(self):
        res = {}

        for method in self.vsomeip_methods:
            if method.isResponseOut():
                if method.getvId() not in res.keys():
                    res[method.getvId()] = set()
                res[method.getvId()].add(method)
                
        return res

    def getAllSomeipRequestIns(self):
        res = []

        for method in self.vsomeip_methods:
            if method.isRequestIn():
                res.append(method)
                
        return utils.Utils.unique(res)

    def getAllUnpairedResponseIns(self):
        res = []

        request_out_msgs = []
        response_ins = self.getAllSomeipResponseIns()

        for model_method in response_ins:
            response_msg = model_method.getMessage()
            request_msg = self.getCorrespondingRequestForResponse(model_method)
            request_out_msgs.append(request_msg)

        request_outs = self.getAllSomeipRequestOuts()

        for _, model_methods in request_outs.items():
            for model_method in model_methods:
                request_msg = model_method.getMessage()
                if request_msg not in request_out_msgs:
                    res.append(model_method)

        return utils.Utils.unique(res)

    def getAllDdsOuts(self):
        res = []

        for method in self.dds_methods:
            if method.getIntent() == "out":
                res.append(method)
                
        return utils.Utils.unique(res)

    def getAllDdsIn(self):
        res = []

        for method in self.dds_methods:
            if method.getIntent() == "in":
                res.append(method)
                
        return utils.Utils.unique(res)
    
    def getAllModelTopics(self):
        res = []
        for method in self.dds_methods:
            res.append(method.getDdsIdlFileNameWithoutExtension())        
        return res

    def getCorrespondingRequestForResponse(self, model_method):
        if not self.findMessage(model_method.getCorrespondingMessage()):
            print(f"[Warning]: Request message: {model_method.getCorrespondingMessage()} corresponding to the response message: {model_method.getMessage()} not found.")
        return model_method.getCorrespondingMessage()
            
    def getCorrespondingResponseForRequest(self, model_method):
        if not self.findMessage(model_method.getCorrespondingMessage()):
            print(f"[Warning]: Response message: {model_method.getCorrespondingMessage()} corresponding to the request message: {model_method.getMessage()} not found.")
        return model_method.getCorrespondingMessage()
            
    def hasTimer(self):
        if len(self.clock_methods) == 0:
            return False       
        return True
    
    def getTimerMethod(self):
        return self.clock_methods[0]
    
    def hasOnAvailable(self):

        if len(self.someip_qos_method) != 0:
            return self.someip_qos_method[0].hasOnAvailable()
                
        return False
    
    def getModelOnAvailableFunName(self):

        for method in self.someip_qos_method:
            if method.hasOnAvailable():
                return method.getMethodName()
            
    def dependentStructs(self):
        for method in self.vsomeip_methods:
            config_getter.DataConverterHelper.helperDependentStructs(method.getMessage(), method.getIPCMappingFileName())
        for method in self.vsomeip_events:
            config_getter.DataConverterHelper.helperDependentStructs(method.getMessage(), method.getIPCMappingFileName())

class VSOMEIP_Method:

    def __init__(self, model_method):
        self.method_name = model_method["method_name"]
        self.model_class = model_method["model_class"]
        self.ipc_type = model_method["ipc_type"]
        self.event_type = model_method["ipc_info"]["event_type"] 
        self.IPCMappingFileName = model_method["ipc_info"]["ipc_mapping_file"] 
        self.message = model_method["ipc_info"]["message"] 
        self.corresponding_message = model_method["additional_info"]["corresponding_message"]
        self.members = model_method["additional_info"]["members"]
        self.model_arg_name = model_method["additional_info"]["model_arg_name"]
        self.model_struct_name = model_method["additional_info"]["model_struct_name"]
        self.service_name = model_method["additional_info"]["service_name"]
        self.package_name = model_method["additional_info"]["package_name"]
        self.method_id = model_method["additional_info"]["MethodID"]
        self.service_id = model_method["additional_info"]["ServiceID"]
        self.intent = model_method["intent"]
        self.arguments = model_method["arguments"]
        self.proto_filename = model_method["proto_filename"]
        self.vid = model_method["additional_info"]["vid"]
        self.service_definition_file = model_method["additional_info"]["service_definition_file"]

    def getProtoFilename(self):
        return self.proto_filename

    def getProtoHeaderFilename(self):
        proto_filename:str = self.proto_filename
        split_filename: list[str] = proto_filename.split('.')
        # TODO: proper exception classes
        if len(split_filename) != 2:
            raise ValueError('Unsupported Proto Filename')
        if split_filename[-1] != 'proto':
            raise ValueError('Unsupported Proto Filename')
        
        proto_filename_without_ext: str = split_filename[0] 
        
        return f'{proto_filename_without_ext}.pb.h'
    
    def getMethodName(self):
        return self.method_name
    
    def getMethodID(self):
        return self.method_id
    
    def getPackageName(self):
        return self.package_name
    
    def getServiceName(self):
        return self.service_name

    def getvId(self):
        return self.vid

    def getServiceDefinitionFile(self):
        return self.service_definition_file
    
    def getServiceID(self):
        return self.service_id

    def getModelStructName(self):
        return self.model_struct_name
    
    def getIPCMappingFileName(self):
        return self.IPCMappingFileName
    
    def getIntent(self):
        return self.intent
    
    def getMessage(self):
        return self.message
    
    def getCorrespondingMessage(self):
        return self.corresponding_message
    
    def getMembers(self):
        return self.members
    
    def getEventType(self):
        return self.event_type

    def isResponseIn(self):
        if self.intent == "in" and self.event_type == "response":
            return True
        return False
    
    def isRequestOut(self):
        if self.intent == "out" and self.event_type == "request":
            return True
        return False

    def isRequestIn(self):
        if self.intent == "in" and self.event_type == "request":
            return True
        return False
    
    def isResponseOut(self):
        if self.intent == "out" and self.event_type == "response":
            return True
        return False
    
    def modelIsServer(self):
        if self.isRequestIn() or self.isResponseOut():
            return True
        return False
    
    def checkIfModelEventHasArgument(self):
        if isinstance(self.arguments, dict):
            if self.arguments["arg_name"] != "" and self.arguments["arg_dtype"] != "":
                return True
        else:
          for arg in self.arguments:
              if arg["arg_name"] != "" and arg["arg_dtype"] != "":
                  return True
        return False

    
class VSOMEIP_Event:

    def __init__(self, model_event):
        self.method_name = model_event["method_name"]
        self.model_class = model_event["model_class"]
        self.ipc_type = model_event["ipc_type"]
        self.message = model_event["ipc_info"]["message"]    
        self.IPCMappingFileName = model_event["ipc_info"]["ipc_mapping_file"] 
        self.event_type = model_event["ipc_info"]["event_type"] 
        if isinstance(model_event["additional_info"]["members"], dict):
            self.members = [model_event["additional_info"]["members"]]
        else:
          self.members = model_event["additional_info"]["members"]
        self.model_arg_name = model_event["additional_info"]["model_arg_name"]
        self.model_struct_name = model_event["additional_info"]["model_struct_name"]
        self.service_name = model_event["additional_info"]["service_name"]
        self.package_name = model_event["additional_info"]["package_name"]
        self.service_id = model_event["additional_info"]["ServiceID"]
        self.event_id = model_event["additional_info"]["EventID"]
        self.eventgroups = model_event["additional_info"]["eventgroupIDs"]
        self.intent = model_event["intent"]
        if isinstance(model_event["arguments"], dict):
          self.arguments = [model_event["arguments"]]
        else:
          self.arguments = model_event["arguments"]
        
        self.proto_filename = model_event["proto_filename"]
        self.vid = model_event["additional_info"]["vid"]
        self.service_definition_file = model_event["additional_info"]["service_definition_file"]

    def getProtoFilename(self):
        return self.proto_filename
    
    def getProtoHeaderFilename(self):
        proto_filename:str = self.proto_filename
        split_filename: list[str] = proto_filename.split('.')
        # TODO: proper exception classes
        if len(split_filename) != 2:
            raise ValueError('Unsupported Proto Filename')
        if split_filename[-1] != 'proto':
            raise ValueError('Unsupported Proto Filename')
        
        proto_filename_without_ext: str = split_filename[0] 
        
        return f'{proto_filename_without_ext}.pb.h'

    def getMethodName(self):
        return self.method_name
    
    def getEventID(self):
        return self.event_id

    def getPackageName(self):
        return self.package_name
    
    def getServiceName(self):
        return self.service_name
    
    def getvId(self):
        return self.vid

    def getServiceDefinitionFile(self):
        return self.service_definition_file

    def getServiceID(self):
        return self.service_id

    def getModelStructName(self):
        return self.model_struct_name
    
    def getIPCMappingFileName(self):
        return self.IPCMappingFileName
    
    def getMessage(self):
        return self.message
    
    def getEventType(self):
        return self.event_type
    
    def getIntent(self):
        return self.intent
    
    def getMembers(self):
        return self.members
    
    def getAllEventGroupIDs(self):
        return self.eventgroups
    
    def isNotifyOut(self):
        if self.intent == "out":
            return True
        return False
    
    def isNotifyIn(self):
        if self.intent == "in":
            return True 
        return False
    
    def modelIsServer(self):
        if self.intent == "out":
            return True
        return False

    def checkIfEventHasArgument(self):
        if isinstance(self.arguments, dict):
            if self.arguments["arg_name"] != "" and self.arguments["arg_dtype"] != "":
                return True
        else:
          for arg in self.arguments:
              if arg["arg_name"] != "" and arg["arg_dtype"] != "":
                  return True
        return False   
    
class FastDDS_Method:
    
    def __init__(self, model_method):
        self.method_name = model_method["method_name"]
        self.model_class = model_method["model_class"]
        self.ipc_type = model_method["ipc_type"]

        self.message = model_method["ipc_info"]["message"]
        self.IPCMappingFileName = model_method["ipc_info"]["ipc_mapping_file"] 
        self.topic = model_method["additional_info"]["topic"]
        self.members = model_method["additional_info"]["members"]
        self.model_arg_name = model_method["additional_info"]["model_arg_name"]
        self.model_struct_name = model_method["additional_info"]["model_struct_name"]
        self.idl_file = model_method["additional_info"]["idl_file"]
        self.intent = model_method["intent"]
        self.arguments = model_method["arguments"] 

    def getMethodName(self):
        return self.method_name
    
    def getTopicName(self):
        return self.topic

    def getIntent(self):
        return self.intent
    
    def getIPCMappingFileName(self):
        return self.IPCMappingFileName
    
    def getMembers(self):
        return self.members
    
    def getModelStructName(self):
        return self.model_struct_name
    
    def getDdsIdlFileNameWithoutExtension(self):
        return self.idl_file.split(".")[0]
        

# ========== NEW: ML_API_Method CLASS ==========
class ML_API_Method:
    """Handles ML_API methods (e.g., EarlyCCF integration)"""
    
    def __init__(self, model_method):
        self.method_name = model_method["method_name"]
        self.model_class = model_method["model_class"]
        self.ipc_type = model_method["ipc_type"]
        
        # ML_API specific fields
        self.IPCMappingFileName = model_method["ipc_info"]["ipc_mapping_file"]
        self.message = model_method["ipc_info"]["message"]
        
        # From additional_info (populated by input_testing.py)
        print(f"DEBUG: model_method keys: {model_method.keys()}")
        print(f"DEBUG: model_method content: {model_method}")
        self.members = model_method["additional_info"]["members"]
        self.model_arg_name = model_method["additional_info"]["model_arg_name"]
        self.model_struct_name = model_method["additional_info"]["model_struct_name"]
        
        self.intent = model_method["intent"]
        self.arguments = model_method["arguments"]

    def getMethodName(self):
        return self.method_name
    
    def getIPCType(self):
        return self.ipc_type
    
    def getIntent(self):
        return self.intent
    
    def getIPCMappingFileName(self):
        return self.IPCMappingFileName
    
    def getMembers(self):
        return self.members
    
    def getModelStructName(self):
        return self.model_struct_name
    
    def getMessage(self):
        return self.message


class SOMEIP_QOS:    
    def __init__(self, model_method):
        self.method_name = model_method["method_name"]
        self.model_class = model_method["model_class"]
        self.ipc_type = model_method["ipc_type"]

        self.type = model_method["ipc_info"]["type"]

        self.intent = model_method["intent"]
        self.arguments = model_method["arguments"] 

    def getMethodName(self):
        return self.method_name
    
    def getIntent(self):
        return self.intent
    
    def getType(self):
        return self.type

    def hasOnAvailable(self):
        if self.type == "on_available":
            return True
        
        return False

class Clock_Method:
    
    def __init__(self, model_method):
        self.method_name = model_method["method_name"]
        self.model_class = model_method["model_class"]
        self.ipc_type = model_method["ipc_type"]

        self.type = model_method["ipc_info"]["type"]
        self.time_period = model_method["ipc_info"]["time_period"]

        self.intent = model_method["intent"]
        self.arguments = model_method["arguments"] 

    def getMethodName(self):
        return self.method_name

    def getIntent(self):
        return self.intent
        
    def getTimerPeriod(self):
        return self.time_period[:-2]
    
