import utils

class ModelStructPrint:
  log = ""
  def __init__(self, model_object, model_method):
    self.log = self.constructPrint(model_object, model_method)

  def constructPrint(self, model_object, model_method):
    result = ""    
    modelName = model_object.getModelName()
    modelStruct = model_method.getModelStructName()
    arg_name = "rtu_" + modelStruct[6:]
    members = model_method.getMembers()
    if isinstance(members, dict):
      members = [members]
    for member in members:
      name = member["model_member_name"]
      if member["model_dtype"] in utils.primitive:
        result += f"\t\tDI_MODEL_LOG_MCTX_DEBUG << \"[{modelName}] DDS {name} \" << static_cast<std::int32_t>({arg_name}->{name});\n"
      elif(utils.Utils.is_enum(member["model_dtype"])):
        result += f"\t\tDI_MODEL_LOG_MCTX_DEBUG << \"[{modelName}] DDS {name} \" << static_cast<std::int32_t>({arg_name}->{name});\n"
      elif member["model_dtype"] == "dds_str_uint8":
        result += f"\t\tconst std::string payload{name}({arg_name}->{name}.payload, {arg_name}->{name}.payload + {arg_name}->{name}.payload_length);\n"
        result += f"\t\tDI_MODEL_LOG_MCTX_DEBUG << \"[{modelName}] DDS {name} \" << payload{name};\n"
      else:
        result += f'\t\tDI_MODEL_LOG_MCTX_DEBUG << \"[{modelName}] DDS {name} \" << \"Cannot print this type\" << std::endl;\n'
    return result
  def substitute(self):
    return self.log
