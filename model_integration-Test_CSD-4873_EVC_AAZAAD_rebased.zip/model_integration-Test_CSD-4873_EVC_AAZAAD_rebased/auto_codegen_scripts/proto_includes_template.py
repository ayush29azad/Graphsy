from string import Template

proto_includes_template = Template(
'''
#ifndef ${MODEL_NAME}_PROTO_INCLUDES_HEADER_H
#define ${MODEL_NAME}_PROTO_INCLUDES_HEADER_H
${includes}
#endif //${MODEL_NAME}_PROTO_INCLUDES_HEADER_H
'''
)
