import sys
import proto_includes_gen
import proto_data_converters_gen
import model_playback_converters_gen
#import environment_utils
import model_json_parser
import utils
import model_init_gen
import model_wrapper_gen
import model_out_gen
import model_global_vars_gen
import filepaths
import os
import dlt_multi_ctx_logger_gen
import input_testing
import global_data
import class_definition
import argparse
from pathlib import Path
import shutil
import subprocess

def clang_format_file_inplace(file_path):
    path=Path(file_path)
    if not path.exists():
        print("[Error]: Couldn't find this file for clang formatting: ", file_path)
        return

    exe=shutil.which("clang-format")
    if not exe:
        print("[Error]: clang-format not found in PATH.")
        return

    cmd = [exe, "-i", file_path]
    subprocess.run(cmd)

class Code_Generation:

    def __init__(self, filepaths_instance):
        self.filepaths_instance = filepaths_instance

    #Generates code for all models given in the simulink models artifact config file along with the cmake files.
    def gen(self):
        # if input_testing.Test.test_common_input_files(self.filepaths_instance) == True:
            
        model_data = model_json_parser.JsonParser.read_json(self.filepaths_instance.getModelConfigFilepath())
        # Test all our input files (including ModelConfig, IPC_Mapping and Proto Files)
        if input_testing.Test(model_data, self.filepaths_instance).validate_and_combine_input_data():
            #If we have valid input data
            print("[Info]: Input Testing and Combining Done")
            model_object = class_definition.Model(model_data)
            print("[Info]: Initialized an object of class Model with the combined input data")
            self.model_code_gen(model_object)
        else:
            print("[Error]: Code Generation stopped due to invalid inputs")
                

    #Generates the model ipc logic .cpp files for the model passed as argument
    def model_code_gen(self, model_object):
        
        proto_includes_header = proto_includes_gen.ProtoIncludesHeadersGen(model_object).substitute()
        #deepcode ignore PT:<This is used to generate the code>
        utils.Utils.write_to_file(self.filepaths_instance.getProtoIncludesHeaderFilepath(), proto_includes_header)

        proto_data_converters = proto_data_converters_gen.ProtoDataConvertersGen(model_object).substitute()
        #deepcode ignore PT:<This is used to generate the code>
        utils.Utils.write_to_file(self.filepaths_instance.getProtoDataConverterFilepath(), proto_data_converters)

        playback_data_converters = model_playback_converters_gen.PlaybackDataConvertersGen(model_object).substitute()
        #deepcode ignore PT:<This is used to generate the code>
        utils.Utils.write_to_file(self.filepaths_instance.getPlaybackDataConverterFilepath(), playback_data_converters)


        model_init = model_init_gen.ModelInit(model_object).substitute()
        #deepcode ignore PT:<This is used to generate the code>
        utils.Utils.write_to_file(self.filepaths_instance.getModelInitFilepath(), model_init)

        hpp_model_global_vars, cpp_model_global_vars = model_global_vars_gen.ModelGlobalVarGen(model_object).substitute()
        utils.Utils.write_to_file(self.filepaths_instance.getModelGlobalVarHeaderFilepath(), hpp_model_global_vars)
        utils.Utils.write_to_file(self.filepaths_instance.getModelGlobalVarFilepath(), cpp_model_global_vars)

        model_outs = model_out_gen.ModelOutGen(model_object).substitute()
        #deepcode ignore PT:<This is used to generate the code>
        utils.Utils.write_to_file(self.filepaths_instance.getModelOutFilepath(), model_outs)

        multi_ctx_logger = dlt_multi_ctx_logger_gen.DltMultiCtxLogger(model_object).substitute()
        #deepcode ignore PT:<This is used to generate the code>
        utils.Utils.write_to_file(self.filepaths_instance.getModelDltloggerFilepath(), multi_ctx_logger)

        model_wrapper = model_wrapper_gen.ModelWrapperHeaderGen(model_object, self.filepaths_instance).substitute()
        #deepcode ignore PT:<This is used to generate the code>
        utils.Utils.write_to_file(self.filepaths_instance.getModelWrapperHeaderFilepath(), model_wrapper)

        file_list = [self.filepaths_instance.getProtoIncludesHeaderFilepath(),
                    self.filepaths_instance.getProtoDataConverterFilepath(),
                    self.filepaths_instance.getPlaybackDataConverterFilepath(),
                    self.filepaths_instance.getModelInitFilepath(),
                    self.filepaths_instance.getModelGlobalVarHeaderFilepath(),
                    self.filepaths_instance.getModelGlobalVarFilepath(),
                    self.filepaths_instance.getModelOutFilepath(),
                    self.filepaths_instance.getModelDltloggerFilepath(),
                    self.filepaths_instance.getModelWrapperHeaderFilepath()
                    ]

        for file_name in file_list:
            print("[Info]: Running clang-format in place on auto generated file: ", file_name)
            clang_format_file_inplace(file_name)


if __name__ == "__main__":
    print("---------------------Main---------------------")

    parser = argparse.ArgumentParser()

    parser.add_argument("--modelname", help="name of the model you want to generate code for", required=True)
    parser.add_argument("--modelconfig", help="path to the model config json file", required=True)
    parser.add_argument("--codegendir", help="path to directory you want to generate the code", required=True)
    parser.add_argument("--servicemapping", help="path to someip service mapping json file", required=True)
    parser.add_argument("--servicedefdir", help="path to someip service definition json files dir", required=True)
    parser.add_argument("--ipcmappingdir", help="path to ipcmapping files dir", required=True)

    args = parser.parse_args()

    Code_Generation(filepaths.Filepaths(args)).gen()
