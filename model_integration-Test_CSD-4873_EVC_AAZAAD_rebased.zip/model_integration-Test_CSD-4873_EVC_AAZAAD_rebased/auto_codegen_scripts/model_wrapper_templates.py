from string import Template


someip_create_consumer = Template('''
    vsomeip::instance_t const $instaceIdName = instanceMapping.get_service_instanceId("$service_name");
    vsomeip::instance_t const $serviceIdName = static_cast<vsomeip::instance_t>($service_id);

    DI_MODEL_LOG_MCTX_INFO << "$instaceIdName-> " << $instaceIdName << std::endl;
    auto const ${consumer}Consumer = someipHandler${vid}->create_consumer($serviceIdName, $instaceIdName);
''')

someip_create_provider = Template('''
    vsomeip::instance_t const $instaceIdName = instanceMapping.get_service_instanceId("$service_name");
    vsomeip::instance_t const $serviceIdName = static_cast<vsomeip::instance_t>($service_id);

    DI_MODEL_LOG_MCTX_INFO << "$instaceIdName-> " << $instaceIdName << std::endl;
    auto const ${provider}Provider = someipHandler${vid}->create_provider($serviceIdName, $instaceIdName);
''')

someip_notify_in = Template('''
    auto const ${model_fun} = [mModelPtr=mModelPtr, dltAppId=dltAppId]($model_notify const *const modelData) {
      #if defined(ENABLE_MODEL_PLAYBACK) 
        bool jsonPayload = true;
        #if defined(ENABLE_DLT_LOGGING)
          jsonPayload = generic_logging::get_log_level_for_dlt_only(dltAppId,logging::ctx) == boost::log::trivial::severity_level::trace;
        #endif
        if(jsonPayload){
          Json::Value obj = Json::objectValue;
          obj["model_func_name"] = "$model_fun";
          obj["args"] = Json::arrayValue;
          obj["args"][0] = Json::objectValue;
          obj["args"][0]["$model_notify"] = Json::objectValue;
          PlaybackDataConverter${model_name}::create_json(modelData, obj["args"][0]["$model_notify"] );
          Json::StreamWriterBuilder wBuilder;
          wBuilder["indentation"] = "";
          const std::string document = Json::writeString(wBuilder,obj);
          DI_MODEL_LOG_MCTX_DEBUG << document << "\\n";
          // Assuming that the following function does not return anything
          // Type system should catch it if it does actually return something
        }
      #endif
      mModelPtr->$model_fun(modelData);
    };
    someipHandler${vid}->notify_in<${package_name}::${proto_notify}, $model_notify>(${consumer}Consumer, $event_Name, std::vector<uint16_t> $grps, ${model_fun});
''')

someip_notify_in_empty = Template('''
    auto const ${model_fun} = [mModelPtr=mModelPtr, dltAppId=dltAppId]() {
      #if defined(ENABLE_MODEL_PLAYBACK) 
        bool jsonPayload = true;
        #if defined(ENABLE_DLT_LOGGING)
          jsonPayload = generic_logging::get_log_level_for_dlt_only(dltAppId,logging::ctx) == boost::log::trivial::severity_level::trace;
        #endif
        if(jsonPayload){
          Json::Value obj = Json::objectValue;
          obj["model_func_name"] = "$model_fun";
          obj["args"] = Json::arrayValue;
          Json::StreamWriterBuilder wBuilder;
          wBuilder["indentation"] = "";
          const std::string document = Json::writeString(wBuilder,obj);
          DI_MODEL_LOG_MCTX_DEBUG << document << "\\n";
          // Assuming that the following function does not return anything
          // Type system should catch it if it does actually return something
        }
      #endif
      mModelPtr->$model_fun();
    };
    someipHandler${vid}->notify_in<${package_name}::${proto_notify}>(${consumer}Consumer, $event_Name, std::vector<uint16_t> $grps, ${model_fun});
''')

someip_response_in = Template('''
    auto const ${model_fun} = [mModelPtr=mModelPtr, dltAppId=dltAppId]($model_get_response const *const modelData) {
      #if defined(ENABLE_MODEL_PLAYBACK) 
        bool jsonPayload = true;
        #if defined(ENABLE_DLT_LOGGING)
          jsonPayload = generic_logging::get_log_level_for_dlt_only(dltAppId,logging::ctx) == boost::log::trivial::severity_level::trace;
        #endif
        if(jsonPayload){
          Json::Value obj = Json::objectValue;
          obj["model_func_name"] = "$model_fun";
          obj["args"] = Json::arrayValue;
          obj["args"][0] = Json::objectValue;
          obj["args"][0]["$model_get_response"] = Json::objectValue;
          PlaybackDataConverter${model_name}::create_json(modelData, obj["args"][0]["$model_get_response"] );
          Json::StreamWriterBuilder wBuilder;
          wBuilder["indentation"] = "";
          const std::string document = Json::writeString(wBuilder,obj);
          DI_MODEL_LOG_MCTX_DEBUG << document << "\\n";
          // Assuming that the following function does not return anything
          // Type system should catch it if it does actually return something
        }
      #endif
      mModelPtr->$model_fun(modelData);
    };
    someipHandler${vid}->response_in<${package_name}::${proto_get_request}, ${package_name}::${proto_get_response}, $model_get_response>(${consumer}Consumer, $method_Name, ${model_fun});
''')

someip_unpaired_response_in = Template('''
    someipHandler${vid}->unpaired_response_in<${package_name}::${proto_get_request}, ${package_name}::${proto_get_response}>(${consumer}Consumer, $method_Name);
''')

someip_notify_out = Template('''
    someipHandler${vid}->notify_out<${package_name}::${proto_notify}>(${provider}Provider, $event_Name, std::vector<uint16_t> $grps);
''')

someip_request_in_empty = Template('''
    auto const ${model_fun} = [mModelPtr=mModelPtr, dltAppId=dltAppId]() {
      #if defined(ENABLE_MODEL_PLAYBACK) 
        bool jsonPayload = true;
        #if defined(ENABLE_DLT_LOGGING)
          jsonPayload = generic_logging::get_log_level_for_dlt_only(dltAppId,logging::ctx) == boost::log::trivial::severity_level::trace;
        #endif
        if(jsonPayload){
          Json::Value obj = Json::objectValue;
          obj["model_func_name"] = "$model_fun";
          obj["args"] = Json::arrayValue;
          Json::StreamWriterBuilder wBuilder;
          wBuilder["indentation"] = "";
          const std::string document = Json::writeString(wBuilder,obj);
          DI_MODEL_LOG_MCTX_DEBUG << document << "\\n";
          // Assuming that the following function does not return anything
          // Type system should catch it if it does actually return something
        }
      #endif
      mModelPtr->$model_fun();
    };
    someipHandler${vid}->request_in<${package_name}::${proto_get_request}, ${package_name}::${proto_get_response}>(${provider}Provider, $method_Name, ${model_fun});
''')


someip_request_in_nonempty = Template('''
    auto const ${model_fun} = [mModelPtr=mModelPtr, dltAppId=dltAppId]($model_get_request const *const modelData) {    
      #if defined(ENABLE_MODEL_PLAYBACK) 
        bool jsonPayload = true;
        #if defined(ENABLE_DLT_LOGGING)
          jsonPayload = generic_logging::get_log_level_for_dlt_only(dltAppId,logging::ctx) == boost::log::trivial::severity_level::trace;
        #endif
        if(jsonPayload){
          Json::Value obj = Json::objectValue;
          obj["model_func_name"] = "$model_fun";
          obj["args"] = Json::arrayValue;
          obj["args"][0] = Json::objectValue;
          obj["args"][0]["$model_get_request"] = Json::objectValue;
          PlaybackDataConverter${model_name}::create_json(modelData, obj["args"][0]["$model_get_request"] );
          Json::StreamWriterBuilder wBuilder;
          wBuilder["indentation"] = "";
          const std::string document = Json::writeString(wBuilder,obj);
          DI_MODEL_LOG_MCTX_DEBUG << document << "\\n";
          // Assuming that the following function does not return anything
          // Type system should catch it if it does actually return something
        }
      #endif
      mModelPtr->$model_fun(modelData);
    };
    someipHandler${vid}->request_in<${package_name}::${proto_get_request}, ${package_name}::${proto_get_response}, $model_get_request>(${provider}Provider, $method_Name, ${model_fun});
''')

id_declaration_template = Template('''
    uint16_t $idName;''')

id_definition_template = Template('''
      $idName(static_cast<uint16_t>($id)),''')

on_available_template = Template('''
    auto const on_available = [mModelPtr=mModelPtr, dltAppId=dltAppId](uint16_t const serviceId, uint16_t const instanceId, bool const isAvailable) {
      #if defined(ENABLE_MODEL_PLAYBACK) 
        bool jsonPayload = true;
        #if defined(ENABLE_DLT_LOGGING)
          jsonPayload = generic_logging::get_log_level_for_dlt_only(dltAppId,logging::ctx) == boost::log::trivial::severity_level::trace;
        #endif
        if(jsonPayload){
          Json::Value obj = Json::objectValue;
          obj["model_func_name"] = "$model_fun";
          obj["args"] = Json::arrayValue;
          
          obj["args"][0] = Json::objectValue;
          obj["args"][0]["serviceId"] = serviceId;
          obj["args"][1] = Json::objectValue;
          obj["args"][1]["instanceId"] = instanceId;
          obj["args"][2] = Json::objectValue;
          obj["args"][2]["isAvailable"] = isAvailable;
              
          Json::StreamWriterBuilder wBuilder;
          wBuilder["indentation"] = "";
          const std::string document = Json::writeString(wBuilder,obj);
          DI_MODEL_LOG_MCTX_DEBUG << document << "\\n";
        }
      #endif
      mModelPtr->$model_fun(serviceId,instanceId,isAvailable);
    };
''')

set_on_available = Template('''
    someipHandler${vid}->set_on_available(${consumer}Consumer, on_available);
    ''')

dds_topic_out = Template('''
    {
      std::unique_ptr<$topic_name_pubsub> ${topic_name_small}Ptr = std::make_unique<$topic_name_pubsub>();
      const bool topicOutRegistrationStatus = ddsHandler->topic_out("$topic_name", ${topic_name_small}Ptr.release()) ;
      if(topicOutRegistrationStatus == true)
      {
        DI_MODEL_LOG_MCTX_INFO << "[Info]  : Registration of DDS publish topic, dds_ipc::$topic_name Success!!";
      }
      else
      {
        DI_MODEL_LOG_MCTX_ERROR << "[error]  : Registration of DDS publish topic, dds_ipc::$topic_name failed!!";
      }
    }
    ''')

dds_topic_in = Template('''
    {
      std::function<void(const ${model_struct} *)> modelCallBack{};
      modelCallBack = [mModelPtr = mModelPtr, dltAppId=dltAppId](const ${model_struct} * modelData){
        #if defined(ENABLE_MODEL_PLAYBACK) 
          bool jsonPayload = true;
          #if defined(ENABLE_DLT_LOGGING)
            jsonPayload = generic_logging::get_log_level_for_dlt_only(dltAppId,logging::ctx) == boost::log::trivial::severity_level::trace;
          #endif
          if(jsonPayload){
        
          /*{
            Json::Value obj = Json::objectValue;
            obj["model_func_name"] = "${model_fun}";
            obj["args"] = Json::arrayValue;
            obj["args"][0] = Json::objectValue;
            obj["args"][0]["$model_struct"] = Json::objectValue;
            PlaybackDataConverter${model_name}::create_json(modelData, obj["args"][0]["$model_struct"] );
            Json::StreamWriterBuilder wBuilder;
            wBuilder["indentation"] = "";
            const std::string document = Json::writeString(wBuilder,obj);
            DI_MODEL_LOG_MCTX_DEBUG << document << "\\n";
          }*/
          }
        #endif
        mModelPtr->${model_fun}(modelData);
        };
      
      const auto callBack = [modelCallBack, ddsHandler = ddsHandler.get()](){
        ${model_struct} modelData;
        if (ddsHandler->recv(&modelData, "$topic_name") == true)
        {
          DI_MODEL_LOG_MCTX_DEBUG << "Received $topic_name data from ddsHandler" << std::endl;
          modelCallBack(&modelData);
        }
        else
        {
          DI_MODEL_LOG_MCTX_WARN << "[Warn]: No data read from ddsHandler" << std::endl;
        }
      };                
  
      std::unique_ptr<$topic_name_pubsub> ${topic_name_small}Ptr = std::make_unique<$topic_name_pubsub>();
      const bool topicInRegistrationStatus = ddsHandler->topic_in("$topic_name", ${topic_name_small}Ptr.release(), callBack);
      if(topicInRegistrationStatus == true)
      {
        DI_MODEL_LOG_MCTX_INFO << "[Info]  : Registration of DDS subscriber topic, dds_ipc::$topic_name Success!!";
      }
      else
      {
        DI_MODEL_LOG_MCTX_ERROR << "[error]  : Registration of DDS subscriber topic, dds_ipc::$topic_name failed!!";
      }
    }
    ''')

timer_template = Template('''
    int32_t const timer_period = static_cast<int32_t>($timer_period);
    const std::string _threadName = std::string("$model_name") + std::string("_timerThread");

    auto const timerFun = [mModelPtr=mModelPtr, dltAppId=dltAppId]() {
      #if defined(ENABLE_MODEL_PLAYBACK) 
        bool jsonPayload = true;
        #if defined(ENABLE_DLT_LOGGING)
          jsonPayload = generic_logging::get_log_level_for_dlt_only(dltAppId,logging::ctx) == boost::log::trivial::severity_level::trace;
        #endif
        if(jsonPayload){
          Json::Value obj = Json::objectValue;
          obj["model_func_name"] = "$model_timer_fun";
          obj["args"] = Json::arrayValue;
          Json::StreamWriterBuilder wBuilder;
          wBuilder["indentation"] = "";
          const std::string document = Json::writeString(wBuilder,obj);
          DI_MODEL_LOG_MCTX_VERBOSE << document << "\\n";
          // Assuming that the following function does not return anything
          // Type system should catch it if it does actually return somethingg 
        }
      #endif
      mModelPtr->$model_timer_fun();
    };
    mModelController->init_model_timer(timerFun, timer_period, _threadName);
''')

someip_handlers = Template('''
      std::shared_ptr<SomeipCommunicationHandler> someipHandler${vid} = mModelController->get_someip_handler("${key}");  
''')

wrapper_init_template = Template(
'''
    /// @brief Implements ModelLibInterface init
    ///
    /// @satisfy{Requirement01321452,Requirement01321457,Requirement01321459,Requirement01321608,Requirement01321460,Requirement01321463,Requirement01321626,Requirement01340698,Requirement01321467,Requirement01321613,Requirement01321612,Requirement01415381,Requirement01415387,Requirement01415483, Requirement01415577, Requirement01446314, Requirement01446316, Requirement01446329, Requirement01445541}
    ///
    /// @param context Launcher context which injects all comms dependencies
    void init(std::shared_ptr<cccm::di::launcher::LauncherContext> context) final
    {

      const auto vsomeipMap = context->someipApp_map;
      const std::shared_ptr<WorkExecutor>& workExecutor = context->workExecutor;
      const std::shared_ptr<jlr::cccm::di::dds::DDSEntityFactoryInterface>& ddsFactory = context->ddsFactory;
      const std::string& dltAppId = context->dltApplication.first;
      const std::string& dltAppDescription = context->dltApplication.second;
      const std::string& someipMappingFilename = context->someipMappingFilename;

      #if defined(ENABLE_DLT_LOGGING)
        generic_logging::initialize_loggers(
          dltAppId, 
          logging::ctx, 
          dltAppDescription, 
          "DI ${model_name}",
          std::vector<generic_logging::LoggerKind>{generic_logging::LoggerKind::dlt_log}, 
          logging::g_use_multi_contexts);
      #endif

      // Output which release package this library is from
      DI_MODEL_LOG_MCTX_INFO << "Release version information: " << version::release_version << std::endl;

      if(nullptr == workExecutor)
      {
        DI_MODEL_LOG_MCTX_WARN << "[Warn] : WorkExecutor is NULL, Can Impact the latency";
      }

      this->mModelController = std::make_shared<ModelControllerType>();
      // Set global model controller
      {
        // BUG: Make this operation atomic. If two threads try to create a controller at the same time, this will result in unexpected behavior.
        // However, this can be ignored since that is not expected to happen in the current architecture.
        if (!jlr::cccm::di::get_model_controller().expired())
        {
          throw std::runtime_error("Model controller already exists. Cannot create a new one.");
        }
        jlr::cccm::di::set_model_controller(this->mModelController);
      }
      
      mModelController->init_model(mModelPtr);

      {
        int32_t const numOfvIds = ${numVIds};
        if(vsomeipMap.size() < numOfvIds )
        {
          throw std::runtime_error("Can not initialize someip handlers, number of vid in vsomeip services and in arguments do not match!!");
        }
        const std::vector<std::string> vids = {${vids}};
        bool allPresent = true;
        for(std::size_t i = 0; i < vids.size(); ++i)
        {
          if(vsomeipMap.find(vids[i]) == vsomeipMap.end())
          {
            allPresent = false;
            DI_MODEL_LOG_MCTX_ERROR << "[Error] : vid " << vids[i] << " is not passed in arguments"<< std::endl;
          }
        }
        if(allPresent == false)
        {
          throw std::runtime_error("Can not initialize someip handlers, vids in vsomeip services and in arguments do not match!!");
        }
      }
                                      
      // VSOMEIP COMMS HANDLING
        for(auto it = vsomeipMap.begin(); it != vsomeipMap.end(); ++it){
          const std::shared_ptr<vsomeip::application> _app = it->second;
          if(_app != nullptr){
            const std::string _key = it->first;
            mModelController->init_model_someip(_app, _key);
          }
        }

        ${someip_handlers}
          
        bool parsed = false;
        
        ServiceInstanceIdMapping instanceMapping;

        #if defined(INSTANCE_ID_MAPPING)
        parsed = instanceMapping.parse_json(someipMappingFilename);
        if(parsed == false)
        {
          DI_MODEL_LOG_MCTX_WARN << "[Warn] Couldn't parse someip instance id json file, using defaults" << std::endl;
        }
        #endif

        // SOMEIP initialisation
        ${someip_init}


        // On available
        ${on_available}

        ${set_oa}
        
                                      
      // DDS COMMS HANDLING 

      mModelController->init_model_dds(ddsFactory, dltAppId);
      auto ddsHandler = mModelController->get_dds_handler();
      ddsHandler->set_work_executor(workExecutor);
                                  
      ${dds_init}
      // MODEL TIMER HANDLING 

      ${timer_init}
    }
'''
)

wrapper_terminate_template = Template(
'''
    /// @brief Implements ModelLibInterface terminate
    void terminate() final
    {         
      mModelController->terminate();
      // https://dev.to/fenbf/how-a-weakptr-might-prevent-full-memory-cleanup-of-managed-object-i0i
      jlr::cccm::di::set_model_controller({});
    }
'''
)


wrapper_class_declaration_template = Template(
'''
namespace cccm::di::models
{
  /// @brief The Concrete Implementation of ModelLibInterface for ${model_name}
  ///
  /// @details This class will implement init and terminate methods of 
  /// ModelLibInterface to register comms with the models as well as timers
  ///
  /// This class is templated to allow injection of a mock model which follows
  /// the same interface as ${model_name} which allows to test 
  ///
  /// @tparam ModelClasss Either ${model_name} or a mock model which follows the 
  /// the same interface
  template<typename ModelClass>
  class Wrapper${model_name} final: public cccm::di::ModelLibInterface
  {
    private:
    
    using PlaybackDataConverter${model_name} = jlr::cccm::di::PlaybackDataConverter${model_name};
    using ServiceInstanceIdMapping = ipc_wrapper::instance_id_mapping::ServiceInstanceIdMapping;
    // @brief alias of ModelController template for ModelClass 
    using ModelControllerType = jlr::cccm::di::ModelController<ModelClass>;
    using SomeipCommunicationHandler = jlr::cccm::di::SomeipCommunicationHandler;

    std::shared_ptr<ModelClass> mModelPtr;
    std::shared_ptr<ModelControllerType> mModelController;

    ${event_method_id_declarations}
    
    public:

    /// @brief deleted default constructor to enforce initialisation with a model
    Wrapper${model_name}() = delete;

    /// @brief constructs the wrapper with a given model instance 
    Wrapper${model_name}(
      const std::shared_ptr<ModelClass>& _mModelPtr
    ): 
      cccm::di::ModelLibInterface(),
      mModelPtr(_mModelPtr),
      ${event_method_id_definition}
    {
    }

    /// @brief Default destructor
    ~Wrapper${model_name}() override = default;                      

${wrapper_init}

${wrapper_terminate}

  };
};
'''
)


wrapper_header = Template('''#ifndef JLRCCCM_MODEL_IPC_WRAPPER_HEADER_${model_name}
#define JLRCCCM_MODEL_IPC_WRAPPER_HEADER_${model_name}

#include <iostream>
#include <memory>

#include "ModelLibInterface.h"
#include "types.h"
#include "dlt_logger.hpp"
#include "PlaybackDataConverter${model_name}.hpp"
#include "ProtoIncludes${model_name}.hpp"           
#include "release_version.h"
#include "SomeipInstanceIdMapping.hpp"
#include "ModelController.hpp"
#include "${model_name}_global_vars.hpp"

${wrapper_class_declaration}

#endif

''')
