
import model_json_parser
import os
import filepaths
import global_data
from cmake_gen import CMakeLists, CMake
import utils

#@todo: Hardcodede the autocodegen dir as the root and other inputs and folders added here in autocodegen folder
root_dir_cmake = "$ENV{ROOTPATH}"


models_path = global_data.model_path
out_lib_path_cmake = global_data.out_lib_path_cmake
shared_headers_folder_path_cmake = root_dir_cmake + "/" + global_data.common_data["shared_headers_folder_name"]

class CommonCmakeGen:
    def __init__(self):
        pass
    @staticmethod
    def gen_topic_idls():
        dds_topics_out_path_cmake = out_lib_path_cmake + "/" + global_data.common_data["out_paths"]["dds_topics"]
        idl_path = filepaths.root + "/" + global_data.common_data["input_paths"]["idls_folder"]
        target_install = []
        # files = os.listdir(idl_path)
        idlFiles = os.listdir(filepaths.getIdlFolderPath())
        add_library = []
        model_include_dirs_common = []
        model_include_dirs_common += [shared_headers_folder_path_cmake]
        for idlFile in idlFiles:
            if len(idlFile.split(".")) == 2 : 
                idlName, ext = idlFile.split(".")
                if ext == "idl" or ext == "IDL" : 
                    file1 = "${CMAKE_CURRENT_LIST_DIR}/gen/" + idlName + ".cxx"
                    file2 = "${CMAKE_CURRENT_LIST_DIR}/gen/" + idlName + "PubSubTypes.cxx" 
                    idl_dict = {"name": idlName, "data": [file1,file2]}
                    add_library.append(idl_dict)
                    target_install.append({"LINUX":dds_topics_out_path_cmake, "name": idlName})
        cmake_dict = {
            "name" : "all_topics_cmake",
            "type" : "lib",
            "src" : {"data": add_library, "type":"SHARED", "flag": False},  
            "include_dirs_common" : model_include_dirs_common,
            "target_install" : {"data":target_install, "flag":False}
        }
        #deepcode ignore PT:<This is used to generate the code>
        utils.Utils.write_to_file(idl_path + "/CMakeLists.txt", CMakeLists(cmake_dict).substitute())

    @staticmethod
    def common_dds_proto_gen():
        common_dds_proto_build_path = filepaths.root + "/" + global_data.common_data["input_paths"]["common_dds_proto_build_cmake"]

        if not os.path.exists(common_dds_proto_build_path):
            include_cmakelists = [global_data.common_data["input_paths"]["idls_folder"]]

            include_cmakelists_paths = []
            for item in include_cmakelists:
                include_cmakelists_paths.append("${CMAKE_CURRENT_SOURCE_DIR}" + "/" + item + "/" + "CMakeLists.txt")

            cmake_dict = {
                "set" : {"ROOT_DIR": filepaths.root ,"MODEL_DIR" : models_path},
                "include" : include_cmakelists_paths
            }
            utils.Utils.write_to_file(common_dds_proto_build_path, CMake(cmake_dict).substitute())

    @staticmethod
    def common_models_gen():
        include_dirs = []

        include_cmakelists_paths = []

        for model_name in global_data.simulink_data["models"]:
            model_source_dir = model_name + "_ert_rtw"
            model_cmake_repo = global_data.common_data["input_paths"]["model_path"] + "/" + model_source_dir

            include_cmakelists_paths.append("${CMAKE_CURRENT_SOURCE_DIR}" + "/" + model_cmake_repo + "/" + "CMakeLists.txt")

        cmake_dict = {
            "set" : {"ROOT_DIR": filepaths.root ,"MODEL_DIR" : models_path},
            "include_dirs_common" : include_dirs,
            "include" : include_cmakelists_paths,
        }
        #deepcode ignore PT:<This is used to generate the code>
        utils.Utils.write_to_file(filepaths.root + "/model_ipc/models/models_build.cmake", CMake(cmake_dict).substitute())

    @staticmethod
    def common_mock_vals_gen():
        vsomeip_repo = global_data.common_data["input_paths"]["vsomeip_repo"]
        val_vsomeip_servers_repo = global_data.common_data["input_paths"]["val_vsomeip_servers_repo"]
        val_vsomeip_servers_path = filepaths.root + "/" + vsomeip_repo + "/" + val_vsomeip_servers_repo

        include_dirs = []
        include_dirs.append("${CMAKE_CURRENT_LIST_DIR}/proto_files/gen")
        include_dirs.append("${CMAKE_CURRENT_SOURCE_DIR}/utils")

        include_cmakelists_paths = []
        for mock_val_name in global_data.simulink_data["mock_vals"]:
            mock_val_cmake_repo = val_vsomeip_servers_path + "/" + mock_val_name
            mock_val_rel_path = vsomeip_repo + "/" + val_vsomeip_servers_repo + "/" + mock_val_name

            include_cmakelists_paths.append("${CMAKE_CURRENT_SOURCE_DIR}" + "/" + mock_val_rel_path + "/" + "CMakeLists.txt")

        cmake_dict = {
            "set" : {"ROOT_DIR": filepaths.root ,"MODEL_DIR" : models_path},
            "include_dirs_common" : include_dirs,
            "include" : include_cmakelists_paths,
        }
        #deepcode ignore PT:<This is used to generate the code>
        utils.Utils.write_to_file(filepaths.root + "/test/val_vsomeip_servers/val_vsomeip_servers.cmake", CMake(cmake_dict).substitute())

    @staticmethod
    def gen():
      CommonCmakeGen.gen_topic_idls()
      CommonCmakeGen.common_dds_proto_gen()
      CommonCmakeGen.common_models_gen()
      CommonCmakeGen.common_mock_vals_gen()

if __name__ == "__main__":
    CommonCmakeGen().gen()    
