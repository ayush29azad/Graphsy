dependentStructsList = set()

#Dictionary containing mapping of ipc_mapping_file_name to ipc_mapping_data
ipc_mapping_data = {}
