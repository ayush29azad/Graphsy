import validate_json
import model_json_parser
import global_data
import os

class Test:
    # T3best Class Constructor

    json_schema_validator = validate_json.validateJsonSchema()

    def __init__(self, model_data, filepaths_instance):
        self.model_data = model_data
        self.filepaths_instance = filepaths_instance
        self.validated_serviceJson_files = []
    
    # Test all input data files and combine them
    def validate_and_combine_input_data(self):

        #If JSON Schema of the model config file is invalid
        if not Test.json_schema_validator.validate_modelConfig(self.model_data):

            if "model_name" in self.model_data and isinstance(self.model_data["model_name"], str):
                print(f"[Error]: JSON Schema Validation Failed for " + self.model_data["model_name"] + ".json" )
            else:
                print(f"[Error]: JSON Schema Validation Failed for _____.json" )
            return False
        
        #If JSON Schema of the model config file is correct
        print(f"[Info]: JSON Schema Validation Succesful for " + self.model_data["model_name"] + ".json")

        #If there is a problem in the methods data in IPC Mapping/Service Json files or their linking
        if self.test_and_combine_all_methods_data() == False:
            return False
        
        #If no problem found so far, consider the input as valid
        print(f"[Info]: Multiple JSON files linking checked succesfully")
        return True
    
    #Check the data for each method's message in other input files and combine data from other files into one
    def test_and_combine_all_methods_data(self):
        for method in self.model_data["model_methods"]:
            if method["ipc_type"] == "vsomeip":
                if self.test_and_combine_vsomeip_data(method) == False:
                    return False
            elif method["ipc_type"] == "dds":
                if self.test_and_combine_fastdds_data(method) == False:
                    return False
            elif method["ipc_type"] == "ml_API":
                if self.test_and_combine_ml_api_data(method) == False:
                    return False
        return True
    
    #Test and combine VSOMEIP data for the method from all input files(IPC mapping, Service Json, someip-id-mapping, etc.)
    def test_and_combine_vsomeip_data(self, method):
        
        ipc_mapping_filename = method["ipc_info"]["ipc_mapping_file"]

        #If ipc mapping file already validated before and it's data has been added to the global ipc_mapping_data dict
        if ipc_mapping_filename in global_data.ipc_mapping_data:
            ipc_mapping_data = global_data.ipc_mapping_data[ipc_mapping_filename]
            print(f"[Info]: JSON Schema Validation for IPC Mapping file: {ipc_mapping_filename} already done before")

        #If ipc mapping file has not been validated before
        else:
            ipc_mapping_data = model_json_parser.JsonParser.read_json(os.path.join(self.filepaths_instance.getIPCMappingDir(), ipc_mapping_filename))
            #If JSON Schema of the ipc mapping file is invalid
            if not Test.json_schema_validator.validate_ipc_mapping(ipc_mapping_data):
                print(f"[Error]: JSON Schema Validation Failed for IPC Mapping file: {ipc_mapping_filename}")
                return False
            #If JSON Schema of the ipc mapping file is valid
            print(f"[Info]: JSON Schema Validation Succesful for IPC Mapping file: {ipc_mapping_filename}")
            global_data.ipc_mapping_data[ipc_mapping_filename] = ipc_mapping_data
        
        vsomeip_message = method["ipc_info"]["message"]
        message_Found = False
        # Search for the given method's message in the ipc mapping file
        for message in ipc_mapping_data["messages"]:
            #If message found in ipc mapping file
            if message["message"] == vsomeip_message:
                message_Found = True
                method["additional_info"] = message
                method["proto_filename"] = ipc_mapping_data["proto_file"]
                break

        #If message NOT found in ipc mapping file
        if not message_Found:
            print(f"[Error]: Vsomeip message: {vsomeip_message} not found  in file: {ipc_mapping_filename}")
            return False
        

        vsomeip_event_type = method["ipc_info"]["event_type"] #Event type can be request/response/event
       
        service_json_filename = ipc_mapping_data["service_definition_file"]
        service_json_file = model_json_parser.JsonParser.read_json(os.path.join(self.filepaths_instance.getServiceDefinitionDirPath(), service_json_filename))

        # If the service json file has not been validated before
        if service_json_filename not in self.validated_serviceJson_files:
            # If the service json file schema is not valid
            if not Test.json_schema_validator.validate_serviceJson(service_json_file):
                print(f"[Error]: JSON Schema Validation Failed for Service Json file: {service_json_filename}")
                return False
            print(f"[Info]: JSON Schema Validation Succesful for Service Json file: {service_json_filename}")
            # If the service json file is valid, add it to the validated_serviceJson_files list
            self.validated_serviceJson_files.append(service_json_filename)

        #If the current method is of type "Event"
        if vsomeip_event_type == "event":
            event_found = False

            #check for dict & array of service_json_file["service"]["EventMappings"]
            if isinstance(service_json_file["service"]["EventMappings"], dict):
                #If event message found
                if service_json_file["service"]["EventMappings"]["EventMessage"] == vsomeip_message:
                    event_found = True
                    event_id = service_json_file["service"]["EventMappings"]["EventID"]
            else:
                #Search for the event message in the event mappings of the service json files
                for eventMapping in service_json_file["service"]["EventMappings"]:
                    #If event message found
                    if eventMapping["EventMessage"] == vsomeip_message:
                        event_found = True
                        event_id = eventMapping["EventID"]
                        break

            #If event message is not found
            if not event_found:
                print(f"[Error]: Vsomeip event message: {vsomeip_message} not found in file: {service_json_filename}")
                return False
            
            eventgroups = []
            
            #check for dict & array type of service_json_file["service"]["eventgroups"]
            if isinstance(service_json_file["service"]["eventgroups"], dict):
                #If event-id is part of some eventgroup
                if event_id in service_json_file["service"]["eventgroups"]["events"]:
                    eventgroups.append(service_json_file["service"]["eventgroups"]["eventgroup"])
            else:
                #Search for the event-id of our event message in the eventgroups
                for eventgroup in service_json_file["service"]["eventgroups"]:
                    #If event-id is part of some eventgroup
                    if event_id in eventgroup["events"]:
                        eventgroups.append(eventgroup["eventgroup"])
                
            #If event-id is not part of any eventgroup
            if len(eventgroups) == 0:
                print(f"[Error]: Vsomeip event {vsomeip_message} ({event_id}) not part of any eventgroup in file: {service_json_filename}")
                return False
            
            #To combine our input into one file, add data from the other files under the key: additional_info
            method["additional_info"]["EventID"] = event_id
            method["additional_info"]["eventgroupIDs"] = eventgroups
            method["additional_info"]["vid"] = service_json_file["service"]["vid"]
            method["additional_info"]["service_definition_file"] = service_json_filename
            
        else:
            method_found = False
            #check the condition for array & dict type of MethodMappings object.
            if isinstance(service_json_file["service"]["MethodMappings"], dict):
                #If request message found(given that our message is of request type)
                if (vsomeip_event_type == "request" and service_json_file["service"]["MethodMappings"]["RequestMessage"] == vsomeip_message):
                    method_found = True

                    #To combine our input into one file, add data from the other files under the key: additional_info
                    method["additional_info"]["MethodID"] = service_json_file["service"]["MethodMappings"]["MethodID"]
                    #Add the corresponding response message for our given request message
                    method["additional_info"]["corresponding_message"] = service_json_file["service"]["MethodMappings"]["ResponseMessage"]

                #If response message found(given that our message is of reponse type)
                elif (vsomeip_event_type == "response" and service_json_file["service"]["MethodMappings"]["ResponseMessage"] == vsomeip_message):
                    method_found = True

                    #To combine our input into one file, add data from the other files under the key: additional_info
                    method["additional_info"]["MethodID"] = service_json_file["service"]["MethodMappings"]["MethodID"]
                    #Add the corresponding request message for our given response message
                    method["additional_info"]["corresponding_message"] = service_json_file["service"]["MethodMappings"]["RequestMessage"]
            else:
                #Search for the method's message in the method mappings of the service json files
                for methodMapping in service_json_file["service"]["MethodMappings"]:

                    #If request message found(given that our message is of request type)
                    if (vsomeip_event_type == "request" and methodMapping["RequestMessage"] == vsomeip_message):
                        method_found = True

                        #To combine our input into one file, add data from the other files under the key: additional_info
                        method["additional_info"]["MethodID"] = methodMapping["MethodID"]
                        #Add the corresponding response message for our given request message
                        method["additional_info"]["corresponding_message"] = methodMapping["ResponseMessage"]
                        break

                    #If response message found(given that our message is of reponse type)
                    elif (vsomeip_event_type == "response" and methodMapping["ResponseMessage"] == vsomeip_message):
                        method_found = True

                        #To combine our input into one file, add data from the other files under the key: additional_info
                        method["additional_info"]["MethodID"] = methodMapping["MethodID"]
                        #Add the corresponding request message for our given response message
                        method["additional_info"]["corresponding_message"] = methodMapping["RequestMessage"]
                        break

            #If request/response message not found
            if not method_found:
                print(f"[Error]: Vsomeip message: {vsomeip_message} not found in file: {service_json_filename}")
                return False
            
        #If service name found in the someip-id-mapping file, add the service_name and its corresponding service id in the additional info
        method["additional_info"]["service_name"] = service_json_file["service"]["Name"]
        method["additional_info"]["ServiceID"] = service_json_file["service"]["ServiceID"]
        method["additional_info"]["vid"] = service_json_file["service"]["vid"]
        method["additional_info"]["service_definition_file"] = service_json_filename

    #Test and combine DDS data for the method from all input files(IPC mapping)
    def test_and_combine_fastdds_data(self, method):
        ipc_mapping_filename = method["ipc_info"]["ipc_mapping_file"]

        #If ipc mapping file already validated before and it's data has been added to the global ipc_mapping_data dict
        if ipc_mapping_filename in global_data.ipc_mapping_data:
            ipc_mapping_data = global_data.ipc_mapping_data[ipc_mapping_filename]
            print(f"[Info]: JSON Schema Validation for IPC Mapping file: {ipc_mapping_filename} already done before")

        #If ipc mapping file has not been validated before
        else:
            ipc_mapping_data = model_json_parser.JsonParser.read_json(os.path.join(self.filepaths_instance.getIPCMappingDir(), ipc_mapping_filename))

            #If JSON Schema of the ipc mapping file is invalid
            if not Test.json_schema_validator.validate_topicsMapping(ipc_mapping_data):
                print(f"[Error]: JSON Schema Validation Failed for IPC Mapping file: {ipc_mapping_filename}")
                return False
            
             #If JSON Schema of the ipc mapping file is valid
            print(f"[Info]: JSON Schema Validation Succesful for IPC Mapping file: {ipc_mapping_filename}")
            global_data.ipc_mapping_data[ipc_mapping_filename] = ipc_mapping_data
        

        dds_topic = method["ipc_info"]["message"]
        topic_Found = False
        # Search for the given method's message/topic in the ipc mapping file
        for message in ipc_mapping_data["messages"]:
            #If message found in ipc mapping file
            if message["topic"] == dds_topic:
                method["additional_info"] = message
                topic_Found = True
                break
        
        #If message not found in ipc mapping file
        if not topic_Found:
            print(f"[Error]: FastDDS Topic: {dds_topic} not found in file: {ipc_mapping_filename}")
            return False

    #Test and combine ML_API data for the method from all input files(IPC mapping)
    def test_and_combine_ml_api_data(self, method):
        ipc_mapping_filename = method["ipc_info"]["ipc_mapping_file"]

        #If ipc mapping file already validated before and it's data has been added to the global ipc_mapping_data dict
        if ipc_mapping_filename in global_data.ipc_mapping_data:
            ipc_mapping_data = global_data.ipc_mapping_data[ipc_mapping_filename]
            print(f"[Info]: JSON Schema Validation for IPC Mapping file: {ipc_mapping_filename} already done before")

        #If ipc mapping file has not been validated before
        else:
            ipc_mapping_data = model_json_parser.JsonParser.read_json(os.path.join(self.filepaths_instance.getIPCMappingDir(), ipc_mapping_filename))

            #If JSON Schema of the ipc mapping file is invalid
            if not Test.json_schema_validator.validate_ipc_mapping(ipc_mapping_data):
                print(f"[Error]: JSON Schema Validation Failed for IPC Mapping file: {ipc_mapping_filename}")
                return False
            
            #If JSON Schema of the ipc mapping file is valid
            print(f"[Info]: JSON Schema Validation Succesful for IPC Mapping file: {ipc_mapping_filename}")
            global_data.ipc_mapping_data[ipc_mapping_filename] = ipc_mapping_data
        
        ml_api_message = method["ipc_info"]["message"]
        message_Found = False
        
        # Search for the given method's message in the ipc mapping file
        for message in ipc_mapping_data["messages"]:
            #If message found in ipc mapping file
            if message["message"] == ml_api_message:
                method["additional_info"] = message
                method["proto_filename"] = ipc_mapping_data["proto_file"]
                message_Found = True
                break
        
        #If message not found in ipc mapping file
        if not message_Found:
            print(f"[Error]: ML_API message: {ml_api_message} not found in file: {ipc_mapping_filename}")
            return False
        
        return True

    # #Check the json schema of the common json input files such as simulink_models_artifact_config, someip_id_mapping and someip_json_mapping.
    # @staticmethod
    # def test_common_input_files(filepaths_instance):

    #     #Validate JSON Schema of SOMEIP Service ID Mapping File
    #     someip_service_mapping_filename = filepaths_instance.getServiceMappingFilepath()
    #     someip_service_mapping_json = model_json_parser.JsonParser.read_json(someip_service_mapping_filename)
    #     if not Test.json_schema_validator.validate_model_someip_service_config(someip_service_mapping_json):
    #         print(f"[Error]: JSON Schema Validation Failed for file: {someip_service_mapping_json}")
    #         return False
    #     print(f"[Info]: JSON Schema Validation Succesful for {someip_service_mapping_filename}")
        
    #     return True
