import utils
import dlt_multi_ctx_logger_template


class DltMultiCtxLogger:
  template = dlt_multi_ctx_logger_template.dlt_multi_ctx_logger
  values_dict = {}

  def __init__(self, model_object):
    self.values_dict["modelName"] = model_object.getModelName().upper()

  def substitute(self):
    return self.template.substitute(self.values_dict)

    
