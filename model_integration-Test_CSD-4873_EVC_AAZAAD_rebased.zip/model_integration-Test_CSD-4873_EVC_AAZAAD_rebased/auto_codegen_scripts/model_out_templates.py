from string import Template

include = Template('''#include <$fun_name.h>
''')

someip_request_out_empty = Template('''
/// @brief Sends out a someip request for ${package_name}::${proto_request}
/// @satisfy{Requirement01321459}
void $fun_name(){
    $package_name::$proto_request const protoData;
    consumer::MessageChannel<$package_name::$proto_request, $package_name::$proto_response>::get_instance().sendRequest(protoData);
}
''')
                                    
someip_request_out_nonempty = Template('''
/// @brief Sends out a someip request for ${package_name}::${proto_request}
/// @satisfy{Requirement01321459}
void $fun_name(const $model_struct *$arg_name){
    $package_name::$proto_request protoData;
    jlr::cccm::di::model_to_proto_dataconverter_message(*$arg_name, protoData);
    consumer::MessageChannel<$package_name::$proto_request, $package_name::$proto_response>::get_instance().sendRequest(protoData);
}
''')
                                       
someip_notify_out = Template('''
/// @brief Sends out a someip notify for ${package_name}::${proto_notify}
/// @satisfy{Requirement01321612}
void $fun_name(const $model_struct *$arg_name){
    $package_name::$proto_notify protoData;
    jlr::cccm::di::model_to_proto_dataconverter_message(*$arg_name, protoData);
    provider::NotifyChannel<$package_name::$proto_notify>::get_instance().send(protoData);
}
''')
                             
someip_response_out = Template('''
/// @brief Sends out a someip notify for ${package_name}::${proto_response}
/// @satisfy{Requirement01321613}
void $fun_name(const $model_struct *$arg_name){
    $package_name::$proto_response protoData;
    jlr::cccm::di::model_to_proto_dataconverter_message(*$arg_name, protoData);
    provider::MessageChannel<$package_name::$proto_request, $package_name::$proto_response>::get_instance().sendResponse(protoData);
}
''')
                               
dds_out = Template('''
void $fun_name(const $model_struct *$arg_name){
  const std::shared_ptr<IModelController> controller = get_model_controller().lock();
  if (!static_cast<bool>(controller))
  {
    std::cout << "$fun_name : ModelController is not initialized!"<< std::endl;
    DI_MODEL_LOG_MCTX_ERROR <<"[Error] : $fun_name : ModelController is not initialized!!";
    return;
  }
  if (!static_cast<bool>(controller->get_dds_handler()))
  {
    std::cout << "$fun_name : DDS Handler is not initiialized!"<< std::endl;
    DI_MODEL_LOG_MCTX_ERROR <<"[Error] : $fun_name : DDS Handler is not initialized!!";
    return;
  }
  $model_struct $copy_arg_name= *$arg_name;
  if (!controller->get_dds_handler()->send(&$copy_arg_name, "$topic_name"))
  {
    std::cout << "$fun_name : failed hmi"<< std::endl;
    DI_MODEL_LOG_MCTX_ERROR <<"[Error] : $fun_name : sent to HMI Fail!!";
    return;
  }
  else
  {
    std::cout << "$fun_name : HMI success"<< std::endl;
    $printModelStruct
    DI_MODEL_LOG_MCTX_DEBUG <<"$fun_name : sent to HMI Success!!"; 
  }
}
''')

# ========== NEW: ML_API TEMPLATE ==========
ml_api_request_out = Template('''
/// @brief Handles ML_API request for EarlyCCF
/// @param $arg_name Model request structure containing MDF IDs
/// @satisfy{Requirement01637438,Requirement01637440,Requirement01637441}
void $fun_name($model_struct const * const $arg_name){
    // 1. Initialize EarlyCCF library (singleton pattern - thread-safe)
    static std::unique_ptr<nmspEarlyCCF::EarlyCCFImpl> g_earlyCCF = nullptr;
    static std::once_flag init_flag;
 /// @satisfy{Requirement01637630}   
    std::call_once(init_flag, []() {
        g_earlyCCF = std::make_unique<nmspEarlyCCF::EarlyCCFImpl>();
        DI_MODEL_LOG_MCTX_INFO << "[Info] : EarlyCCF library initialized";
    });
    
    if (g_earlyCCF == nullptr) {
        DI_MODEL_LOG_MCTX_ERROR << "[Error] : $fun_name : EarlyCCF initialization failed!";
        return;
    }
    
    // 2. Get model controller
    const std::shared_ptr<IModelController> controller = get_model_controller().lock();
    if (!static_cast<bool>(controller)) {
        DI_MODEL_LOG_MCTX_ERROR << "[Error] : $fun_name : ModelController not initialized!";
        return;
    }
    
    // 3. Convert Model struct → Platform library format (int32_t → uint32_t)
    /// @satisfy{Requirement01637443,Requirement01637443}
    nmspEarlyCCF::GetEarlyCCFParamRequest request;
    request.params.clear();
    
    for (uint32_t i = 0U; i < $arg_name->params.payload_length; ++i) {
        nmspEarlyCCF::RepMdfidEarlyCCF mdf;
        mdf.mdf_id = static_cast<uint32_t>($arg_name->params.payload[i].mdf_id);
        request.params.push_back(mdf);
    }
    
    DI_MODEL_LOG_MCTX_INFO << "[Info] : $fun_name : Calling EarlyCCF with " 
                           << request.params.size() << " MDF IDs";
    
    try {
        // 4. Call platform library (BLOCKING call)
        /// @satisfy{Requirement01637445}
        const nmspEarlyCCF::GetEarlyCCFParamResponse response = g_earlyCCF->get_ccf(request);
        
        DI_MODEL_LOG_MCTX_INFO << "[Info] : $fun_name : EarlyCCF returned " 
                               << response.params.size() << " results, status=" 
                               << static_cast<int32_t>(response.status);
        
        // Validate response
        if (response.params.empty()) {
            DI_MODEL_LOG_MCTX_WARN << "[Warn] : $fun_name : EarlyCCF returned empty response";
        }
        /// @satisfy{Requirement01637443,Requirement01637443}
        // 5. Convert Platform response → Model struct (uint32_t → int32_t)
        $model_response modelResponse{};
        
        uint32_t const max_array_size = 50U;
        modelResponse.params.payload_length = std::min(
            static_cast<uint32_t>(response.params.size()), 
            max_array_size  // Max array size from model
        );
        
        for (uint32_t i = 0U; i < modelResponse.params.payload_length; ++i) {
            if (i >= max_array_size) {
                DI_MODEL_LOG_MCTX_WARN << "[Warn] : $fun_name : Truncating response at 50 items";
                break;
            }
            
            modelResponse.params.payload[i].mdf = 
                static_cast<int32_t>(response.params[i].mdf);
            modelResponse.params.payload[i].value = 
                static_cast<int32_t>(response.params[i].value);
            modelResponse.params.payload[i].mdf_status = 
                static_cast<ml_API_earlyCCF_EnumStatusMDFID>(response.params[i].mdf_status);
                              
            // ========== LOG EACH CONVERSION ==========
            std::cout << "[Debug] : $fun_name : Converted[" << i << "] "
                                    << "MDF=" << modelResponse.params.payload[i].mdf 
                                    << ", Value=" << modelResponse.params.payload[i].value 
                                    << ", Status=" << static_cast<int32_t>(modelResponse.params.payload[i].mdf_status);
            // ========== END LOG ==========
        }
        
        modelResponse.status = static_cast<ml_API_earlyCCF_EnumStatusCCF>(response.status);
        
        // 6. Call model response handler
        /// @satisfy{Requirement01637446,Requirement01637586}
        const auto modelController = std::static_pointer_cast<ModelController<$model_class>>(controller);
        if (modelController != nullptr) {
            const auto model = modelController->get_model_ptr();  
            if (model != nullptr) {
                model->$response_fun(&modelResponse);
                DI_MODEL_LOG_MCTX_INFO << "[Info] : $fun_name : Response delivered to model";
            } else {
                DI_MODEL_LOG_MCTX_ERROR << "[Error] : $fun_name : Model pointer is null!";
            }
        } else { 
            DI_MODEL_LOG_MCTX_ERROR << "[Error] : $fun_name : ModelController cast failed!";
        }
        
    } catch (const std::exception& e) {
        DI_MODEL_LOG_MCTX_ERROR << "[Error] : $fun_name failed: " << e.what();
    } catch (...) {
        DI_MODEL_LOG_MCTX_ERROR << "[Error] : $fun_name failed with unknown exception";
    }
}
''')
# ========== UPDATED: MAIN TEMPLATE WITH ML_API ==========
model_out_template = Template('''#include "dlt_logger.hpp"
#include "ProtoDataConverterMessage.hpp"
#include <SomeipServiceConsumer.hpp>
#include <SomeipServiceProvider.hpp>
#include <DdsCommunicationHandler.hpp>
#include <ModelController.hpp>
#include "${model_name}_global_vars.hpp"
#include "ProtoIncludes${model_name}.hpp"
#include "${model_name}.h"  // ⬅️ Model class definition
$ml_api_includes

$includes

namespace jlr{
namespace cccm{
namespace di{

extern "C" {

$ml_api_request_outs

$someip_request_outs
                              
$someip_notify_outs
                              
$someip_response_outs
                              
$dds_outs
} // extern "C"
}   // namespace di
}   // namespace cccm
}   // namespace jlr 
                            
''')          
