import config_getter
import model_playback_converters_template
import utils
import global_data


class PlaybackModelToJsonGenProto:

    template = model_playback_converters_template.model_to_json_template
    values_dict = {}

    # the fields which we don't want to log, like personally identifiable information
    blacklist_model_fields = ["user_account_id"]

    def __init__(self, message, package_name, model_name, ipc_mapping):

        self.values_dict["data_type"] = message["model_struct_name"]
        self.values_dict["conversion_statements"] = self.construct_conversion(message, package_name, model_name, ipc_mapping)

    def construct_conversion(self, message, package_name, model_name, ipc_mapping):
        res = ""
        
        # Each message corresponds to a model struct
        #
        # Each message that is passed on to this function is an object that contains the following
        # 
        # {
        #   "message":"Name of message in proto file",
        #   "model_arg_name": "There will be a single function that takes a struct of this type as the only argument??
        #                      The name of the argument used in the protoype",
        #   "model_struct_name": "type name of the struct which corresponds to the protobuf message",
        #   "members": one of the following
        #              1. An object if the model struct contains exactly one member
        #              2. An array if the model struct contains more that one member
        #              3. An empty array of the model struct does not contain any members??????????
        # }
        #
        # Assumptions:
        # 1. A function in Model that deals with IPC only has a single argument

        
        # members hold an array of struct members
        
        if isinstance(message["members"], dict):
          members = [message["members"]]
        else:
          members = message["members"]
        for member in members:
            # A message struct data member has to be one of the following:
            # 1. Another messsage struct
            # 2. An enum type
            # 3. An Array type, which would make it a member of custom_data_type entry in method.getIPCMappingFileName()
            # 4. None of the above and we will assume that in that case, a normal assignment will work in C++

            model_field = member["model_member_name"]
            model_dtype = member["model_dtype"]


            if config_getter.DataConverterHelper.isAMessageFromIPCMappingFile(member["model_dtype"],ipc_mapping) and model_field not in self.blacklist_model_fields:
                # Case 1: Another message struct
                # Assumption is that there won't be a circular dependency

                res += f"\t\t\tobj[\"{model_field}\"] = Json::objectValue;\n"
                res += f"\t\t\tcreate_json(&(model_data->{model_field}) , obj[\"{model_field}\"]);\n"
            
            elif config_getter.DataConverterHelper.isAnEnumFromIPCMappingFile(member["model_dtype"],ipc_mapping) and model_field not in self.blacklist_model_fields:
                # Case 2: An enum type
                #
                # Not gonna use a static cast for now, need to see what will happen
                # should add static cast if necessary
                res += f"\t\t\tobj[\"{model_field}\"] = static_cast<int32_t>(model_data->{model_field});\n" 

            elif config_getter.DataConverterHelper.isACustomTypeFromIPCMappingFile(member["model_dtype"],ipc_mapping):
                # Case 3: A data type in CustomDataType section
                # 
                # There are the following possibilities based on language rules of proto files
                # 1. It is a repeated message
                # 2. It is a bytes keyword
                # 3. It is a string keyword
                # 4. It is a repeated bytes
                # 5. It is a repeated string
                # 6. It is a repeated enum
                # 7. It is a repeated primitive (apart from bytes,string, enum)
                #

                # First let us get the info about the custom type
                custom_type_info = config_getter.DataConverterHelper.findCustomTypeInfo(member["model_dtype"],ipc_mapping)

                model_struct_name = custom_type_info["model_struct_name"]
                
                # Assumption: Every custom data type will have the following data
                length_submember_name = custom_type_info["length_attribute"]
                payload_submember_name = custom_type_info["data_attribute"]

                payload_submember_datatype = None
                for submember in custom_type_info["members"]:
                    if submember["model_member_name"]==payload_submember_name:
                        payload_submember_datatype = submember["model_dtype"]

                res += f"\t\t\tobj[\"{model_field}\"] = Json::objectValue;\n"
                res += f"\t\t\tobj[\"{model_field}\"][\"{length_submember_name}\"] = (model_data->{model_field}).{length_submember_name};\n"
                
                if config_getter.DataConverterHelper.isAMessageFromIPCMappingFile(payload_submember_datatype, ipc_mapping) and model_field not in self.blacklist_model_fields:
                    # Case 1: It is a repeated message
                    # Model side fixed array Length is 50 according to requirements
                    res += f"\t\t\tobj[\"{model_field}\"][\"{payload_submember_name}\"] = Json::arrayValue ;\n"
                    res += f"\t\t\tint32_t const {model_field}_{payload_submember_name}_length = static_cast<int32_t>(50);\n"
                    res += f"\t\t\tfor(int32_t i=0; i<{model_field}_{payload_submember_name}_length; ++i)\n"
                    res += "\t\t\t{\n"
                    res += f"\t\t\t\tcreate_json( &((model_data->{model_field}).{payload_submember_name}[i]) , obj[\"{model_field}\"][\"{payload_submember_name}\"][i] );\n"
                    res += "\t\t\t}\n"

                elif config_getter.DataConverterHelper.isStrByt(model_struct_name) and model_field not in self.blacklist_model_fields:
                    # Case 2: it is a bytes keyword
                    # OR
                    # Case 3: it is a string keyword
                    # Model side fixed array length is 30 according to requirements
                    res += f"\t\t\tobj[\"{model_field}\"][\"{payload_submember_name}\"] = Json::arrayValue ;\n"
                    res += f"\t\t\tint32_t const {model_field}_{payload_submember_name}_length = static_cast<int32_t>(30);\n"
                    res += f"\t\t\tfor(int32_t i=0; i<{model_field}_{payload_submember_name}_length; ++i)\n"
                    res += "\t\t\t{\n"
                    res += f"\t\t\t\tobj[\"{model_field}\"][\"{payload_submember_name}\"][i] = (model_data->{model_field}).{payload_submember_name}[i] ;\n"
                    res += "\t\t\t}\n"

                elif config_getter.DataConverterHelper.isRepStrByt(model_struct_name) and config_getter.DataConverterHelper.isStrByt(payload_submember_datatype):
                    # Case 4: It is a repeated bytes
                    # OR
                    # Case 5: It is a repeated string
                    #
                    # Leaving this unimplemented for now because of the following reasons:
                    # 1. Currently, no production model uses this
                    # 2. The current implementation of this for data conversion assumes names
                    #    for the struct encapsulation of byte and str subelements
                    pass

                elif config_getter.DataConverterHelper.isAnEnumFromIPCMappingFile(payload_submember_datatype, ipc_mapping) and model_field not in self.blacklist_model_fields:
                    # Case 6: It is a repeated enum
                    # Model side fixed array length is 50 according to requirements
                    #
                    # Not gonna use a static cast for now, need to see what will happen
                    # should add static cast if necessary
                    res += f"\t\t\tobj[\"{model_field}\"][\"{payload_submember_name}\"] = Json::arrayValue ;\n"
                    res += f"\t\t\tint32_t const {model_field}_{payload_submember_name}_length = static_cast<int32_t>(50);\n"
                    res += f"\t\t\tfor(int32_t i=0; i<{model_field}_{payload_submember_name}_length; ++i)\n"
                    res += "\t\t\t{\n"
                    res += f"\t\t\t\tobj[\"{model_field}\"][\"{payload_submember_name}\"][i] = static_cast<int32_t>((model_data->{model_field}).{payload_submember_name}[i]) ;\n"
                    res += "\t\t\t}\n"

                elif model_field not in self.blacklist_model_fields:
                    # Case 7: It is a repeated primitive (apart from bytes,string, enum)
                    # Assumption is that the cases I have enumerated is exhaustive
                    res += f"\t\t\tobj[\"{model_field}\"][\"{payload_submember_name}\"] = Json::arrayValue ;\n"
                    res += f"\t\t\tint32_t const {model_field}_{payload_submember_name}_length = static_cast<int32_t>(50);\n"
                    res += f"\t\t\tfor(int32_t i=0; i<{model_field}_{payload_submember_name}_length; ++i)\n"
                    res += "\t\t\t{\n"
                    res += f"\t\t\t\tobj[\"{model_field}\"][\"{payload_submember_name}\"][i] = (model_data->{model_field}).{payload_submember_name}[i] ;\n"
                    res += "\t\t\t}\n"

            else:
                # Case 4: primitive data type
                # Assumption is that the cases I have enumerated is exhaustive
                res += f"\t\t\tobj[\"{model_field}\"] = model_data->{model_field};\n" 

      
        return res

    def substitute(self):
        return self.template.substitute(self.values_dict)






class PlaybackModelToJsonGenDDS:

    template = model_playback_converters_template.model_to_json_template
    values_dict = {}

    def __init__(self, method, model_name):

        self.values_dict["data_type"] = method.getModelStructName()
        self.values_dict["conversion_statements"] = self.construct_conversion(method, model_name)

    def construct_conversion(self, method, model_name):
        res = ""
        
        # Each DDS struct corresponds exactly to a struct in IDL
        #
        # Each message that is passed on to this function is an object that contains the following
        # 
        # {
        #   "message":"Name of message in proto file",
        #   "model_arg_name": "There will be a single function that takes a struct of this type as the only argument??
        #                      The name of the argument used in the protoype",
        #   "model_struct_name": "type name of the struct which corresponds to the protobuf message",
        #   "members": one of the following
        #              1. An object if the model struct contains exactly one member
        #              2. An array if the model struct contains more that one member
        #              3. An empty array of the model struct does not contain any members??????????
        # }
        #
        # Assumptions:
        # 1. A function in Model that deals with IPC only has a single argument which is struct

        
        # members hold an array of struct members
        members = method.getMembers()
        if isinstance(members, dict):
          members = [members]
        ipc_mapping = method.getIPCMappingFileName()
        for member in members:
            # A message struct data member has to be one of the following:
            # 1. Another struct
            # 2. An enum type
            # 3. A fixed size array
            #    No sequence will be used.
            #    Need to think about how mapping.json changes
            # 
            #    
            # 4. None of the above and we will assume that in that case, a normal assignment will work in C++

            model_field = member["model_member_name"]
            model_dtype = member["model_dtype"]


            if config_getter.DataConverterHelper.isAMessageFromIPCMappingFile(member["model_dtype"],ipc_mapping):
                # Case 1: Another IDL struct
                # Assumption is that there won't be a circular dependency

                res += f"\t\t\tobj[\"{model_field}\"] = Json::objectValue;\n"
                res += f"\t\t\tcreate_json(&(model_data->{model_field}) , obj[\"{model_field}\"]);\n"
            
            elif config_getter.DataConverterHelper.isAnEnumFromIPCMappingFile(member["model_dtype"],ipc_mapping):
                # Case 2: An enum type
                #
                # should add static cast if necessary
                res += f"\t\t\tobj[\"{model_field}\"] = static_cast<int32_t>(model_data->{model_field});\n" 

            elif config_getter.DataConverterHelper.isACustomTypeFromIPCMappingFile(member["model_dtype"],ipc_mapping):
                # Case 3: A data type in CustomDataType section
                # 
                # It is not clear what this would map to. We have not considered arrays in IDL till now
                # Leaving it unimplemented as this is not used as of now
                res += f"\t\t\t// IGNORING CUSTOM TYPE field name:{model_field}\n"

            else:
                # Case 4: primitive data type
                # Assumption is that the cases I have enumerated is exhaustive
                # 
                # We also need to take care of quirks like MATLAB using unsigned char for boolean_T
                # This will affect how it is printed...
                res += f"\t\t\tobj[\"{model_field}\"] = model_data->{model_field};\n" 

      
        return res

    def substitute(self):
        return self.template.substitute(self.values_dict)




class PlaybackDataConvertersGen:

    template = model_playback_converters_template.playback_data_converter_template
    values_dict = {}

    def __init__(self, model_object):

        self.values_dict["model_name"] = model_object.getModelName()
        self.values_dict["conversion_funs"] = self.construct_funs(model_object)
        self.values_dict["includes"] = self.construct_includes(model_object)

    def construct_funs(self, model_object):
        res = ""
        global_data.dependentStructsList = set()
        model_object.dependentStructs()

        for service_name, ipc_mapping in model_object.getServiceNameIPCMapping(): #change it to include vsomeip events too(method in both vsomeip methods dict and events_list)

            for message in global_data.ipc_mapping_data[ipc_mapping]["messages"]:
              if config_getter.DataConverterHelper.generationNeeded(message):
                  if len(message["members"]) > 0:
                      package_name = message["package_name"]
                      res += PlaybackModelToJsonGenProto(message, package_name, model_object.getModelName(), ipc_mapping).substitute()

       
        # for method in model_object.get_dds_methods():
        #     # BIG ASSUMPTION
        #     # We are only generating converters for the data structure that gets sent in a topic
        #     # FastDDS (And I am guessing DDS) only allows one data structure to be sent in a single topic
        #     # But this struct could have other structs as members.
        #     # Currently we are ONLY generating Json converters for the struct that is sent in the topic, and this
        #     # works because for now, because we only have enums and primitives as members in structs that are sent
        #     # out in topics
            
        #     if len(method.getMembers()) > 0:
        #         res += PlaybackModelToJsonGenDDS(method, model_object.getModelName()).substitute()
            
        
        return res
    
    def construct_includes(self, model_object):
        res = "#include <json/json.h>\n"
        services = model_object.getAllServicesForModel()

        model_name = model_object.getModelName()
        res += f"#include <{model_name}.h>\n"

        res += "#include <CombinedTopicsPubSubTypes.h>\n"

        #dds_topic_methods = model_object.getAllDdsOuts()
        #for model_method in dds_topic_methods:
        #    idl_filename = model_method.getDdsIdlFileNameWithoutExtension()
        #    res += f"#include <{idl_filename}PubSubTypes.h>\n"
        #    
        #dds_topic_methods = model_object.getAllDdsIn()
        #for model_method in dds_topic_methods:
        #    idl_filename = model_method.getDdsIdlFileNameWithoutExtension()
        #    res += f"#include <{idl_filename}PubSubTypes.h>\n"
        

        return res
    
    def substitute(self):
        return self.template.substitute(self.values_dict)
