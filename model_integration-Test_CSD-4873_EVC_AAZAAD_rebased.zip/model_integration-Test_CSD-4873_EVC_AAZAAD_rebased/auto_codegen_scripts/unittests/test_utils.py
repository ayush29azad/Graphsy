import unittest
import os
import sys

current_dir = os.path.dirname(os.path.abspath(__file__))
autocodegen_dir = os.path.join(current_dir, '..') 

# Add autocodegen to the Python path
sys.path.append(autocodegen_dir)
import utils

class TestUtils(unittest.TestCase):
    def test_is_enum(self):
        valid_test_cases = ["Enumabc", "aenumbc", "abenmc", "abcEnm", "EenmEnumabc","Enenenm"]
        invalid_test_cases = ["Enuambc", "aencmbc", "abenxmc", "abcEnnm"]
        for test_case in valid_test_cases:
            with self.subTest(test_case=test_case):
                result = utils.Utils.is_enum(test_case)
                self.assertTrue(result)

        for test_case in invalid_test_cases:
            with self.subTest(test_case=test_case):
                result = utils.Utils.is_enum(test_case)
                self.assertFalse(result)

    def test_unique(self):
        test_case_1 = ["abc", "Abc", "aBc", "abc", "abC", "ABc", "ABC", "aBC", "aBc" ]
        test_case_2 = ["abc", "Abc", "aBc", "abC", "ABc", "ABC", "aBC"]
        
        expected_result = ["abc", "Abc", "aBc", "abC", "ABc", "ABC", "aBC"]
        result_1 = utils.Utils.unique(test_case_1)
        self.assertEqual(result_1, expected_result)


        result_2 = utils.Utils.unique(test_case_2)
        self.assertEqual(result_2, expected_result)

    def test_write_to_file(self):
        utilstest_writetc_path = current_dir + "/UtilsTestCases/write_tc.json"
        expected_result = "This is the expected result."
        utils.Utils.write_to_file(utilstest_writetc_path, expected_result)

        with open(utilstest_writetc_path, 'r') as src:
            result = src.read()

        self.assertEqual(result, expected_result)
        

if __name__ == '__main__':
    unittest.main()
