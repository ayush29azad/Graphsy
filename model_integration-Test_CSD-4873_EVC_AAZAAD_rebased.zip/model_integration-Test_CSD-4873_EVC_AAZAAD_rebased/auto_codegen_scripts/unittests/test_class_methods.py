import unittest
import os
import sys

current_dir = os.path.dirname(os.path.abspath(__file__))
autocodegen_dir = os.path.join(current_dir, '..') 
# Add autocodegen to the Python path
sys.path.append(autocodegen_dir)

import input_testing
import class_definition
import model_json_parser
import global_data
import filepaths

class TestArgs:
    def __init__(self):
        self.modelname = None
        self.modelconfig = None
        self.codegendir = None
        self.servicemapping = None
        self.servicedefdir = None
        self.ipcmappingdir = None

test_args = TestArgs()
filepaths_instance = filepaths.Filepaths(test_args)

filepaths_instance.service_mapping = current_dir + "/ClassMethodTestCases/config/model_someip_service_config.json"
filepaths_instance.ipcmapping_dir = current_dir + "/ClassMethodTestCases/models/IPCMapping/"
filepaths_instance.servicedef_dir = current_dir + "/ClassMethodTestCases/proto_files/"

filepaths_instance.model_config = current_dir + "/ClassMethodTestCases/models/modelConfig/vehicleLifecycle.json"
model_data = model_json_parser.JsonParser.read_json(filepaths_instance.model_config)
input_testing.Test(model_data, filepaths_instance).validate_and_combine_input_data()

filepaths_instance.model_config = current_dir + "/ClassMethodTestCases/models/modelConfig/batteryStateOfChargeDisp.json"
model_data_2 = model_json_parser.JsonParser.read_json(filepaths_instance.model_config)
input_testing.Test(model_data_2, filepaths_instance).validate_and_combine_input_data()

filepaths_instance.model_config = current_dir + "/ClassMethodTestCases/models/modelConfig/displayOdometerTripComputer.json"
model_data_3 = model_json_parser.JsonParser.read_json(filepaths_instance.model_config)
input_testing.Test(model_data_3, filepaths_instance).validate_and_combine_input_data()


class TestVsomeipMethodClass(unittest.TestCase):
    def __init__(self, methodName='runTest'):
        super().__init__(methodName)
        
        self.method_object = class_definition.VSOMEIP_Method(model_data["model_methods"][2])
        self.method_object_2 = class_definition.VSOMEIP_Method(model_data["model_methods"][0])
        self.method_object_3 = class_definition.VSOMEIP_Method(model_data["model_methods"][4])

    def test_getMethodName(self):
        result = self.method_object.getMethodName()
        self.assertEqual(result, "soip_lifecycle_userapps_vlca_GetVLCAStateResponse")

    def test_getMethodID(self):
        result = self.method_object.getMethodID()
        self.assertEqual(result, "0x0001")

    def test_getServiceName(self):
        result = self.method_object.getServiceName()
        self.assertEqual(result, "lifecycle_cccmuserapps_vlca_service")

    def test_getServiceID(self):
        result = self.method_object.getServiceID()
        self.assertEqual(result, "0x0016")

    def test_getModelStructName(self):
        result = self.method_object.getModelStructName()
        self.assertEqual(result, "structlifecycle_userapps_vlca_GetVLCAStateResponse")

    def test_getIPCMappingFileName(self):
        result = self.method_object.getIPCMappingFileName()
        self.assertEqual(result, "lifecycle_userapps_vlca_service_mapping.json")

    def test_getIntent(self):
        result = self.method_object.getIntent()
        self.assertEqual(result, "in")

    def test_getMessage(self):
        result = self.method_object.getMessage()
        self.assertEqual(result, "GetVLCAStateResponse")

    def test_getCorrespondingMessage(self):
        result = self.method_object.getCorrespondingMessage()
        self.assertEqual(result, "GetVLCAStateRequest")

    def test_getMembers(self):
        result = self.method_object.getMembers()
        expected_result = [
            {
                "proto_member_name": "vlca_state",
                "model_member_name": "vlca_state",
                "model_dtype": "lifecycle_userapps_vlca_EnumVLCAState"
            },
            {
                "proto_member_name": "vehicle_mode",
                "model_member_name": "vehicle_mode",
                "model_dtype": "cvlc_common_EnumVehicleMode"
            },
            {
                "proto_member_name": "vehicle_state",
                "model_member_name": "vehicle_state",
                "model_dtype": "cvlc_common_EnumVehicleState"
            }
        ]
        self.assertEqual(result, expected_result)

    def test_getEventType(self):
        result = self.method_object.getEventType()
        self.assertEqual(result, "response")

    def test_isResponseIn(self):
        result = self.method_object.isResponseIn()
        self.assertTrue(result)

    def test_isRequestOut(self):
        result = self.method_object.isRequestOut()
        self.assertFalse(result)

    def test_isRequestIn(self):
        result = self.method_object.isRequestIn()
        self.assertFalse(result)

        result2 = self.method_object_3.isRequestIn()
        self.assertTrue(result2)

    def test_isResponseOut(self):
        result = self.method_object.isResponseOut()
        self.assertFalse(result)

        result2 = self.method_object_2.isResponseOut()
        self.assertTrue(result2)

    def test_modelIsServer(self):
        result = self.method_object.modelIsServer()
        self.assertFalse(result)

        result2 = self.method_object_2.modelIsServer()
        self.assertTrue(result2)

    def test_checkIfModelEventHasArgument(self):
        result = self.method_object.checkIfModelEventHasArgument()
        self.assertTrue(result)

        result2 = self.method_object_2.checkIfModelEventHasArgument()
        self.assertFalse(result2)


class TestVsomeipEventClass(unittest.TestCase):
    def __init__(self, methodName='runTest'):
        super().__init__(methodName)
        
        self.event_object = class_definition.VSOMEIP_Event(model_data["model_methods"][1])
        self.event_object_2 = class_definition.VSOMEIP_Event(model_data["model_methods"][3])
    
    def test_getMethodName(self):
        result = self.event_object.getMethodName()
        self.assertEqual(result, "soip_energymanagement_NotifyPowertrainReadyStatus")

    def test_getMethodID(self):
        result = self.event_object.getEventID()
        self.assertEqual(result, "0x8003")

    def test_getServiceName(self):
        result = self.event_object.getServiceName()
        self.assertEqual(result, "energymanagement_service")

    def test_getServiceID(self):
        result = self.event_object.getServiceID()
        self.assertEqual(result, "0x0009")

    def test_getModelStructName(self):
        result = self.event_object.getModelStructName()
        self.assertEqual(result, "structenergymanagement_NotifyPowertrainReadyStatus")

    def test_getIPCMappingFileName(self):
        result = self.event_object.getIPCMappingFileName()
        self.assertEqual(result, "energymanagement_service_mapping.json")

    def test_getIntent(self):
        result = self.event_object.getIntent()
        self.assertEqual(result, "in")

    def test_getMessage(self):
        result = self.event_object.getMessage()
        self.assertEqual(result, "NotifyPowertrainReadyStatus")

    def test_getMembers(self):
        result = self.event_object.getMembers()
        expected_result = [
            {
                "proto_member_name": "powertrain_ready_status",
                "model_member_name": "powertrain_ready_status",
                "model_dtype": "energymanagement_EnumPowertrainReadyStatus"
            },
            {
                "proto_member_name": "status",
                "model_member_name": "status",
                "model_dtype": "energymanagement_EnumStatus"
            }
        ]
        self.assertEqual(result, expected_result)

    def test_getAllEventGroupIDs(self):
        result = self.event_object.getAllEventGroupIDs()
        expected_result = ["0x1212", "0x4455"]
        self.assertEqual(sorted(result), sorted(expected_result))

    def test_getEventType(self):
        result = self.event_object.getEventType()
        self.assertEqual(result, "event")

    def test_isNotifyOut(self):
        result = self.event_object.isNotifyOut()
        self.assertFalse(result)

        result2 = self.event_object_2.isNotifyOut()
        self.assertTrue(result2)

    def test_isNotifyIn(self):
        result = self.event_object.isNotifyIn()
        self.assertTrue(result)

        result2 = self.event_object_2.isNotifyIn()
        self.assertFalse(result2)

    def test_modelIsServer(self):
        result = self.event_object.modelIsServer()
        self.assertFalse(result)


class TestFastDDSMethodClass(unittest.TestCase):
    def __init__(self, methodName='runTest'):
        super().__init__(methodName)
        
        self.method_object = class_definition.FastDDS_Method(model_data["model_methods"][6])
    
    def test_getMethodName(self):
        result = self.method_object.getMethodName()
        self.assertEqual(result, "ddsTx_vehicleLifecycleInt")

    def test_getModelStructName(self):
        result = self.method_object.getModelStructName()
        self.assertEqual(result, "structvehicleLifecycleInt")

    def test_getIPCMappingFileName(self):
        result = self.method_object.getIPCMappingFileName()
        self.assertEqual(result, "DI_INT_topics_mapping.json")

    def test_getIntent(self):
        result = self.method_object.getIntent()
        self.assertEqual(result, "out")

    def test_getTopicName(self):
        result = self.method_object.getTopicName()
        self.assertEqual(result, "vehicleLifecycleInt")

    def test_getMembers(self):
        result = self.method_object.getMembers()
        expected_result = [
            {
                "idl_member_name": "eVehicle_State",
                "model_member_name": "eVehicle_State",
                "model_dtype": "enmVehicleStateInt"
            }
        ]
        self.assertEqual(result, expected_result)

    def test_getDdsIdlFileNameWithoutExtension(self):
        result = self.method_object.getDdsIdlFileNameWithoutExtension()
        self.assertEqual(result, "vehicleLifecycleInt_topic")


class TestSomeipQOSMethodClass(unittest.TestCase):
    def __init__(self, methodName='runTest'):
        super().__init__(methodName)
        
        self.method_object = class_definition.SOMEIP_QOS(model_data["model_methods"][-1])
    
    def test_getMethodName(self):
        result = self.method_object.getMethodName()
        self.assertEqual(result, "soip_on_available")

    def test_getIntent(self):
        result = self.method_object.getIntent()
        self.assertEqual(result, "in")

    def test_getType(self):
        result = self.method_object.getType()
        self.assertEqual(result, "on_available")

    def test_hasOnAvailable(self):
        result = self.method_object.hasOnAvailable()
        self.assertTrue(result)


class TestClockMethodClass(unittest.TestCase):
    def __init__(self, methodName='runTest'):
        super().__init__(methodName)
        
        self.method_object = class_definition.Clock_Method(model_data["model_methods"][-2])
    
    def test_getMethodName(self):
        result = self.method_object.getMethodName()
        self.assertEqual(result, "tic_1000ms")

    def test_getIntent(self):
        result = self.method_object.getIntent()
        self.assertEqual(result, "in")
    
    def test_getTimerPeriod(self):
        result = self.method_object.getTimerPeriod()
        self.assertEqual(result, "1000")


class TestModelClass(unittest.TestCase):
    def __init__(self, methodName='runTest'):
        super().__init__(methodName)
        self.model_class_object = class_definition.Model(model_data)
        self.model_class_object_2 = class_definition.Model(model_data_2)
        self.model_class_object_3 = class_definition.Model(model_data_3)

    def test_getModelName(self):
        result = self.model_class_object.getModelName()
        self.assertEqual(result, "vehicleLifecycle")

    def test_getModelClassName(self):
        result = self.model_class_object.getModelClassName()
        self.assertEqual(result, "vehicleLifecycleModelClass")
        
    def test_get_vsomeip_methods(self):
        methods = self.model_class_object.get_vsomeip_methods()
        result = []
        for method in methods:
            result.append(method.getMessage())
        expected_result = ["GetPowertrainReadyStatusResponse", "GetVLCAStateResponse", "GetPowertrainReadyStatusRequest", "GetVLCAStateRequest"]
        self.assertEqual(sorted(result), sorted(expected_result))

    def test_get_vsomeip_events(self):
        events = self.model_class_object.get_vsomeip_events()
        result = []
        for event in events:
            result.append(event.getMessage())
        expected_result = ["NotifyPowertrainReadyStatus", "NotifyVLCAState"]
        self.assertEqual(sorted(result), sorted(expected_result))

    def test_get_dds_methods(self):
        methods = self.model_class_object.get_dds_methods()
        result = []
        for method in methods:
            result.append(method.getTopicName())
        expected_result = ["vehicleLifecycleInt", "vehicleLifecycle"]
        self.assertEqual(sorted(result), sorted(expected_result))

    def test_getAllServicesForModel(self):
        result = self.model_class_object.getAllServicesForModel()
        expected_result = ['energymanagement_service', 'lifecycle_cccmuserapps_vlca_service']
        self.assertEqual(sorted(result), sorted(expected_result))

    def test_getAllServicesForModelAsServer(self):
        result = self.model_class_object.getAllServicesForModelAsServer()
        expected_result = {
            10 : {'energymanagement_service'}
        }
        self.assertEqual(sorted(result), sorted(expected_result))

    def test_getServiceIDfromServiceName(self):
        
        for service_name in self.model_class_object.getAllServicesForModel():
            result = self.model_class_object.getServiceIDfromServiceName(service_name)
            
            if service_name == "energymanagement_service":
                expected_result = "0x0009"
            elif service_name == "lifecycle_cccmuserapps_vlca_service":
                expected_result = "0x0016"
            self.assertEqual(result, expected_result)

    def test_getInstanceIDforService(self):
        for service_name in self.model_class_object.getAllServicesForModel():
            result = self.model_class_object.getInstanceIDforService(service_name)
            self.assertEqual(result, "1")

    def test_getServiceNameIPCMapping(self):
        result = self.model_class_object.getServiceNameIPCMapping()
        expected_result = [('energymanagement_service', 'energymanagement_service_mapping.json'), ('lifecycle_cccmuserapps_vlca_service', 'lifecycle_userapps_vlca_service_mapping.json')]
        self.assertEqual(sorted(result), sorted(expected_result))

    def test_get_dds_ipc_mapping_files(self):
        result = self.model_class_object.get_dds_ipc_mapping_files()
        expected_result = ['DI_INT_topics_mapping.json', 'DI_GUI_topics_mapping.json']
        self.assertEqual(sorted(result), sorted(expected_result))

    def test_findMessage(self):
        for method in self.model_class_object.get_vsomeip_methods():
            message = method.getMessage() 
            result = self.model_class_object.findMessage(message)
            self.assertTrue(result)

        for method in self.model_class_object.get_vsomeip_events():
            message = method.getMessage() 
            result = self.model_class_object.findMessage(message)
            self.assertFalse(result)


        for method in self.model_class_object.get_dds_methods():
            message = method.getTopicName() 
            result = self.model_class_object.findMessage(message)
            self.assertFalse(result)

    def test_getAllModelOuts(self):
        result=[] 
        for method in self.model_class_object.getAllModelOuts():
            result.append(method.getMethodName())
        expected_result = ['soip_energymanagement_GetPowertrainReadyStatusResponse', 'soip_lifecycle_userapps_vlca_GetVLCAStateRequest', 'ddsTx_vehicleLifecycleInt', 'ddsTx_vehicleLifecycle', 'soip_lifecycle_userapps_vlca_NotifyVLCAState']
        self.assertEqual(sorted(result), sorted(expected_result))

    def test_getAllSomeipNotifyIns(self):
        result=[] 
        for method in self.model_class_object.getAllSomeipNotifyIns():
            result.append(method.getMethodName())
        expected_result = ['soip_energymanagement_NotifyPowertrainReadyStatus']
        self.assertEqual(sorted(result), sorted(expected_result))

    def test_getAllSomeipResponseIns(self):
        result=[] 
        for method in self.model_class_object.getAllSomeipResponseIns():
            result.append(method.getMethodName())
        expected_result = ['soip_lifecycle_userapps_vlca_GetVLCAStateResponse']
        self.assertEqual(sorted(result), sorted(expected_result))

    def test_getAllSomeipRequestOuts(self):
        result=self.model_class_object.getAllSomeipRequestOuts()
        expected_result = {
            10 : {'soip_lifecycle_userapps_vlca_GetVLCAStateRequest'}
        }
        self.assertEqual(sorted(result), sorted(expected_result))

    def test_getAllSomeipNotifyOuts(self):
        result =  self.model_class_object.getAllSomeipNotifyOuts()
        expected_result = {
            10: {"soip_lifecycle_userapps_vlca_NotifyVLCAState"}
            }
        self.assertEqual(sorted(result), sorted(expected_result))

    def test_getAllSomeipResponseOuts(self):
        result=self.model_class_object.getAllSomeipResponseOuts()
        expected_result = {
            10 : {'soip_energymanagement_GetPowertrainReadyStatusResponse'}
        }
        self.assertEqual(sorted(result), sorted(expected_result))

    def test_getAllSomeipRequestIns(self):
        result=[] 
        for method in self.model_class_object.getAllSomeipRequestIns():
            result.append(method.getMethodName())
        expected_result = ['soip_energymanagement_GetPowertrainReadyStatusRequest']
        self.assertEqual(sorted(result), sorted(expected_result))

    def test_getAllUnpairedResponseIns(self):
        result=[] 
        for method in self.model_class_object.getAllUnpairedResponseIns():
            result.append(method.getMethodName())
        expected_result = []
        self.assertEqual(sorted(result), sorted(expected_result))

    def test_getAllDdsOuts(self):
        result=[] 
        for method in self.model_class_object.getAllDdsOuts():
            result.append(method.getMethodName())
        expected_result = ['ddsTx_vehicleLifecycleInt', 'ddsTx_vehicleLifecycle']
        self.assertEqual(sorted(result), sorted(expected_result))

    def test_getAllDdsIn(self):
        result=[] 
        for method in self.model_class_object_2.getAllDdsIn():
            result.append(method.getMethodName())
        expected_result = ["ddsTx_batteryStateOfChargeDisp"]
        self.assertEqual(sorted(result), sorted(expected_result))

    def test_getAllModelTopics(self):
        result= self.model_class_object.getAllModelTopics()
        expected_result = ['vehicleLifecycleInt_topic', 'vehicleLifecycle_topic']
        self.assertEqual(sorted(result), sorted(expected_result))

    def test_getCorrespondingRequestForResponse(self):
        result=[] 
        for method in self.model_class_object.get_vsomeip_methods():
            if method.getEventType() == "response":
                result.append(self.model_class_object.getCorrespondingRequestForResponse(method))
        expected_result = ['GetPowertrainReadyStatusRequest', 'GetVLCAStateRequest']
        self.assertEqual(sorted(result), sorted(expected_result))

    def test_getCorrespondingResponseForRequest(self):
        result=[] 
        for method in self.model_class_object.get_vsomeip_methods():
            if method.getEventType() == "request":
                result.append(self.model_class_object.getCorrespondingResponseForRequest(method))
        expected_result = ['GetPowertrainReadyStatusResponse', 'GetVLCAStateResponse']
        self.assertEqual(sorted(result), sorted(expected_result))

    def test_hasTimer(self):
        result = self.model_class_object.hasTimer()
        self.assertTrue(result)

        result2 = self.model_class_object_2.hasTimer()
        self.assertFalse(result2)

    def test_getTimerMethod(self):
        clock_method = self.model_class_object.getTimerMethod()
        result = clock_method.getMethodName()
        self.assertEqual(result, "tic_1000ms")
    
    def test_hasOnAvailable(self):
        result = self.model_class_object.hasOnAvailable()
        self.assertTrue(result)

        result2 = self.model_class_object_2.hasOnAvailable()
        self.assertFalse(result2)

    def test_getModelOnAvailableFunName(self):
        result = self.model_class_object.getModelOnAvailableFunName()
        self.assertEqual(result, "soip_on_available")
    
    def test_dependentStrcuts(self):
        global_data.dependentStructsList = set()
        self.model_class_object_3.dependentStructs()
        result = global_data.dependentStructsList
        expected_result = {'', 'rep_featureconfig_userapps_Keyvaluetuple', 'structfeatureconfig_userapps_Keyvaluetuple', 'structcockpit_persistency_ReadDataRequest', 'structcockpit_persistency_WriteDataRequest', 'structenergymanagement_GetEVRangePredictionValueResponse', 'structodometerrollingcount_NotifyOdometerRollingCount', 'structodometerrollingcount_GetOdometerRollingCountResponse', 'structcockpit_persistency_ReadDataResponse', 'rep_featureconfig_userapps_RepMdfid', 'structfeatureconfig_userapps_RepMdfid', 'structfeatureconfig_userapps_GetParamRequest', 'structcockpit_persistency_Domaincontextpair', 'structodometer_NotifyOdometerValue', 'structodometer_GetOdometerValueResponse', 'structfeatureconfig_userapps_GetParamResponse', 'structenergymanagement_NotifyEVRangePredictionValue'}
        self.assertEqual(result, expected_result)
        global_data.dependentStructsList = set()


if __name__ == '__main__':
    unittest.main()
