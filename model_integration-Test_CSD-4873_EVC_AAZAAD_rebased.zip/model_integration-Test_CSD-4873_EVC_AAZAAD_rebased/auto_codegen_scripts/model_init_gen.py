import model_init_templates as mit
import config_getter



class ModelInit:
    
    def __init__(self, model_object):

        self.cpp_template = mit.model_init_cpp_template
        self.cpp_values_dict = {}


        self.cpp_values_dict["model_name"] = model_object.getModelName()
        self.cpp_values_dict["model_class"] = model_object.getModelClassName()
    
    

    def substitute(self):
        return self.cpp_template.substitute(self.cpp_values_dict)
