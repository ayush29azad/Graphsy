import model_out_templates as mot
import config_getter
import log_gen


class ModelOutIncludes:

    template = mot.include
    values_dict = {}

    def __init__(self, model_fun):

        self.values_dict["fun_name"] = model_fun

    def substitute(self):
        return self.template.substitute(self.values_dict)
    

class SomeipEmptyRequestOut:

    template = mot.someip_request_out_empty
    values_dict = {}

    def __init__(self, model_object, model_method):
        self.values_dict["package_name"] = model_method.getPackageName()
        self.values_dict["fun_name"] = model_method.getMethodName()
        self.values_dict["proto_request"] = model_method.getMessage()
        self.values_dict["proto_response"] = model_object.getCorrespondingResponseForRequest(model_method)

    def substitute(self):
        return self.template.substitute(self.values_dict)
    

class SomeipNonEmptyRequestOut:

    template = mot.someip_request_out_nonempty
    values_dict = {}

    def __init__(self, model_object, model_method):
        self.values_dict["package_name"] = model_method.getPackageName()
        self.values_dict["fun_name"] = model_method.getMethodName()
        self.values_dict["model_name"] = model_object.getModelName()
        self.values_dict["model_struct"] = model_method.getModelStructName()
        self.values_dict["proto_request"] = model_method.getMessage()
        self.values_dict["proto_response"] = model_object.getCorrespondingResponseForRequest(model_method)
        self.values_dict["arg_name"] = "rtu_" + model_method.getModelStructName()[6:]

    def substitute(self):
        return self.template.substitute(self.values_dict)
    

class SomeipNotifyOut:

    template = mot.someip_notify_out
    values_dict = {}

    def __init__(self, model_object, model_method):
        self.values_dict["package_name"] = model_method.getPackageName()
        self.values_dict["fun_name"] = model_method.getMethodName()
        self.values_dict["model_name"] = model_object.getModelName()
        self.values_dict["model_struct"] = model_method.getModelStructName()
        self.values_dict["proto_notify"] = model_method.getMessage()
        self.values_dict["arg_name"] = "rtu_" + model_method.getModelStructName()[6:]

    def substitute(self):
        return self.template.substitute(self.values_dict)
    

class SomeipResponsetOut:

    template = mot.someip_response_out
    values_dict = {}

    def __init__(self, model_object, model_method):
        self.values_dict["package_name"] = model_method.getPackageName()
        self.values_dict["fun_name"] = model_method.getMethodName()
        self.values_dict["model_name"] = model_object.getModelName()
        self.values_dict["model_struct"] = model_method.getModelStructName()
        self.values_dict["proto_request"] = model_object.getCorrespondingRequestForResponse(model_method)
        self.values_dict["proto_response"] = model_method.getMessage()
        self.values_dict["arg_name"] = "rtu_" + model_method.getModelStructName()[6:]

    def substitute(self):
        return self.template.substitute(self.values_dict)
    

class DdsOut:

    template = mot.dds_out
    values_dict = {}

    def __init__(self, model_object, model_method):
        self.values_dict["fun_name"] = model_method.getMethodName()
        self.values_dict["model_struct"] = model_method.getModelStructName()
        self.values_dict["model_class"] = model_object.getModelClassName()
        self.values_dict["model_name"] = model_object.getModelName()
        self.values_dict["topic_name"] =  "dds_ipc::"+ model_method.getTopicName()
        self.values_dict["arg_name"] = "rtu_" + model_method.getModelStructName()[6:]
        self.values_dict["printModelStruct"] = log_gen.ModelStructPrint(model_object, model_method).substitute()
        self.values_dict["copy_arg_name"] = "mutable" + model_method.getModelStructName()[6:7].upper() + model_method.getModelStructName()[7:]

    def substitute(self):
        return self.template.substitute(self.values_dict)


# ========== NEW: ML_API REQUEST OUT CLASS ==========
class MlApiRequestOut:
    """Generates ML_API request handler (only for quickControls model)"""
    
    template = mot.ml_api_request_out
    values_dict = {}

    def __init__(self, model_object, model_method):
        self.values_dict["fun_name"] = model_method.getMethodName()
        self.values_dict["model_struct"] = model_method.getModelStructName()
        self.values_dict["arg_name"] = "rtu_" + model_method.getModelStructName()[6:]
        
        # Derive response function name
        # ml_api_earlyccf_GetEarlyCCFParamRequest → ml_api_earlyccf_GetEarlyCCFParamResponse
        request_name = model_method.getMethodName()
        self.values_dict["response_fun"] = request_name.replace("Request", "Response")

        self.values_dict["model_class"] = model_object.getModelClassName()


        
        # Derive response struct name
        # structGetEarlyCCFParamRequest → structGetEarlyCCFParamResponse
        request_struct = model_method.getModelStructName()
        self.values_dict["model_response"] = request_struct.replace("Request", "Response")

    def substitute(self):
        return self.template.substitute(self.values_dict)


# ========== NEW: ML_API INCLUDES CLASS ==========
class MlApiIncludes:
    """Generates ML_API specific includes (only for quickControls)"""
    
    @staticmethod
    def substitute(model_name):
        if model_name != "quickControls":
            return ""
        
        return '''
#include "early_ccf.hpp"
#include<ml_API_earlyCCF_GetEarlyCCFParamRequest.h>

#include "structml_API_earlyCCF_GetEarlyCCFParamResponse.h"
#include <mutex>
#include <cstring>
'''


# ========== UPDATED: MAIN GENERATOR CLASS ==========      
class ModelOutGen:

    template = mot.model_out_template
    values_dict = {}

    def __init__(self, model_object):
        self.values_dict["includes"] = self.getIncludes(model_object)
        self.values_dict["model_name"] = model_object.getModelName()
        
        # NEW: ML_API Integration
        self.values_dict["ml_api_includes"] = MlApiIncludes.substitute(
            model_object.getModelName()
        )
        self.values_dict["ml_api_request_outs"] = self.mlApiRequestOuts(model_object)
        
        # Existing SOME-IP and DDS
        self.values_dict["someip_request_outs"] = self.someipRequestOuts(model_object)
        self.values_dict["someip_notify_outs"] = self.someipNotifyOuts(model_object)
        self.values_dict["someip_response_outs"] = self.someipResponseOuts(model_object)
        self.values_dict["dds_outs"] = self.DdsOuts(model_object)

    def getIncludes(self, model_object):
        all_outs = model_object.getAllModelOuts()
        
        res = ""
        for model_method in all_outs: 
          model_fun = model_method.getMethodName()
          res += ModelOutIncludes(model_fun).substitute()
        return res

    # ========== NEW: ML_API REQUEST OUTS METHOD ==========
    def mlApiRequestOuts(self, model_object):
        """Generate ML_API request handlers - ONLY for quickControls model"""
        
        # Check if this is quickControls model
        if model_object.getModelName() != "quickControls":
            return ""
        
        res = ""
        
        # Get all model methods
        all_methods = model_object.getAllModelMethods()
        
        # Filter ML_API methods with intent="out"
        for model_method in all_methods:
            if (hasattr(model_method, 'getIPCType') and 
                model_method.getIPCType() == "ml_API" and 
                model_method.getIntent() == "out"):
                res += MlApiRequestOut(model_object, model_method).substitute()
        
        return res

    def someipRequestOuts(self, model_object):
        request_outs = model_object.getAllSomeipRequestOuts()
        res = ""
        for _, model_methods in request_outs.items():
          for model_method in model_methods:
            isEmpty = model_method.checkIfModelEventHasArgument()
            if isEmpty:
                res += SomeipNonEmptyRequestOut(model_object, model_method).substitute()
            else:
                res += SomeipEmptyRequestOut(model_object, model_method).substitute()
        return res
    
    def someipNotifyOuts(self, model_object):
        notify_outs = model_object.getAllSomeipNotifyOuts()
        res = ""

        for vid, model_methods in notify_outs.items():
            for model_method in model_methods:
                res += SomeipNotifyOut(model_object, model_method).substitute()
            
        return res
    
    def someipResponseOuts(self, model_object):
        response_outs = model_object.getAllSomeipResponseOuts()
        res = ""

        for vid, model_methods in response_outs.items():
          for model_method in model_methods:
            res += SomeipResponsetOut(model_object, model_method).substitute()
            
        return res
    
    def DdsOuts(self, model_object):
        dds_outs = model_object.getAllDdsOuts()
        res = ""

        for model_method in dds_outs:
            res += DdsOut(model_object, model_method).substitute()
            
        return res

    def substitute(self):
        return self.template.substitute(self.values_dict)
