#ifndef _DI_MOCKVAL_SERVICE_
#define _DI_MOCKVAL_SERVICE_

#include <iostream>
#include <vector>

namespace di
{

  namespace mockval
  {

    struct Event
    {

      int mEventId;
      std::string mEventMessage;
    };

    struct EventGroup
    {

      int mEventGrpId;
      std::vector<int> mEvents;
    };

    struct Method
    {

      int mMethodId;
      std::string mRequestName;
      std::string mResponseName;
    };

    class Service
    {

    private:
      std::string mName;
      int mServiceId;
      int mInstanceId;
      bool mOffers;
      int mPeriod;
      std::vector<Event> mEvents;
      std::vector<EventGroup> mEventGrps;
      std::vector<Method> mMethods;

    public:
      Service();

      void set_name(std::string const& serviceName);

      std::string get_name() const;

      void set_service_id(int const serviceId);

      int get_service_id() const;

      void set_instance_id(int const instanceId);

      int get_instance_id() const;

      void set_offers(bool const offers);

      bool get_offers() const;

      void set_period(int const period);

      int get_period() const;

      void add_event(Event const& event);

      std::vector<Event> get_events() const;

      void add_eventgrp(EventGroup const& eventgrp);

      std::vector<EventGroup> get_eventgrps() const;

      void add_method(Method const& method);

      std::vector<Method> get_methods() const;
    };

  }  // namespace mockval

}  // namespace di

#endif
