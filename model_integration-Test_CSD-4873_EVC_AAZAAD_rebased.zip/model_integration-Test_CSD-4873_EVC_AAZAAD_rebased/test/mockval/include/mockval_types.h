#ifndef _DI_MOCKVAL_TYPES_HEADER_
#define _DI_MOCKVAL_TYPES_HEADER_

#include <iostream>

namespace di
{

  namespace mockval
  {

    struct InputData
    {

      /// @brief  Event name
      std::string messageName;

      /// @brief  Json object serialized to string
      std::string messageDict;
    };

    struct InputDataTimer
    {

      /// @brief  Event name
      std::string messageName;

      /// @brief  Json object serialized to string
      std::string messageDict;

      /// @brief time period to sleep after sending
      int timePeriod;
    };

    struct RequestResponseMapping
    {
      InputData requestData;
      InputData responseData;
    };

  }  // namespace mockval

}  // namespace di

#endif
