#ifndef _DI_MOCKVAL_SERVICE_INITIALIZER_
#define _DI_MOCKVAL_SERVICE_INITIALIZER_

#include <iostream>
#include <set>
#include <vector>
#include <map>
#include <Service.hpp>
#include <someip.hpp>
#include <GlobalFunctors.hpp>

namespace di
{

  namespace mockval
  {

    class ServiceInitializer
    {

    private:
      // Objects not allowed
      ServiceInitializer();

    public:
      static void init(Service const& service, std::shared_ptr<JLR::someip::Application> app);

      static std::set<vsomeip::eventgroup_t> find_groups(std::vector<EventGroup> const& eventgrps, int const eventId);
    };

  }  // namespace mockval

}  // namespace di

#endif
