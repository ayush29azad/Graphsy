#ifndef _DI_MOCKVAL_SERVICE_DEFINITION_PARSER_
#define _DI_MOCKVAL_SERVICE_DEFINITION_PARSER_

#include <vector>
#include <rapidjson/document.h>
#include <rapidjson/filereadstream.h>
#include <rapidjson/stringbuffer.h>
#include <rapidjson/writer.h>
#include <Service.hpp>

namespace di
{

  namespace mockval
  {

    constexpr int MAX_FILESIZE = 65536;

    class ServiceDefinitionParser
    {

    private:
      char readBuffer[MAX_FILESIZE];
      rapidjson::Document mDocument;

      std::vector<Service> mServices;

    public:
      ServiceDefinitionParser(std::string const filename);

      void add_service(Service const& service);

      std::vector<Service> get_services() const;

      void populate_services();

      Service jsonvalue_to_service(rapidjson::Value const& service);

      std::string find_name_jsonvalue(rapidjson::Value const& service);

      int find_service_id(rapidjson::Value const& service);

      int find_instance_id(rapidjson::Value const& service);

      bool find_offers(rapidjson::Value const& service);

      int find_period(rapidjson::Value const& service);

      Event find_event(rapidjson::Value const& eventMapping);

      EventGroup find_eventgrp(rapidjson::Value const& eventGroup);

      Method find_method(rapidjson::Value const& methodMapping);
    };

  }  // namespace mockval

}  // namespace di

#endif
