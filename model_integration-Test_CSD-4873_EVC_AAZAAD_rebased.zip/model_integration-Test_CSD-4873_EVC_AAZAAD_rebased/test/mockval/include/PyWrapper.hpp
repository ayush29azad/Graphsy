#ifndef _DI_MOCKVAL_PY_WRAPPER_
#define _DI_MOCKVAL_PY_WRAPPER_

#include <iostream>
#include <map>
#include <functional>
#include <memory>
#include <Python.h>

namespace di
{

  namespace mockval
  {

    class PyWrapper
    {

    private:
      PyWrapper()
      {
        Py_Initialize();
      }

      PyObject* import_module(std::string module_path);

      PyObject* get_function(std::string function, PyObject* module);

      PyObject* get_args(std::string args);

      PyObject* call_function1(PyObject* function, PyObject* args);

    public:
      std::map<std::string, PyObject*> modules;
      std::map<std::string, PyObject*> functions;

      PyWrapper(PyWrapper const&) = delete;
      void operator=(PyWrapper const&) = delete;

      static PyWrapper& get_instance()
      {
        static PyWrapper py_wrapper;
        return py_wrapper;
      }

      void set_python_path(std::string path);

      std::string call_function1_from_module(std::string module, std::string function_name, std::string arg);

      void destroy();
    };

  }  // namespace mockval

}  // namespace di

#endif
