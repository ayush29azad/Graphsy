#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from conans import CMake, ConanFile
from conan.tools.cmake import CMake, CMakeToolchain, CMakeDeps
from conan.tools.files import collect_libs
import os


class MockvalConan(ConanFile):
    name = "mockval"
    description = "Mockval"
    settings = "os", "compiler", "build_type", "arch"
    generators = "cmake_find_package", "CMakeToolchain"
    build_policy="never"
    options = {
        "shared": [True, False],
    }

    default_options = {
        "shared": True,
    }

    requires = (
        "fmt/9.1.0",
        "gtest/[1.x]",
        )
    
    def configure(self):
        self.options["fmt"].header_only = True

    
    def requirements(self):
        if self.settings.arch == "armv8":
            self.requires("vsomeip/3.3.0-fc-binary@visteoncccm/prd")
            self.requires("protobuf/3.21.11-fc@jlrcccm/prd")

    def imports(self):

        if self.settings.arch == "armv8":
            self.copy("*", dst="../include", src=self.deps_cpp_info["protobuf"].include_paths[0])
            self.copy("*", dst="../include", src=self.deps_cpp_info["vsomeip"].include_paths[0])
            self.copy("lib*", dst="../lib/protobuf", src=self.deps_cpp_info["protobuf"].lib_paths[0])
            self.copy("lib*", dst="../lib/vsomeip", src=self.deps_cpp_info["vsomeip"].lib_paths[0])


    def generate(self):
        tc = CMakeToolchain(self)
        tc.variables["BUILD_SHARED_LIBS"] = self.options.shared
            
        tc.generate()
        deps = CMakeDeps(self)
        deps.generate()

    def build(self):
        cmake = CMake(self)
        cmake.verbose = False
        cmake.configure()
        cmake.build()
        cmake.install()

    def package(self):
        cmake = CMake(self)
        cmake.install()

    def package_info(self):
        self.cpp_info.libs = collect_libs(self)
