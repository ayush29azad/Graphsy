#include <InputJsonParser.hpp>

using namespace di::mockval;

InputJsonParser::InputJsonParser(std::string const filename)
{

  FILE* fp = fopen(filename.c_str(), "rb");

  if (!fp)
  {
    std::cerr << "[Error]: unable to open file" << std::endl;
  }

  rapidjson::FileReadStream fileReadStream(fp, readBuffer, sizeof(readBuffer));
  mDocument.ParseStream(fileReadStream);

  if (mDocument.HasParseError())
  {
    std::cerr << "[Error]: failed to parse TestJson document" << std::endl;
  }

  fclose(fp);

  populate_initial_events();
  populate_input_data();
  populate_mapping_data();

  std::cout << "[Info]: Successfully parsed TestJson document" << std::endl;
}

void InputJsonParser::add_input_data(InputDataTimer const inputData)
{
  dataList.push_back(inputData);
}

void InputJsonParser::add_initial_data(InputData const inputData)
{
  initialEvents.push_back(inputData);
}

void InputJsonParser::add_mapping_data(RequestResponseMapping const& mappingData)
{
  mappingList.push_back(mappingData);
}

std::vector<InputDataTimer> InputJsonParser::get_input_data() const
{
  return dataList;
}

std::vector<InputData> InputJsonParser::get_initial_data() const
{
  return initialEvents;
}

std::vector<RequestResponseMapping> InputJsonParser::get_mapping_data() const
{
  return mappingList;
}

std::string InputJsonParser::get_message_name(rapidjson::Value const& value)
{

  if (value.HasMember("eventname"))
  {
    std::string result = value["eventname"].GetString();
    return result;
  }
  else
  {
    std::cout << "[Error]: Message has no member eventname" << std::endl;
    return "";
  }
}

std::string InputJsonParser::get_message_data(rapidjson::Value const& value)
{

  std::string resultString;

  if (value.HasMember("data"))
  {
    rapidjson::Value const& resultJson = value["data"].GetObject();
    pbjson::json2string(&resultJson, resultString);
  }
  else
  {
    std::cout << "[Error]: Message has no member data" << std::endl;
  }

  return resultString;
}

int InputJsonParser::get_time_period(rapidjson::Value const& value)
{

  if (value.HasMember("wait"))
  {
    int resultJson = value["wait"].GetInt();
    return resultJson;
  }
  else
  {
    // std::cout << "[Info]: Message has no member wait" << std::endl;
    return 1000;
  }
}

InputData InputJsonParser::jsonvalue_to_input_data(rapidjson::Value const& value)
{

  InputData inputData;

  inputData.messageName = get_message_name(value);
  inputData.messageDict = get_message_data(value);

  return inputData;
}

InputDataTimer InputJsonParser::jsonvalue_to_input_data_timer(rapidjson::Value const& value)
{

  InputDataTimer inputData;

  inputData.messageName = get_message_name(value);
  inputData.messageDict = get_message_data(value);
  inputData.timePeriod = get_time_period(value);

  return inputData;
}

RequestResponseMapping InputJsonParser::jsonvalue_to_mapping_data(rapidjson::Value const& value)
{

  RequestResponseMapping mapData;

  if (value.HasMember("request") && value.HasMember("response"))
  {
    rapidjson::Value const& requestDict = value["request"].GetObject();
    rapidjson::Value const& responseDict = value["response"].GetObject();
    mapData.requestData = jsonvalue_to_input_data(requestDict);
    mapData.responseData = jsonvalue_to_input_data(responseDict);
  }
  else
  {
    std::cout << "[Error]: Message has no member request or maybe response" << std::endl;
  }

  return mapData;
}

void InputJsonParser::populate_input_data()
{

  rapidjson::Value const& messageList = mDocument["flow"];

  for (rapidjson::SizeType i = 0; i < messageList.Size(); i++)
  {

    InputDataTimer inputData = jsonvalue_to_input_data_timer(messageList[i]);
    add_input_data(inputData);
  }
}

void InputJsonParser::populate_initial_events()
{

  rapidjson::Value const& messageList = mDocument["initial"];

  for (rapidjson::SizeType i = 0; i < messageList.Size(); i++)
  {

    InputData inputData = jsonvalue_to_input_data(messageList[i]);
    add_initial_data(inputData);
  }
}

void InputJsonParser::populate_mapping_data()
{

  rapidjson::Value const& mapList = mDocument["mapping"];

  for (rapidjson::SizeType i = 0; i < mapList.Size(); i++)
  {

    RequestResponseMapping mapData = jsonvalue_to_mapping_data(mapList[i]);
    add_mapping_data(mapData);
  }
}
