#include <iostream>
#include <rapidjson/document.h>
#include <rapidjson/filereadstream.h>
#include <rapidjson/stringbuffer.h>
#include <pbjson/pbjson.hpp>
#include <google/protobuf/message.h>
#include <vehiclespeed_service.pb.h>
#include <Python.h>

using namespace vehiclespeed_service;

int main()
{

  NotifyVehicleSpeed data;
  data.set_vehicle_speed_raw(11);
  data.set_vehicle_speed_tyre_size_corr(1);
  data.set_vehicle_speed_market_bias_corr(1);
  data.set_status(ENUM_STATUS_OK);

  std::string strJson;

  pbjson::pb2json(&data, strJson);

  // Calling python request response logic

  Py_Initialize();
  PySys_SetPath(L"../input");

  PyObject* myModuleString = PyUnicode_FromString((char*)"responseGen");
  PyObject* myModule = PyImport_Import(myModuleString);

  PyObject* myFunction = PyObject_GetAttrString(myModule, (char*)"main");
  PyObject* args = PyTuple_Pack(1, PyUnicode_FromString(strJson.c_str()));

  PyObject* myResult = PyObject_CallObject(myFunction, args);

  std::string stringResponse = PyUnicode_AsUTF8(myResult);

  Py_Finalize();

  std::cout << stringResponse << std::endl;

  // Getting response back in json object
  std::string errorString;
  NotifyVehicleSpeed resposeData;

  pbjson::json2pb(stringResponse, &resposeData, errorString);
  std::cout << resposeData.DebugString() << std::endl;

  return 0;
}
