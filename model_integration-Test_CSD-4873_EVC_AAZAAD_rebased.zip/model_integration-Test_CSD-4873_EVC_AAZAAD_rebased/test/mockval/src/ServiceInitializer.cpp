#include <ServiceInitializer.hpp>

using namespace di::mockval;

void ServiceInitializer::init(Service const& service, std::shared_ptr<JLR::someip::Application> app)
{

  if (service.get_offers())
  {
    app->offer_service(service.get_name(), service.get_service_id(), service.get_instance_id());

    for (auto event : service.get_events())
    {
      auto grps = find_groups(service.get_eventgrps(), event.mEventId);
      auto functor = app->offer_event(event.mEventMessage, event.mEventId, service.get_service_id(), grps);
      di::mockval::data::GlobalTables::get_instance().mSendFunctors[event.mEventMessage] = functor;
    }

    // todo : test this - done
    for (auto method : service.get_methods())
    {
      auto tmp = di::mockval::data::GlobalTables::get_instance().mRequestRecvFunctors[method.mRequestName];
      auto functor = app->register_message_handler_server(
          method.mRequestName, method.mMethodId, service.get_service_id(), service.get_instance_id(), tmp);
      di::mockval::data::GlobalTables::get_instance().mSendResponseFunctors[method.mResponseName] = functor;
    }
  }
  else
  {
    app->request_service(service.get_service_id(), service.get_instance_id());
    for (auto event : service.get_events())
    {
      auto grps = find_groups(service.get_eventgrps(), event.mEventId);
      app->request_event(event.mEventId, grps, service.get_service_id(), service.get_instance_id());
      for (auto grp_id : grps)
      {
        app->subscribe_to_eventgroup(grp_id, service.get_service_id(), service.get_instance_id());
      }
      auto nofify_handler =
          di::mockval::data::GlobalTables::get_instance().mNotifyResponseRecvFunctors[event.mEventMessage];
      app->register_message_handler(
          event.mEventMessage, event.mEventId, service.get_service_id(), service.get_instance_id(), nofify_handler);
    }

    for (auto method : service.get_methods())
    {
      auto response_handler =
          di::mockval::data::GlobalTables::get_instance().mNotifyResponseRecvFunctors[method.mResponseName];
      app->register_message_handler(
          method.mResponseName,
          method.mMethodId,
          service.get_service_id(),
          service.get_instance_id(),
          response_handler);

      di::mockval::data::GlobalTables::get_instance().mSendFunctors[method.mRequestName] =
          app->send_request(service.get_service_id(), service.get_instance_id(), method.mMethodId);
    }
  }
}

std::set<vsomeip::eventgroup_t> ServiceInitializer::find_groups(
    std::vector<EventGroup> const& eventgrps, int const eventId)
{

  std::set<vsomeip::eventgroup_t> res;

  for (auto grps : eventgrps)
  {
    auto events = grps.mEvents;
    for (auto event : events)
    {
      if (event == eventId)
      {
        res.insert(grps.mEventGrpId);
      }
    }
  }

  return res;
}
