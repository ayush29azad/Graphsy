#include <iostream>
#include <vehiclespeed_service.pb.h>
#include <ServiceInitializer.hpp>
#include <ServiceDefinitionParser.hpp>
#include <InputJsonParser.hpp>
#include <someip.hpp>

using namespace vehiclespeed_service;

int main()
{

  // Initialize service part

  std::map<std::string, std::function<void(std::string&)>> functorTable;

  di::mockval::ServiceDefinitionParser p = di::mockval::ServiceDefinitionParser(
      "/home/ravi/workspace/someip_boilerplate/exp/model_integration/mockval/config/gaugeSpeedometer_mockval.json");
  auto services = p.get_services();

  auto app = std::make_shared<JLR::someip::Application>("mockval");
  app->init();

  for (auto service : services)
  {
    auto mpp = di::mockval::ServiceInitializer::init(service, app);
    for (auto el : mpp)
    {
      functorTable[el.first] = el.second;
    }
  }

  app->start();

  // Send test cases part

  di::mockval::InputJsonParser inputParser = di::mockval::InputJsonParser(
      "/home/ravi/workspace/someip_boilerplate/exp/model_integration/mockval/tests/gaugeSpeedometer_input.json");
  auto inputList = inputParser.get_input_data();

  di::mockval::DataHandler dataHandler;
  auto mappingTable = dataHandler.get_mapping_table();

  while (1)
  {

    for (auto& el : inputList)
    {
      std::string event_name = el.messageName;

      std::string str_data = mappingTable[event_name](el.messageDict);
      functorTable[event_name](str_data);

      std::cout << "Sent message : " << el.messageName << std::endl;
      std::cout << el.messageDict << std::endl << std::endl;
      std::this_thread::sleep_for(std::chrono::milliseconds(1000));
    }
  }

  return 0;
}
