#include <ServiceDefinitionParser.hpp>

using namespace di::mockval;

ServiceDefinitionParser::ServiceDefinitionParser(std::string filename)
{

  FILE* fp = fopen(filename.c_str(), "rb");

  if (!fp)
  {
    std::cerr << "[Error]: unable to open file" << std::endl;
  }

  rapidjson::FileReadStream fileReadStream(fp, readBuffer, sizeof(readBuffer));
  mDocument.ParseStream(fileReadStream);

  if (mDocument.HasParseError())
  {
    std::cerr << "[Error]: failed to parse ServiceJson document" << std::endl;
  }

  fclose(fp);

  populate_services();

  std::cout << "[Info]: Successfully parsed ServiceJson document" << std::endl;
}

void ServiceDefinitionParser::add_service(Service const& service)
{
  mServices.push_back(service);
}

std::vector<Service> ServiceDefinitionParser::get_services() const
{
  return mServices;
}

void ServiceDefinitionParser::populate_services()
{

  rapidjson::Value const& services = mDocument["services"];

  for (rapidjson::SizeType i = 0; i < services.Size(); i++)
  {

    Service service = jsonvalue_to_service(services[i]);
    add_service(service);
  }
}

std::string ServiceDefinitionParser::find_name_jsonvalue(rapidjson::Value const& service)
{

  if (service.HasMember("Name"))
  {
    std::string result = service["Name"].GetString();
    return result;
  }
  else
  {
    std::cout << "[Error]: Service has no member Name" << std::endl;
    return "";
  }
}

int ServiceDefinitionParser::find_service_id(rapidjson::Value const& service)
{

  if (service.HasMember("ServiceID"))
  {
    std::string result = service["ServiceID"].GetString();
    return std::stoi(result, 0, 16);
  }
  else
  {
    std::cout << "[Error]: Service has no member ServiceID" << std::endl;
    return -1;
  }
}

int ServiceDefinitionParser::find_instance_id(rapidjson::Value const& service)
{

  if (service.HasMember("InstanceID"))
  {
    std::string result = service["InstanceID"].GetString();
    return std::stoi(result, 0, 16);
  }
  else
  {
    std::cout << "[Error]: Service has no member InstanceID" << std::endl;
    return -1;
  }
}

bool ServiceDefinitionParser::find_offers(rapidjson::Value const& service)
{

  if (service.HasMember("Offers"))
  {
    bool result = service["Offers"].GetBool();
    return result;
  }
  else
  {
    std::cout << "[Error]: Service has no member Offers" << std::endl;
    return false;
  }
}

int ServiceDefinitionParser::find_period(rapidjson::Value const& service)
{

  if (service.HasMember("Period"))
  {
    int result = service["Period"].GetInt();
    return result;
  }
  else
  {
    std::cout << "[Error]: Service has no member Period" << std::endl;
    return -1;
  }
}

Event ServiceDefinitionParser::find_event(rapidjson::Value const& eventMapping)
{

  Event event;

  if (eventMapping.HasMember("EventID"))
  {
    std::string result = eventMapping["EventID"].GetString();
    event.mEventId = std::stoi(result, 0, 16);
  }
  else
  {
    std::cout << "[Error]: eventMapping has no member EventID" << std::endl;
    return event;
  }

  if (eventMapping.HasMember("EventMessage"))
  {
    std::string result = eventMapping["EventMessage"].GetString();
    event.mEventMessage = result;
  }
  else
  {
    std::cout << "[Error]: eventMapping has no member EventMessage" << std::endl;
    return event;
  }

  return event;
}

Method ServiceDefinitionParser::find_method(rapidjson::Value const& methodMapping)
{

  Method method;

  if (methodMapping.HasMember("MethodID"))
  {
    std::string result = methodMapping["MethodID"].GetString();
    method.mMethodId = std::stoi(result, 0, 16);
  }
  else
  {
    std::cout << "[Error]: methodMapping obj has no member MethodID" << std::endl;
    return method;
  }

  if (methodMapping.HasMember("RequestMessage"))
  {
    std::string result = methodMapping["RequestMessage"].GetString();
    method.mRequestName = result;
  }
  else
  {
    std::cout << "[Error]: methodMapping obj has no member RequestMessage" << std::endl;
    return method;
  }

  if (methodMapping.HasMember("ResponseMessage"))
  {
    std::string result = methodMapping["ResponseMessage"].GetString();
    method.mResponseName = result;
  }
  else
  {
    std::cout << "[Error]: methodMapping obj has no member ResponseMessage" << std::endl;
    return method;
  }

  return method;
}

EventGroup ServiceDefinitionParser::find_eventgrp(rapidjson::Value const& eventGroup)
{

  EventGroup grp;

  if (eventGroup.HasMember("eventgroup"))
  {
    std::string result = eventGroup["eventgroup"].GetString();
    grp.mEventGrpId = std::stoi(result, 0, 16);
  }
  else
  {
    std::cout << "[Error]: eventgroup has no member eventgroup" << std::endl;
  }

  std::vector<int> events;

  if (eventGroup.HasMember("events"))
  {
    rapidjson::Value const& eventList = eventGroup["events"];
    for (rapidjson::Value::ConstValueIterator itr = eventList.Begin(); itr != eventList.End(); ++itr)
    {
      std::string val = itr->GetString();
      events.push_back(std::stoi(val, 0, 16));
    }
  }
  else
  {
    std::cout << "[Error]: eventgroup has no member events" << std::endl;
  }

  grp.mEvents = events;

  return grp;
}

Service ServiceDefinitionParser::jsonvalue_to_service(rapidjson::Value const& serviceValue)
{

  Service service;
  service.set_name(find_name_jsonvalue(serviceValue));
  service.set_service_id(find_service_id(serviceValue));
  service.set_instance_id(find_instance_id(serviceValue));
  service.set_offers(find_offers(serviceValue));
  service.set_period(find_period(serviceValue));

  if (serviceValue.HasMember("EventMappings"))
  {
    rapidjson::Value const& eventList = serviceValue["EventMappings"];
    for (rapidjson::Value::ConstValueIterator itr = eventList.Begin(); itr != eventList.End(); ++itr)
    {
      Event e = find_event(*itr);
      service.add_event(e);
    }
  }
  else
  {
    std::cout << "[Error]: Service has no member EventMappings" << std::endl;
  }

  if (serviceValue.HasMember("eventgroups"))
  {
    rapidjson::Value const& eventgrps = serviceValue["eventgroups"];
    for (rapidjson::Value::ConstValueIterator itr = eventgrps.Begin(); itr != eventgrps.End(); ++itr)
    {
      EventGroup e = find_eventgrp(*itr);
      service.add_eventgrp(e);
    }
  }
  else
  {
    std::cout << "[Error]: Service has no member EventMappings" << std::endl;
  }

  if (serviceValue.HasMember("MethodMappings"))
  {
    rapidjson::Value const& methods = serviceValue["MethodMappings"];
    for (rapidjson::Value::ConstValueIterator itr = methods.Begin(); itr != methods.End(); ++itr)
    {
      Method m = find_method(*itr);
      service.add_method(m);
    }
  }
  else
  {
    std::cout << "[Error]: Service has no member MethodMappings" << std::endl;
  }

  return service;
}
