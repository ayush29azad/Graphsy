#include <memory>

#include "someip.hpp"
#include "receiver.hpp"

int main()
{
  auto app = std::make_shared<JLR::someip::Application>("JLR subscriber");

  app->init();
  app->request_service(0x0008, 0x0001);
  {
    std::set<vsomeip::eventgroup_t> groups;
    groups.insert(0x4455);
    app->request_event(0x8001, groups, 0x0008, 0x0001);
  }
  app->subscribe_to_eventgroup(0x4455, 0x0008, 0x0001);

  app->register_message_handler("NotifyVehicleSpeed", 0x8001, 0x0008, 0x0001, &Receiver::NotifyVehicleSpeed);

  app->start();
}
