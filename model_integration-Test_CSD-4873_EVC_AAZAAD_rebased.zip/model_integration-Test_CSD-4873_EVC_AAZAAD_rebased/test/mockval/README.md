# mockval

The mockval application helps in testing DI software by emulating vsomeip services (this mocks VAL + pseudocom). It takes two input files at runtime - one for defining the services that it offers and another for controlling the data it sends. Third optional python input file can be provided for generating responses based of received request. 

## How to run 

- Copy both the input and service definition json from config folder to the target 
- Execute 

```
./mockval <service_def_json> <input_json> <python_file>
```

Third argument is optional. You can also launch any combination of services per instance of the mockval.

## Extending for any given event

Modify the file **SupportedEvents.hpp** after generating the pb.cc and pb.h for the proto file.

```
// Include header files for the required events 
#include <vehiclespeed_service.pb.h>
#include <featureconfig_userapps_service.pb.h>

namespace di::mockval::data {

    void init(){

        // Adding support for Notify events (so that mockval can act as server)
        di::mockval::FunctorsHandler::add_support<vehiclespeed_service::NotifyVehicleSpeed>("NotifyVehicleSpeed");

        // Adding support for Notify events (so that mockval can act as client)
        di::mockval::FunctorsHandler::add_support_client<vehiclespeed_service::NotifyVehicleSpeed>("NotifyVehicleSpeed");

        // Adding support for Request-Response events (so that mockval can act as server)
        di::mockval::FunctorsHandler::add_support<vehiclespeed_service::GetVehicleSpeedRequest,vehiclespeed_service::GetVehicleSpeedResponse>
        ("GetVehicleSpeedRequest", "GetVehicleSpeedResponse");

        di::mockval::FunctorsHandler::add_support<featureconfig_userapps_service::GetParamRequest,featureconfig_userapps_service::GetParamResponse>
        ("GetParamRequest", "GetParamResponse");

        // Adding support for Request-Response events (so that mockval can act as client)
        di::mockval::FunctorsHandler::add_support_client<vehiclespeed_service::GetVehicleSpeedRequest,vehiclespeed_service::GetVehicleSpeedResponse>
        ("GetVehicleSpeedRequest", "GetVehicleSpeedResponse");

    }

}
```

Once the mockval executable is built, you need to rebuild it only if the proto file changes or you want to add support for more events. It is advised that you add support for all the events present across all the models you want to test at once and use the same executable till the proto is changed (which mostly happens once for a release)

Both add_support() and add_support_client() can be used for the same event in the above file. The service definition file provided at runtime will define the behaviour of the mockval. These functions aren't defining the mockval behaviour as client/server.


## Structure of input json file

- **initial** : Creates an in memory object for the proto message and initializes it with the given values
- **flow** : Initialized notifies will be sent in a periodic fashion (with period hardcoded as of now) in this order. For response fields, the state of the in-memory response messages that were created during initialization will be modified. This modified response will only be sent when an empty request is received.
- **mapping** : If the received request contains any data (non-empty), then we have to specify the corresponding response here.


```
{
    "initial" : [
        {
            "eventname" : "NotifyVehicleSpeed",
            "data" : {
                "vehicle_speed_raw" : 0,
                "vehicle_speed_tyre_size_corr" : 1,
                "vehicle_speed_market_bias_corr" : 2,
                "status" : "ENUM_STATUS_OK"
            }
        },
        {
            "eventname" : "GetVehicleSpeedResponse",
            "data" : {
                "vehicle_speed_raw" : 0,
                "vehicle_speed_tyre_size_corr" : 1,
                "vehicle_speed_market_bias_corr" : 2,
                "status" : "ENUM_STATUS_OK"
            }
        }
    ],

    "flow" : [
        {
            "eventname" : "NotifyVehicleSpeed",
            "data" : {
                "vehicle_speed_raw" : 11
            },
            "wait" : 100
        },
        {
            "eventname" : "GetVehicleSpeedResponse",
            "data" : {
                "vehicle_speed_raw" : 11
            },
            "wait" : 200
        },
        {
            "eventname" : "NotifyVehicleSpeed",
            "data" : {
                "vehicle_speed_raw" : 12
            },
            "wait" : 300
        },
        {
            "eventname" : "NotifyVehicleSpeed",
            "data" : {
                "vehicle_speed_raw" : 13
            },
            "wait" : 500
        },
        {
            "eventname" : "GetVehicleSpeedResponse",
            "data" : {
                "vehicle_speed_raw" : 13
            },
            "wait" : 1000
        },
        {
            "eventname" : "NotifyVehicleSpeed",
            "data" : {
                "vehicle_speed_raw" : 50,
                "vehicle_speed_tyre_size_corr" : 1,
                "vehicle_speed_market_bias_corr" : 2,
                "status" : "ENUM_STATUS_OK"
            },
            "wait" : 2000
        }
    ],

    "mapping" : [
        {
            "request" : {
                "eventname" : "GetParamRequest",
                "data" : {
                    "params" : [
                        {
                            "mdf_id" : 22071
                        },
                        {
                            "mdf_id" : 22055
                        }
                    ]
                }
            },
            "response" : {
                "eventname" : "GetParamResponse",
                "data" : {
                    "params" : [
                        {
                            "mdf" : 22071,
                            "value" : 31,
                            "mdf_status" : "ENUM_STATUS_MDFID_OK"
                        },
                        {
                            "mdf" : 22055,
                            "value" : 64,
                            "mdf_status" : "ENUM_STATUS_MDFID_OK"
                        }
                    ],
                    "status" : "ENUM_STATUS_CCF_OK"
                }
            }
        }
    ]
}
```

## Structure of service definition json file

It defines an array of services that we want to offer. Each such service is pretty much same as the service definition json file except for few fields :

- **InstanceID** : Instance ID that we want to offer for that service.
- **Offers** : If this is true, it means that the application will act as a server for the given service. False would mean that the application will act as a client for that service.
- **Period** : Not being used from here. Instead "wait" property is added for every event in the Input data json.

```
{
    "services": [
        {
            "Name": "vehiclespeed_service",
            "ServiceID": "0x0008",
            "InstanceID" : "0x0001",
            "Offers" : true,
            "Period" : 200,
            "MethodMappings": [
                {
                    "MethodID": "0x0001",
                    "RequestMessage": "GetVehicleSpeedRequest",
                    "ResponseMessage": "GetVehicleSpeedResponse"
                }
            ],
            "EventMappings": [
                {
                    "EventID": "0x8001",
                    "EventMessage": "NotifyVehicleSpeed"
                }
            ],
            "eventgroups": [
                {
                    "eventgroup": "0x4455",
                    "events": [
                        "0x8001"
                    ]
                }
            ]
        },
        {
            "Name": "featureconfig_cccmuserapps_service",
            "ServiceID": "0x000B",
            "InstanceID" : "0x0001",
            "Offers": true,
            "Period": 200,
            "MethodMappings": [
                {
                    "MethodID": "0x7001",
                    "RequestMessage": "GetParamRequest",
                    "ResponseMessage": "GetParamResponse"
                },
                {
                    "MethodID": "0x7002",
                    "RequestMessage": "GetUpdatedParamRequest",
                    "ResponseMessage": "GetUpdatedParamResponse"
                },
                {
                    "MethodID": "0x7003",
                    "RequestMessage": "GetCCFFromCCFMasterRequest",
                    "ResponseMessage": "GetCCFFromCCFMasterResponse"
                },
                {
                    "MethodID": "0x7004",
                    "RequestMessage": "GetVINRequest",
                    "ResponseMessage": "GetVINResponse"
                },
                {
                    "MethodID": "0x7005",
                    "RequestMessage": "ReportBadValueRequest",
                    "ResponseMessage": "ReportBadValueResponse"
                }
            ],
            "EventMappings": [
                {
                    "EventID": "0x8901",
                    "EventMessage": "NotifyUpdatedParameterInfo"
                }
            ],
            "eventgroups": [
                {
                    "eventgroup": "0x9000",
                    "events": [
                        "0x8901"
                    ]
                }
            ]
        }
    ]
}

```

## Python file input

Using python c-api, we can interpret python code from C/C++ code. A wrapper class for calling the **main** function of this python file has been developed.

```
import sys

# Takes request as dict and returns response as dict object
# Write the response generation logic here 
def generator(request_json):
    # print(request_json)

    response_json = dict()
    response_json["status"] = "ENUM_STATUS_CCF_OK"
    response_json["params"] = []

    request_params = request_json["params"]
    for param in request_params:
        tmp = dict()
        tmp["mdf_status"] = "ENUM_STATUS_MDFID_OK"
        tmp["mdf"] = param["mdf_id"]
        if param["mdf_id"]%7 == 0 : 
            tmp["value"] = 51

        response_json["params"].append(tmp)

    # return python dict object
    return response_json


# Do not modify name, return or argument of the below function - cpp code is calling this function
def main(request_str):

    # modify this to "/usr/lib/python3.11" for qnx 
    sys.path.append("/usr/lib/python3.10")
    import json 

    request_json = json.loads(request_str)

    return json.dumps(generator(request_json))
```

The flow here is - cpp code will call the main function with request json **string** as argument, and expect a response json **string** to be returned. **sys.path.append()** is used to set the python path variable so that all the system imports are available. The request is then converted to python dict and forwarded to **generator** function. The generator function should return python dict object. Developers are supposed to write the logic in the **generator()** .
