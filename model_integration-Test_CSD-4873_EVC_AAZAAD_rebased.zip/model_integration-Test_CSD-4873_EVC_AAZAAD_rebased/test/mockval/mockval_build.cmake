set(ROOT_DIR $ENV{ROOTPATH})
set(MODEL_DIR "${ROOT_DIR}/model_ipc/models")

cmake_minimum_required(VERSION 3.5)
set(BINARY_NAME "mockval")
project(mockval)
function(target_add_dependencies target)

endfunction()

include(${CMAKE_CURRENT_SOURCE_DIR}/test/mockval/CMakeLists.txt)
