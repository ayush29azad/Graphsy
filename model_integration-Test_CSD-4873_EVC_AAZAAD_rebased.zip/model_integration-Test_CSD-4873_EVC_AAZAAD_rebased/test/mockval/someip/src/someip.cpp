#include <vsomeip/vsomeip.hpp>
#include <thread>
#include <string>
#include <functional>
#include <set>
#include <iostream>

#include "someip.hpp"
#include "soa.h"

namespace JLR
{

  namespace someip
  {
    struct event
    {
      vsomeip::event_t event_id;
      std::string event_name;
    };

    struct service_instance
    {
      service_instance(
          std::string service_name, vsomeip::service_t service_id, vsomeip::instance_t instance_id = 0x0010
          // TODO : Check if default value will cause an issue
          // when we make multiple applications with the same service.
          // Need a way to detect such things
          )
          : service_name(service_name)
          , service_id(service_id)
          , instance_id(instance_id)
      {
      }

      std::string service_name;
      vsomeip::service_t service_id;
      vsomeip::instance_t instance_id;
      std::map<vsomeip::event_t, event> events;
    };

    Application::Application(std::string name)
        : app_(vsomeip::runtime::get()->create_application(name))
    {
    }

    Application::~Application()
    {
      if (event_loop_thread.joinable())
        event_loop_thread.join();
    }

    bool Application::init()
    {
      if (!app_->init())
      {
        return false;
      }
      else
        return true;
    }

    void Application::start()
    {
      event_loop_thread = std::thread(std::bind(&Application::start_, this));
    }

    void Application::offer_service(
        std::string service_name, vsomeip::service_t service_id, vsomeip::instance_t instance_id)
    {
      // TODO: Enforce single instance of service per application??
      service_instance_[service_id] = std::make_shared<service_instance>(service_name, service_id, instance_id);
      app_->offer_service(service_id, instance_id, JLR_SOMEIP_MAJOR_VERSION);
    }

    void Application::request_service(vsomeip::service_t service_id, vsomeip::instance_t instance_id)
    {
      app_->request_service(service_id, instance_id, JLR_SOMEIP_MAJOR_VERSION);
    }

    void Application::request_event(
        vsomeip::event_t event_id, std::set<vsomeip::eventgroup_t>& eventgroups, vsomeip::service_t service_id,
        vsomeip::instance_t instance_id)
    {
      app_->request_event(service_id, instance_id, event_id, eventgroups);
    }

    void Application::subscribe_to_eventgroup(
        vsomeip::eventgroup_t eventgroup, vsomeip::service_t service_id, vsomeip::instance_t instance_id)
    {
      app_->subscribe(service_id, instance_id, eventgroup, JLR_SOMEIP_MAJOR_VERSION);
    }

    std::function<void(std::string&)> Application::offer_event(
        std::string event_message_name, vsomeip::event_t event_id, vsomeip::service_t service_id,
        std::set<vsomeip::eventgroup_t> groups)
    {
      app_->offer_event(
          service_instance_[service_id]->service_id, service_instance_[service_id]->instance_id, event_id, groups);

      return std::function<void(std::string&)>(
          [this, service_id, event_id](std::string& data)
          {
            // TODO: Make sure that this function is not called if the object no longer exists
            auto payload = soa_payload::create_soa_payload(data);

            this->app_->notify(service_id, this->service_instance_[service_id]->instance_id, event_id, payload);
          });
    }

    void Application::register_message_handler(
        std::string method_name, vsomeip::method_t method_id, vsomeip::service_t service_id,
        vsomeip::instance_t instance_id, message_handler_t handler)
    {
      message_handlers[method_name] = [handler](std::shared_ptr<vsomeip::message> const& message)
      {
        auto payload = message->get_payload();

        if (!soa_payload::is_malformed(payload))
        {
          std::string data = soa_payload::extract_protobuf(payload);
          handler(data);
        }
      };
      app_->register_message_handler(service_id, instance_id, method_id, message_handlers[method_name]);
    }

    std::function<void(std::string&)> Application::register_message_handler_server(
        std::string method_name, vsomeip::method_t method_id, vsomeip::service_t service_id,
        vsomeip::instance_t instance_id, message_handler_t handler)
    {
      message_handlers[method_name] = [this, method_name, handler](std::shared_ptr<vsomeip::message> const& message)
      {
        this->lastRequest[method_name] = message;
        auto payload = message->get_payload();
        if (!soa_payload::is_malformed(payload))
        {
          std::string data = soa_payload::extract_protobuf(payload);
          handler(data);
        }
        else
        {
          std::cout << "[Info] : Request Payload was malformed" << std::endl;
        }
      };
      app_->register_message_handler(service_id, instance_id, method_id, message_handlers[method_name]);

      return std::function<void(std::string&)>(
          [this, method_name, method_id](std::string data)
          {
            auto response = vsomeip::runtime::get()->create_response(this->lastRequest[method_name]);
            auto payload = soa_payload::create_soa_payload(data);
            response->set_payload(payload);

            this->app_->send(response);
          });
    }

    std::function<void(std::string&)> Application::send_request(
        vsomeip::service_t service_id, vsomeip::instance_t instance_id, vsomeip::method_t method_id)
    {
      auto lam = [this, service_id, instance_id, method_id](std::string data)
      {
        auto payloadToBeSent = soa_payload::create_soa_payload(data);

        auto someIP_request = vsomeip::runtime::get()->create_request();

        someIP_request->set_service(service_id);
        someIP_request->set_instance(instance_id);
        someIP_request->set_method(method_id);
        someIP_request->set_interface_version(JLR_SOMEIP_MAJOR_VERSION);

        someIP_request->set_payload(payloadToBeSent);

        app_->send(someIP_request);
      };

      return lam;
    }

    void Application::start_()
    {
      app_->start();
    }

  }  // namespace someip
}  // namespace JLR
