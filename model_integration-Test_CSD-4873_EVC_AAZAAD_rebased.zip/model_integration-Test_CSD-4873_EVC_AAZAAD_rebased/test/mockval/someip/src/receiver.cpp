#include <string>
#include "receiver.hpp"

// void Receiver::NotifyVehicleSpeed(std::string& data)
// {
//     vehiclespeed_service::NotifyVehicleSpeed proto_message;
//     proto_message.ParseFromString(data);

//     std::cout<<"--------------------------------------------------"<< std::endl
//         <<"Message Received:"<< std::endl
//         << proto_message.DebugString() << std::endl
//         <<"---------------------------------------------------"<< std::endl;
// }

void Receiver::GetParamResponse(std::string& data)
{
  featureconfig_userapps_service::GetParamResponse proto_message;
  proto_message.ParseFromString(data);

  std::cout << "--------------------------------------------------" << std::endl
            << "Message Received:" << std::endl
            << proto_message.DebugString() << std::endl
            << "---------------------------------------------------" << std::endl;
}
