#include <vsomeip/vsomeip.hpp>
#include <thread>
#include <memory>
#include <functional>
#include <set>
#include <unordered_map>
#include <map>
#include <string>

#ifndef JLR_SOMEIP_HPP
#define JLR_SOMEIP_HPP

#define JLR_SOMEIP_MAJOR_VERSION 1
namespace JLR
{

  namespace someip
  {

    struct event;

    struct service_instance;

    typedef std::function<void(std::string&)> message_handler_t;

    /**
     *
     * \brief Manages a vsomeip application
     *
     * We will only create one instance of a service
     * in a single application, need to enforce that
     */
    class Application
    {
    public:
      Application(std::string name);

      ~Application();

      bool init();

      void start();

      void offer_service(
          std::string service_name, vsomeip::service_t service_id, vsomeip::instance_t instance_id = 0x0010);

      void request_service(vsomeip::service_t service_id, vsomeip::instance_t instance_id);

      void request_event(
          vsomeip::event_t event_id, std::set<vsomeip::eventgroup_t>& eventgroups, vsomeip::service_t service_id,
          vsomeip::instance_t instance_id);

      void subscribe_to_eventgroup(
          vsomeip::eventgroup_t eventgroup, vsomeip::service_t service_id, vsomeip::instance_t instance_id);

      std::function<void(std::string&)> offer_event(
          std::string event_message_name, vsomeip::event_t event_id, vsomeip::service_t service_id,
          std::set<vsomeip::eventgroup_t> groups);

      void register_message_handler(
          std::string method_name, vsomeip::method_t method_id, vsomeip::service_t service_id,
          vsomeip::instance_t instance_id, message_handler_t handler);

      std::function<void(std::string&)> register_message_handler_server(
          std::string method_name, vsomeip::method_t method_id, vsomeip::service_t service_id,
          vsomeip::instance_t instance_id, message_handler_t handler);

      std::function<void(std::string&)> send_request(
          vsomeip::service_t service_id, vsomeip::instance_t instance_id, vsomeip::method_t method_id);

    private:
      void start_();

      std::shared_ptr<vsomeip::application> app_;
      std::unordered_map<vsomeip::service_t, std::shared_ptr<service_instance>> service_instance_;

      std::thread event_loop_thread;

      std::unordered_map<std::string, vsomeip::message_handler_t> message_handlers;
      std::map<std::string, std::shared_ptr<vsomeip::message>> lastRequest;
    };
  }  // namespace someip
}  // namespace JLR
#endif
