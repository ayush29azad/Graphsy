Feature:
    Scenario: Start server/clients
        When Start server for lifecycle_cccmuserapps_vlca_service
        And Start server for visibility_service
    
    Scenario: Set Vehicle_State = 'ENUM_STATE_RUNNING'
        Given Receive request GetVLCAStateRequest
        When GetVLCAStateResponse.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When GetVLCAStateResponse.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When GetVLCAStateResponse.vehicle_state = 'ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL'
        When Send response GetVLCAStateResponse
    

    Scenario:  # 'ENUM_WIPER_MODE_OFF' and 'ENUM_STATE_RUNNING' (default)
        When NotifyFrontWiperStatus.status = 'ENUM_STATUS_OK'
        When NotifyFrontWiperStatus.wiper_mode = 'ENUM_WIPER_MODE_OFF'
        When NotifyFrontWiperStatus is sent
        Then HMI shows:  DI_GUI.transFrontWiper.eTransFrontWiper == 'FRONT_WIPER_OFF' DI_GUI.transFrontWiper.vTransFrontWiper == TRUE
    
    Scenario: Set Vehicle_State = 'ENUM_STATE_COMFORT'
        When NotifyVLCAState.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_state = 'ENUM_VEHICLE_STATE_COMFORT'
        When NotifyVLCAState is sent
    
    Scenario:   # 'ENUM_WIPER_MODE_OFF' and 'ENUM_STATE_COMFORT'
        When NotifyFrontWiperStatus.status = 'ENUM_STATUS_OK'
        When NotifyFrontWiperStatus.wiper_mode = 'ENUM_WIPER_MODE_OFF'
        When NotifyFrontWiperStatus is sent
        Then HMI shows:  DI_GUI.transFrontWiper.eTransFrontWiper == 'FRONT_WIPER_OFF' DI_GUI.transFrontWiper.vTransFrontWiper == TRUE
    
    Scenario:  # 'ENUM_STATE_COMFORT' and 'ENUM_WIPER_MODE_NORMAL'
        When NotifyFrontWiperStatus.status = 'ENUM_STATUS_OK'
        When NotifyFrontWiperStatus.wiper_mode = 'ENUM_WIPER_MODE_NORMAL'
        When NotifyFrontWiperStatus is sent
        Then HMI shows:  DI_GUI.transFrontWiper.eTransFrontWiper == 'FRONT_WIPER_SLOW' DI_GUI.transFrontWiper.vTransFrontWiper == TRUE
    
    Scenario:  # 'ENUM_STATE_COMFORT' and 'ENUM_WIPER_MODE_FAST'
        When NotifyFrontWiperStatus.status = 'ENUM_STATUS_OK'
        When NotifyFrontWiperStatus.wiper_mode = 'ENUM_WIPER_MODE_FAST'
        When NotifyFrontWiperStatus is sent
        Then HMI shows:  DI_GUI.transFrontWiper.eTransFrontWiper == 'FRONT_WIPER_FAST' DI_GUI.transFrontWiper.vTransFrontWiper == TRUE
    
    Scenario:  # 'ENUM_STATE_COMFORT' and 'ENUM_WIPER_MODE_FAST' and  ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY6 (don't care)
        When NotifyFrontWiperStatus.status = 'ENUM_STATUS_OK'
        When NotifyFrontWiperStatus.wiper_mode = 'ENUM_WIPER_MODE_FAST'
        When NotifyFrontWiperStatus is sent
        When NotifyWiperSensitivityStatus.status = 'ENUM_STATUS_OK'
        When NotifyWiperSensitivityStatus.wiper_sensitivity = 'ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY6'
        When NotifyWiperSensitivityStatus is sent
        Then HMI shows:  DI_GUI.transFrontWiper.eTransFrontWiper == 'FRONT_WIPER_FAST' DI_GUI.transFrontWiper.vTransFrontWiper == TRUE
    
    Scenario:  # 'ENUM_STATE_COMFORT' and 'ENUM_WIPER_MODE_INTERMITTENT' and ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY6
        When NotifyFrontWiperStatus.status = 'ENUM_STATUS_OK'
        When NotifyFrontWiperStatus.wiper_mode = 'ENUM_WIPER_MODE_INTERMITTENT'
        When NotifyFrontWiperStatus is sent
        Then HMI shows:  DI_GUI.transFrontWiper.eTransFrontWiper == 'FRONT_WIPER_INT_6' DI_GUI.transFrontWiper.vTransFrontWiper == TRUE
    
    Scenario:  # 'ENUM_STATE_COMFORT' and 'ENUM_WIPER_MODE_INTERMITTENT' and  ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY1
        When NotifyFrontWiperStatus.status = 'ENUM_STATUS_OK'
        When NotifyFrontWiperStatus.wiper_mode = 'ENUM_WIPER_MODE_INTERMITTENT'
        When NotifyFrontWiperStatus is sent
        When NotifyWiperSensitivityStatus.status = 'ENUM_STATUS_OK'
        When NotifyWiperSensitivityStatus.wiper_sensitivity = 'ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY1'
        When NotifyWiperSensitivityStatus is sent
        Then HMI shows:  DI_GUI.transFrontWiper.eTransFrontWiper == 'FRONT_WIPER_INT_1' DI_GUI.transFrontWiper.vTransFrontWiper == TRUE
    
    Scenario: 'ENUM_STATE_COMFORT' and 'ENUM_WIPER_MODE_INTERMITTENT' and  ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY2
        When NotifyFrontWiperStatus.status = 'ENUM_STATUS_OK'
        When NotifyFrontWiperStatus.wiper_mode = 'ENUM_WIPER_MODE_INTERMITTENT'
        When NotifyFrontWiperStatus is sent
        When NotifyWiperSensitivityStatus.status = 'ENUM_STATUS_OK'
        When NotifyWiperSensitivityStatus.wiper_sensitivity = 'ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY2'
        When NotifyWiperSensitivityStatus is sent
        Then HMI shows:  DI_GUI.transFrontWiper.eTransFrontWiper == 'FRONT_WIPER_INT_2' DI_GUI.transFrontWiper.vTransFrontWiper == TRUE
    
    Scenario: # 'ENUM_STATE_COMFORT' and 'ENUM_WIPER_MODE_INTERMITTENT' and  ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY2# Check DDS when same input is repeated twice
        When NotifyFrontWiperStatus.status = 'ENUM_STATUS_OK'
        When NotifyFrontWiperStatus.wiper_mode = 'ENUM_WIPER_MODE_INTERMITTENT'
        When NotifyFrontWiperStatus is sent
        When NotifyWiperSensitivityStatus.status = 'ENUM_STATUS_OK'
        When NotifyWiperSensitivityStatus.wiper_sensitivity = 'ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY2'
        When NotifyWiperSensitivityStatus is sent
        Then HMI shows:  DI_GUI.transFrontWiper.eTransFrontWiper == 'FRONT_WIPER_INT_2' DI_GUI.transFrontWiper.vTransFrontWiper == TRUE
    
    Scenario:  # 'ENUM_STATE_COMFORT' and 'ENUM_WIPER_MODE_INTERMITTENT' and  ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY3
        When NotifyFrontWiperStatus.status = 'ENUM_STATUS_OK'
        When NotifyFrontWiperStatus.wiper_mode = 'ENUM_WIPER_MODE_INTERMITTENT'
        When NotifyFrontWiperStatus is sent
        When NotifyWiperSensitivityStatus.status = 'ENUM_STATUS_OK'
        When NotifyWiperSensitivityStatus.wiper_sensitivity = 'ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY3'
        When NotifyWiperSensitivityStatus is sent
        Then HMI shows:  DI_GUI.transFrontWiper.eTransFrontWiper == 'FRONT_WIPER_INT_3' DI_GUI.transFrontWiper.vTransFrontWiper == TRUE
    
    Scenario:  # Check DDS when vehicle state changes
        When NotifyVLCAState.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_state = 'ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL'
        When NotifyVLCAState is sent
    
    
    Scenario:  # 'ENUM_STATE_RUNNING' and 'ENUM_WIPER_MODE_INTERMITTENT' and  ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY4
        When NotifyFrontWiperStatus.status = 'ENUM_STATUS_OK'
        When NotifyFrontWiperStatus.wiper_mode = 'ENUM_WIPER_MODE_INTERMITTENT'
        When NotifyFrontWiperStatus is sent
        When NotifyWiperSensitivityStatus.status = 'ENUM_STATUS_OK'
        When NotifyWiperSensitivityStatus.wiper_sensitivity = 'ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY4'
        When NotifyWiperSensitivityStatus is sent
        Then HMI shows:  DI_GUI.transFrontWiper.eTransFrontWiper == 'FRONT_WIPER_INT_4' DI_GUI.transFrontWiper.vTransFrontWiper == TRUE
    
    Scenario:  # 'ENUM_STATE_RUNNING' and 'ENUM_WIPER_MODE_INTERMITTENT' and  ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY5
        When NotifyFrontWiperStatus.status = 'ENUM_STATUS_OK'
        When NotifyFrontWiperStatus.wiper_mode = 'ENUM_WIPER_MODE_INTERMITTENT'
        When NotifyFrontWiperStatus is sent
        When NotifyWiperSensitivityStatus.status = 'ENUM_STATUS_OK'
        When NotifyWiperSensitivityStatus.wiper_sensitivity = 'ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY5'
        When NotifyWiperSensitivityStatus is sent
        Then HMI shows:  DI_GUI.transFrontWiper.eTransFrontWiper == 'FRONT_WIPER_INT_5' DI_GUI.transFrontWiper.vTransFrontWiper == TRUE
    
    Scenario:  # 'ENUM_STATE_RUNNING' and 'ENUM_WIPER_MODE_INTERMITTENT' and 'ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY5' and 'ENUM_STATUS_NOT_OK'
        When NotifyFrontWiperStatus.status = 'ENUM_STATUS_OK'
        When NotifyFrontWiperStatus.wiper_mode = 'ENUM_WIPER_MODE_INTERMITTENT'
        When NotifyFrontWiperStatus is sent
        When NotifyWiperSensitivityStatus.status = 'ENUM_STATUS_NOT_OK'
        When NotifyWiperSensitivityStatus.wiper_sensitivity = 'ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY5'
        When NotifyWiperSensitivityStatus is sent
        Then HMI shows:  DI_GUI.transFrontWiper.eTransFrontWiper == 'FRONT_WIPER_UNSPECIFIED' DI_GUI.transFrontWiper.vTransFrontWiper == FALSE
    
    Scenario: # 'ENUM_STATE_RUNNING' and 'ENUM_WIPER_MODE_INTERMITTENT' and 'ENUM_WIPER_SENSITIVITY_STATUS_NO'
        When NotifyFrontWiperStatus.status = 'ENUM_STATUS_OK'
        When NotifyFrontWiperStatus.wiper_mode = 'ENUM_WIPER_MODE_INTERMITTENT'
        When NotifyFrontWiperStatus is sent
        When NotifyWiperSensitivityStatus.status = 'ENUM_STATUS_OK'
        When NotifyWiperSensitivityStatus.wiper_sensitivity = 'ENUM_WIPER_SENSITIVITY_STATUS_NO'
        When NotifyWiperSensitivityStatus is sent
        Then HMI shows:  DI_GUI.transFrontWiper.eTransFrontWiper == 'FRONT_WIPER_UNSPECIFIED' DI_GUI.transFrontWiper.vTransFrontWiper == FALSE
    
    Scenario:  # 'ENUM_STATE_RUNNING' and 'ENUM_WIPER_MODE_INTERMITTENT' and 'ENUM_WIPER_SENSITIVITY_STATUS_UNSPECIFIED'
        When NotifyFrontWiperStatus.status = 'ENUM_STATUS_OK'
        When NotifyFrontWiperStatus.wiper_mode = 'ENUM_WIPER_MODE_INTERMITTENT'
        When NotifyFrontWiperStatus is sent
        When NotifyWiperSensitivityStatus.status = 'ENUM_STATUS_OK'
        When NotifyWiperSensitivityStatus.wiper_sensitivity = 'ENUM_WIPER_SENSITIVITY_STATUS_UNSPECIFIED'
        When NotifyWiperSensitivityStatus is sent
        Then HMI shows:  DI_GUI.transFrontWiper.eTransFrontWiper == 'FRONT_WIPER_UNSPECIFIED' DI_GUI.transFrontWiper.vTransFrontWiper == FALSE
    
    Scenario:  # 'ENUM_STATE_RUNNING' and 'ENUM_WIPER_MODE_AUTO' and 'ENUM_WIPER_SENSITIVITY_STATUS_UNSPECIFIED'
        When NotifyFrontWiperStatus.status = 'ENUM_STATUS_OK'
        When NotifyFrontWiperStatus.wiper_mode = 'ENUM_WIPER_MODE_AUTO'
        When NotifyFrontWiperStatus is sent 
        Then HMI shows:  DI_GUI.transFrontWiper.eTransFrontWiper == 'FRONT_WIPER_UNSPECIFIED' DI_GUI.transFrontWiper.vTransFrontWiper == FALSE
    
    Scenario:  # 'ENUM_STATE_RUNNING' and 'ENUM_WIPER_MODE_AUTO' and 'ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY5' and 'ENUM_STATUS_NOT_OK'
        When NotifyFrontWiperStatus.status = 'ENUM_STATUS_OK'
        When NotifyFrontWiperStatus.wiper_mode = 'ENUM_WIPER_MODE_AUTO'
        When NotifyFrontWiperStatus is sent 
        When NotifyWiperSensitivityStatus.status = 'ENUM_STATUS_NOT_OK'
        When NotifyWiperSensitivityStatus.wiper_sensitivity = 'ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY5'
        When NotifyWiperSensitivityStatus is sent
        Then HMI shows:  DI_GUI.transFrontWiper.eTransFrontWiper == 'FRONT_WIPER_UNSPECIFIED' DI_GUI.transFrontWiper.vTransFrontWiper == FALSE
    
    Scenario:  # 'ENUM_STATE_RUNNING' and 'ENUM_WIPER_MODE_AUTO' and 'ENUM_WIPER_SENSITIVITY_STATUS_NO'
        When NotifyFrontWiperStatus.status = 'ENUM_STATUS_OK'
        When NotifyFrontWiperStatus.wiper_mode = 'ENUM_WIPER_MODE_AUTO'
        When NotifyFrontWiperStatus is sent 
        When NotifyWiperSensitivityStatus.status = 'ENUM_STATUS_OK'
        When NotifyWiperSensitivityStatus.wiper_sensitivity = 'ENUM_WIPER_SENSITIVITY_STATUS_NO'
        When NotifyWiperSensitivityStatus is sent
        Then HMI shows:  DI_GUI.transFrontWiper.eTransFrontWiper == 'FRONT_WIPER_UNSPECIFIED' DI_GUI.transFrontWiper.vTransFrontWiper == FALSE
    
    Scenario:  # 'ENUM_STATE_RUNNING' and 'ENUM_WIPER_MODE_AUTO' and 'ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY1'
        When NotifyFrontWiperStatus.status = 'ENUM_STATUS_OK'
        When NotifyFrontWiperStatus.wiper_mode = 'ENUM_WIPER_MODE_AUTO'
        When NotifyFrontWiperStatus is sent 
        When NotifyWiperSensitivityStatus.status = 'ENUM_STATUS_OK'
        When NotifyWiperSensitivityStatus.wiper_sensitivity = 'ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY1'
        When NotifyWiperSensitivityStatus is sent
        Then HMI shows:  DI_GUI.transFrontWiper.eTransFrontWiper == 'FRONT_WIPER_INT_1' DI_GUI.transFrontWiper.vTransFrontWiper == TRUE

    Scenario: Set Vehicle_State = 'ENUM_STATE_COMFORT'
        When NotifyVLCAState.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_state = 'ENUM_VEHICLE_STATE_COMFORT'
        When NotifyVLCAState is sent
    
    Scenario:  # 'ENUM_STATE_COMFORT' and 'ENUM_WIPER_MODE_AUTO' and 'ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY2'
        When NotifyFrontWiperStatus.status = 'ENUM_STATUS_OK'
        When NotifyFrontWiperStatus.wiper_mode = 'ENUM_WIPER_MODE_AUTO'
        When NotifyFrontWiperStatus is sent 
        When NotifyWiperSensitivityStatus.status = 'ENUM_STATUS_OK'
        When NotifyWiperSensitivityStatus.wiper_sensitivity = 'ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY2'
        When NotifyWiperSensitivityStatus is sent
        Then HMI shows:  DI_GUI.transFrontWiper.eTransFrontWiper == 'FRONT_WIPER_INT_2' DI_GUI.transFrontWiper.vTransFrontWiper == TRUE
    
    Scenario:  # 'ENUM_STATE_COMFORT' and 'ENUM_WIPER_MODE_AUTO' and 'ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY3'
        When NotifyFrontWiperStatus.status = 'ENUM_STATUS_OK'
        When NotifyFrontWiperStatus.wiper_mode = 'ENUM_WIPER_MODE_AUTO'
        When NotifyFrontWiperStatus is sent 
        When NotifyWiperSensitivityStatus.status = 'ENUM_STATUS_OK'
        When NotifyWiperSensitivityStatus.wiper_sensitivity = 'ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY3'
        When NotifyWiperSensitivityStatus is sent
        Then HMI shows:  DI_GUI.transFrontWiper.eTransFrontWiper == 'FRONT_WIPER_INT_3' DI_GUI.transFrontWiper.vTransFrontWiper == TRUE
    
    Scenario:  # 'ENUM_STATE_COMFORT' and 'ENUM_WIPER_MODE_AUTO' and 'ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY4'
        When NotifyFrontWiperStatus.status = 'ENUM_STATUS_OK'
        When NotifyFrontWiperStatus.wiper_mode = 'ENUM_WIPER_MODE_AUTO'
        When NotifyFrontWiperStatus is sent 
        When NotifyWiperSensitivityStatus.status = 'ENUM_STATUS_OK'
        When NotifyWiperSensitivityStatus.wiper_sensitivity = 'ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY4'
        When NotifyWiperSensitivityStatus is sent
        Then HMI shows:  DI_GUI.transFrontWiper.eTransFrontWiper == 'FRONT_WIPER_UNSPECIFIED' DI_GUI.transFrontWiper.vTransFrontWiper == FALSE
    
    Scenario:  # 'ENUM_STATE_COMFORT' and 'ENUM_WIPER_MODE_AUTO' and 'ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY5'
        When NotifyFrontWiperStatus.status = 'ENUM_STATUS_OK'
        When NotifyFrontWiperStatus.wiper_mode = 'ENUM_WIPER_MODE_AUTO'
        When NotifyFrontWiperStatus is sent 
        When NotifyWiperSensitivityStatus.status = 'ENUM_STATUS_OK'
        When NotifyWiperSensitivityStatus.wiper_sensitivity = 'ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY5'
        When NotifyWiperSensitivityStatus is sent
        Then HMI shows:  DI_GUI.transFrontWiper.eTransFrontWiper == 'FRONT_WIPER_UNSPECIFIED' DI_GUI.transFrontWiper.vTransFrontWiper == FALSE
    
    Scenario:  # 'ENUM_STATE_COMFORT' and 'ENUM_WIPER_MODE_AUTO' and 'ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY6'
        When NotifyFrontWiperStatus.status = 'ENUM_STATUS_OK'
        When NotifyFrontWiperStatus.wiper_mode = 'ENUM_WIPER_MODE_AUTO'
        When NotifyFrontWiperStatus is sent 
        When NotifyWiperSensitivityStatus.status = 'ENUM_STATUS_OK'
        When NotifyWiperSensitivityStatus.wiper_sensitivity = 'ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY6'
        When NotifyWiperSensitivityStatus is sent
        Then HMI shows:  DI_GUI.transFrontWiper.eTransFrontWiper == 'FRONT_WIPER_UNSPECIFIED' DI_GUI.transFrontWiper.vTransFrontWiper == FALSE
    
    Scenario:  # 'ENUM_STATE_COMFORT' and 'ENUM_WIPER_MODE_NORMAL' and 'ENUM_STATUS_NOT_OK'
        When NotifyFrontWiperStatus.status = 'ENUM_STATUS_OK'
        When NotifyFrontWiperStatus.wiper_mode = 'ENUM_WIPER_MODE_AUTO'
        When NotifyFrontWiperStatus is sent 
        When NotifyFrontWiperStatus.status = 'ENUM_STATUS_NOT_OK'
        When NotifyFrontWiperStatus.wiper_mode = 'ENUM_WIPER_MODE_NORMAL'
        When NotifyFrontWiperStatus is sent
        Then HMI shows:  DI_GUI.transFrontWiper.eTransFrontWiper == 'FRONT_WIPER_UNSPECIFIED' DI_GUI.transFrontWiper.vTransFrontWiper == FALSE
