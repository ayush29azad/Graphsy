Feature:
    Scenario: Start server/clients
        When Start server for lifecycle_cccmuserapps_vlca_service
        And Start server for visibility_service

    Scenario: Set Vehicle_State = 'ENUM_STATE_RUNNING'
        Given Receive request GetVLCAStateRequest
        When GetVLCAStateResponse.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When GetVLCAStateResponse.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When GetVLCAStateResponse.vehicle_state = 'ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL'
        When Send response GetVLCAStateResponse
    
    Scenario: # DEFL_FrontWashWipe = ON and 'ENUM_WASH_STATUS_ACTIVE' and 'ENUM_STATE_RUNNING' (default)
        When NotifyRearWashStatus.status = 'ENUM_STATUS_OK'
        When NotifyRearWashStatus.rear_wash = 'ENUM_WASH_STATUS_ACTIVE'
        When NotifyRearWashStatus is sent
        Then HMI shows:  DI_GUI.transRearWashWipe.eTransRearWashWipe == 'FRONT_WASH_WIPE_ACTIVE' DI_GUI.transRearWashWipe.vTransRearWashWipe == TRUE

    Scenario:# DEFL_FrontWashWipe = OFF and 'ENUM_WASH_STATUS_INACTIVE' and 'ENUM_STATE_RUNNING'
        When NotifyRearWashStatus.status = 'ENUM_STATUS_OK'
        When NotifyRearWashStatus.rear_wash = 'ENUM_WASH_STATUS_INACTIVE'
        When NotifyRearWashStatus is sent
        Then HMI shows:  DI_GUI.transRearWashWipe.eTransRearWashWipe == 'FRONT_WASH_WIPE_UNSPECIFIED' DI_GUI.transRearWashWipe.vTransRearWashWipe == FALSE
    
    Scenario:# DEFL_FrontWashWipe = OFF and 'ENUM_WASH_STATUS_UNSPECIFIED' and 'ENUM_STATE_RUNNING'
        When NotifyRearWashStatus.status = 'ENUM_STATUS_OK'
        When NotifyRearWashStatus.rear_wash = 'ENUM_WASH_STATUS_UNSPECIFIED'
        When NotifyRearWashStatus is sent
        Then HMI shows:  DI_GUI.transRearWashWipe.eTransRearWashWipe == 'FRONT_WASH_WIPE_UNSPECIFIED' DI_GUI.transRearWashWipe.vTransRearWashWipe == FALSE
    
    Scenario:# DEFL_FrontWashWipe = ON and 'ENUM_WASH_STATUS_ACTIVE' and 'ENUM_STATE_RUNNING'
        When NotifyRearWashStatus.status = 'ENUM_STATUS_OK'
        When NotifyRearWashStatus.rear_wash = 'ENUM_WASH_STATUS_ACTIVE'
        When NotifyRearWashStatus is sent
        Then HMI shows:  DI_GUI.transRearWashWipe.eTransRearWashWipe == 'FRONT_WASH_WIPE_ACTIVE' DI_GUI.transRearWashWipe.vTransRearWashWipe == TRUE
    
    Scenario:# DEFL_FrontWashWipe = ON and 'ENUM_WASH_STATUS_ACTIVE' and 'ENUM_STATE_RUNNING' Check DDS when same input is repeated twice
        When NotifyRearWashStatus.status = 'ENUM_STATUS_OK'
        When NotifyRearWashStatus.rear_wash = 'ENUM_WASH_STATUS_ACTIVE'
        When NotifyRearWashStatus is sent
        Then HMI shows:  DI_GUI.transRearWashWipe.eTransRearWashWipe == 'FRONT_WASH_WIPE_ACTIVE' DI_GUI.transRearWashWipe.vTransRearWashWipe == TRUE

    Scenario: # DEFL_FrontWashWipe = OFF and 'ENUM_WASH_STATUS_INACTIVE' and 'ENUM_STATE_COMFORT'
        When NotifyRearWashStatus.status = 'ENUM_STATUS_OK'
        When NotifyRearWashStatus.rear_wash = 'ENUM_WASH_STATUS_INACTIVE'
        When NotifyRearWashStatus is sent
        Then HMI shows:  DI_GUI.transRearWashWipe.eTransRearWashWipe == 'FRONT_WASH_WIPE_UNSPECIFIED' DI_GUI.transRearWashWipe.vTransRearWashWipe == FALSE
    
    Scenario: Set Vehicle_State = 'ENUM_STATE_COMFORT'
        When NotifyVLCAState.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_state = 'ENUM_VEHICLE_STATE_COMFORT'
        When NotifyVLCAState is sent
    
    Scenario: # DEFL_FrontWashWipe = ON and 'ENUM_WASH_STATUS_ACTIVE' and 'ENUM_STATE_COMFORT'
        When NotifyRearWashStatus.status = 'ENUM_STATUS_OK'
        When NotifyRearWashStatus.rear_wash = 'ENUM_WASH_STATUS_ACTIVE'
        When NotifyRearWashStatus is sent
        Then HMI shows:  DI_GUI.transRearWashWipe.eTransRearWashWipe == 'FRONT_WASH_WIPE_ACTIVE' DI_GUI.transRearWashWipe.vTransRearWashWipe == TRUE

    Scenario:# DEFL_FrontWashWipe = OFF and 'ENUM_WASH_STATUS_INACTIVE' and 'ENUM_STATE_COMFORT'
        When NotifyRearWashStatus.status = 'ENUM_STATUS_OK'
        When NotifyRearWashStatus.rear_wash = 'ENUM_WASH_STATUS_INACTIVE'
        When NotifyRearWashStatus is sent
        Then HMI shows:  DI_GUI.transRearWashWipe.eTransRearWashWipe == 'FRONT_WASH_WIPE_UNSPECIFIED' DI_GUI.transRearWashWipe.vTransRearWashWipe == FALSE
    
    Scenario:# DEFL_FrontWashWipe = OFF and 'ENUM_WASH_STATUS_UNSPECIFIED' and 'ENUM_STATE_COMFORT'
        When NotifyRearWashStatus.status = 'ENUM_STATUS_OK'
        When NotifyRearWashStatus.rear_wash = 'ENUM_WASH_STATUS_UNSPECIFIED'
        When NotifyRearWashStatus is sent
        Then HMI shows:  DI_GUI.transRearWashWipe.eTransRearWashWipe == 'FRONT_WASH_WIPE_UNSPECIFIED' DI_GUI.transRearWashWipe.vTransRearWashWipe == FALSE
    
    Scenario:# DEFL_FrontWashWipe = ON and 'ENUM_WASH_STATUS_ACTIVE' and 'ENUM_STATE_COMFORT'
        When NotifyRearWashStatus.status = 'ENUM_STATUS_OK'
        When NotifyRearWashStatus.rear_wash = 'ENUM_WASH_STATUS_ACTIVE'
        When NotifyRearWashStatus is sent
        Then HMI shows:  DI_GUI.transRearWashWipe.eTransRearWashWipe == 'FRONT_WASH_WIPE_ACTIVE' DI_GUI.transRearWashWipe.vTransRearWashWipe == TRUE
    
    Scenario:# DEFL_FrontWashWipe = ON and 'ENUM_WASH_STATUS_ACTIVE' and 'ENUM_STATE_COMFORT' Check DDS when same input is repeated twice
        When NotifyRearWashStatus.status = 'ENUM_STATUS_OK'
        When NotifyRearWashStatus.rear_wash = 'ENUM_WASH_STATUS_ACTIVE'
        When NotifyRearWashStatus is sent
        Then HMI shows:  DI_GUI.transRearWashWipe.eTransRearWashWipe == 'FRONT_WASH_WIPE_ACTIVE' DI_GUI.transRearWashWipe.vTransRearWashWipe == TRUE

    Scenario: # DEFL_FrontWashWipe = OFF and 'ENUM_WASH_STATUS_INACTIVE' and 'ENUM_STATE_COMFORT'
        When NotifyRearWashStatus.status = 'ENUM_STATUS_OK'
        When NotifyRearWashStatus.rear_wash = 'ENUM_WASH_STATUS_INACTIVE'
        When NotifyRearWashStatus is sent
        Then HMI shows:  DI_GUI.transRearWashWipe.eTransRearWashWipe == 'FRONT_WASH_WIPE_UNSPECIFIED' DI_GUI.transRearWashWipe.vTransRearWashWipe == FALSE
