Feature:
    Scenario: Start server/clients
        When Start server for lifecycle_cccmuserapps_vlca_service
        And Start server for visibility_service
    
    Scenario: Set Vehicle_State = 'ENUM_STATE_RUNNING'
        Given Receive request GetVLCAStateRequest
        When GetVLCAStateResponse.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When GetVLCAStateResponse.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When GetVLCAStateResponse.vehicle_state = 'ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL'
        When Send response GetVLCAStateResponse
    
    Scenario: # 'ENUM_WIPER_MODE_OFF' and 'ENUM_STATE_RUNNING' (default)
        When NotifyRearWiperStatus.status = 'ENUM_STATUS_OK'
        When NotifyRearWiperStatus.rear_wiper = 'ENUM_WIPER_MODE_OFF'
        When NotifyRearWiperStatus is sent
        Then HMI shows:  DI_GUI.transRearWiper.eTransRearWiper == 'REAR_WIPER_OFF' DI_GUI.transRearWiper.vTransRearWiper == TRUE
        
    Scenario: Set Vehicle_State = 'ENUM_STATE_COMFORT'
        When NotifyVLCAState.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_state = 'ENUM_VEHICLE_STATE_COMFORT'
        When NotifyVLCAState is sent

    Scenario: # 'ENUM_STATE_COMFORT' and 'ENUM_WIPER_MODE_NORMAL'
        When NotifyRearWiperStatus.status = 'ENUM_STATUS_OK'
        When NotifyRearWiperStatus.rear_wiper = 'ENUM_WIPER_MODE_NORMAL'
        When NotifyRearWiperStatus is sent
        Then HMI shows:  DI_GUI.transRearWiper.eTransRearWiper == 'REAR_WIPER_ON' DI_GUI.transRearWiper.vTransRearWiper == TRUE

    Scenario: # 'ENUM_STATE_COMFORT' and 'ENUM_WIPER_MODE_FAST' (any other value)
        When NotifyRearWiperStatus.status = 'ENUM_STATUS_OK'
        When NotifyRearWiperStatus.rear_wiper = 'ENUM_WIPER_MODE_FAST'
        When NotifyRearWiperStatus is sent
        Then HMI shows:  DI_GUI.transRearWiper.eTransRearWiper == 'REAR_WIPER_UNSPECIFIED' DI_GUI.transRearWiper.vTransRearWiper == FALSE

    Scenario:  # 'ENUM_STATE_COMFORT' and 'ENUM_WIPER_MODE_FAST' (any other value) and  ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY6 (don't care)
        When NotifyWiperSensitivityStatus.status = 'ENUM_STATUS_OK'
        When NotifyWiperSensitivityStatus.wiper_sensitivity = 'ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY6'
        When NotifyWiperSensitivityStatus is sent
        Then HMI shows:  DI_GUI.transRearWiper.eTransRearWiper == 'REAR_WIPER_UNSPECIFIED' DI_GUI.transRearWiper.vTransRearWiper == FALSE

    Scenario:  # 'ENUM_STATE_COMFORT' and 'ENUM_WIPER_MODE_INTERMITTENT' and ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY6
        When NotifyRearWiperStatus.status = 'ENUM_STATUS_OK'
        When NotifyRearWiperStatus.rear_wiper = 'ENUM_WIPER_MODE_INTERMITTENT'
        When NotifyRearWiperStatus is sent
        Then HMI shows:  DI_GUI.transRearWiper.eTransRearWiper == 'REAR_WIPER_UNSPECIFIED' DI_GUI.transRearWiper.vTransRearWiper == FALSE'


    Scenario: # 'ENUM_STATE_COMFORT' and 'ENUM_WIPER_MODE_INTERMITTENT' and  ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY1
        When NotifyRearWiperStatus.status = 'ENUM_STATUS_OK'
        When NotifyRearWiperStatus.rear_wiper = 'ENUM_WIPER_MODE_INTERMITTENT'
        When NotifyRearWiperStatus is sent
        When NotifyWiperSensitivityStatus.status = 'ENUM_STATUS_OK'
        When NotifyWiperSensitivityStatus.wiper_sensitivity = 'ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY1'
        When NotifyWiperSensitivityStatus is sent
        Then HMI shows:  DI_GUI.transRearWiper.eTransRearWiper == 'REAR_WIPER_INT_1' DI_GUI.transRearWiper.vTransRearWiper == TRUE

    Scenario:  # 'ENUM_STATE_COMFORT' and 'ENUM_WIPER_MODE_INTERMITTENT' and  ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY2
        When NotifyRearWiperStatus.status = 'ENUM_STATUS_OK'
        When NotifyRearWiperStatus.rear_wiper = 'ENUM_WIPER_MODE_INTERMITTENT'
        When NotifyRearWiperStatus is sent
        When NotifyWiperSensitivityStatus.status = 'ENUM_STATUS_OK'
        When NotifyWiperSensitivityStatus.wiper_sensitivity = 'ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY2'
        When NotifyWiperSensitivityStatus is sent
        Then HMI shows:  DI_GUI.transRearWiper.eTransRearWiper == 'REAR_WIPER_UNSPECIFIED' DI_GUI.transRearWiper.vTransRearWiper == FALSE

    Scenario: 'ENUM_STATE_COMFORT' and 'ENUM_WIPER_MODE_INTERMITTENT' and  ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY2 Check DDS         When same input is repeated twice
        When NotifyRearWiperStatus.status = 'ENUM_STATUS_OK'
        When NotifyRearWiperStatus.rear_wiper = 'ENUM_WIPER_MODE_INTERMITTENT'
        When NotifyRearWiperStatus is sent
        When NotifyWiperSensitivityStatus.status = 'ENUM_STATUS_OK'
        When NotifyWiperSensitivityStatus.wiper_sensitivity = 'ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY2'
        When NotifyWiperSensitivityStatus is sent
        Then HMI shows:  DI_GUI.transRearWiper.eTransRearWiper == 'REAR_WIPER_UNSPECIFIED' DI_GUI.transRearWiper.vTransRearWiper == FALSE

    Scenario: # 'ENUM_STATE_COMFORT' and 'ENUM_WIPER_MODE_INTERMITTENT' and  ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY3
        When NotifyRearWiperStatus.status = 'ENUM_STATUS_OK'
        When NotifyRearWiperStatus.rear_wiper = 'ENUM_WIPER_MODE_INTERMITTENT'
        When NotifyRearWiperStatus is sent
        When NotifyWiperSensitivityStatus.status = 'ENUM_STATUS_OK'
        When NotifyWiperSensitivityStatus.wiper_sensitivity = 'ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY3'
        When NotifyWiperSensitivityStatus is sent
        Then HMI shows:  DI_GUI.transRearWiper.eTransRearWiper == 'REAR_WIPER_UNSPECIFIED' DI_GUI.transRearWiper.vTransRearWiper == FALSE

    Scenario:   Check DDS when vehicle state changes
        When NotifyVLCAState.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_state = 'ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL'
        When NotifyVLCAState is sent

    Scenario: # 'ENUM_STATE_RUNNING' and 'ENUM_WIPER_MODE_INTERMITTENT' and  ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY4
        When NotifyRearWiperStatus.status = 'ENUM_STATUS_OK'
        When NotifyRearWiperStatus.rear_wiper = 'ENUM_WIPER_MODE_INTERMITTENT'
        When NotifyRearWiperStatus is sent
        When NotifyWiperSensitivityStatus.status = 'ENUM_STATUS_OK'
        When NotifyWiperSensitivityStatus.wiper_sensitivity = 'ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY4'
        When NotifyWiperSensitivityStatus is sent
        Then HMI shows:  DI_GUI.transRearWiper.eTransRearWiper == 'REAR_WIPER_UNSPECIFIED' DI_GUI.transRearWiper.vTransRearWiper == FALSE

    Scenario: 'ENUM_STATE_RUNNING' and 'ENUM_WIPER_MODE_INTERMITTENT' and  ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY5
        When NotifyRearWiperStatus.status = 'ENUM_STATUS_OK'
        When NotifyRearWiperStatus.rear_wiper = 'ENUM_WIPER_MODE_INTERMITTENT'
        When NotifyRearWiperStatus is sent
        When NotifyWiperSensitivityStatus.status = 'ENUM_STATUS_OK'
        When NotifyWiperSensitivityStatus.wiper_sensitivity = 'ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY5'
        When NotifyWiperSensitivityStatus is sent
        Then HMI shows:  DI_GUI.transRearWiper.eTransRearWiper == 'REAR_WIPER_UNSPECIFIED' DI_GUI.transRearWiper.vTransRearWiper == FALSE

    Scenario: 'ENUM_STATE_RUNNING' and 'ENUM_WIPER_MODE_INTERMITTENT' and 'ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY5' and 'ENUM_STATUS_NOT_OK'
        When NotifyRearWiperStatus.status = 'ENUM_STATUS_OK'
        When NotifyRearWiperStatus.rear_wiper = 'ENUM_WIPER_MODE_INTERMITTENT'
        When NotifyRearWiperStatus is sent
        When NotifyWiperSensitivityStatus.status = 'ENUM_STATUS_NOT_OK'
        When NotifyWiperSensitivityStatus.wiper_sensitivity = 'ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY5'
        When NotifyWiperSensitivityStatus is sent
        Then HMI shows:  DI_GUI.transRearWiper.eTransRearWiper == 'REAR_WIPER_UNSPECIFIED' DI_GUI.transRearWiper.vTransRearWiper == FALSE

    Scenario: 'ENUM_STATE_RUNNING' and 'ENUM_WIPER_MODE_INTERMITTENT' and 'ENUM_WIPER_SENSITIVITY_STATUS_NO'
        When NotifyRearWiperStatus.status = 'ENUM_STATUS_OK'
        When NotifyRearWiperStatus.rear_wiper = 'ENUM_WIPER_MODE_INTERMITTENT'
        When NotifyRearWiperStatus is sent
        When NotifyWiperSensitivityStatus.status = 'ENUM_STATUS_OK'
        When NotifyWiperSensitivityStatus.wiper_sensitivity = 'ENUM_WIPER_SENSITIVITY_STATUS_NO'
        When NotifyWiperSensitivityStatus is sent
        Then HMI shows:  DI_GUI.transRearWiper.eTransRearWiper == 'REAR_WIPER_UNSPECIFIED' DI_GUI.transRearWiper.vTransRearWiper == FALSE

    Scenario: 'ENUM_STATE_RUNNING' and 'ENUM_WIPER_MODE_INTERMITTENT' and 'ENUM_WIPER_SENSITIVITY_STATUS_UNSPECIFIED'
        When NotifyRearWiperStatus.status = 'ENUM_STATUS_OK'
        When NotifyRearWiperStatus.rear_wiper = 'ENUM_WIPER_MODE_INTERMITTENT'
        When NotifyRearWiperStatus is sent
        When NotifyWiperSensitivityStatus.status = 'ENUM_STATUS_OK'
        When NotifyWiperSensitivityStatus.wiper_sensitivity = 'ENUM_WIPER_SENSITIVITY_STATUS_UNSPECIFIED'
        When NotifyWiperSensitivityStatus is sent
        Then HMI shows:  DI_GUI.transRearWiper.eTransRearWiper == 'REAR_WIPER_UNSPECIFIED' DI_GUI.transRearWiper.vTransRearWiper == FALSE

    Scenario: 'ENUM_STATE_RUNNING' and 'ENUM_WIPER_MODE_AUTO' and 'ENUM_WIPER_SENSITIVITY_STATUS_UNSPECIFIED'
        When NotifyRearWiperStatus.status = 'ENUM_STATUS_OK'
        When NotifyRearWiperStatus.rear_wiper = 'ENUM_WIPER_MODE_AUTO'
        When NotifyRearWiperStatus is sent
        When NotifyWiperSensitivityStatus.status = 'ENUM_STATUS_OK'
        When NotifyWiperSensitivityStatus.wiper_sensitivity = 'ENUM_WIPER_SENSITIVITY_STATUS_UNSPECIFIED'
        When NotifyWiperSensitivityStatus is sent
        Then HMI shows:  DI_GUI.transRearWiper.eTransRearWiper == 'REAR_WIPER_UNSPECIFIED' DI_GUI.transRearWiper.vTransRearWiper == FALSE

    Scenario: 'ENUM_STATE_RUNNING' and 'ENUM_WIPER_MODE_AUTO' and 'ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY5' and 'ENUM_STATUS_NOT_OK'
        When NotifyRearWiperStatus.status = 'ENUM_STATUS_OK'
        When NotifyRearWiperStatus.rear_wiper = 'ENUM_WIPER_MODE_AUTO'
        When NotifyRearWiperStatus is sentWhen NotifyWiperSensitivityStatus.status = 'ENUM_STATUS_NOT_OK'
        When NotifyWiperSensitivityStatus.wiper_sensitivity = 'ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY5'
        When NotifyWiperSensitivityStatus is sent
        Then HMI shows:  DI_GUI.transRearWiper.eTransRearWiper == 'REAR_WIPER_UNSPECIFIED' DI_GUI.transRearWiper.vTransRearWiper == FALSE

    Scenario: 'ENUM_STATE_RUNNING' and 'ENUM_WIPER_MODE_AUTO' and 'ENUM_WIPER_SENSITIVITY_STATUS_NO'
        When NotifyRearWiperStatus.status = 'ENUM_STATUS_OK'
        When NotifyRearWiperStatus.rear_wiper = 'ENUM_WIPER_MODE_AUTO'
        When NotifyRearWiperStatus is sent
        When NotifyWiperSensitivityStatus.status = 'ENUM_STATUS_OK'
        When NotifyWiperSensitivityStatus.wiper_sensitivity = 'ENUM_WIPER_SENSITIVITY_STATUS_NO'
        When NotifyWiperSensitivityStatus is sent
        Then HMI shows:  DI_GUI.transRearWiper.eTransRearWiper == 'REAR_WIPER_UNSPECIFIED' DI_GUI.transRearWiper.vTransRearWiper == FALSE

    Scenario: 'ENUM_STATE_RUNNING' and 'ENUM_WIPER_MODE_AUTO' and 'ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY1'
        When NotifyRearWiperStatus.status = 'ENUM_STATUS_OK'
        When NotifyRearWiperStatus.rear_wiper = 'ENUM_WIPER_MODE_AUTO'
        When NotifyRearWiperStatus is sent
        When NotifyWiperSensitivityStatus.status = 'ENUM_STATUS_OK'
        When NotifyWiperSensitivityStatus.wiper_sensitivity = 'ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY1'
        When NotifyWiperSensitivityStatus is sent
        Then HMI shows:  DI_GUI.transRearWiper.eTransRearWiper == 'REAR_WIPER_UNSPECIFIED' DI_GUI.transRearWiper.vTransRearWiper == FALSE

    Scenario: Set Vehicle_State = 'ENUM_STATE_COMFORT'
        When NotifyVLCAState.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_state = 'ENUM_VEHICLE_STATE_COMFORT'
        When NotifyVLCAState is sent

    Scenario: 'ENUM_STATE_COMFORT' and 'ENUM_WIPER_MODE_AUTO' and 'ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY2'
        When NotifyRearWiperStatus.status = 'ENUM_STATUS_OK'
        When NotifyRearWiperStatus.rear_wiper = 'ENUM_WIPER_MODE_AUTO'
        When NotifyRearWiperStatus is sent
        When NotifyWiperSensitivityStatus.status = 'ENUM_STATUS_OK'
        When NotifyWiperSensitivityStatus.wiper_sensitivity = 'ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY2'
        When NotifyWiperSensitivityStatus is sent
        Then HMI shows:  DI_GUI.transRearWiper.eTransRearWiper == 'REAR_WIPER_UNSPECIFIED' DI_GUI.transRearWiper.vTransRearWiper == FALSE

    Scenario: 'ENUM_STATE_COMFORT' and 'ENUM_WIPER_MODE_AUTO' and 'ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY3'
        When NotifyRearWiperStatus.status = 'ENUM_STATUS_OK'
        When NotifyRearWiperStatus.rear_wiper = 'ENUM_WIPER_MODE_AUTO'
        When NotifyRearWiperStatus is sent
        When NotifyWiperSensitivityStatus.status = 'ENUM_STATUS_OK'
        When NotifyWiperSensitivityStatus.wiper_sensitivity = 'ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY3'
        When NotifyWiperSensitivityStatus is sent
        Then HMI shows:  DI_GUI.transRearWiper.eTransRearWiper == 'REAR_WIPER_UNSPECIFIED' DI_GUI.transRearWiper.vTransRearWiper == FALSE

    Scenario: 'ENUM_STATE_COMFORT' and 'ENUM_WIPER_MODE_AUTO' and 'ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY4'
        When NotifyRearWiperStatus.status = 'ENUM_STATUS_OK'
        When NotifyRearWiperStatus.rear_wiper = 'ENUM_WIPER_MODE_AUTO'
        When NotifyRearWiperStatus is sent
        When NotifyWiperSensitivityStatus.status = 'ENUM_STATUS_OK'
        When NotifyWiperSensitivityStatus.wiper_sensitivity = 'ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY4'
        When NotifyWiperSensitivityStatus is sent
        Then HMI shows:  DI_GUI.transRearWiper.eTransRearWiper == 'REAR_WIPER_UNSPECIFIED' DI_GUI.transRearWiper.vTransRearWiper == FALSE

    Scenario: 'ENUM_STATE_COMFORT' and 'ENUM_WIPER_MODE_AUTO' and 'ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY5'
        When NotifyRearWiperStatus.status = 'ENUM_STATUS_OK'
        When NotifyRearWiperStatus.rear_wiper = 'ENUM_WIPER_MODE_AUTO'
        When NotifyRearWiperStatus is sent
        When NotifyWiperSensitivityStatus.status = 'ENUM_STATUS_OK'
        When NotifyWiperSensitivityStatus.wiper_sensitivity = 'ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY5'
        When NotifyWiperSensitivityStatus is sent
        Then HMI shows:  DI_GUI.transRearWiper.eTransRearWiper == 'REAR_WIPER_UNSPECIFIED' DI_GUI.transRearWiper.vTransRearWiper == FALSE

    Scenario: 'ENUM_STATE_COMFORT' and 'ENUM_WIPER_MODE_AUTO' and 'ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY6'
        When NotifyRearWiperStatus.status = 'ENUM_STATUS_OK'
        When NotifyRearWiperStatus.rear_wiper = 'ENUM_WIPER_MODE_AUTO'
        When NotifyRearWiperStatus is sent
        When NotifyWiperSensitivityStatus.status = 'ENUM_STATUS_OK'
        When NotifyWiperSensitivityStatus.wiper_sensitivity = 'ENUM_WIPER_SENSITIVITY_STATUS_SENSITIVITY6'
        When NotifyWiperSensitivityStatus is sent
        Then HMI shows:  DI_GUI.transRearWiper.eTransRearWiper == 'REAR_WIPER_UNSPECIFIED' DI_GUI.transRearWiper.vTransRearWiper == FALSE

    Scenario: 'ENUM_STATE_COMFORT' and 'ENUM_WIPER_MODE_NORMAL' and 'ENUM_STATUS_NOT_OK'
        When NotifyRearWiperStatus.status = 'ENUM_STATUS_OK'
        When NotifyRearWiperStatus.rear_wiper = 'ENUM_WIPER_MODE_AUTO'
        When NotifyRearWiperStatus is sent
        When NotifyRearWiperStatus.status = 'ENUM_STATUS_NOT_OK'
        When NotifyRearWiperStatus.rear_wiper = 'ENUM_WIPER_MODE_NORMAL'
        When NotifyRearWiperStatus is sent
        Then HMI shows:  DI_GUI.transRearWiper.eTransRearWiper == 'REAR_WIPER_UNSPECIFIED' DI_GUI.transRearWiper.vTransRearWiper == FALSE
