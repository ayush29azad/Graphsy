Feature:

   Scenario: Start server/clients
        When Start server for lifecycle_cccmuserapps_vlca_service
        And Start server for suspension_service

    Scenario: Set Vehicle_State = 'ENUM_STATE_RUNNING'
        Given Receive request GetVLCAStateRequest
        When GetVLCAStateResponse.vlca_state = "ENUM_VLCA_STATE_UNSPECIFIED"
        When GetVLCAStateResponse.vehicle_mode = "ENUM_VEHICLE_MODE_UNSPECIFIED"
        When GetVLCAStateResponse.vehicle_state = "ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL"
        When Send response GetVLCAStateResponse
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_STATE_RUNNING'

    Scenario:
        Given Receive request GetAirSuspensionCurrentHeightInformationRequest
        When GetAirSuspensionCurrentHeightInformationResponse.status = "ENUM_STATUS_OK"
        When GetAirSuspensionCurrentHeightInformationResponse.current_height_mode_information = "ENUM_AIR_SUSPENSION_HEIGHT_MODE_OFF_ROAD_1"
        When GetAirSuspensionCurrentHeightInformationResponse.suspension_movement_information = "ENUM_AIR_SUSPENSION_MOVEMENT_STATIONARY"
        When Send response GetAirSuspensionCurrentHeightInformationResponse
        Then HMI shows: DI_GUI.vehicleLifecycleInt.miscTelltales
        
    Scenario: 
        When NotifyAirSuspensionCurrentHeightInformation.current_height_information = "ENUM_AIR_SUSPENSION_HEIGHT_MODE_UNSPECIFIED"
        When NotifyAirSuspensionCurrentHeightInformation.suspension_movement_information = "ENUM_AIR_SUSPENSION_MOVEMENT_STATIONARY"
        When NotifyAirSuspensionCurrentHeightInformation is sent
        Then HMI Shows: DI_GUI.miscTelltales

    Scenario: the OFFROAD with suspension movement as STATIONARY
        When NotifyAirSuspensionCurrentHeightInformation.current_height_information = "ENUM_AIR_SUSPENSION_HEIGHT_MODE_AUTO_OFF_ROAD"
        When NotifyAirSuspensionCurrentHeightInformation.suspension_movement_information = "ENUM_AIR_SUSPENSION_MOVEMENT_STATIONARY"
        When NotifyAirSuspensionCurrentHeightInformation is sent
        Then HMI Shows: DI_GUI.miscTelltales.eAirSusp_Symbol == "AIR_SUSP_OFF_ROAD"

    Scenario: the OFFROAD_1 with suspension movement as STATIONARY
        When NotifyAirSuspensionCurrentHeightInformation.current_height_information = "ENUM_AIR_SUSPENSION_HEIGHT_MODE_OFF_ROAD_1"
        When NotifyAirSuspensionCurrentHeightInformation.suspension_movement_information = "ENUM_AIR_SUSPENSION_MOVEMENT_STATIONARY"
        When NotifyAirSuspensionCurrentHeightInformation is sent
        Then HMI Shows: DI_GUI.miscTelltales.eAirSusp_Symbol == "AIR_SUSP_OFF_ROAD1"

    Scenario: the OFFROAD_2 with suspension movement as STATIONARY
        When NotifyAirSuspensionCurrentHeightInformation.current_height_information = "ENUM_AIR_SUSPENSION_HEIGHT_MODE_OFF_ROAD_2"
        When NotifyAirSuspensionCurrentHeightInformation.suspension_movement_information = "ENUM_AIR_SUSPENSION_MOVEMENT_STATIONARY"
        When NotifyAirSuspensionCurrentHeightInformation is sent is sent
        Then HMI Shows: DI_GUI.miscTelltales.eAirSusp_Symbol == "AIR_SUSP_OFF_ROAD2"

    Scenario: the HIGH_HEIGHT with suspension movement as STATIONARY
        When NotifyAirSuspensionCurrentHeightInformation.current_height_information = "ENUM_AIR_SUSPENSION_HEIGHT_MODE_HIGH_HEIGHT"
        When NotifyAirSuspensionCurrentHeightInformation.suspension_movement_information = "ENUM_AIR_SUSPENSION_MOVEMENT_STATIONARY"
        When NotifyAirSuspensionCurrentHeightInformation is sent
        Then HMI Shows: DI_GUI.miscTelltales.eAirSusp_Symbol == "AIR_SUSP_HIGH_HEIGHT"

    Scenario: the NORAML_HEIGHT with suspension movement as STATIONARY
        When NotifyAirSuspensionCurrentHeightInformation.current_height_information = "ENUM_AIR_SUSPENSION_HEIGHT_MODE_NORMAL_HEIGHT"
        When NotifyAirSuspensionCurrentHeightInformation.suspension_movement_information = "ENUM_AIR_SUSPENSION_MOVEMENT_STATIONARY"
        When NotifyAirSuspensionCurrentHeightInformation is sent
        Then HMI Shows: DI_GUI.miscTelltales.eAirSusp_Symbol == "AIR_SUSP_NORM_HEIGHT"

    Scenario: the ACCESS_HEIGHT with suspension movement as STATIONARY
        When NotifyAirSuspensionCurrentHeightInformation.current_height_information = "ENUM_AIR_SUSPENSION_HEIGHT_MODE_ACCESS_HEIGHT"
        When NotifyAirSuspensionCurrentHeightInformation.suspension_movement_information = "ENUM_AIR_SUSPENSION_MOVEMENT_STATIONARY"
        When NotifyAirSuspensionCurrentHeightInformation is sent
        Then HMI Shows: DI_GUI.miscTelltales.eAirSusp_Symbol == "AIR_SUSP_ACCESS_HEIGHT"

    Scenario: the ACCESS_LOCK_HEIGHT with suspension movement as STATIONARY
        When NotifyAirSuspensionCurrentHeightInformation.current_height_information = "ENUM_AIR_SUSPENSION_HEIGHT_MODE_LOCK_ACCESS_HEIGHT"
        When NotifyAirSuspensionCurrentHeightInformation.suspension_movement_information = "ENUM_AIR_SUSPENSION_MOVEMENT_STATIONARY"
        When NotifyAirSuspensionCurrentHeightInformation is sent
        Then HMI Shows: DI_GUI.miscTelltales.eAirSusp_Symbol == "AIR_SUSP_LOCK_ACS_HEIGHT"

    Scenario: the EXTENDED_MODE with suspension movement as STATIONARY
        When NotifyAirSuspensionCurrentHeightInformation.current_height_information = "ENUM_AIR_SUSPENSION_HEIGHT_MODE_EXTENDED_MODE"
        When NotifyAirSuspensionCurrentHeightInformation.suspension_movement_information = "ENUM_AIR_SUSPENSION_MOVEMENT_STATIONARY"
        When NotifyAirSuspensionCurrentHeightInformation is sent
        Then HMI Shows: DI_GUI.miscTelltales.eAirSusp_Symbol == "AIR_SUSP_EXTD_MODE"

    Scenario: the Notify to make defalut
        When NotifyAirSuspensionCurrentHeightInformation.current_height_information = "ENUM_AIR_SUSPENSION_HEIGHT_MODE_UNSPECIFIED"
        When NotifyAirSuspensionCurrentHeightInformation.suspension_movement_information = "ENUM_AIR_SUSPENSION_MOVEMENT_STATIONARY"
        When NotifyAirSuspensionCurrentHeightInformation is sent
        Then HMI Shows: DI_GUI.miscTelltales.eAirSusp_Symbol == "AIR_SUSP_NONE"

     
    Scenario: the Suspension Movement OF RAISING the OFFROAD with suspension movement as RAISING
        When NotifyAirSuspensionCurrentHeightInformation.current_height_information = "ENUM_AIR_SUSPENSION_HEIGHT_MODE_AUTO_OFF_ROAD"
        When NotifyAirSuspensionCurrentHeightInformation.suspension_movement_information = "ENUM_AIR_SUSPENSION_MOVEMENT_RAISING"
        When NotifyAirSuspensionCurrentHeightInformation is sent
        Then HMI Shows: DI_GUI.miscTelltales.eAirSusp_Symbol == "AIR_SUSP_OFF_ROAD_RAISE"

    Scenario: the OFFROAD_1 with suspension movement as RAISING
        When NotifyAirSuspensionCurrentHeightInformation.current_height_information = "ENUM_AIR_SUSPENSION_HEIGHT_MODE_OFF_ROAD_1"
        When NotifyAirSuspensionCurrentHeightInformation.suspension_movement_information = "ENUM_AIR_SUSPENSION_MOVEMENT_RAISING"
        When NotifyAirSuspensionCurrentHeightInformation is sent
        Then HMI Shows: DI_GUI.miscTelltales.eAirSusp_Symbol == "AIR_SUSP_OFF_ROAD1_RAISE"

    Scenario: the OFFROAD_2 with suspension movement as RAISING
        When NotifyAirSuspensionCurrentHeightInformation.current_height_information = "ENUM_AIR_SUSPENSION_HEIGHT_MODE_OFF_ROAD_2"
        When NotifyAirSuspensionCurrentHeightInformation.suspension_movement_information = "ENUM_AIR_SUSPENSION_MOVEMENT_RAISING"
        When NotifyAirSuspensionCurrentHeightInformation is sent
        Then HMI Shows: DI_GUI.miscTelltales.eAirSusp_Symbol == "AIR_SUSP_OFF_ROAD2_RAISE"

    Scenario: the HIGH_HEIGHT with suspension movement as RAISING
        When NotifyAirSuspensionCurrentHeightInformation.current_height_information = "ENUM_AIR_SUSPENSION_HEIGHT_MODE_HIGH_HEIGHT"
        When NotifyAirSuspensionCurrentHeightInformation.suspension_movement_information = "ENUM_AIR_SUSPENSION_MOVEMENT_RAISING"
        When NotifyAirSuspensionCurrentHeightInformation is sent
        Then HMI Shows: DI_GUI.miscTelltales.eAirSusp_Symbol == "AIR_SUSP_HIGH_HEIGHT_RAISE"

    Scenario: the NORAML_HEIGHT with suspension movement as RAISING
        When NotifyAirSuspensionCurrentHeightInformation.current_height_information = "ENUM_AIR_SUSPENSION_HEIGHT_MODE_NORMAL_HEIGHT"
        When NotifyAirSuspensionCurrentHeightInformation.suspension_movement_information = "ENUM_AIR_SUSPENSION_MOVEMENT_RAISING"
        When NotifyAirSuspensionCurrentHeightInformation is sent
        Then HMI Shows: DI_GUI.miscTelltales.eAirSusp_Symbol == "AIR_SUSP_NORM_HEIGHT_RAISE"

    Scenario: the ACCESS_HEIGHT with suspension movement as RAISING
        When NotifyAirSuspensionCurrentHeightInformation.current_height_information = "ENUM_AIR_SUSPENSION_HEIGHT_MODE_ACCESS_HEIGHT"
        When NotifyAirSuspensionCurrentHeightInformation.suspension_movement_information = "ENUM_AIR_SUSPENSION_MOVEMENT_RAISING"
        When NotifyAirSuspensionCurrentHeightInformation is sent
        Then HMI Shows: DI_GUI.miscTelltales.eAirSusp_Symbol == "AIR_SUSP_ACCESS_HEIGHT_RAISE"

    Scenario: the ACCESS_LOCK_HEIGHT with suspension movement as RAISING
        When NotifyAirSuspensionCurrentHeightInformation.current_height_information = "ENUM_AIR_SUSPENSION_HEIGHT_MODE_LOCK_ACCESS_HEIGHT"
        When NotifyAirSuspensionCurrentHeightInformation.suspension_movement_information = "ENUM_AIR_SUSPENSION_MOVEMENT_RAISING"
        When NotifyAirSuspensionCurrentHeightInformation is sent
        Then HMI Shows: DI_GUI.miscTelltales.eAirSusp_Symbol == "AIR_SUSP_LOCK_ACS_HEIGHT_RAISE"

    Scenario: the EXTENDED_MODE with suspension movement as RAISING
        When NotifyAirSuspensionCurrentHeightInformation.current_height_information = "ENUM_AIR_SUSPENSION_HEIGHT_MODE_EXTENDED_MODE"
        When NotifyAirSuspensionCurrentHeightInformation.suspension_movement_information = "ENUM_AIR_SUSPENSION_MOVEMENT_RAISING"
        When NotifyAirSuspensionCurrentHeightInformation is sent
        Then HMI Shows: DI_GUI.miscTelltales.eAirSusp_Symbol == "AIR_SUSP_EXTD_MODE_RAISE"

    Scenario: the Notify to make defalut
        When NotifyAirSuspensionCurrentHeightInformation.current_height_information = "ENUM_AIR_SUSPENSION_HEIGHT_MODE_UNSPECIFIED"
        When NotifyAirSuspensionCurrentHeightInformation.suspension_movement_information = "ENUM_AIR_SUSPENSION_MOVEMENT_STATIONARY"
        When NotifyAirSuspensionCurrentHeightInformation is sent
        Then HMI Shows: DI_GUI.miscTelltales.eAirSusp_Symbol == "AIR_SUSP_NONE"

    Scenario: the Suspension Movement OF LOWERING the OFFROAD with suspension movement as LOWERING
        When NotifyAirSuspensionCurrentHeightInformation.current_height_information = "ENUM_AIR_SUSPENSION_HEIGHT_MODE_AUTO_OFF_ROAD"
        When NotifyAirSuspensionCurrentHeightInformation.suspension_movement_information = "ENUM_AIR_SUSPENSION_MOVEMENT_LOWERING"
        When NotifyAirSuspensionCurrentHeightInformation is sent
        Then HMI Shows: DI_GUI.miscTelltales.eAirSusp_Symbol == "AIR_SUSP_OFF_ROAD_LOWER"

    Scenario: the OFFROAD_1 with suspension movement as LOWERING
        When NotifyAirSuspensionCurrentHeightInformation.current_height_information = "ENUM_AIR_SUSPENSION_HEIGHT_MODE_OFF_ROAD_1"
        When NotifyAirSuspensionCurrentHeightInformation.suspension_movement_information = "ENUM_AIR_SUSPENSION_MOVEMENT_LOWERING"
        When NotifyAirSuspensionCurrentHeightInformation is sent
        Then HMI Shows: DI_GUI.miscTelltales.eAirSusp_Symbol == "AIR_SUSP_OFF_ROAD1_LOWER"

    Scenario: the OFFROAD_2 with suspension movement as LOWERING
        When NotifyAirSuspensionCurrentHeightInformation.current_height_information = "ENUM_AIR_SUSPENSION_HEIGHT_MODE_OFF_ROAD_2"
        When NotifyAirSuspensionCurrentHeightInformation.suspension_movement_information = "ENUM_AIR_SUSPENSION_MOVEMENT_LOWERING"
        When NotifyAirSuspensionCurrentHeightInformation is sent
        Then HMI Shows: DI_GUI.miscTelltales.eAirSusp_Symbol == "AIR_SUSP_OFF_ROAD2_LOWER"

    Scenario: the HIGH_HEIGHT with suspension movement as LOWERING
        When NotifyAirSuspensionCurrentHeightInformation.current_height_information = "ENUM_AIR_SUSPENSION_HEIGHT_MODE_HIGH_HEIGHT"
        When NotifyAirSuspensionCurrentHeightInformation.suspension_movement_information = "ENUM_AIR_SUSPENSION_MOVEMENT_LOWERING"
        When NotifyAirSuspensionCurrentHeightInformation is sent
        Then HMI Shows: DI_GUI.miscTelltales.eAirSusp_Symbol == "AIR_SUSP_HIGH_HEIGHT_LOWER"

    Scenario: the NORAML_HEIGHT with suspension movement as LOWERING
        When NotifyAirSuspensionCurrentHeightInformation.current_height_information = "ENUM_AIR_SUSPENSION_HEIGHT_MODE_NORMAL_HEIGHT"
        When NotifyAirSuspensionCurrentHeightInformation.suspension_movement_information = "ENUM_AIR_SUSPENSION_MOVEMENT_LOWERING"
        When NotifyAirSuspensionCurrentHeightInformation is sent
        Then HMI Shows: DI_GUI.miscTelltales.eAirSusp_Symbol == "AIR_SUSP_NORM_HEIGHT_LOWER"

    Scenario: the ACCESS_HEIGHT with suspension movement as LOWERING
        When NotifyAirSuspensionCurrentHeightInformation.current_height_information = "ENUM_AIR_SUSPENSION_HEIGHT_MODE_ACCESS_HEIGHT"
        When NotifyAirSuspensionCurrentHeightInformation.suspension_movement_information = "ENUM_AIR_SUSPENSION_MOVEMENT_LOWERING"
        When NotifyAirSuspensionCurrentHeightInformation is sent
        Then HMI Shows: DI_GUI.miscTelltales.eAirSusp_Symbol == "AIR_SUSP_ACCESS_HEIGHT_LOWER"

    Scenario: the ACCESS_LOCK_HEIGHT with suspension movement as LOWERING
        When NotifyAirSuspensionCurrentHeightInformation.current_height_information = "ENUM_AIR_SUSPENSION_HEIGHT_MODE_LOCK_ACCESS_HEIGHT"
        When NotifyAirSuspensionCurrentHeightInformation.suspension_movement_information = "ENUM_AIR_SUSPENSION_MOVEMENT_LOWERING"
        When NotifyAirSuspensionCurrentHeightInformation is sent
        Then HMI Shows: DI_GUI.miscTelltales.eAirSusp_Symbol == "AIR_SUSP_LOCK_ACS_HEIGHT_LOWER"

    Scenario: the EXTENDED_MODE with suspension movement as LOWERING
        When NotifyAirSuspensionCurrentHeightInformation.current_height_information = "ENUM_AIR_SUSPENSION_HEIGHT_MODE_EXTENDED_MODE"
        When NotifyAirSuspensionCurrentHeightInformation.suspension_movement_information = "ENUM_AIR_SUSPENSION_MOVEMENT_LOWERING"
        When NotifyAirSuspensionCurrentHeightInformation is sent
        Then HMI Shows: DI_GUI.miscTelltales.eAirSusp_Symbol == "AIR_SUSP_EXTD_MODE_LOWER"
