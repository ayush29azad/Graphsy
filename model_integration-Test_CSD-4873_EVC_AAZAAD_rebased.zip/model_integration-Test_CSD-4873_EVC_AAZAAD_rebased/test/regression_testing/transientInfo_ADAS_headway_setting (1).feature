Feature:

    Scenario: Start server/clients
        When Start server for lifecycle_cccmuserapps_vlca_service
        And Start server for motion_setting_service
        And Start server for display_control_service

    Scenario:
        When GetHUDStateRequest.hud_type = 'ENUM_HUDTYPE_DRIVER_HUD'
        When Send request GetHUDStateRequest

    Scenario: Set Vehicle_State = 'ENUM_STATE_RUNNING'
        Given Receive request GetVLCAStateRequest
        When GetVLCAStateResponse.vlca_state = "ENUM_VLCA_STATE_UNSPECIFIED"
        When GetVLCAStateResponse.vehicle_mode = "ENUM_VEHICLE_MODE_UNSPECIFIED"
        When GetVLCAStateResponse.vehicle_state = "ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL"
        When Send response GetVLCAStateResponse
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_STATE_RUNNING' 
    
    Scenario:
        When NotifyHeadwaySettingStatus.status = 'ENUM_STATUS_OK'
        When NotifyHeadwaySettingStatus.headway_mode_level = 'ENUM_HEADWAY_MODE_LEVEL1'
        When Send NotifyHeadwaySettingStatus
        Then HMI shows: DI_GUI.transHeadwaySetting.eTransHeadwaySetting_Level == 'HEADWAY_MODE_LEVEL1'

    Scenario:
        When NotifyHeadwaySettingStatus.status = 'ENUM_STATUS_OK'
        When NotifyHeadwaySettingStatus.headway_mode_level = 'ENUM_HEADWAY_MODE_LEVEL2'
        When Send NotifyHeadwaySettingStatus
        Then HMI shows: DI_GUI.transHeadwaySetting.eTransHeadwaySetting_Level == 'HEADWAY_MODE_LEVEL2'

    Scenario:
        When NotifyHeadwaySettingStatus.status = 'ENUM_STATUS_OK'
        When NotifyHeadwaySettingStatus.headway_mode_level = 'ENUM_HEADWAY_MODE_LEVEL3'
        When Send NotifyHeadwaySettingStatus
        Then HMI shows: DI_GUI.transHeadwaySetting.eTransHeadwaySetting_Level == 'HEADWAY_MODE_LEVEL3'
    
    Scenario:
        When NotifyHeadwaySettingStatus.status = 'ENUM_STATUS_OK'
        When NotifyHeadwaySettingStatus.headway_mode_level = 'ENUM_HEADWAY_MODE_LEVEL4'
        When Send NotifyHeadwaySettingStatus
        Then HMI shows: DI_GUI.transHeadwaySetting.eTransHeadwaySetting_Level == 'HEADWAY_MODE_LEVEL4'
    
    Scenario:
        When NotifyHeadwaySettingStatus.status = 'ENUM_STATUS_OK'
        When NotifyHeadwaySettingStatus.headway_mode_level = 'ENUM_HEADWAY_MODE_OFF'
        When Send NotifyHeadwaySettingStatus
        Then HMI shows: DI_GUI.transHeadwaySetting.eTransHeadwaySetting_Level
    
    Scenario:
        When NotifyHeadwaySettingStatus.status = 'ENUM_STATUS_UNSPECIFIED'
        When NotifyHeadwaySettingStatus.headway_mode_level = 'ENUM_HEADWAY_MODE_LEVEL1'
        When Send NotifyHeadwaySettingStatus
        Then HMI shows: DI_GUI.transHeadwaySetting.eTransHeadwaySetting_Level

   
