Feature: AOCC Comfort Levels

    Scenario: Start server/clients
        When Start server for lifecycle_cccmuserapps_vlca_service
        And Start server for steering_service

    #### Comfort Mode
    Scenario: Set Vehicle_State = 'ENUM_STATE_COMFORT'
        Given Receive request GetVLCAStateRequest
        When GetVLCAStateResponse.vlca_state = "ENUM_VLCA_STATE_UNSPECIFIED"
        When GetVLCAStateResponse.vehicle_mode = "ENUM_VEHICLE_MODE_UNSPECIFIED"
        When GetVLCAStateResponse.vehicle_state = "ENUM_VEHICLE_STATE_COMFORT"
        When Send response GetVLCAStateResponse
        Then HMI shows: eVehicle_State in ENUM_STATE_COMFORT

    Scenario: Check DDS when 'ENUM_ATPC_PRO_COMFORT_SETTING_UNSPECIFIED' and eVehicle_State = 'ENUM_STATE_COMFORT'
        When NotifyATPCProComfortSetting.status = 'ENUM_STATUS_OK'
        When NotifyATPCProComfortSetting.atpc_pro_comfort_setting = 'ENUM_ATPC_PRO_COMFORT_SETTING_UNSPECIFIED'
        When NotifyATPCProComfortSetting is sent
        Then HMI shows: AOCC Comfort Levels is updated to ATPC_COMFORT_UNSPECIFIED in ENUM_VEHICLE_STATE_COMFORT

    Scenario: Check DDS when 'ENUM_ATPC_PRO_COMFORT_SETTING_OFF' and eVehicle_State = 'ENUM_STATE_COMFORT'
        When NotifyATPCProComfortSetting.status = 'ENUM_STATUS_OK'
        When NotifyATPCProComfortSetting.atpc_pro_comfort_setting = 'ENUM_ATPC_PRO_COMFORT_SETTING_OFF'
        When NotifyATPCProComfortSetting is sent
        Then HMI shows: AOCC Comfort Levels is updated to ATPC_COMFORT_OFF in ENUM_VEHICLE_STATE_COMFORT

    Scenario: Check DDS when 'ENUM_ATPC_PRO_COMFORT_SETTING_LOW' and eVehicle_State = 'ENUM_STATE_COMFORT'
        When NotifyATPCProComfortSetting.status = 'ENUM_STATUS_OK'
        When NotifyATPCProComfortSetting.atpc_pro_comfort_setting = 'ENUM_ATPC_PRO_COMFORT_SETTING_LOW'
        When NotifyATPCProComfortSetting is sent
        Then HMI shows: AOCC Comfort Levels is updated to ATPC_COMFORT_LOW in ENUM_VEHICLE_STATE_COMFORT

    Scenario: Check DDS when 'ENUM_ATPC_PRO_COMFORT_SETTING_MEDIUM' and eVehicle_State = 'ENUM_STATE_COMFORT'
        When NotifyATPCProComfortSetting.status = 'ENUM_STATUS_OK'
        When NotifyATPCProComfortSetting.atpc_pro_comfort_setting = 'ENUM_ATPC_PRO_COMFORT_SETTING_MEDIUM'
        When NotifyATPCProComfortSetting is sent
        Then HMI shows: AOCC Comfort Levels is updated to ATPC_COMFORT_MEDIUM in ENUM_VEHICLE_STATE_COMFORT

    Scenario: Check DDS when 'ENUM_ATPC_PRO_COMFORT_SETTING_HIGH' and eVehicle_State = 'ENUM_STATE_COMFORT'
        When NotifyATPCProComfortSetting.status = 'ENUM_STATUS_OK'
        When NotifyATPCProComfortSetting.atpc_pro_comfort_setting = 'ENUM_ATPC_PRO_COMFORT_SETTING_HIGH'
        When NotifyATPCProComfortSetting is sent
        Then HMI shows: AOCC Comfort Levels is updated to ATPC_COMFORT_HIGH in ENUM_VEHICLE_STATE_COMFORT

    Scenario: Check DDS is sent again when same input is repeated when 'ENUM_ATPC_PRO_COMFORT_SETTING_HIGH' and eVehicle_State = 'ENUM_STATE_COMFORT'
        When NotifyATPCProComfortSetting.status = 'ENUM_STATUS_OK'
        When NotifyATPCProComfortSetting.atpc_pro_comfort_setting = 'ENUM_ATPC_PRO_COMFORT_SETTING_HIGH'
        When NotifyATPCProComfortSetting is sent
        Then HMI shows: AOCC Comfort Levels is updated to ATPC_COMFORT_HIGH in ENUM_VEHICLE_STATE_COMFORT

    #### Running Mode
    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_RUNNING'
        When NotifyVLCAState.vlca_state = "ENUM_VLCA_STATE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_mode = "ENUM_VEHICLE_MODE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_state = "ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL"
        When Send notify NotifyVLCAState
        Then HMI shows: eVehicle_State in ENUM_STATE_RUNNING
    
    Scenario: Check DDS when 'ENUM_ATPC_PRO_COMFORT_SETTING_UNSPECIFIED' and eVehicle_State = 'ENUM_VEHICLE_RUNNING'
        When NotifyATPCProComfortSetting.status = 'ENUM_STATUS_OK'
        When NotifyATPCProComfortSetting.atpc_pro_comfort_setting = 'ENUM_ATPC_PRO_COMFORT_SETTING_UNSPECIFIED'
        When NotifyATPCProComfortSetting is sent
        Then HMI shows: AOCC Comfort Levels is updated to ATPC_COMFORT_UNSPECIFIED in ENUM_VEHICLE_RUNNING
    
    Scenario: Check AOCC Comfort Levels is updated when eVehicle_State = 'ENUM_STATE_RUNNING'
        When NotifyATPCProComfortSetting.status = 'ENUM_STATUS_OK'
        When NotifyATPCProComfortSetting.atpc_pro_comfort_setting = 'ENUM_ATPC_PRO_COMFORT_SETTING_OFF'
        When NotifyATPCProComfortSetting is sent
        Then HMI shows: AOCC Comfort Levels is updated to ATPC_COMFORT_OFF in ENUM_STATE_RUNNING
    
    Scenario: Check AOCC Comfort Levels is updated when eVehicle_State = 'ENUM_STATE_RUNNING'
        When NotifyATPCProComfortSetting.status = 'ENUM_STATUS_OK'
        When NotifyATPCProComfortSetting.atpc_pro_comfort_setting = 'ENUM_ATPC_PRO_COMFORT_SETTING_LOW'
        When NotifyATPCProComfortSetting is sent
        Then HMI shows: AOCC Comfort Levels is updated to ATPC_COMFORT_LOW in ENUM_STATE_RUNNING
    
    Scenario: Check AOCC Comfort Levels is updated when eVehicle_State = 'ENUM_STATE_RUNNING'
        When NotifyATPCProComfortSetting.status = 'ENUM_STATUS_OK'
        When NotifyATPCProComfortSetting.atpc_pro_comfort_setting = 'ENUM_ATPC_PRO_COMFORT_SETTING_MEDIUM'
        When NotifyATPCProComfortSetting is sent
        Then HMI shows: AOCC Comfort Levels is updated to ATPC_COMFORT_MEDIUM in ENUM_STATE_RUNNING
    
    Scenario: Check AOCC Comfort Levels is updated when eVehicle_State = 'ENUM_STATE_RUNNING'
        When NotifyATPCProComfortSetting.status = 'ENUM_STATUS_OK'
        When NotifyATPCProComfortSetting.atpc_pro_comfort_setting = 'ENUM_ATPC_PRO_COMFORT_SETTING_HIGH'
        When NotifyATPCProComfortSetting is sent
        Then HMI shows: AOCC Comfort Levels is updated to ATPC_COMFORT_HIGH in ENUM_STATE_RUNNING

    #### No Update
    Scenario: Check AOCC Comfort Levels is not updated when status = 'ENUM_STATUS_UNSPECIFIED'
        When NotifyATPCProComfortSetting.status = 'ENUM_STATUS_UNSPECIFIED'
        When NotifyATPCProComfortSetting is sent
        Then HMI shows: AOCC Comfort Levels is not updated for ENUM_STATUS_UNSPECIFIED

    Scenario: Check AOCC Comfort Levels is not updated when status = 'ENUM_STATUS_DATA_DEGRADED'
        When NotifyATPCProComfortSetting.status = 'ENUM_STATUS_DATA_DEGRADED'
        When NotifyATPCProComfortSetting is sent
        Then HMI shows: AOCC Comfort Levels is not updated for ENUM_STATUS_DATA_DEGRADED

    Scenario: Check AOCC Comfort Levels is not updated when status = 'ENUM_STATUS_DATA_UNRELIABLE'
        When NotifyATPCProComfortSetting.status = 'ENUM_STATUS_DATA_UNRELIABLE'
        When NotifyATPCProComfortSetting is sent
        Then HMI shows: AOCC Comfort Levels is not updated for ENUM_STATUS_DATA_UNRELIABLE

    Scenario: Check AOCC Comfort Levels is not updated when status = 'ENUM_STATUS_DATA_UNAVAILABLE'
        When NotifyATPCProComfortSetting.status = 'ENUM_STATUS_DATA_UNAVAILABLE'
        When NotifyATPCProComfortSetting is sent
        Then HMI shows: AOCC Comfort Levels is not updated for ENUM_STATUS_DATA_UNAVAILABLE

    Scenario: Check AOCC Comfort Levels is not updated when status = 'ENUM_STATUS_ERROR_INVALID_SERVICE_STATE'
        When NotifyATPCProComfortSetting.status = 'ENUM_STATUS_ERROR_INVALID_SERVICE_STATE'
        When NotifyATPCProComfortSetting is sent
        Then HMI shows: AOCC Comfort Levels is not updated for ENUM_STATUS_ERROR_INVALID_SERVICE_STATE

    Scenario: Check AOCC Comfort Levels is not updated when status = 'ENUM_STATUS_ERROR_INVALID_VEHICLE_STATE'
        When NotifyATPCProComfortSetting.status = 'ENUM_STATUS_ERROR_INVALID_VEHICLE_STATE'
        When NotifyATPCProComfortSetting is sent
        Then HMI shows: AOCC Comfort Levels is not updated for ENUM_STATUS_ERROR_INVALID_VEHICLE_STATE

    #### Sleep Mode
    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_SLEEP'
        When NotifyVLCAState.vlca_state = "ENUM_VLCA_STATE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_mode = "ENUM_VEHICLE_MODE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_state = "ENUM_VEHICLE_STATE_SLEEP"
        When Send notify NotifyVLCAState
        Then HMI shows: eVehicle_State in ENUM_VEHICLE_SLEEP
    
    Scenario: Check DDS when 'ENUM_ATPC_PRO_COMFORT_SETTING_UNSPECIFIED' and eVehicle_State = 'ENUM_VEHICLE_SLEEP'
        When NotifyATPCProComfortSetting.status = 'ENUM_STATUS_OK'
        When NotifyATPCProComfortSetting.atpc_pro_comfort_setting = 'ENUM_ATPC_PRO_COMFORT_SETTING_UNSPECIFIED'
        When NotifyATPCProComfortSetting is sent
        Then HMI shows: AOCC Comfort Levels is updated to ATPC_COMFORT_UNSPECIFIED in ENUM_VEHICLE_SLEEP
    
    Scenario: Check DDS when 'ENUM_ATPC_PRO_COMFORT_SETTING_OFF' and eVehicle_State = 'ENUM_VEHICLE_SLEEP'
        When NotifyATPCProComfortSetting.status = 'ENUM_STATUS_OK'
        When NotifyATPCProComfortSetting.atpc_pro_comfort_setting = 'ENUM_ATPC_PRO_COMFORT_SETTING_OFF'
        When NotifyATPCProComfortSetting is sent
        Then HMI shows: AOCC Comfort Levels is updated to ATPC_COMFORT_OFF in ENUM_VEHICLE_SLEEP

    Scenario: Check DDS when 'ENUM_ATPC_PRO_COMFORT_SETTING_LOW' and eVehicle_State = 'ENUM_VEHICLE_SLEEP'
        When NotifyATPCProComfortSetting.status = 'ENUM_STATUS_OK'
        When NotifyATPCProComfortSetting.atpc_pro_comfort_setting = 'ENUM_ATPC_PRO_COMFORT_SETTING_LOW'
        When NotifyATPCProComfortSetting is sent
        Then HMI shows: AOCC Comfort Levels is updated to ATPC_COMFORT_LOW in ENUM_VEHICLE_SLEEP
    

    #### Duty Mode
    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_DUTY'
        When NotifyVLCAState.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_state = 'ENUM_VEHICLE_STATE_DUTY'
        When Send notify NotifyVLCAState
        Then HMI shows: eVehicle_State in ENUM_VEHICLE_DUTY
    
    Scenario: Check DDS when 'ENUM_ATPC_PRO_COMFORT_SETTING_UNSPECIFIED' and eVehicle_State = 'ENUM_VEHICLE_DUTY'
        When NotifyATPCProComfortSetting.status = 'ENUM_STATUS_OK'
        When NotifyATPCProComfortSetting.atpc_pro_comfort_setting = 'ENUM_ATPC_PRO_COMFORT_SETTING_UNSPECIFIED'
        When NotifyATPCProComfortSetting is sent
        Then HMI shows: AOCC Comfort Levels is updated to ATPC_COMFORT_UNSPECIFIED in ENUM_VEHICLE_DUTY
    
    Scenario: Check DDS when 'ENUM_ATPC_PRO_COMFORT_SETTING_OFF' and eVehicle_State = 'ENUM_VEHICLE_DUTY'
        When NotifyATPCProComfortSetting.status = 'ENUM_STATUS_OK'
        When NotifyATPCProComfortSetting.atpc_pro_comfort_setting = 'ENUM_ATPC_PRO_COMFORT_SETTING_OFF'
        When NotifyATPCProComfortSetting is sent
        Then HMI shows: AOCC Comfort Levels is updated to ATPC_COMFORT_OFF in ENUM_VEHICLE_DUTY

    Scenario: Check DDS when 'ENUM_ATPC_PRO_COMFORT_SETTING_LOW' and eVehicle_State = 'ENUM_VEHICLE_DUTY'
        When NotifyATPCProComfortSetting.status = 'ENUM_STATUS_OK'
        When NotifyATPCProComfortSetting.atpc_pro_comfort_setting = 'ENUM_ATPC_PRO_COMFORT_SETTING_LOW'
        When NotifyATPCProComfortSetting is sent
        Then HMI shows: AOCC Comfort Levels is updated to ATPC_COMFORT_LOW in ENUM_VEHICLE_DUTY
    
    Scenario: Check DDS when 'ENUM_ATPC_PRO_COMFORT_SETTING_MEDIUM' and eVehicle_State = 'ENUM_VEHICLE_DUTY'
        When NotifyATPCProComfortSetting.status = 'ENUM_STATUS_OK'
        When NotifyATPCProComfortSetting.atpc_pro_comfort_setting = 'ENUM_ATPC_PRO_COMFORT_SETTING_MEDIUM'
        When NotifyATPCProComfortSetting is sent
        Then HMI shows: AOCC Comfort Levels is updated to ATPC_COMFORT_MEDIUM in ENUM_VEHICLE_DUTY
