    
Feature: SeatBelt_Indicator 
    Scenario: Start server/clients
        When Start client for telltale_service
        And Start server for lifecycle_cccmuserapps_vlca_service
    
    #### FULL running Mode
    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_STATE_FULL'
        When NotifyVLCAState.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_state = 'ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL'
        When Send notify NotifyVLCAState   
         
    Scenario: Initial Values 				
        When SetDriverSeatbeltIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_UNSPECIFIED'
        When SetDriverSeatbeltIndicatorRequest.flashing_status = 'ENUM_FLASHING_STATE_UNSPECIFIED'
        When SetDriverSeatbeltIndicatorRequest is sent

    Scenario: Check SeatbeltIndicator is OFF state  
        When SetDriverSeatbeltIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetDriverSeatbeltIndicatorRequest is sent

    Scenario: Check SeatbeltIndicator is OFF state  
        When SetDriverSeatbeltIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON'
        When SetDriverSeatbeltIndicatorRequest.flashing_status = 'ENUM_FLASHING_STATE_UNSPECIFIED'
        When SetDriverSeatbeltIndicatorRequest is sent								
        Then HMI Shows: topic DI_GUI.genericTelltalesFlash

    Scenario: Check INDICATOR SEATBELT FLASH ON State		
        When SetDriverSeatbeltIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON'
        When SetDriverSeatbeltIndicatorRequest.flashing_status = 'ENUM_FLASHING_STATE_ON'
        When SetDriverSeatbeltIndicatorRequest is sent
        Then HMI Shows: DI_GUI.genericTelltalesFlash.bSeatbeltIndicator == TRUE


    Scenario: Check INDICATOR SEATBELT ON State
        When SetDriverSeatbeltIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON'
        When SetDriverSeatbeltIndicatorRequest.flashing_status = 'ENUM_FLASHING_STATE_OFF'
        When SetDriverSeatbeltIndicatorRequest is sent
        Then HMI Shows: DI_GUI.genericTelltalesFlash.bSeatbeltIndicator == TRUE
