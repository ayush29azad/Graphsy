Feature:

    Scenario: Start server/clients
        When Start server for lifecycle_cccmuserapps_vlca_service
        And Start server for vehiclespeed_service
        And Start server for featureconfig_cccmuserapps_service
        And Start server for audio_service
        And Start server for charging_service
    
    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 28466}]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 28466, "value" : 1}] 
        When Send response GetParamResponse
        Then HMI shows: DI_GUI.MPH_MODE
    
    ### Comfort Mode
    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_STATE_COMFORT'
        When NotifyVLCAState.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_state = 'ENUM_VEHICLE_STATE_COMFORT'
        When Send notify NotifyVLCAState
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_VEHICLE_STATE_COMFORT' 

    
    # Scenario: Charging State T
    #     When NotifyChargeState.status = 'ENUM_STATUS_OK'
    #     When NotifyChargeState.charging_status = 'ENUM_CHARGE_STATE_CHARGE_COMPLETE'
    #     When NotifyChargeState.charge_error_state = 'ENUM_CHARGE_ERROR_MODE_NO_ERROR'
    #     When NotifyChargeState.charging_inlet_state = 'ENUM_CHARGING_INLET_STATE_PLUGGED'
    #     When Send notify NotifyChargeState
    #     Then HMI shows: DI_GUI.displayOdometerTripComputer== ''

    Scenario:
        When NotifyChargeSettings.status = 'ENUM_STATUS_OK'
        When NotifyChargeSettings.charge_type = 'ENUM_CHARGE_TYPE_FIXED_SCHEDULE'
        When NotifyChargeSettings is sent
    
    Scenario: T
        When NotifyChargeState.status = 'ENUM_STATUS_OK'
        When NotifyChargeState.charge_error_state = 'ENUM_CHARGE_ERROR_MODE_NO_ERROR'
        When NotifyChargeState.charging_status = 'ENUM_CHARGE_STATE_WAITING_TO_CHARGE'
        When NotifyChargeState.charging_inlet_state = 'ENUM_CHARGING_INLET_STATE_PLUGGED'
        When Send notify NotifyChargeState

    Scenario: T
        When NotifyChargeInProgressData.status = 'ENUM_STATUS_OK'
        When NotifyChargeInProgressData.charging_method = 'ENUM_CHARGING_METHOD_AC_CHARGING'
        When NotifyChargeInProgressData is sent
        Then HMI shows: DI_GUI.chargingInfo.eCharging_Mode == 'CHARGING_METHOD_AC_CHARGING'

    Scenario: T
        When NotifyChargeState.status = 'ENUM_STATUS_OK'
        When NotifyChargeState.charge_error_state = 'ENUM_CHARGE_ERROR_MODE_NO_ERROR'
        When NotifyChargeState.charging_status = 'ENUM_CHARGE_STATE_CHARGE_IN_PROGRESS'
        When NotifyChargeState.charging_inlet_state = 'ENUM_CHARGING_INLET_STATE_PLUGGED'
        When Send notify NotifyChargeState

    Scenario: T
        When NotifyChargeInProgressData.status = 'ENUM_STATUS_OK'
        When NotifyChargeInProgressData.charging_method = 'ENUM_CHARGING_METHOD_AC_CHARGING'
        When NotifyChargeInProgressData.inst_charge_power = 400000
        When NotifyChargeInProgressData is sent
        Then HMI shows: DI_GUI.chargingInfo.eCharging_Mode == 'CHARGING_METHOD_AC_CHARGING'

    Scenario: T
        When NotifyChargeInProgressData.status = 'ENUM_STATUS_OK'
        When NotifyChargeInProgressData.charging_method = 'ENUM_CHARGING_METHOD_AC_CHARGING'
        When NotifyChargeInProgressData.inst_charge_power = 500001
        When NotifyChargeInProgressData is sent
        Then HMI shows: DI_GUI.chargingInfo.eCharging_Mode == 'CHARGING_METHOD_AC_CHARGING'
    
    Scenario: T
        When NotifyChargeInProgressData.status = 'ENUM_STATUS_OK'
        When NotifyChargeInProgressData.charging_method = 'ENUM_CHARGING_METHOD_AC_CHARGING'
        When NotifyChargeInProgressData.inst_charge_power = -1
        When NotifyChargeInProgressData is sent
        Then HMI shows: DI_GUI.chargingInfo.eCharging_Mode == 'CHARGING_METHOD_AC_CHARGING'
    
    Scenario: T
        When NotifyChargeInProgressData.status = 'ENUM_STATUS_OK'
        When NotifyChargeInProgressData.charging_method = 'ENUM_CHARGING_METHOD_AC_CHARGING'
        When NotifyChargeInProgressData.inst_charge_power = 500000
        When NotifyChargeInProgressData is sent
        Then HMI shows: DI_GUI.chargingInfo.eCharging_Mode == 'CHARGING_METHOD_AC_CHARGING'
    
    Scenario: T
        When NotifyChargeInProgressData.status = 'ENUM_STATUS_OK'
        When NotifyChargeInProgressData.charging_method = 'ENUM_CHARGING_METHOD_AC_CHARGING'
        When NotifyChargeInProgressData.inst_charge_power = 500000
        When NotifyChargeInProgressData.charge_rate_mts_ph = 3200001
        When NotifyChargeInProgressData is sent
        Then HMI shows: DI_GUI.chargingInfo.eCharging_Mode == 'CHARGING_METHOD_AC_CHARGING'
    
    Scenario: T
        When NotifyChargeInProgressData.status = 'ENUM_STATUS_OK'
        When NotifyChargeInProgressData.charging_method = 'ENUM_CHARGING_METHOD_AC_CHARGING'
        When NotifyChargeInProgressData.inst_charge_power = 500000
        When NotifyChargeInProgressData.charge_rate_mts_ph = 3200001
        When NotifyChargeInProgressData is sent
        Then HMI shows: DI_GUI.chargingInfo.eCharging_Mode == 'CHARGING_METHOD_AC_CHARGING'
    
    Scenario: T
        When NotifyChargeInProgressData.status = 'ENUM_STATUS_OK'
        When NotifyChargeInProgressData.charging_method = 'ENUM_CHARGING_METHOD_AC_CHARGING'
        When NotifyChargeInProgressData.inst_charge_power = 500000
        When NotifyChargeInProgressData.charge_rate_mts_ph = 3200000
        When NotifyChargeInProgressData is sent
        Then HMI shows: DI_GUI.chargingInfo.eCharging_Mode == 'CHARGING_METHOD_AC_CHARGING'
    
    Scenario: T
        When NotifyChargeInProgressData.status = 'ENUM_STATUS_OK'
        When NotifyChargeInProgressData.charging_method = 'ENUM_CHARGING_METHOD_DC_CHARGING'
        When NotifyChargeInProgressData.inst_charge_power = 500000
        When NotifyChargeInProgressData.charge_rate_mts_ph = 3200000
        When NotifyChargeInProgressData is sent
        Then HMI shows: DI_GUI.chargingInfo.eCharging_Mode == 'CHARGING_METHOD_DC_CHARGING'

    Scenario: T
        When NotifyChargeInProgressData.status = 'ENUM_STATUS_OK'
        When NotifyChargeInProgressData.charging_method = 'ENUM_CHARGING_METHOD_DC_CHARGING'
        When NotifyChargeInProgressData.inst_charge_power = 2000
        When NotifyChargeInProgressData.charge_rate_mts_ph = 60000
        When NotifyChargeInProgressData is sent
        Then HMI shows: DI_GUI.chargingInfo.eCharging_Mode == 'CHARGING_METHOD_DC_CHARGING'
    
    Scenario:
        When restart featureconfig_cccmuserapps_service

    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 28466}]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 28466, "value" : 2}] 
        When Send response GetParamResponse
        Then HMI shows: DI_GUI.MPH_MODE
    
    Scenario: T
        When NotifyChargeInProgressData.status = 'ENUM_STATUS_OK'
        When NotifyChargeInProgressData.charging_method = 'ENUM_CHARGING_METHOD_AC_CHARGING'
        When NotifyChargeInProgressData.inst_charge_power = 500000
        When NotifyChargeInProgressData.charge_rate_mts_ph = 3200000
        When NotifyChargeInProgressData is sent
        Then HMI shows: DI_GUI.chargingInfo.eCharging_Mode == 'CHARGING_METHOD_AC_CHARGING'
    
    Scenario:
        When restart featureconfig_cccmuserapps_service

    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 28466}]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 28466, "value" : 0}] 
        When Send response GetParamResponse
        Then HMI shows: DI_GUI.MPH_MODE
    
    Scenario: T
        When NotifyChargeInProgressData.status = 'ENUM_STATUS_OK'
        When NotifyChargeInProgressData.charging_method = 'ENUM_CHARGING_METHOD_UNSPECIFIED'
        When NotifyChargeInProgressData.inst_charge_power = 500000
        When NotifyChargeInProgressData.charge_rate_mts_ph = 3200000
        When NotifyChargeInProgressData is sent
        Then HMI shows: DI_GUI.chargingInfo.eCharging_Mode == 'CHARGING_METHOD_UNSPECIFIED'
    
    Scenario:
        When restart featureconfig_cccmuserapps_service

    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 28466}]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 28466, "value" : 2}] 
        When Send response GetParamResponse
        Then HMI shows: DI_GUI.MPH_MODE
    
    Scenario:
        When NotifyChargeSessionAttributes.status = 'ENUM_STATUS_OK'
        When NotifyChargeSessionAttributes.energy_added = 200001
        When NotifyChargeSessionAttributes.range_added = 1001
        When NotifyChargeSessionAttributes is sent
    
    Scenario:
        When NotifyChargeSessionAttributes.status = 'ENUM_STATUS_OK'
        When NotifyChargeSessionAttributes.energy_added = 200000
        When NotifyChargeSessionAttributes.range_added = 1000
        When NotifyChargeSessionAttributes is sent
   
    Scenario: T
        When NotifyChargeInProgressData.status = 'ENUM_STATUS_OK'
        When NotifyChargeInProgressData.charging_method = 'ENUM_CHARGING_METHOD_AC_CHARGING'
        When NotifyChargeInProgressData.inst_charge_power = 500000
        When NotifyChargeInProgressData.charge_rate_mts_ph = 3200000
        When NotifyChargeInProgressData is sent
        Then HMI shows: DI_GUI.chargingInfo.eCharging_Mode == 'CHARGING_METHOD_UNSPECIFIED'

    Scenario: T
        When NotifyChargeState.status = 'ENUM_STATUS_OK'
        When NotifyChargeState.charge_error_state = 'ENUM_CHARGE_ERROR_MODE_NO_ERROR'
        When NotifyChargeState.charging_status = 'ENUM_CHARGE_STATE_CHARGE_IN_PROGRESS'
        When NotifyChargeState.charging_inlet_state = 'ENUM_CHARGING_INLET_STATE_PLUGGED'
        When Send notify NotifyChargeState
    
    Scenario:
        When NotifyChargeSettings.status = 'ENUM_STATUS_OK'
        When NotifyChargeSettings.charge_type = 'ENUM_CHARGE_TYPE_FIXED_SCHEDULE'
        When NotifyChargeSettings.max_battery_soc = 90
        When NotifyPredictedCharge.status = 'ENUM_STATUS_OK'
        When NotifyPredictedCharge.time_to_tgt_soc = 3600
        When NotifyPredictedCharge.predicted_charge_data = [{"battery_level" : 101}]
        When NotifyBatteryCurrentStateOfCharge.status = 'ENUM_STATUS_OK'
        When NotifyBatteryCurrentStateOfCharge.current_battery_soc = 10
        When NotifyChargeSettings is sent
        When NotifyPredictedCharge is sent
        When NotifyBatteryCurrentStateOfCharge is sent
        Then HMI shows: topic DI_GUI.chargingInfo
    
    Scenario:
        When NotifyChargeSettings.status = 'ENUM_STATUS_OK'
        When NotifyChargeSettings.charge_type = 'ENUM_CHARGE_TYPE_SCHEDULE_PLUS'
        When NotifyChargeSettings.max_battery_soc = 90
        When NotifyPredictedCharge.status = 'ENUM_STATUS_OK'
        When NotifyPredictedCharge.time_to_tgt_soc = 3600
        When NotifyPredictedCharge.predicted_charge_data = [{"battery_level" : 101}]
        When NotifyBatteryCurrentStateOfCharge.status = 'ENUM_STATUS_OK'
        When NotifyBatteryCurrentStateOfCharge.current_battery_soc = 70
        When NotifyChargeSettings is sent
        When NotifyPredictedCharge is sent
        When NotifyBatteryCurrentStateOfCharge is sent
        Then HMI shows: topic DI_GUI.chargingInfo
    
    Scenario:
        When NotifyChargeSettings.status = 'ENUM_STATUS_OK'
        When NotifyChargeSettings.charge_type = 'ENUM_CHARGE_TYPE_FIXED_SCHEDULE'
        When NotifyChargeSettings.max_battery_soc = 90
        When NotifyPredictedCharge.status = 'ENUM_STATUS_OK'
        When NotifyPredictedCharge.time_to_tgt_soc = 3600
        When NotifyPredictedCharge.predicted_charge_data = [{"battery_level" : 3601}]
        When NotifyBatteryCurrentStateOfCharge.status = 'ENUM_STATUS_OK'
        When NotifyBatteryCurrentStateOfCharge.current_battery_soc = 70
        When NotifyChargeSettings is sent
        When NotifyPredictedCharge is sent
        When NotifyBatteryCurrentStateOfCharge is sent
        Then HMI shows: topic DI_GUI.chargingInfo
    
    Scenario:
        When NotifyChargeSettings.status = 'ENUM_STATUS_OK'
        When NotifyChargeSettings.charge_type = 'ENUM_CHARGE_TYPE_FIXED_SCHEDULE'
        When NotifyChargeSettings.max_battery_soc = 90
        When NotifyPredictedCharge.status = 'ENUM_STATUS_OK'
        When NotifyPredictedCharge.time_to_tgt_soc = 3430
        When NotifyPredictedCharge.predicted_charge_data = [{"battery_level" : 3600}]
        When NotifyBatteryCurrentStateOfCharge.status = 'ENUM_STATUS_OK'
        When NotifyBatteryCurrentStateOfCharge.current_battery_soc = 70
        When NotifyChargeSettings is sent
        When NotifyPredictedCharge is sent
        When NotifyBatteryCurrentStateOfCharge is sent
        Then HMI shows: topic DI_GUI.chargingInfo
    
    Scenario:
        When NotifyChargeSettings.status = 'ENUM_STATUS_OK'
        When NotifyChargeSettings.charge_type = 'ENUM_CHARGE_TYPE_FIXED_SCHEDULE'
        When NotifyChargeSettings.max_battery_soc = 90
        When NotifyPredictedCharge.status = 'ENUM_STATUS_OK'
        When NotifyPredictedCharge.time_to_tgt_soc = 3430
        When NotifyPredictedCharge.predicted_charge_data = [{"battery_level" : 80}]
        When NotifyBatteryCurrentStateOfCharge.status = 'ENUM_STATUS_OK'
        When NotifyBatteryCurrentStateOfCharge.current_battery_soc = 70
        When NotifyChargeSettings is sent
        When NotifyPredictedCharge is sent
        When NotifyBatteryCurrentStateOfCharge is sent
        Then HMI shows: topic DI_GUI.chargingInfo
    
    Scenario:
        When NotifyChargeSettings.status = 'ENUM_STATUS_OK'
        When NotifyChargeSettings.charge_type = 'ENUM_CHARGE_TYPE_FIXED_SCHEDULE'
        When NotifyChargeSettings.max_battery_soc = 90
        When NotifyPredictedCharge.status = 'ENUM_STATUS_OK'
        When NotifyPredictedCharge.time_to_tgt_soc = 3430
        When NotifyPredictedCharge.predicted_charge_data = [{"battery_level" : 3601,"predicted_time" : 3430}]
        When NotifyBatteryCurrentStateOfCharge.status = 'ENUM_STATUS_OK'
        When NotifyBatteryCurrentStateOfCharge.current_battery_soc = 70
        When NotifyChargeSettings is sent
        When NotifyPredictedCharge is sent
        When NotifyBatteryCurrentStateOfCharge is sent
        Then HMI shows: topic DI_GUI.chargingInfo
    
    Scenario:
        When NotifyChargeSettings.status = 'ENUM_STATUS_OK'
        When NotifyChargeSettings.charge_type = 'ENUM_CHARGE_TYPE_FIXED_SCHEDULE'
        When NotifyChargeSettings.max_battery_soc = 90
        When NotifyPredictedCharge.status = 'ENUM_STATUS_OK'
        When NotifyPredictedCharge.time_to_tgt_soc = 3430
        When NotifyPredictedCharge.predicted_charge_data = [{"battery_level" : 3601,"predicted_time" : 3430}]
        When NotifyBatteryCurrentStateOfCharge.status = 'ENUM_STATUS_OK'
        When NotifyBatteryCurrentStateOfCharge.current_battery_soc = 70
        When NotifyChargeSettings is sent
        When NotifyPredictedCharge is sent
        When NotifyBatteryCurrentStateOfCharge is sent
        Then HMI shows: topic DI_GUI.chargingInfo

    Scenario:
        When NotifyChargeSettings.status = 'ENUM_STATUS_OK'
        When NotifyChargeSettings.charge_type = 'ENUM_CHARGE_TYPE_FIXED_SCHEDULE'
        When NotifyChargeSettings.max_battery_soc = 90
        When NotifyPredictedCharge.status = 'ENUM_STATUS_OK'
        When NotifyPredictedCharge.time_to_tgt_soc = 3430
        When NotifyPredictedCharge.predicted_charge_data = [{"battery_level" : 3601,"predicted_time" : 3430}]
        When NotifyBatteryCurrentStateOfCharge.status = 'ENUM_STATUS_OK'
        When NotifyBatteryCurrentStateOfCharge.current_battery_soc = 75
        When NotifyChargeSettings is sent
        When NotifyPredictedCharge is sent
        When NotifyBatteryCurrentStateOfCharge is sent
        Then HMI shows: topic DI_GUI.chargingInfo

    Scenario:
        When NotifyChargeSettings.status = 'ENUM_STATUS_OK'
        When NotifyChargeSettings.charge_type = 'ENUM_CHARGE_TYPE_FIXED_SCHEDULE'
        When NotifyChargeSettings.max_battery_soc = 90
        When NotifyPredictedCharge.status = 'ENUM_STATUS_OK'
        When NotifyPredictedCharge.time_to_tgt_soc = 3430
        When NotifyPredictedCharge.predicted_charge_data = [{"battery_level" : 3601,"predicted_time" : 3430, "predicted_range" : 15}]
        When NotifyBatteryCurrentStateOfCharge.status = 'ENUM_STATUS_OK'
        When NotifyBatteryCurrentStateOfCharge.current_battery_soc = 75
        When NotifyChargeSettings is sent
        When NotifyPredictedCharge is sent
        When NotifyBatteryCurrentStateOfCharge is sent
        Then HMI shows: topic DI_GUI.chargingInfo

    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_STATE_DUTY'
        When NotifyVLCAState.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_state = 'ENUM_VEHICLE_STATE_DUTY'
        When Send notify NotifyVLCAState
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_VEHICLE_STATE_DUTY' 

    Scenario:
        When NotifyChargeSettings.status = 'ENUM_STATUS_OK'
        When NotifyChargeSettings.charge_type = 'ENUM_CHARGE_TYPE_FIXED_SCHEDULE'
        When NotifyChargeSettings.max_battery_soc = 44
        When NotifyPredictedCharge.status = 'ENUM_STATUS_OK'
        When NotifyPredictedCharge.time_to_tgt_soc = 3430
        When NotifyPredictedCharge.predicted_charge_data = [{"battery_level" : 3601,"predicted_time" : 3430, "predicted_range" : 15}]
        When NotifyBatteryCurrentStateOfCharge.status = 'ENUM_STATUS_OK'
        When NotifyBatteryCurrentStateOfCharge.current_battery_soc = 75
        When NotifyChargeSettings is sent
        When NotifyPredictedCharge is sent
        When NotifyBatteryCurrentStateOfCharge is sent
        Then HMI shows: topic DI_GUI.chargingInfo

    Scenario:
        When NotifyChargeSettings.status = 'ENUM_STATUS_OK'
        When NotifyChargeSettings.charge_type = 'ENUM_CHARGE_TYPE_FIXED_SCHEDULE'
        When NotifyChargeSettings.max_battery_soc = 20
        When NotifyPredictedCharge.status = 'ENUM_STATUS_OK'
        When NotifyPredictedCharge.time_to_tgt_soc = 3430
        When NotifyPredictedCharge.predicted_charge_data = [{"battery_level" : 3601,"predicted_time" : 3430, "predicted_range" : 15}]
        When NotifyBatteryCurrentStateOfCharge.status = 'ENUM_STATUS_OK'
        When NotifyBatteryCurrentStateOfCharge.current_battery_soc = 75
        When NotifyChargeSettings is sent
        When NotifyPredictedCharge is sent
        When NotifyBatteryCurrentStateOfCharge is sent
        Then HMI shows: topic DI_GUI.chargingInfo
    
    Scenario:
        When NotifyChargeSettings.status = 'ENUM_STATUS_OK'
        When NotifyChargeSettings.charge_type = 'ENUM_CHARGE_TYPE_FIXED_SCHEDULE'
        When NotifyChargeSettings.max_battery_soc = 60
        When NotifyPredictedCharge.status = 'ENUM_STATUS_OK'
        When NotifyPredictedCharge.time_to_tgt_soc = 3430
        When NotifyPredictedCharge.predicted_charge_data = [{"battery_level" : 3601,"predicted_time" : 3430, "predicted_range" : 15}]
        When NotifyBatteryCurrentStateOfCharge.status = 'ENUM_STATUS_OK'
        When NotifyBatteryCurrentStateOfCharge.current_battery_soc = 75
        When NotifyChargeSettings is sent
        When NotifyPredictedCharge is sent
        When NotifyBatteryCurrentStateOfCharge is sent
        Then HMI shows: topic DI_GUI.chargingInfo

    Scenario:
        When NotifyChargeSettings.status = 'ENUM_STATUS_OK'
        When NotifyChargeSettings.charge_type = 'ENUM_CHARGE_TYPE_FIXED_SCHEDULE'
        When NotifyChargeSettings.max_battery_soc = 60
        When NotifyPredictedCharge.status = 'ENUM_STATUS_OK'
        When NotifyPredictedCharge.time_to_tgt_soc = 3430
        When NotifyPredictedCharge.predicted_charge_data = [{"battery_level" : 3601,"predicted_time" : 3430, "predicted_range" : 15}]
        When NotifyBatteryCurrentStateOfCharge.status = 'ENUM_STATUS_OK'
        When NotifyBatteryCurrentStateOfCharge.current_battery_soc = 20
        When NotifyChargeSettings is sent
        When NotifyPredictedCharge is sent
        When NotifyBatteryCurrentStateOfCharge is sent
        Then HMI shows: topic DI_GUI.chargingInfo

    Scenario:
        When NotifyChargeSettings.status = 'ENUM_STATUS_OK'
        When NotifyChargeSettings.charge_type = 'ENUM_CHARGE_TYPE_FIXED_SCHEDULE'
        When NotifyChargeSettings.max_battery_soc = 45
        When NotifyPredictedCharge.status = 'ENUM_STATUS_OK'
        When NotifyPredictedCharge.time_to_tgt_soc = 3430
        When NotifyPredictedCharge.predicted_charge_data = [{"battery_level" : 3601,"predicted_time" : 3430, "predicted_range" : 15}]
        When NotifyBatteryCurrentStateOfCharge.status = 'ENUM_STATUS_OK'
        When NotifyBatteryCurrentStateOfCharge.current_battery_soc = 20
        When NotifyChargeSettings is sent
        When NotifyPredictedCharge is sent
        When NotifyBatteryCurrentStateOfCharge is sent
        Then HMI shows: topic DI_GUI.chargingInfo
    
    
