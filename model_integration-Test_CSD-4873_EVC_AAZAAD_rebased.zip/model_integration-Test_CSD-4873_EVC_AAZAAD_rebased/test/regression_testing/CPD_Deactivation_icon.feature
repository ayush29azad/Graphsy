Feature: CPD Deactivation 
    Scenario: Start server/clients
        When Start client for telltale_service
        And Start server for lifecycle_cccmuserapps_vlca_service

    Scenario: 1: checking DDS when 'ENUM_INDICATOR_STATE_UNSPECIFIED'
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_CPD'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_UNSPECIFIED'
        When SetIndicatorRequest is sent
        When GetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_CPD'
        When SetIndicatorRequest is sent
        Then HMI Shows:  DI_GUI.telltaleService1.bCPDOffIndicator_IsOn == FALSE

    Scenario: 2: checking DDS when CPD State ON
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_CPD'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON'
        When SetIndicatorRequest is sent
        When GetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_CPD'
        When SetIndicatorRequest is sent
        Then HMI Shows: DI_GUI.telltaleService1.bCPDOffIndicator_IsOn == TRUE

    Scenario: 3: checking DDS when CPD State OFF
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_CPD'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetIndicatorRequest is sent
        When GetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_CPD'
        When SetIndicatorRequest is sent
        Then HMI Shows:  DI_GUI.telltaleService1.bCPDOffIndicator_IsOn == FALSE
 

    
