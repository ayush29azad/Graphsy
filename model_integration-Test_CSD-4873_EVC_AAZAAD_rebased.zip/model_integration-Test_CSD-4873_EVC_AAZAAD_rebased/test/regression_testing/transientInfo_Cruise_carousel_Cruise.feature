Feature:

    Scenario: Start server/clients
        When Start server for lifecycle_cccmuserapps_vlca_service
        And Start server for motion_setting_service
	    And Start server for display_control_service

    Scenario: Set Vehicle_State = 'ENUM_STATE_Running'
        Given Receive request GetVLCAStateRequest
        When GetVLCAStateResponse.vlca_state = "ENUM_VLCA_STATE_UNSPECIFIED"
        When GetVLCAStateResponse.vehicle_mode = "ENUM_VEHICLE_MODE_UNSPECIFIED"
        When GetVLCAStateResponse.vehicle_state = "ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL"
        When Send response GetVLCAStateResponse
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_VEHICLE_STATE_RUNNING' 
    
    Scenario: 
        Given Receive request GetHUDStateRequest
        When GetHUDStateResponse.status = 'ENUM_STATUS_OK'
        When GetHUDStateResponse.hud_type = 'ENUM_HUDTYPE_DRIVER_HUD'
        When GetHUDStateResponse.hud_state = 'ENUM_HUD_STATE_ON'
        When GetHUDStateResponse is sent
    
    Scenario:
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_CRUISE_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_READY_TO_ACTIVATE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 0
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 5
        When Send NotifyCruiseConfiguratorModeStatus
        Then HMI shows: DI_GUI.transCruiseCarousel_Cruise

    Scenario:
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_CRUISE_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 1
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 4
        When Send NotifyCruiseConfiguratorModeStatus
        Then HMI shows: DI_GUI.transCruiseCarousel_Cruise

    Scenario:
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_CRUISE_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_FAILURE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 2
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 0
        When Send NotifyCruiseConfiguratorModeStatus
        Then HMI shows: DI_GUI.transCruiseCarousel_Cruise
    
    Scenario:
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_CRUISE_ACTIVE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_READY_TO_ACTIVATE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 0
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 5
        When Send NotifyCruiseConfiguratorModeStatus
        Then HMI shows: DI_GUI.transCruiseCarousel_Cruise
    
    Scenario:
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_CRUISE_ACTIVE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 1
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 4
        When Send NotifyCruiseConfiguratorModeStatus
        Then HMI shows: DI_GUI.transCruiseCarousel_Cruise
    
    Scenario:
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_CRUISE_ACTIVE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_FAILURE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 2
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 0
        When Send NotifyCruiseConfiguratorModeStatus
        Then HMI shows: DI_GUI.transCruiseCarousel_Cruise

    Scenario:
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_CRUISE_NOT_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_READY_TO_ACTIVATE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 0
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 5
        When Send NotifyCruiseConfiguratorModeStatus
        Then HMI shows: DI_GUI.transCruiseCarousel_Cruise
    
    Scenario:
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_CRUISE_NOT_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 1
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 4
        When Send NotifyCruiseConfiguratorModeStatus
        Then HMI shows: DI_GUI.transCruiseCarousel_Cruise
    
    Scenario:
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_CRUISE_NOT_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_FAILURE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 2
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 0
        When Send NotifyCruiseConfiguratorModeStatus
        Then HMI shows: DI_GUI.transCruiseCarousel_Cruise

    Scenario: Check Cruise Mode Carousel is updated when 'ENUM_STATE_COMFORT' and 'ENUM_CC_MODE_TYPE_CRUISE_AVAILABLE' and 'ENUM_DA_FEATURE_SUBSTATE_READY_TO_ACTIVATE'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_CRUISE_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_READY_TO_ACTIVATE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 5
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 3
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_Cruise
    
    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_RUNNING'
        When NotifyVLCAState.vlca_state = "ENUM_VLCA_STATE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_mode = "ENUM_VEHICLE_MODE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_state = "ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL"
        When Send notify NotifyVLCAState
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_VEHICLE_RUNNING' 


    Scenario:Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_CRUISE_AVAILABLE' and 'ENUM_DA_FEATURE_SUBSTATE_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_CRUISE_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 4
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 2
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_Cruise


    Scenario:Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_CRUISE_AVAILABLE' and 'ENUM_DA_FEATURE_SUBSTATE_FAILURE'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_CRUISE_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_FAILURE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 3
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 1
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_Cruise

    Scenario:Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_CRUISE_ACTIVE' and 'ENUM_DA_FEATURE_SUBSTATE_READY_TO_ACTIVATE'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_CRUISE_ACTIVE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_READY_TO_ACTIVATE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 5
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 3
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_Cruise == TRUE

    Scenario:Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_CRUISE_ACTIVE' and 'ENUM_DA_FEATURE_SUBSTATE_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_CRUISE_ACTIVE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 4
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 2
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_Cruise

    Scenario: Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_CRUISE_ACTIVE' and 'ENUM_DA_FEATURE_SUBSTATE_FAILURE'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_CRUISE_ACTIVE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_FAILURE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 3
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 1
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_Cruise

    Scenario:Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_CRUISE_NOT_AVAILABLE' and 'ENUM_DA_FEATURE_SUBSTATE_READY_TO_ACTIVATE'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_CRUISE_NOT_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_READY_TO_ACTIVATE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 5
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 3
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_Cruise


    Scenario: Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_CRUISE_NOT_AVAILABLE' and 'ENUM_DA_FEATURE_SUBSTATE_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_CRUISE_NOT_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 4
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 2
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_Cruise

    Scenario: Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_CRUISE_NOT_AVAILABLE' and 'ENUM_DA_FEATURE_SUBSTATE_FAILURE'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_CRUISE_NOT_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_FAILURE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 3
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 1
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_Cruise

    Scenario: Check Cruise Mode Carousel is not updated when 'ENUM_STATE_DUTY'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_CRUISE_NOT_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_FAILURE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 3
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 1
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_Cruise
    
    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_STATE_DUTY'
        When NotifyVLCAState.vlca_state = "ENUM_VLCA_STATE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_mode = "ENUM_VEHICLE_MODE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_state = "ENUM_VEHICLE_STATE_DUTY"
        When Send notify NotifyVLCAState
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_VEHICLE_STATE_DUTY' 

    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_RUNNING'
        When NotifyVLCAState.vlca_state = "ENUM_VLCA_STATE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_mode = "ENUM_VEHICLE_MODE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_state = "ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL"
        When Send notify NotifyVLCAState
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_VEHICLE_RUNNING' 


    Scenario: Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_CRUISE_AVAILABLE' and 'ENUM_DA_FEATURE_SUBSTATE_NORMAL'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_CRUISE_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_NORMAL' 
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 2
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 0
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_Cruise

    Scenario: Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_CRUISE_ACTIVE' and 'ENUM_DA_FEATURE_SUBSTATE_COUNTRY_NOT_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_CRUISE_ACTIVE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_COUNTRY_NOT_AVAILABLE' 
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 3
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 0
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_Cruise

    Scenario: Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_CRUISE_NOT_AVAILABLE' and 'ENUM_DA_FEATURE_SUBSTATE_SENSOR_BLOCKED'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_CRUISE_NOT_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_SENSOR_BLOCKED' 
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 4
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 0
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_Cruise
    
    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_SLEEP'
        When NotifyVLCAState.vlca_state = "ENUM_VLCA_STATE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_mode = "ENUM_VEHICLE_MODE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_state = "ENUM_VEHICLE_STATE_SLEEP"
        When Send notify NotifyVLCAState
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_VEHICLE_SLEEP' 

    Scenario:Check Cruise Mode Carousel is updated when 'ENUM_STATE_SLEEP'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_CRUISE_ACTIVE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 4
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 2
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_Cruise
    
    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_RUNNING'
        When NotifyVLCAState.vlca_state = "ENUM_VLCA_STATE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_mode = "ENUM_VEHICLE_MODE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_state = "ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL"
        When Send notify NotifyVLCAState
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_VEHICLE_RUNNING' 

    Scenario: Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_CRUISE_AVAILABLE' and 'ENUM_DA_FEATURE_SUBSTATE_READY_TO_ACTIVATE'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_CRUISE_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_READY_TO_ACTIVATE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 0
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 5
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_Cruise

    Scenario: Check Cruise Mode Carousel is not updated when status = 'ENUM_STATUS_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_Cruise

    Scenario: # Check Cruise Mode Carousel is not updated when status = 'ENUM_STATUS_DATA_DEGRADED'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_DATA_DEGRADED'
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_Cruise 



    

    



    
