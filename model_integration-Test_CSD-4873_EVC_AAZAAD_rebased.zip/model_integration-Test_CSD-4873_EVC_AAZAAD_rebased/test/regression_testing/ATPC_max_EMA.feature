Feature:
    Scenario: Start server/clients
        When Start server for lifecycle_cccmuserapps_vlca_service
        And Start server for motion_service
        And Start server for featureconfig_cccmuserapps_service
    
    Scenario: Set Vehicle_State = 'ENUM_STATE_RUNNING'
        Given Receive request GetVLCAStateRequest
        When GetVLCAStateResponse.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When GetVLCAStateResponse.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When GetVLCAStateResponse.vehicle_state = 'ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL'
        When Send response GetVLCAStateResponse
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_STATE_RUNNING' 

    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 295}]
        When GetParamResponse.status = 'ENUM_STATUS_CCF_OK'
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 295, "value" : 66} ]
        When Send response GetParamResponse
        Then HMI shows: Screenshot 

    Scenario:
        When NotifyATPCMode.status = 'ENUM_STATUS_OK'
        And NotifyHDCMode.status = 'ENUM_STATUS_OK'
        And NotifyATPCMode.atpc_indicate_colour = 'ENUM_OFFROAD_DRIVERASSISTANCE_INDICATION_HDC_COLOUR_3'
        And NotifyHDCMode.hdc_indicate_colour = 'ENUM_OFFROAD_DRIVERASSISTANCE_INDICATION_HDC_COLOUR_3'
        And NotifyATPCMode.atpc_set_speed_value = 15000 
        And NotifyHDCMode.hdc_set_speed_value = 15000
        And Send notify NotifyATPCMode 
        And Send notify NotifyHDCMode 
        Then HMI shows: Screenshot 

    Scenario:
        When NotifyATPCMode.atpc_indicate_colour = 'ENUM_OFFROAD_DRIVERASSISTANCE_INDICATION_HDC_COLOUR_3'
        And NotifyHDCMode.hdc_indicate_colour = 'ENUM_OFFROAD_DRIVERASSISTANCE_INDICATION_HDC_COLOUR_3'
        And NotifyATPCMode.atpc_set_speed_value = 15000 
        And NotifyHDCMode.hdc_set_speed_value = 15000
        And Send notify NotifyATPCMode 
        And Send notify NotifyHDCMode 
        Then HMI shows: Screenshot 

    Scenario:
        When NotifyATPCMode.atpc_indicate_colour = 'ENUM_OFFROAD_DRIVERASSISTANCE_INDICATION_ATPC_DESCENT_CONTROL_COLOUR_1'
        And NotifyHDCMode.hdc_indicate_colour = 'ENUM_OFFROAD_DRIVERASSISTANCE_INDICATION_ATPC_DESCENT_CONTROL_COLOUR_1'
        And NotifyATPCMode.atpc_set_speed_value = 5000
        And NotifyHDCMode.hdc_set_speed_value = 5000
        And Send notify NotifyATPCMode 
        And Send notify NotifyHDCMode 
        Then HMI shows: Screenshot 

    Scenario:
        When NotifyATPCMode.atpc_indicate_colour = 'ENUM_OFFROAD_DRIVERASSISTANCE_INDICATION_HDC_COLOUR_3' 
        And NotifyHDCMode.hdc_indicate_colour = 'ENUM_OFFROAD_DRIVERASSISTANCE_INDICATION_HDC_COLOUR_3' 
        And NotifyATPCMode.atpc_set_speed_value = 5000
        And NotifyHDCMode.hdc_set_speed_value = 5000
        And Send notify NotifyATPCMode 
        And Send notify NotifyHDCMode 
        Then HMI shows: Screenshot 

    Scenario:
        When NotifyATPCMode.atpc_set_speed_value = 64500
        And NotifyHDCMode.hdc_set_speed_value = 35000
        And Send notify NotifyATPCMode 
        And Send notify NotifyHDCMode 
        Then HMI shows: Screenshot 

    Scenario:
        When NotifyATPCMode.atpc_indicate_colour = 'ENUM_OFFROAD_DRIVERASSISTANCE_INDICATION_ATPC_FULL_FUNCTION_COLOUR_1'
        And NotifyHDCMode.hdc_indicate_colour = 'ENUM_OFFROAD_DRIVERASSISTANCE_INDICATION_ATPC_FULL_FUNCTION_COLOUR_1'
        And NotifyATPCMode.atpc_set_speed_value = 25000
        And NotifyHDCMode.hdc_set_speed_value = 25000
        And Send notify NotifyATPCMode 
        And Send notify NotifyHDCMode 
        Then HMI shows: Screenshot 

    Scenario:
        When NotifyATPCMode.atpc_set_speed_value = 61000
        And NotifyHDCMode.hdc_set_speed_value = 31000
        And Send notify NotifyATPCMode 
        And Send notify NotifyHDCMode 
        Then HMI shows: Screenshot 

    Scenario:
        When NotifyATPCMode.atpc_indicate_colour = 'ENUM_OFFROAD_DRIVERASSISTANCE_INDICATION_ATPC_FULL_FUNCTION_COLOUR_1'
        And NotifyHDCMode.hdc_indicate_colour = 'ENUM_OFFROAD_DRIVERASSISTANCE_INDICATION_ATPC_FULL_FUNCTION_COLOUR_1'
        And NotifyATPCMode.atpc_set_speed_value = 3000
        And NotifyHDCMode.hdc_set_speed_value = 3000
        And Send notify NotifyATPCMode 
        And Send notify NotifyHDCMode 
        Then HMI shows: Screenshot 

    Scenario:
        When NotifyATPCMode.atpc_set_speed_value = 64000 
        And NotifyHDCMode.hdc_set_speed_value = 40000 
        And Send notify NotifyATPCMode 
        And Send notify NotifyHDCMode 
        Then HMI shows: Screenshot 
