Feature: Auto Engine Start Stop

    Scenario: Start server/clients
        When Start server for lifecycle_cccmuserapps_vlca_service
        And Start client for telltale_service1
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_OIL_LOW_PRESSURE'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON'
        When SetIndicatorRequest is sent

    Scenario: 
        When GetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_OIL_LOW_PRESSURE'
        When GetIndicatorRequest is sent
        Then HMI shows: DI_GUI.telltaleService1.bOilPressureLowInd_IsOn == TRUE 
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_OIL_LOW_PRESSURE'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetIndicatorRequest is sent

    Scenario: 
        When GetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_OIL_LOW_PRESSURE'
        When GetIndicatorRequest is sent
        Then HMI shows: DI_GUI.telltaleService1.bOilPressureLowInd_IsOn == FALSE 
    

    
