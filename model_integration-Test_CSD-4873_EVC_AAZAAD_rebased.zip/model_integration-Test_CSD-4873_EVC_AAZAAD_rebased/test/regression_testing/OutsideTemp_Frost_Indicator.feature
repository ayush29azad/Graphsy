
Feature: OutsideTemp and Frost Indicator
    Scenario: Start server/clients
            When Start server for lifecycle_cccmuserapps_vlca_service
            And Start server for climate_service
            And Start server for cockpit_settings_service

    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL'
        When NotifyVLCAState.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_state = 'ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL'
        When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_NOT_OK'
        When NotifyTemperatureUnitsStatus.temperature_units = 'ENUM_TEMPERATURE_UNITS_CELSIUS'
        When Send notify NotifyVLCAState
        When NotifyTemperatureUnitsStatus is sent
        Then HMI shows: HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL' 

    Scenario:
        When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureUnitsStatus.temperature_units = 'ENUM_TEMPERATURE_UNITS_UNSPECIFIED'
        When NotifyTemperatureUnitsStatus is sent

    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_STATE_SLEEP'
        When NotifyVLCAState.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_state = 'ENUM_VEHICLE_STATE_SLEEP'
        When Send notify NotifyVLCAState
        Then HMI shows: DI_GUI.outsideTempFrostInd.eOutsideAirTemp_Units == 'OUTSIDETEMP_UNITS_UNSPECIFIED' iOutsideAirTemp_Value == 263 bFrostIndicator_IsOn == FALSE

    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_STATE_COMFORT'
        When NotifyVLCAState.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_state = 'ENUM_VEHICLE_STATE_COMFORT'
        When Send notify NotifyVLCAState
        Then HMI shows: DI_GUI.outsideTempFrostInd.eOutsideAirTemp_Units == 'OUTSIDETEMP_UNITS_UNSPECIFIED' iOutsideAirTemp_Value == 263 bFrostIndicator_IsOn == FALSE
    Scenario:
        When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureUnitsStatus.temperature_units = 'ENUM_TEMPERATURE_UNITS_CELSIUS'
        When NotifyTemperatureUnitsStatus is sent
        Then HMI shows: DI_GUI.outsideTempFrostInd.eOutsideAirTemp_Units == 'OUTSIDETEMP_UNITS_CELSIUS' iOutsideAirTemp_Value == 263 bFrostIndicator_IsOn == FALSE

    Scenario:
        When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureUnitsStatus.temperature_units = 'ENUM_TEMPERATURE_UNITS_CELSIUS'
        When NotifyOutsideTemp.status = 'ENUM_STATUS_OK'
        When NotifyOutsideTemp.outsidetemp = 4.6 
        When NotifyTemperatureUnitsStatus is sent
        When NotifyOutsideTemp is sent
        Then HMI shows: DI_GUI.outsideTempFrostInd.eOutsideAirTemp_Units == 'OUTSIDETEMP_UNITS_CELSIUS' iOutsideAirTemp_Value == 5 bFrostIndicator_IsOn == FALSE
    Scenario:
        When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureUnitsStatus.temperature_units = 'ENUM_TEMPERATURE_UNITS_CELSIUS'
        When NotifyOutsideTemp.status = 'ENUM_STATUS_OK'
        When NotifyOutsideTemp.outsidetemp = 4.4
        When NotifyTemperatureUnitsStatus is sent
        When NotifyOutsideTemp is sent
        Then HMI shows: DI_GUI.outsideTempFrostInd.eOutsideAirTemp_Units == 'OUTSIDETEMP_UNITS_CELSIUS' iOutsideAirTemp_Value == 4 bFrostIndicator_IsOn == TRUE

    Scenario:
        When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureUnitsStatus.temperature_units = 'ENUM_TEMPERATURE_UNITS_CELSIUS'
        When NotifyOutsideTemp.status = 'ENUM_STATUS_OK'
        When NotifyOutsideTemp.outsidetemp = 4.5
        When NotifyTemperatureUnitsStatus is sent
        When NotifyOutsideTemp is sent
        Then HMI shows: DI_GUI.outsideTempFrostInd.eOutsideAirTemp_Units == 'OUTSIDETEMP_UNITS_CELSIUS' iOutsideAirTemp_Value == 5 bFrostIndicator_IsOn == TRUE

    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_STATE_DUTY'
        When NotifyVLCAState.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_state = 'ENUM_VEHICLE_STATE_DUTY'
        When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureUnitsStatus.temperature_units = 'ENUM_TEMPERATURE_UNITS_CELSIUS'
        When NotifyOutsideTemp.status = 'ENUM_STATUS_OK'
        When NotifyOutsideTemp.outsidetemp = 4.5
        When Send notify NotifyVLCAState
        When NotifyTemperatureUnitsStatus is sent
        When NotifyOutsideTemp is sent
        Then HMI shows: DI_GUI.outsideTempFrostInd.eOutsideAirTemp_Units == 'OUTSIDETEMP_UNITS_UNSPECIFIED' iOutsideAirTemp_Value == 263 bFrostIndicator_IsOn == TRUE

    # Test 10
    # DEFL_VEHICLE_STATE = 'ENUM_STATE_RUNNING'
    # DEFL_OUTSIDETEMP_UNITS = 'OUTSIDETEMP_UNITS_CELSIUS'
    # DEFL_OUTSIDETEMP_VALUE = 4.5
    Scenario:
        When NotifyVLCAState.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_state = 'ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL'
        When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureUnitsStatus.temperature_units = 'ENUM_TEMPERATURE_UNITS_CELSIUS'
        When NotifyOutsideTemp.status = 'ENUM_STATUS_OK'
        When NotifyOutsideTemp.outsidetemp = 4.5
        When Send notify NotifyVLCAState
        When NotifyTemperatureUnitsStatus is sent
        When NotifyOutsideTemp is sent


    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_STATE_COMFORT'
        When NotifyVLCAState.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_state = 'ENUM_VEHICLE_STATE_COMFORT'
        When NotifyOutsideTemp.status = 'ENUM_STATUS_OK'
        When NotifyOutsideTemp.outsidetemp = 4.5
        When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureUnitsStatus.temperature_units = 'ENUM_TEMPERATURE_UNITS_CELSIUS'
        When Send notify NotifyVLCAState
        When NotifyTemperatureUnitsStatus is sent
        When NotifyOutsideTemp is sent
        Then HMI shows: DI_GUI.outsideTempFrostInd.eOutsideAirTemp_Units == 'OUTSIDETEMP_UNITS_CELSIUS' iOutsideAirTemp_Value == 5 bFrostIndicator_IsOn == TRUE

    # Test 11
    # DEFL_VEHICLE_STATE = 'ENUM_STATE_RUNNING'
    # DEFL_OUTSIDETEMP_UNITS = 'OUTSIDETEMP_UNITS_FAHRENHEIT'
    # DEFL_OUTSIDETEMP_VALUE = 40.1

    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL'
        When NotifyVLCAState.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_state = 'ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL'
        When NotifyOutsideTemp.status = 'ENUM_STATUS_OK'
        When NotifyOutsideTemp.outsidetemp = 4.5
        When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureUnitsStatus.temperature_units = 'ENUM_TEMPERATURE_UNITS_FAHRENHEIT'
        When Send notify NotifyVLCAState
        When NotifyOutsideTemp is sent
        When NotifyTemperatureUnitsStatus is sent
        Then HMI shows: DI_GUI.outsideTempFrostInd.eOutsideAirTemp_Units == 'OUTSIDETEMP_UNITS_FAHRENHEIT' iOutsideAirTemp_Value == 40 bFrostIndicator_IsOn == TRUE

    # Test 12
    # DEFL_VEHICLE_STATE = 'ENUM_STATE_RUNNING'
    # DEFL_OUTSIDETEMP_UNITS = 'OUTSIDETEMP_UNITS_FAHRENHEIT'
    # DEFL_OUTSIDETEMP_VALUE = 40.28
    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL'
        When NotifyVLCAState.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_state = 'ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL'
        When NotifyOutsideTemp.status = 'ENUM_STATUS_OK'
        When NotifyOutsideTemp.outsidetemp = 4.6
        When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureUnitsStatus.temperature_units = 'ENUM_TEMPERATURE_UNITS_FAHRENHEIT'
        When NotifyTemperatureUnitsStatus is sent
        When NotifyOutsideTemp is sent
        When Send notify NotifyVLCAState
        Then HMI shows: DI_GUI.outsideTempFrostInd.eOutsideAirTemp_Units == 'OUTSIDETEMP_UNITS_FAHRENHEIT' iOutsideAirTemp_Value == 40 bFrostIndicator_IsOn == FALSE

    # Test 13
    # DEFL_VEHICLE_STATE = 'ENUM_STATE_RUNNING'
    # DEFL_OUTSIDETEMP_UNITS = 'OUTSIDETEMP_UNITS_FAHRENHEIT'
    # DEFL_OUTSIDETEMP_VALUE = 127.5
    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL'
        When NotifyVLCAState.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_state = 'ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL'
        When NotifyOutsideTemp.status = 'ENUM_STATUS_OK'
        When NotifyOutsideTemp.outsidetemp = 127.5
        When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureUnitsStatus.temperature_units = 'ENUM_TEMPERATURE_UNITS_FAHRENHEIT'
        When Send notify NotifyVLCAState
        When NotifyTemperatureUnitsStatus is sent
        When NotifyOutsideTemp is sent

    # Test 14
    # DEFL_VEHICLE_STATE = 'ENUM_STATE_RUNNING'
    # DEFL_OUTSIDETEMP_UNITS = 'OUTSIDETEMP_UNITS_FAHRENHEIT'
    # DEFL_OUTSIDETEMP_VALUE = -127.6

    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL'
        When NotifyVLCAState.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_state = 'ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL'
        When NotifyOutsideTemp.status = 'ENUM_STATUS_OK'
        When NotifyOutsideTemp.outsidetemp = -127.6
        When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureUnitsStatus.temperature_units = 'ENUM_TEMPERATURE_UNITS_FAHRENHEIT'
        When Send notify NotifyVLCAState
        When NotifyTemperatureUnitsStatus is sent
        When NotifyOutsideTemp is sent
        Then HMI shows: DI_GUI.outsideTempFrostInd.eOutsideAirTemp_Units == 'OUTSIDETEMP_UNITS_FAHRENHEIT' iOutsideAirTemp_Value == -198 bFrostIndicator_IsOn == TRUE

    # Test 15
    # DEFL_VEHICLE_STATE = 'ENUM_STATE_RUNNING'
    # DEFL_OUTSIDETEMP_UNITS = 'OUTSIDETEMP_UNITS_FAHRENHEIT'
    # DEFL_OUTSIDETEMP_VALUE = 128.2

    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL'
        When NotifyVLCAState.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_state = 'ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL'
        When NotifyOutsideTemp.status = 'ENUM_STATUS_OK'
        When NotifyOutsideTemp.outsidetemp = 128.2
        When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureUnitsStatus.temperature_units = 'ENUM_TEMPERATURE_UNITS_FAHRENHEIT'
        When Send notify NotifyVLCAState
        When NotifyTemperatureUnitsStatus is sent
        When NotifyOutsideTemp is sent

    # Test 16
    # DEFL_VEHICLE_STATE = 'ENUM_STATE_RUNNING'
    # DEFL_OUTSIDETEMP_UNITS = 'OUTSIDETEMP_UNITS_UNSPECIFIED'
    # DEFL_OUTSIDETEMP_VALUE = 128.2

    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL'
        When NotifyVLCAState.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_state = 'ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL'
        When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureUnitsStatus.temperature_units = 'ENUM_TEMPERATURE_UNITS_UNSPECIFIED'
        When Send notify NotifyVLCAState
        When NotifyTemperatureUnitsStatus is sent
