        
    
Feature: SideLight Indicator 
    Scenario: Start server/clients
        When Start server for exterior_lighting_service

    Scenario:
        When NotifyExtLightIndicatorStatus.status = 'ENUM_STATUS_OK'
        When NotifyExtLightIndicatorStatus.side_light_status = 'ENUM_SIDE_LIGHT_STATUS_OFF'
        When NotifyExtLightIndicatorStatus is sent
        Then HMI Shows: DI_GUI.indExtLights.bSideLights_IsOn == FALSE

    Scenario:Check ON value when the ENUM_SIDE_LIGHT_STATUS_ON
        When NotifyExtLightIndicatorStatus.status = 'ENUM_STATUS_OK'
        When NotifyExtLightIndicatorStatus.side_light_status = 'ENUM_SIDE_LIGHT_STATUS_ON'
        When NotifyExtLightIndicatorStatus is sent
        Then HMI Shows: DI_GUI.indExtLights.bSideLights_IsOn == TRUE

    Scenario:Check OFF when the ENUM_SIDE_LIGHT_STATUS_OFF
        When NotifyExtLightIndicatorStatus.status = 'ENUM_STATUS_OK'
        When NotifyExtLightIndicatorStatus.side_light_status = 'ENUM_SIDE_LIGHT_STATUS_OFF'
        When NotifyExtLightIndicatorStatus is sent
        Then HMI Shows: DI_GUI.indExtLights.bSideLights_IsOn == FALSE
    
    Scenario:Check ON value when the ENUM_SIDE_LIGHT_STATUS_ON
        When NotifyExtLightIndicatorStatus.status = 'ENUM_STATUS_OK'
        When NotifyExtLightIndicatorStatus.side_light_status = 'ENUM_SIDE_LIGHT_STATUS_ON'
        When NotifyExtLightIndicatorStatus is sent
        Then HMI Shows: DI_GUI.indExtLights.bSideLights_IsOn == TRUE
    
    Scenario:Check OFF when the ENUM_SIDE_LIGHT_STATUS_OFF
        When NotifyExtLightIndicatorStatus.status = 'ENUM_STATUS_OK'
        When NotifyExtLightIndicatorStatus.side_light_status = 'ENUM_SIDE_LIGHT_STATUS_OFF'
        When NotifyExtLightIndicatorStatus is sent
        Then HMI Shows: DI_GUI.indExtLights.bSideLights_IsOn == FALSE
