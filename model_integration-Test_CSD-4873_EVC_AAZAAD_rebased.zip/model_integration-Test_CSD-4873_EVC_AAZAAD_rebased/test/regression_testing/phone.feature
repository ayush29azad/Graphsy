    
Feature:
    Scenario: Start server/clients
        When Start server for lifecycle_cccmuserapps_vlca_service
        And Start server for infotainment_metadata_service 

    Scenario: 
        When NotifyTelephonyMetaDataInfo.status = 'ENUM_STATUS_OK'
        When NotifyTelephonyMetaDataInfo.primary_telephony_text = "Declined"
        When NotifyTelephonyMetaDataInfo.telephony_event_type = 'ENUM_PHONE_EVENT_CALL_NOT_IN_PROGRESS'
        When NotifyTelephonyMetaDataInfo.image_id = ["image_0"]
        When NotifyTelephonyMetaDataInfo is sent
        Then HMI shows: DI_GUI.transPhone.vTransPhone == True DI_GUI.transPhone.sTransPhonePrimaryText == "Declined" DI_GUI.transPhone.eTransPhoneEventType == 'ENUM_PHONE_EVENT_CALL_NOT_IN_PROGRESS'

    Scenario: 
        When NotifyTelephonyMetaDataInfo.status = 'ENUM_STATUS_OK'  
        When NotifyTelephonyMetaDataInfo.primary_telephony_text = "Call Ended"
        When NotifyTelephonyMetaDataInfo.image_id = ["image_1"]
        When NotifyTelephonyMetaDataInfo is sent
        Then HMI shows: DI_GUI.transPhone.vTransPhone == True DI_GUI.transPhone.sTransPhonePrimaryText == "Call Ended" DI_GUI.transPhone.eTransPhoneEventType == 'ENUM_PHONE_EVENT_CALL_NOT_IN_PROGRESS'DI_GUI.transPhone.eTransPhoneState == 'ENUM_PHONE_CALL_ENDED'

    Scenario: 
        When NotifyTelephonyMetaDataInfo.status = 'ENUM_STATUS_NOT_OK'  
        When NotifyTelephonyMetaDataInfo.primary_telephony_text = "Others"
        When NotifyTelephonyMetaDataInfo.image_id = ["image_2"]
        When NotifyTelephonyMetaDataInfo is sent
    
    Scenario: 
        When NotifyVLCAState.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_state = 'ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL'
        When Send notify NotifyVLCAState
        When NotifyTelephonyMetaDataInfo.status = 'ENUM_STATUS_OK' 
        When NotifyTelephonyMetaDataInfo.primary_telephony_text = "pulkit"
        When NotifyTelephonyMetaDataInfo.secondary_telephony_text = "8105223677"
        When NotifyTelephonyMetaDataInfo.image_id = ["image_3"]
        When NotifyTelephonyMetaDataInfo is sent
    Scenario: 
        When NotifyVLCAState.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_state = 'ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL'
        When Send notify NotifyVLCAState
        When NotifyTelephonyMetaDataInfo.status = 'ENUM_STATUS_OK' 
        When NotifyTelephonyMetaDataInfo.primary_telephony_text = "Others"
        When NotifyTelephonyMetaDataInfo.secondary_telephony_text = "Home"
        When NotifyTelephonyMetaDataInfo.image_id = ["image_3"]
        When NotifyTelephonyMetaDataInfo is sent
        Then HMI shows: DI_GUI.transPhone.vTransPhone == True DI_GUI.transPhone.sTransPhoneSecondaryText == "Home" DI_GUI.transPhone.eTransPhoneCallerType == 'ENUM_PHONE_CALLER_TYPE_HOME'

    Scenario: 
        When NotifyTelephonyMetaDataInfo.status = 'ENUM_STATUS_OK' 
        When NotifyTelephonyMetaDataInfo.primary_telephony_text = "Others"
        When NotifyTelephonyMetaDataInfo.secondary_telephony_text = "Mobile"
        When NotifyTelephonyMetaDataInfo is sent
        Then HMI shows: DI_GUI.transPhone.vTransPhone == True DI_GUI.transPhone.sTransPhoneSecondaryText == "Mobile" DI_GUI.transPhone.eTransPhoneCallerType == 'ENUM_PHONE_CALLER_TYPE_MOBILE'

    Scenario: 
    #DEFL_Phone_Secondary_Text != "Work" AND DEFL_Phone_Secondary_Text != "Home" AND DEFL_Phone_Secondary_Text != "Mobile"
    #Then HMI shows:  DEFL_Phone_Caller_Type = ENUM_PHONE_CALLER_TYPE_OTHER
        When NotifyTelephonyMetaDataInfo.status = 'ENUM_STATUS_OK' 
        When NotifyTelephonyMetaDataInfo.primary_telephony_text = "Others"
        When NotifyTelephonyMetaDataInfo.secondary_telephony_text = "Demo1"
        When NotifyTelephonyMetaDataInfo.image_id = ["image_4"]
        When NotifyTelephonyMetaDataInfo is sent
        Then HMI shows: DI_GUI.transPhone.vTransPhone == True DI_GUI.transPhone.sTransPhoneSecondaryText ==  "Demo1" DI_GUI.transPhone.eTransPhoneCallerType == 'ENUM_PHONE_CALLER_TYPE_OTHER'

    Scenario: 
        When NotifyTelephonyMetaDataInfo.status = 'ENUM_STATUS_OK' 
        When NotifyTelephonyMetaDataInfo.primary_telephony_text = "Others"
        When NotifyTelephonyMetaDataInfo.secondary_telephony_text = "Work"
        When NotifyTelephonyMetaDataInfo.image_id = ["image_5"]
        When NotifyTelephonyMetaDataInfo is sent
        Then HMI shows: DI_GUI.transPhone.vTransPhone == True DI_GUI.transPhone.sTransPhoneSecondaryText ==  "Work" DI_GUI.transPhone.eTransPhoneCallerType == 'ENUM_PHONE_CALLER_TYPE_WORK'

    Scenario: 
        When NotifyTelephonyMetaDataInfo.status = 'ENUM_STATUS_OK' 
        When NotifyTelephonyMetaDataInfo.primary_telephony_text = "Others"
        When NotifyTelephonyMetaDataInfo.secondary_telephony_text = "Work"
        When NotifyTelephonyMetaDataInfo.is_mute = True
        When NotifyTelephonyMetaDataInfo.is_hold = False
        When NotifyTelephonyMetaDataInfo.is_handset = False
        When NotifyTelephonyMetaDataInfo.image_id = ["image_6"]
        When NotifyTelephonyMetaDataInfo is sent
        Then HMI shows: DI_GUI.transPhone.vTransPhone == True DI_GUI.transPhone.eTransPhoneState == 'ENUM_PHONE_MUTE'

    Scenario:
        When NotifyTelephonyMetaDataInfo.status = 'ENUM_STATUS_OK' 
        When NotifyTelephonyMetaDataInfo.primary_telephony_text = "Others"
        When NotifyTelephonyMetaDataInfo.secondary_telephony_text = "Work"
        When NotifyTelephonyMetaDataInfo.is_mute = False
        When NotifyTelephonyMetaDataInfo.is_hold = True
        When NotifyTelephonyMetaDataInfo.is_handset = False
        When NotifyTelephonyMetaDataInfo.image_id = ["image_0"]
        When NotifyTelephonyMetaDataInfo is sent
        Then HMI shows: DI_GUI.transPhone.vTransPhone == True DI_GUI.transPhone.eTransPhoneState == 'ENUM_PHONE_HOLD'

    Scenario:
        When NotifyTelephonyMetaDataInfo.status = 'ENUM_STATUS_OK' 
        When NotifyTelephonyMetaDataInfo.primary_telephony_text = "Others"
        When NotifyTelephonyMetaDataInfo.secondary_telephony_text = "Work"
        When NotifyTelephonyMetaDataInfo.is_mute = False
        When NotifyTelephonyMetaDataInfo.is_hold = False
        When NotifyTelephonyMetaDataInfo.is_handset = True
        When NotifyTelephonyMetaDataInfo.image_id = ["image_1"]
        When NotifyTelephonyMetaDataInfo is sent
        Then HMI shows: DI_GUI.transPhone.vTransPhone == True DI_GUI.transPhone.eTransPhoneState == 'ENUM_PHONE_HANDSET'

    Scenario:
        When NotifyTelephonyMetaDataInfo.status = 'ENUM_STATUS_OK'
        When NotifyTelephonyMetaDataInfo.primary_telephony_text = "Declined"
        When NotifyTelephonyMetaDataInfo.secondary_telephony_text = "Work"
        When NotifyTelephonyMetaDataInfo.telephony_event_type = 'ENUM_PHONE_EVENT_CALL_NOT_IN_PROGRESS'
        When NotifyTelephonyMetaDataInfo.is_mute = False
        When NotifyTelephonyMetaDataInfo.is_hold = False
        When NotifyTelephonyMetaDataInfo.is_handset = False
        When NotifyTelephonyMetaDataInfo.image_id = ["image_2"]
        When NotifyTelephonyMetaDataInfo is sent
        Then HMI shows: DI_GUI.transPhone.vTransPhone == True sTransPhonePrimaryText == "Declined" eTransPhoneEventType == 'ENUM_PHONE_EVENT_CALL_NOT_IN_PROGRESS' eTransPhoneState == 'ENUM_PHONE_DECLINED'

    Scenario: 12
        When NotifyTelephonyMetaDataInfo.status = 'ENUM_STATUS_OK'  
        When NotifyTelephonyMetaDataInfo.primary_telephony_text = "Call Ended"
        When NotifyTelephonyMetaDataInfo.secondary_telephony_text = "Work"
        When NotifyTelephonyMetaDataInfo.telephony_event_type = 'ENUM_PHONE_EVENT_CALL_NOT_IN_PROGRESS'
        When NotifyTelephonyMetaDataInfo.is_mute = False
        When NotifyTelephonyMetaDataInfo.is_hold = False
        When NotifyTelephonyMetaDataInfo.is_handset = False
        When NotifyTelephonyMetaDataInfo.image_id = ["image_3"]
        When NotifyTelephonyMetaDataInfo is sent
        Then HMI shows: DI_GUI.transPhone.vTransPhone == True sTransPhonePrimaryText == "Call Ended" transPhone.eTransPhoneEventType == 'ENUM_PHONE_EVENT_CALL_NOT_IN_PROGRESS' transPhone.eTransPhoneState == 'ENUM_PHONE_CALL_ENDED'

    Scenario:-13
        #DEFL_Metadata_Image_Id = NotifyTelephonyMetaDataInfo.image_id
        When NotifyTelephonyMetaDataInfo.status = 'ENUM_STATUS_OK' 
        When NotifyTelephonyMetaDataInfo.primary_telephony_text = "Call Ended"
        When NotifyTelephonyMetaDataInfo.secondary_telephony_text = "Work"
        When NotifyTelephonyMetaDataInfo.telephony_event_type = 'ENUM_PHONE_EVENT_CALL_NOT_IN_PROGRESS'
        When NotifyTelephonyMetaDataInfo.is_mute = False
        When NotifyTelephonyMetaDataInfo.is_hold = False
        When NotifyTelephonyMetaDataInfo.is_handset = False
        When NotifyTelephonyMetaDataInfo.image_id = ["image_4"]
        When NotifyTelephonyMetaDataInfo.attendee_count = 1
        When NotifyTelephonyMetaDataInfo is sent
        Then HMI shows: DI_GUI.transPhone.iTransPhoneAttendeeCount == 1 sTransPhoneImageId == "2bdf3625-4354-4eb4-b913-05335a385407"

    Scenario:-14
        #Info.status = 'ENUM_STATUS_NOT_OK' - DEFL_Metadata_Image_Id shall be set to a string data type that contain no charcaters.
        When NotifyTelephonyMetaDataInfo.status = 'ENUM_STATUS_NOT_OK' 
        When NotifyTelephonyMetaDataInfo.primary_telephony_text = "Call Ended"
        When NotifyTelephonyMetaDataInfo.secondary_telephony_text = "Work"
        When NotifyTelephonyMetaDataInfo.telephony_event_type = 'ENUM_PHONE_EVENT_CALL_NOT_IN_PROGRESS'
        When NotifyTelephonyMetaDataInfo.is_mute = False
        When NotifyTelephonyMetaDataInfo.is_hold = False
        When NotifyTelephonyMetaDataInfo.is_handset = False
        When NotifyTelephonyMetaDataInfo.image_id = ["image_5"]
        When NotifyTelephonyMetaDataInfo is sent

    Scenario:-15 Service unavailable 
        When NotifyTelephonyMetaDataInfo.status = 'ENUM_STATUS_OK' 
        When NotifyTelephonyMetaDataInfo.secondary_telephony_text = "Home"
        When NotifyTelephonyMetaDataInfo.primary_telephony_text = "Call Ended"
        When NotifyTelephonyMetaDataInfo.telephony_event_type = 'ENUM_PHONE_EVENT_CALL_NOT_IN_PROGRESS'
        When NotifyTelephonyMetaDataInfo.is_mute = False
        When NotifyTelephonyMetaDataInfo.is_hold = False
        When NotifyTelephonyMetaDataInfo.is_handset = False
        When NotifyTelephonyMetaDataInfo.image_id = ["image_6"]
        When NotifyTelephonyMetaDataInfo is sent
        Then HMI shows: DI_GUI.transPhone.vTransPhone == True sTransPhoneSecondaryText == "Home" eTransPhoneCallerType == 'ENUM_PHONE_CALLER_TYPE_OTHER' eTransPhoneState == 'ENUM_PHONE_UNSPECIFIED'

    Scenario:-16 Service available
        When NotifyVLCAState.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_state = 'ENUM_VEHICLE_STATE_COMFORT'
        When Send notify NotifyVLCAState
        When NotifyTelephonyMetaDataInfo.status = 'ENUM_STATUS_OK'
        When NotifyTelephonyMetaDataInfo.primary_telephony_text = "Declined"
        When NotifyTelephonyMetaDataInfo.telephony_event_type = 'ENUM_PHONE_EVENT_CALL_NOT_IN_PROGRESS'
        When NotifyTelephonyMetaDataInfo.image_id = ["image_0"]
        When NotifyTelephonyMetaDataInfo is sent

    Scenario:-17 To check if DDS topic is sent every 3 seconds when event is incoming call and call is not silenced
        When NotifyVLCAState.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_state = 'ENUM_VEHICLE_STATE_COMFORT'
        When Send notify NotifyVLCAState 
        When NotifyTelephonyMetaDataInfo.status = 'ENUM_STATUS_OK'
        When NotifyTelephonyMetaDataInfo.primary_telephony_text = "Caller"
        When NotifyTelephonyMetaDataInfo.secondary_telephony_text = "Home"
        When NotifyTelephonyMetaDataInfo.telephony_event_type = 'ENUM_PHONE_EVENT_CALL_INCOMING'
        When NotifyTelephonyMetaDataInfo.is_silenced = False
        When NotifyTelephonyMetaDataInfo.image_id = ["image_1"]
        When NotifyTelephonyMetaDataInfo is sent
        Then HMI shows: DI_GUI.transPhone.vTransPhone == True sTransPhonePrimaryText == "Caller" sTransPhoneSecondaryText == "Home" eTransPhoneEventType == 'ENUM_PHONE_EVENT_CALL_INCOMING' eTransPhoneState == 'ENUM_PHONE_UNSPECIFIED'

    Scenario:-18 To check if DDS topic is sent once when event is incoming call and call is silenced
        When NotifyVLCAState.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_state = 'ENUM_VEHICLE_STATE_COMFORT'
        When Send notify NotifyVLCAState
        When NotifyTelephonyMetaDataInfo.status = 'ENUM_STATUS_OK'
        When NotifyTelephonyMetaDataInfo.primary_telephony_text = "Caller"
        When NotifyTelephonyMetaDataInfo.secondary_telephony_text = "Home"
        When NotifyTelephonyMetaDataInfo.telephony_event_type = 'ENUM_PHONE_EVENT_CALL_INCOMING'
        When NotifyTelephonyMetaDataInfo.image_id = ["image_2"]
        When NotifyTelephonyMetaDataInfo.is_silenced = True
        When NotifyTelephonyMetaDataInfo is sent
        Then HMI shows: DI_GUI.transPhone.vTransPhone == True DI_GUI.transPhone.sTransPhonePrimaryText == "Caller"

    Scenario:-19 To check if DDS topic is sent every 3 seconds when event is outgoing call 
        When NotifyVLCAState.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_state = 'ENUM_VEHICLE_STATE_COMFORT'
        When Send notify NotifyVLCAState
        When NotifyTelephonyMetaDataInfo.status = 'ENUM_STATUS_OK'
        When NotifyTelephonyMetaDataInfo.primary_telephony_text = "Caller"
        When NotifyTelephonyMetaDataInfo.secondary_telephony_text = "Home"
        When NotifyTelephonyMetaDataInfo.telephony_event_type = 'ENUM_PHONE_EVENT_CALL_OUTGOING'
        When NotifyTelephonyMetaDataInfo.image_id = ["image_3"]
        When NotifyTelephonyMetaDataInfo is sent
    
    #with Font Changes

    Scenario: 1
        #DEFL_Phone_Primary_Font_Id  & DEFL_Phone_Secondary_Font_Id 
        When NotifyVLCAState.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_state = 'ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL'
        When Send notify NotifyVLCAState  
        When NotifyTelephonyMetaDataInfo.status = 'ENUM_STATUS_OK'
        When NotifyTelephonyMetaDataInfo.primary_telephony_text = "呼叫者"
        When NotifyTelephonyMetaDataInfo.secondary_telephony_text = "家"
        When NotifyTelephonyMetaDataInfo.primary_telephony_font_id = 'ENUM_FONT_ID_PRC'
        When NotifyTelephonyMetaDataInfo.secondary_telephony_font_id = 'ENUM_FONT_ID_PRC'
        When NotifyTelephonyMetaDataInfo.image_id = ["image_4"]
        When NotifyTelephonyMetaDataInfo.telephony_event_type = 'ENUM_PHONE_EVENT_CALL_INCOMING'
        When NotifyTelephonyMetaDataInfo is sent
        Then HMI shows: DI_GUI.transPhone.eTransPrimaryPhoneFontId eTransSecondaryPhoneFontId == 'ENUM_FONT_ID_PRC'

    Scenario: 2
        #DEFL_Phone_Primary_Font_Id  & DEFL_Phone_Secondary_Font_Id 
        When NotifyTelephonyMetaDataInfo.status = 'ENUM_STATUS_OK' 
        When NotifyTelephonyMetaDataInfo.primary_telephony_text = "المتصل"
        When NotifyTelephonyMetaDataInfo.secondary_telephony_text = "بيت"
        When NotifyTelephonyMetaDataInfo.primary_telephony_font_id = 'ENUM_FONT_ID_ARABIC'
        When NotifyTelephonyMetaDataInfo.secondary_telephony_font_id = 'ENUM_FONT_ID_ARABIC'
        When NotifyTelephonyMetaDataInfo.image_id = ["image_5"]
        When NotifyTelephonyMetaDataInfo.telephony_event_type = 'ENUM_PHONE_EVENT_CALL_INCOMING'
        When NotifyTelephonyMetaDataInfo is sent
        Then HMI shows: DI_GUI.transPhone.eTransPrimaryPhoneFontId eTransSecondaryPhoneFontId  == 'ENUM_FONT_ID_ARABIC'

    Scenario: 3
        #DEFL_Phone_Primary_Font_Id  & DEFL_Phone_Secondary_Font_Id 
        When NotifyTelephonyMetaDataInfo.status = 'ENUM_STATUS_OK' 
        When NotifyTelephonyMetaDataInfo.primary_telephony_text = "打電話嚟嘅人"
        When NotifyTelephonyMetaDataInfo.secondary_telephony_text = "屋企"
        When NotifyTelephonyMetaDataInfo.primary_telephony_font_id = 'ENUM_FONT_ID_HKTW'
        When NotifyTelephonyMetaDataInfo.secondary_telephony_font_id = 'ENUM_FONT_ID_HKTW'
        When NotifyTelephonyMetaDataInfo.image_id = ["image_6"]
        When NotifyTelephonyMetaDataInfo.telephony_event_type = 'ENUM_PHONE_EVENT_CALL_INCOMING'
        When NotifyTelephonyMetaDataInfo is sent
        Then HMI shows: DI_GUI.transPhone.eTransPrimaryPhoneFontId eTransSecondaryPhoneFontId == 'ENUM_FONT_ID_HKTW'  

    Scenario: 4
        #DEFL_Phone_Primary_Font_Id  & DEFL_Phone_Secondary_Font_Id 
        When NotifyTelephonyMetaDataInfo.status = 'ENUM_STATUS_OK'
        When NotifyTelephonyMetaDataInfo.primary_telephony_text = "कोलर"
        When NotifyTelephonyMetaDataInfo.secondary_telephony_text = "घर" 
        When NotifyTelephonyMetaDataInfo.primary_telephony_font_id = 'ENUM_FONT_ID_INDIC'
        When NotifyTelephonyMetaDataInfo.secondary_telephony_font_id = 'ENUM_FONT_ID_INDIC'
        When NotifyTelephonyMetaDataInfo.image_id = ["image_0"]
        When NotifyTelephonyMetaDataInfo.telephony_event_type = 'ENUM_PHONE_EVENT_CALL_INCOMING'
        When NotifyTelephonyMetaDataInfo is sent
        Then HMI shows: DI_GUI.transPhone.eTransPrimaryPhoneFontId eTransSecondaryPhoneFontId == 'ENUM_FONT_ID_INDIC'

    Scenario: 5
        #DEFL_Phone_Primary_Font_Id  & DEFL_Phone_Secondary_Font_Id 
        When NotifyTelephonyMetaDataInfo.status = 'ENUM_STATUS_OK'
        When NotifyTelephonyMetaDataInfo.primary_telephony_text = "発信者"
        When NotifyTelephonyMetaDataInfo.secondary_telephony_text = "家" 
        When NotifyTelephonyMetaDataInfo.primary_telephony_font_id = 'ENUM_FONT_ID_JAPANESE'
        When NotifyTelephonyMetaDataInfo.secondary_telephony_font_id = 'ENUM_FONT_ID_JAPANESE'
        When NotifyTelephonyMetaDataInfo.image_id = ["image_1"]
        When NotifyTelephonyMetaDataInfo.telephony_event_type = 'ENUM_PHONE_EVENT_CALL_INCOMING'
        When NotifyTelephonyMetaDataInfo is sent
        Then HMI shows: DI_GUI.transPhone.eTransPrimaryPhoneFontId eTransSecondaryPhoneFontId == 'ENUM_FONT_ID_JAPANESE'

    Scenario: 6
        #DEFL_Phone_Primary_Font_Id  & DEFL_Phone_Secondary_Font_Id 
        When NotifyTelephonyMetaDataInfo.status = 'ENUM_STATUS_OK' 
        When NotifyTelephonyMetaDataInfo.primary_telephony_text = "방문객"
        When NotifyTelephonyMetaDataInfo.secondary_telephony_text = "집"
        When NotifyTelephonyMetaDataInfo.primary_telephony_font_id = 'ENUM_FONT_ID_KOREAN'
        When NotifyTelephonyMetaDataInfo.secondary_telephony_font_id = 'ENUM_FONT_ID_KOREAN'
        When NotifyTelephonyMetaDataInfo.image_id = ["image_2"]
        When NotifyTelephonyMetaDataInfo.telephony_event_type = 'ENUM_PHONE_EVENT_CALL_INCOMING'
        When NotifyTelephonyMetaDataInfo is sent
        Then HMI shows: DI_GUI.transPhone.eTransPrimaryPhoneFontId eTransSecondaryPhoneFontId == 'ENUM_FONT_ID_KOREAN'

    Scenario: 7
        #NotifyTelephonyMetaDataInfo.status = 'ENUM_STATUS_NOT_OK' - Requirement01162613
        When NotifyTelephonyMetaDataInfo.status = 'ENUM_STATUS_NOT_OK'
        When NotifyTelephonyMetaDataInfo.primary_telephony_text = "呼叫者"
        When NotifyTelephonyMetaDataInfo.secondary_telephony_text = "家" 
        When NotifyTelephonyMetaDataInfo.primary_telephony_font_id = 'ENUM_FONT_ID_PRC'
        When NotifyTelephonyMetaDataInfo.secondary_telephony_font_id = 'ENUM_FONT_ID_PRC'
        When NotifyTelephonyMetaDataInfo.image_id = ["image_3"]
        When NotifyTelephonyMetaDataInfo.telephony_event_type = 'ENUM_PHONE_EVENT_CALL_INCOMING'
        When NotifyTelephonyMetaDataInfo is sent

    Scenario: 8
        #eVehicle_State = 'ENUM_STATE_COMFORT' - Requirement01162613
        When NotifyVLCAState.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_state = 'ENUM_VEHICLE_STATE_COMFORT'
        When Send notify NotifyVLCAState  
        When NotifyTelephonyMetaDataInfo.status = 'ENUM_STATUS_OK'
        When NotifyTelephonyMetaDataInfo.primary_telephony_text = "呼叫者"
        When NotifyTelephonyMetaDataInfo.secondary_telephony_text = "家"
        When NotifyTelephonyMetaDataInfo.primary_telephony_font_id = 'ENUM_FONT_ID_PRC'
        When NotifyTelephonyMetaDataInfo.secondary_telephony_font_id = 'ENUM_FONT_ID_PRC'
        When NotifyTelephonyMetaDataInfo.image_id = ["image_4"]
        When NotifyTelephonyMetaDataInfo.telephony_event_type = 'ENUM_PHONE_EVENT_CALL_INCOMING'
        When NotifyTelephonyMetaDataInfo is sent
        Then HMI shows: DI_GUI.transPhone.eTransPrimaryPhoneFontId eTransSecondaryPhoneFontId== 'ENUM_FONT_ID_PRC'

    Scenario: 9
        #eVehicle_State = 'ENUM_STATE_DUTY' - Requirement01162613
        When NotifyVLCAState.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_state = 'ENUM_VEHICLE_STATE_DUTY'
        When Send notify NotifyVLCAState  
        When NotifyTelephonyMetaDataInfo.status = 'ENUM_STATUS_OK'
        When NotifyTelephonyMetaDataInfo.primary_telephony_text = "呼叫者"
        When NotifyTelephonyMetaDataInfo.secondary_telephony_text = "家"
        When NotifyTelephonyMetaDataInfo.primary_telephony_font_id = 'ENUM_FONT_ID_PRC'
        When NotifyTelephonyMetaDataInfo.secondary_telephony_font_id = 'ENUM_FONT_ID_PRC'
        When NotifyTelephonyMetaDataInfo.image_id = ["image_5"]
        When NotifyTelephonyMetaDataInfo.telephony_event_type = 'ENUM_PHONE_EVENT_CALL_INCOMING'
        When NotifyTelephonyMetaDataInfo is sent
