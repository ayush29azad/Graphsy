Feature:
    Scenario: Start server/clients
        When Start server for lifecycle_cccmuserapps_vlca_service
        And Start server for climate_service
        And Start server for cockpit_settings_service
        And Start server for featureconfig_cccmuserapps_service
        And Start server for display_control_service

    Scenario: Set Vehicle_State = 'ENUM_STATE_RUNNING'
        Given Receive request GetVLCAStateRequest
        When GetVLCAStateResponse.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When GetVLCAStateResponse.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When GetVLCAStateResponse.vehicle_state = 'ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL'
        When Send response GetVLCAStateResponse

    Scenario: 
        When NotifyCurrentSystemTheme.status = 'ENUM_STATUS_OK'
        When NotifyCurrentSystemTheme.current_system_theme = 'ENUM_CURRENT_THEME_LIGHT'
        When Send notify NotifyCurrentSystemTheme
    
    Scenario: 
        Given Receive request GetHUDStateRequest
        When GetHUDStateResponse.status = 'ENUM_STATUS_OK'
        When GetHUDStateResponse.hud_type = 'ENUM_HUDTYPE_DRIVER_HUD'
        When GetHUDStateResponse.hud_state = 'ENUM_HUD_STATE_ON'
        When GetHUDStateResponse is sent

     # Steering Position Left 
    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 551},{"mdf_id" : 33923}]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 551, "value" : 1},{"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 33923, "value" : 2}] 
        When Send response GetParamResponse
        When NotifyTemperatureStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyTemperatureStatus.temp_range = 13.5
        When NotifyTemperatureStatus is sent
        Then HMI shows: DI_GUI.transClimateTemperature 

    Scenario:
        When restart featureconfig_cccmuserapps_service
    
    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 551},{"mdf_id" : 33923}]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 551, "value" : 1},{"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 33923, "value" : 2}] 
        When Send response GetParamResponse
        When NotifyTemperatureStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyTemperatureStatus.temp_range = 13.5
        When NotifyTemperatureStatus is sent
        When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureUnitsStatus.temperature_units = 'ENUM_TEMPERATURE_UNITS_CELSIUS'
        When NotifyTemperatureUnitsStatus is sent
        Then HMI shows: DI_GUI.transClimateTemperature  

    Scenario:
        When restart featureconfig_cccmuserapps_service
    
    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 551},{"mdf_id" : 33923}]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 551, "value" : 1},{"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 33923, "value" : 3}] 
        When Send response GetParamResponse
        When NotifyTemperatureStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyTemperatureStatus.temp_range = 14.5
        When NotifyTemperatureStatus is sent
        When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureUnitsStatus.temperature_units = 'ENUM_TEMPERATURE_UNITS_CELSIUS'
        When NotifyTemperatureUnitsStatus is sent
        Then HMI shows: DI_GUI.transClimateTemperature 
    
    Scenario:
        When restart featureconfig_cccmuserapps_service
    
    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 551},{"mdf_id" : 33923}]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 551, "value" : 1},{"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 33923, "value" : 4}] 
        When Send response GetParamResponse
        When NotifyTemperatureStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyTemperatureStatus.temp_range = 15.5
        When NotifyTemperatureStatus is sent
        When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureUnitsStatus.temperature_units = 'ENUM_TEMPERATURE_UNITS_CELSIUS'
        When NotifyTemperatureUnitsStatus is sent
        Then HMI shows: DI_GUI.transClimateTemperature 
    
    Scenario:
        When restart featureconfig_cccmuserapps_service
    
    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 551},{"mdf_id" : 33923}]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 551, "value" : 1},{"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 33923, "value" : 5}] 
        When Send response GetParamResponse
        When NotifyTemperatureStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyTemperatureStatus.temp_range = 16.0
        When NotifyTemperatureStatus is sent
        When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureUnitsStatus.temperature_units = 'ENUM_TEMPERATURE_UNITS_CELSIUS'
        When NotifyTemperatureUnitsStatus is sent
        Then HMI shows: DI_GUI.transClimateTemperature 
    
    Scenario:
        When restart featureconfig_cccmuserapps_service
    
    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 551},{"mdf_id" : 33923}]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 551, "value" : 1},{"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 33923, "value" : 5}] 
        When Send response GetParamResponse
        When NotifyTemperatureStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyTemperatureStatus.temp_range = 16.0
        When NotifyTemperatureStatus is sent
        When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureUnitsStatus.temperature_units = 'ENUM_TEMPERATURE_UNITS_FAHRENHEIT'
        When NotifyTemperatureUnitsStatus is sent
        Then HMI shows: DI_GUI.transClimateTemperature 
    

    Scenario:
        When restart featureconfig_cccmuserapps_service
    
    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 551},{"mdf_id" : 33923}]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 551, "value" : 1},{"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 33923, "value" : 6}] 
        When Send response GetParamResponse
        When NotifyTemperatureStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyTemperatureStatus.temp_range = 16.5
        When NotifyTemperatureStatus is sent
        When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureUnitsStatus.temperature_units = 'ENUM_TEMPERATURE_UNITS_FAHRENHEIT'
        When NotifyTemperatureUnitsStatus is sent
        Then HMI shows: DI_GUI.transClimateTemperature 16.5
    

    Scenario:
        When restart featureconfig_cccmuserapps_service
    
    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 551},{"mdf_id" : 33923}]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 551, "value" : 1},{"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 33923, "value" : 7}] 
        When Send response GetParamResponse
        When NotifyTemperatureStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyTemperatureStatus.temp_range = 17.0
        When NotifyTemperatureStatus is sent
        When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureUnitsStatus.temperature_units = 'ENUM_TEMPERATURE_UNITS_FAHRENHEIT'
        When NotifyTemperatureUnitsStatus is sent
        Then HMI shows: DI_GUI.transClimateTemperature 
    
    Scenario:
        When restart featureconfig_cccmuserapps_service
    
    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 551},{"mdf_id" : 33923}]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 551, "value" : 1},{"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 33923, "value" : 8}] 
        When Send response GetParamResponse
        When NotifyTemperatureStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyTemperatureStatus.temp_range = 17.5
        When NotifyTemperatureStatus is sent
        When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureUnitsStatus.temperature_units = 'ENUM_TEMPERATURE_UNITS_FAHRENHEIT'
        When NotifyTemperatureUnitsStatus is sent
        Then HMI shows: DI_GUI.transClimateTemperature 
    
    Scenario:
        When restart featureconfig_cccmuserapps_service
    
    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 551},{"mdf_id" : 33923}]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 551, "value" : 1},{"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 33923, "value" : 1}] 
        When Send response GetParamResponse
        When NotifyTemperatureStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyTemperatureStatus.temp_range = 15.0
        When NotifyTemperatureStatus is sent
        When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureUnitsStatus.temperature_units = 'ENUM_TEMPERATURE_UNITS_FAHRENHEIT'
        When NotifyTemperatureUnitsStatus is sent
        Then HMI shows: DI_GUI.transClimateTemperature 
    
    Scenario:
        When restart featureconfig_cccmuserapps_service
    
    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 551},{"mdf_id" : 33927}]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 551, "value" : 1},{"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 33927, "value" : 2}] 
        When Send response GetParamResponse
        When NotifyTemperatureStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyTemperatureStatus.temp_range = 28.0
        When NotifyTemperatureStatus is sent
        # When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_OK'
        # When NotifyTemperatureUnitsStatus.temperature_units  = 'ENUM_TEMPERATURE_UNITS_FAHRENHEIT'
        Then HMI shows: DI_GUI.transClimateTemperature 
    
    Scenario:
        When restart featureconfig_cccmuserapps_service
    
    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 551},{"mdf_id" : 33927}]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 551, "value" : 1},{"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 33927, "value" : 3}] 
        When Send response GetParamResponse
        When NotifyTemperatureStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyTemperatureStatus.temp_range = 27.5
        When NotifyTemperatureStatus is sent
        # When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_OK'
        # When NotifyTemperatureUnitsStatus.temperature_units  = 'ENUM_TEMPERATURE_UNITS_FAHRENHEIT'
        Then HMI shows: DI_GUI.transClimateTemperature 27.5
    
    Scenario:
        When restart featureconfig_cccmuserapps_service
    
    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 551},{"mdf_id" : 33927}]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 551, "value" : 1},{"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 33927, "value" : 4}] 
        When Send response GetParamResponse
        When NotifyTemperatureStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyTemperatureStatus.temp_range = 27.5
        When NotifyTemperatureStatus is sent
        When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureUnitsStatus.temperature_units = 'ENUM_TEMPERATURE_UNITS_FAHRENHEIT'
        When NotifyTemperatureUnitsStatus is sent
        Then HMI shows: DI_GUI.transClimateTemperature 
    
    Scenario:
        When restart featureconfig_cccmuserapps_service
    
    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 551},{"mdf_id" : 33927}]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 551, "value" : 1},{"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 33927, "value" : 5}] 
        When Send response GetParamResponse
        When NotifyTemperatureStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyTemperatureStatus.temp_range = 28.0
        When NotifyTemperatureStatus is sent
        When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureUnitsStatus.temperature_units = 'ENUM_TEMPERATURE_UNITS_FAHRENHEIT'
        When NotifyTemperatureUnitsStatus is sent
        Then HMI shows: DI_GUI.transClimateTemperature 
    
    Scenario:
        When restart featureconfig_cccmuserapps_service
    
    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 551},{"mdf_id" : 33927}]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 551, "value" : 1},{"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 33927, "value" : 5}] 
        When Send response GetParamResponse
        When NotifyTemperatureStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyTemperatureStatus.temp_range = 28.0
        When NotifyTemperatureStatus is sent
        When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureUnitsStatus.temperature_units = 'ENUM_TEMPERATURE_UNITS_CELSIUS'
        When NotifyTemperatureUnitsStatus is sent
        Then HMI shows: DI_GUI.transClimateTemperature 
    
    Scenario:
        When restart featureconfig_cccmuserapps_service
    
    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 551},{"mdf_id" : 33927}]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 551, "value" : 1},{"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 33927, "value" : 6}] 
        When Send response GetParamResponse
        When NotifyTemperatureStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyTemperatureStatus.temp_range = 28.5
        When NotifyTemperatureStatus is sent
        When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureUnitsStatus.temperature_units = 'ENUM_TEMPERATURE_UNITS_CELSIUS'
        When NotifyTemperatureUnitsStatus is sent
        Then HMI shows: DI_GUI.transClimateTemperature 
    
    Scenario:
        When restart featureconfig_cccmuserapps_service
    
    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 551},{"mdf_id" : 33927}]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 551, "value" : 1},{"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 33927, "value" : 7}] 
        When Send response GetParamResponse
        When NotifyTemperatureStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyTemperatureStatus.temp_range = 29.0
        When NotifyTemperatureStatus is sent
        When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureUnitsStatus.temperature_units = 'ENUM_TEMPERATURE_UNITS_CELSIUS'
        When NotifyTemperatureUnitsStatus is sent
        Then HMI shows: DI_GUI.transClimateTemperature 
    
    Scenario:
        When restart featureconfig_cccmuserapps_service
    
    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 551},{"mdf_id" : 33927}]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 551, "value" : 1},{"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 33927, "value" : 8}] 
        When Send response GetParamResponse
        When NotifyTemperatureStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyTemperatureStatus.temp_range = 29.5
        When NotifyTemperatureStatus is sent
        When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureUnitsStatus.temperature_units = 'ENUM_TEMPERATURE_UNITS_CELSIUS'
        When NotifyTemperatureUnitsStatus is sent
        Then HMI shows: DI_GUI.transClimateTemperature 
    
    Scenario:
        When restart featureconfig_cccmuserapps_service
    
    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 551},{"mdf_id" : 33927}]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 551, "value" : 1},{"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 33927, "value" : 1}] 
        When Send response GetParamResponse
        When NotifyTemperatureStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyTemperatureStatus.temp_range = 27.5
        When NotifyTemperatureStatus is sent
        When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureUnitsStatus.temperature_units = 'ENUM_TEMPERATURE_UNITS_CELSIUS'
        When NotifyTemperatureUnitsStatus is sent
        Then HMI shows: DI_GUI.transClimateTemperature 
    
    #### Comfort Mode
    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_STATE_COMFORT'
        When NotifyVLCAState.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_state = 'ENUM_VEHICLE_STATE_COMFORT'
        When Send notify NotifyVLCAState
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_VEHICLE_STATE_COMFORT'

    Scenario:
        When restart featureconfig_cccmuserapps_service 
    
    # Steering Position Left 
    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 551},{"mdf_id" : 33923}]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 551, "value" : 1},{"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 33923, "value" : 2}] 
        When Send response GetParamResponse
        When NotifyTemperatureStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyTemperatureStatus.temp_range = 13.5
        When NotifyTemperatureStatus is sent

    Scenario:
        When restart featureconfig_cccmuserapps_service
    
    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 551},{"mdf_id" : 33923}]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 551, "value" : 1},{"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 33923, "value" : 2}] 
        When Send response GetParamResponse
        When NotifyTemperatureStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyTemperatureStatus.temp_range = 13.5
        When NotifyTemperatureStatus is sent
        When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureUnitsStatus.temperature_units = 'ENUM_TEMPERATURE_UNITS_CELSIUS'
        When NotifyTemperatureUnitsStatus is sent
        Then HMI shows: DI_GUI.transClimateTemperature 

    Scenario:
        When restart featureconfig_cccmuserapps_service
    
    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 551},{"mdf_id" : 33923}]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 551, "value" : 1},{"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 33923, "value" : 3}] 
        When Send response GetParamResponse
        When NotifyTemperatureStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyTemperatureStatus.temp_range = 14.5
        When NotifyTemperatureStatus is sent
        When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureUnitsStatus.temperature_units = 'ENUM_TEMPERATURE_UNITS_CELSIUS'
        When NotifyTemperatureUnitsStatus is sent
        Then HMI shows: DI_GUI.transClimateTemperature 
    
    Scenario:
        When restart featureconfig_cccmuserapps_service
    
    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 551},{"mdf_id" : 33923}]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 551, "value" : 1},{"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 33923, "value" : 4}] 
        When Send response GetParamResponse
        When NotifyTemperatureStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyTemperatureStatus.temp_range = 15.5
        When NotifyTemperatureStatus is sent
        When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureUnitsStatus.temperature_units = 'ENUM_TEMPERATURE_UNITS_CELSIUS'
        When NotifyTemperatureUnitsStatus is sent
        Then HMI shows: DI_GUI.transClimateTemperature 
    
    Scenario:
        When restart featureconfig_cccmuserapps_service
    
    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 551},{"mdf_id" : 33923}]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 551, "value" : 1},{"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 33923, "value" : 5}] 
        When Send response GetParamResponse
        When NotifyTemperatureStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyTemperatureStatus.temp_range = 16.0
        When NotifyTemperatureStatus is sent
        When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureUnitsStatus.temperature_units = 'ENUM_TEMPERATURE_UNITS_CELSIUS'
        When NotifyTemperatureUnitsStatus is sent
        Then HMI shows: DI_GUI.transClimateTemperature 
    
    Scenario:
        When restart featureconfig_cccmuserapps_service
    
    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 551},{"mdf_id" : 33923}]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 551, "value" : 1},{"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 33923, "value" : 5}] 
        When Send response GetParamResponse
        When NotifyTemperatureStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyTemperatureStatus.temp_range = 16.0
        When NotifyTemperatureStatus is sent
        When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureUnitsStatus.temperature_units = 'ENUM_TEMPERATURE_UNITS_FAHRENHEIT'
        When NotifyTemperatureUnitsStatus is sent
        Then HMI shows: DI_GUI.transClimateTemperature 
    

    Scenario:
        When restart featureconfig_cccmuserapps_service
    
    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 551},{"mdf_id" : 33923}]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 551, "value" : 1},{"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 33923, "value" : 6}] 
        When Send response GetParamResponse
        When NotifyTemperatureStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyTemperatureStatus.temp_range = 16.5
        When NotifyTemperatureStatus is sent
        When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureUnitsStatus.temperature_units = 'ENUM_TEMPERATURE_UNITS_FAHRENHEIT'
        When NotifyTemperatureUnitsStatus is sent
        Then HMI shows: DI_GUI.transClimateTemperature 
    

    Scenario:
        When restart featureconfig_cccmuserapps_service
    
    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 551},{"mdf_id" : 33923}]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 551, "value" : 1},{"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 33923, "value" : 7}] 
        When Send response GetParamResponse
        When NotifyTemperatureStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyTemperatureStatus.temp_range = 17.0
        When NotifyTemperatureStatus is sent
        When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureUnitsStatus.temperature_units = 'ENUM_TEMPERATURE_UNITS_FAHRENHEIT'
        When NotifyTemperatureUnitsStatus is sent
        Then HMI shows: DI_GUI.transClimateTemperature 
    
    Scenario:
        When restart featureconfig_cccmuserapps_service
    
    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 551},{"mdf_id" : 33923}]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 551, "value" : 1},{"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 33923, "value" : 8}] 
        When Send response GetParamResponse
        When NotifyTemperatureStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyTemperatureStatus.temp_range = 17.5
        When NotifyTemperatureStatus is sent
        When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureUnitsStatus.temperature_units = 'ENUM_TEMPERATURE_UNITS_FAHRENHEIT'
        When NotifyTemperatureUnitsStatus is sent
        Then HMI shows: DI_GUI.transClimateTemperature 
    
    Scenario:
        When restart featureconfig_cccmuserapps_service
    
    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 551},{"mdf_id" : 33923}]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 551, "value" : 1},{"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 33923, "value" : 1}] 
        When Send response GetParamResponse
        When NotifyTemperatureStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyTemperatureStatus.temp_range = 15.0
        When NotifyTemperatureStatus is sent
        When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureUnitsStatus.temperature_units = 'ENUM_TEMPERATURE_UNITS_FAHRENHEIT'
        When NotifyTemperatureUnitsStatus is sent
        Then HMI shows: DI_GUI.transClimateTemperature 
    
    Scenario:
        When restart featureconfig_cccmuserapps_service
    
    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 551},{"mdf_id" : 33927}]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 551, "value" : 1},{"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 33927, "value" : 2}] 
        When Send response GetParamResponse
        When NotifyTemperatureStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyTemperatureStatus.temp_range = 28.0
        When NotifyTemperatureStatus is sent
        # When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_OK'
        # When NotifyTemperatureUnitsStatus.temperature_units  = 'ENUM_TEMPERATURE_UNITS_FAHRENHEIT'
        Then HMI shows: DI_GUI.transClimateTemperature 
    
    Scenario:
        When restart featureconfig_cccmuserapps_service
    
    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 551},{"mdf_id" : 33927}]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 551, "value" : 1},{"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 33927, "value" : 3}] 
        When Send response GetParamResponse
        When NotifyTemperatureStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyTemperatureStatus.temp_range = 27.5
        When NotifyTemperatureStatus is sent
        # When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_OK'
        # When NotifyTemperatureUnitsStatus.temperature_units  = 'ENUM_TEMPERATURE_UNITS_FAHRENHEIT'
        Then HMI shows: DI_GUI.transClimateTemperature 
    
    Scenario:
        When restart featureconfig_cccmuserapps_service
    
    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 551},{"mdf_id" : 33927}]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 551, "value" : 1},{"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 33927, "value" : 4}] 
        When Send response GetParamResponse
        When NotifyTemperatureStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyTemperatureStatus.temp_range = 27.5
        When NotifyTemperatureStatus is sent
        When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureUnitsStatus.temperature_units = 'ENUM_TEMPERATURE_UNITS_FAHRENHEIT'
        When NotifyTemperatureUnitsStatus is sent
        Then HMI shows: DI_GUI.transClimateTemperature 
    
    Scenario:
        When restart featureconfig_cccmuserapps_service
    
    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 551},{"mdf_id" : 33927}]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 551, "value" : 1},{"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 33927, "value" : 5}] 
        When Send response GetParamResponse
        When NotifyTemperatureStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyTemperatureStatus.temp_range = 28.0
        When NotifyTemperatureStatus is sent
        When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureUnitsStatus.temperature_units = 'ENUM_TEMPERATURE_UNITS_FAHRENHEIT'
        When NotifyTemperatureUnitsStatus is sent
        Then HMI shows: DI_GUI.transClimateTemperature 
    
    Scenario:
        When restart featureconfig_cccmuserapps_service
    
    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 551},{"mdf_id" : 33927}]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 551, "value" : 1},{"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 33927, "value" : 5}] 
        When Send response GetParamResponse
        When NotifyTemperatureStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyTemperatureStatus.temp_range = 28.0
        When NotifyTemperatureStatus is sent
        When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureUnitsStatus.temperature_units = 'ENUM_TEMPERATURE_UNITS_CELSIUS'
        When NotifyTemperatureUnitsStatus is sent
        Then HMI shows: DI_GUI.transClimateTemperature 
    
    Scenario:
        When restart featureconfig_cccmuserapps_service
    
    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 551},{"mdf_id" : 33927}]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 551, "value" : 1},{"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 33927, "value" : 6}] 
        When Send response GetParamResponse
        When NotifyTemperatureStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyTemperatureStatus.temp_range = 28.5
        When NotifyTemperatureStatus is sent
        When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureUnitsStatus.temperature_units = 'ENUM_TEMPERATURE_UNITS_CELSIUS'
        When NotifyTemperatureUnitsStatus is sent
        Then HMI shows: DI_GUI.transClimateTemperature 
    
    Scenario:
        When restart featureconfig_cccmuserapps_service
    
    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 551},{"mdf_id" : 33927}]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 551, "value" : 1},{"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 33927, "value" : 7}] 
        When Send response GetParamResponse
        When NotifyTemperatureStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyTemperatureStatus.temp_range = 29.0
        When NotifyTemperatureStatus is sent
        When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureUnitsStatus.temperature_units = 'ENUM_TEMPERATURE_UNITS_CELSIUS'
        When NotifyTemperatureUnitsStatus is sent
        Then HMI shows: DI_GUI.transClimateTemperature 
    
    Scenario:
        When restart featureconfig_cccmuserapps_service
    
    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 551},{"mdf_id" : 33927}]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 551, "value" : 1},{"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 33927, "value" : 8}] 
        When Send response GetParamResponse
        When NotifyTemperatureStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyTemperatureStatus.temp_range = 29.5
        When NotifyTemperatureStatus is sent
        When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureUnitsStatus.temperature_units = 'ENUM_TEMPERATURE_UNITS_CELSIUS'
        When NotifyTemperatureUnitsStatus is sent
        Then HMI shows: DI_GUI.transClimateTemperature 
    
    Scenario:
        When restart featureconfig_cccmuserapps_service
    
    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 551},{"mdf_id" : 33927}]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 551, "value" : 1},{"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 33927, "value" : 1}] 
        When Send response GetParamResponse
        When NotifyTemperatureStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyTemperatureStatus.temp_range = 27.5
        When NotifyTemperatureStatus is sent
        When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureUnitsStatus.temperature_units = 'ENUM_TEMPERATURE_UNITS_CELSIUS'
        When NotifyTemperatureUnitsStatus is sent
        Then HMI shows: DI_GUI.transClimateTemperature 
    
