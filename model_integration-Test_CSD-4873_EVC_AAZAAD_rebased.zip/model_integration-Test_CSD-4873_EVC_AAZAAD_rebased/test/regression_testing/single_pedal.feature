Feature: Single Pedal Driving

  Scenario: Start server/clients
        When Start server for lifecycle_cccmuserapps_vlca_service
        And Start server for motion_setting_service
        And Start server for steering_wheel_switch_service
        And Start server for cockpit_settings_service
        And Start server for propulsion_service
	And Start server for display_control_service

    Scenario:
        When GetHUDStateRequest.hud_type = 'ENUM_HUDTYPE_DRIVER_HUD'
        When Send request GetHUDStateRequest

    Scenario: Set Vehicle_State = 'ENUM_STATE_RUNNING'
        Given Receive request GetVLCAStateRequest
        When GetVLCAStateResponse.vlca_state = "ENUM_VLCA_STATE_UNSPECIFIED"
        When GetVLCAStateResponse.vehicle_mode = "ENUM_VEHICLE_MODE_UNSPECIFIED"
        When GetVLCAStateResponse.vehicle_state = "ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL"
        When Send response GetVLCAStateResponse
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_STATE_RUNNING' 
    
    Scenario:
        When NotifySinglePedalDrivingMode.status = 'ENUM_STATUS_OK'
        When NotifySinglePedalDrivingMode.single_pedal_mode_status = 'ENUM_SINGLE_PEDAL_DRIVING_MODE_ENABLE'
        When Send NotifySinglePedalDrivingMode
        Then HMI shows: DI_GUI.transSinglePedalDriveMode.vTransSinglePedalDriveMode == 'TRUE'
        Then HMI shows: DI_GUI.transSinglePedalDriveMode.bTransSinglePedalDriveMode == 'TRUE'

    Scenario:
        When NotifySinglePedalDrivingMode.status = 'ENUM_STATUS_OK'
        When NotifySinglePedalDrivingMode.single_pedal_mode_status = 'ENUM_SINGLE_PEDAL_DRIVING_MODE_DISABLE'
        When Send NotifySinglePedalDrivingMode
        Then HMI shows: DI_GUI.transSinglePedalDriveMode.vTransSinglePedalDriveMode == 'TRUE'
        Then HMI shows: DI_GUI.transSinglePedalDriveMode.bTransSinglePedalDriveMode == 'FALSE'

    Scenario:
        When NotifySinglePedalDrivingMode.status = 'ENUM_STATUS_OK'
        When NotifySinglePedalDrivingMode.single_pedal_mode_status = 'ENUM_SINGLE_PEDAL_DRIVING_MODE_UNSPECIFIED'
        When Send NotifySinglePedalDrivingMode
        Then HMI shows: DI_GUI.transSinglePedalDriveMode.vTransSinglePedalDriveMode == 'TRUE'
        Then HMI shows: DI_GUI.transSinglePedalDriveMode.bTransSinglePedalDriveMode == 'FALSE'
    
   
