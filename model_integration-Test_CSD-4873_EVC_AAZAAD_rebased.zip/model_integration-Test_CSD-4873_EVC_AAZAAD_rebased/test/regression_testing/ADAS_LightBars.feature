Feature: ADAS Light Bars        
    Scenario: Start server/clients
        When Start client for telltale_service
        And Start server for lifecycle_cccmuserapps_vlca_service
    
    #### FULL running Mode
    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_STATE_FULL'
        When NotifyVLCAState.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_state = 'ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL'
        When Send notify NotifyVLCAState
        
    Scenario: 
        When SetLightbarRequest.lightbar_colour = 'ENUM_LIGHTBAR_COLOUR_UNSPECIFIED'
        When SetLightbarRequest.lightbar_state = 'ENUM_LIGHTBAR_STATE_UNSPECIFIED'
        When SetLightbarRequest is sent
        
    Scenario: ADASLight_Bars == 'ADAS_LIGHT_BAR_NONE'
        When SetLightbarRequest.lightbar_colour = 'ENUM_LIGHTBAR_COLOUR_UNSPECIFIED'
        When SetLightbarRequest.lightbar_state = 'ENUM_LIGHTBAR_STATE_ON_SOLID'
        When SetLightbarRequest is sent
        Then HMI Shows:  topic DI_GUI.driverAssistTelltales 
        
    Scenario: ADASLight_Bars == 'ADAS_LIGHT_BAR_GREEN'
        When SetLightbarRequest.lightbar_colour = 'ENUM_LIGHTBAR_COLOUR_GREEN'
        When SetLightbarRequest.lightbar_state = 'ENUM_LIGHTBAR_STATE_ON_SOLID'
        When SetLightbarRequest is sent
        Then HMI Shows:  DI_GUI.driverAssistTelltales.eADASLight_Bars  == 'ADAS_LIGHT_BAR_GREEN'
        
    Scenario: ADASLight_Bars == 'ADAS_LIGHT_BAR_RED'
        When SetLightbarRequest.lightbar_colour = 'ENUM_LIGHTBAR_COLOUR_RED'
        When SetLightbarRequest.lightbar_state = 'ENUM_LIGHTBAR_STATE_ON_SOLID'
        When SetLightbarRequest is sent
        Then HMI Shows:  DI_GUI.driverAssistTelltales.eADASLight_Bars  == 'ADAS_LIGHT_BAR_RED'
        
    Scenario: ADASLight_Bars == 'ADAS_LIGHT_BAR_AMBER'
        When SetLightbarRequest.lightbar_colour = 'ENUM_LIGHTBAR_COLOUR_AMBER'
        When SetLightbarRequest.lightbar_state = 'ENUM_LIGHTBAR_STATE_ON_SOLID'
        When SetLightbarRequest is sent
        Then HMI Shows:  DI_GUI.driverAssistTelltales.eADASLight_Bars  == 'ADAS_LIGHT_BAR_AMBER'
        
    Scenario: ADASLight_Bars == 'ADAS_LIGHT_BAR_BLUE'
        When SetLightbarRequest.lightbar_colour = 'ENUM_LIGHTBAR_COLOUR_BLUE'
        When SetLightbarRequest.lightbar_state = 'ENUM_LIGHTBAR_STATE_ON_SOLID'
        When SetLightbarRequest is sent
        Then HMI Shows:  DI_GUI.driverAssistTelltales.eADASLight_Bars == 'ADAS_LIGHT_BAR_BLUE'
        
    Scenario: ADASLight_Bars == 'ADAS_LIGHT_BAR_PURPLE'
        When SetLightbarRequest.lightbar_colour = 'ENUM_LIGHTBAR_COLOUR_PURPLE'
        When SetLightbarRequest.lightbar_state = 'ENUM_LIGHTBAR_STATE_ON_SOLID'
        When SetLightbarRequest is sent
        Then HMI Shows:  DI_GUI.driverAssistTelltales.eADASLight_Bars == 'ADAS_LIGHT_BAR_PURPLE'
        
    Scenario: ADASLight_Bars == 'ADAS_LIGHT_BAR_WHITE'
        When SetLightbarRequest.lightbar_colour = 'ENUM_LIGHTBAR_COLOUR_WHITE'
        When SetLightbarRequest.lightbar_state = 'ENUM_LIGHTBAR_STATE_ON_SOLID'
        When SetLightbarRequest is sent
        Then HMI Shows:  DI_GUI.driverAssistTelltales.eADASLight_Bars  == 'ADAS_LIGHT_BAR_WHITE'
        
    Scenario: ADASLight_Bars == 'ADAS_LIGHT_BAR_NONE'
        When SetLightbarRequest.lightbar_colour = 'ENUM_LIGHTBAR_COLOUR_WHITE'
        When SetLightbarRequest.lightbar_state = 'ENUM_LIGHTBAR_STATE_OFF'
        When SetLightbarRequest is sent
        Then HMI Shows:  DI_GUI.driverAssistTelltales.eADASLight_Bars == 'ADAS_LIGHT_BAR_NONE'
