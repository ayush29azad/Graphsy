Feature:
    Scenario: Start server/clients
        When Start server for lifecycle_cccmuserapps_vlca_service
        And Start server for climate_service
        And Start server for cockpit_settings_service
        And Start server for featureconfig_cccmuserapps_service

    Scenario: Set Vehicle_State = 'ENUM_STATE_RUNNING'
        Given Receive request GetVLCAStateRequest
        When GetVLCAStateResponse.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When GetVLCAStateResponse.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When GetVLCAStateResponse.vehicle_state = 'ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL'
        When Send response GetVLCAStateResponse

    Scenario: 
        When NotifyCurrentSystemTheme.status = 'ENUM_STATUS_OK'
        When NotifyCurrentSystemTheme.current_system_theme = 'ENUM_CURRENT_THEME_LIGHT'
        When Send notify NotifyCurrentSystemTheme

# Steering Position Left 
    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 551}]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 551, "value" : 1}] 
        When Send response GetParamResponse

    Scenario:
        When NotifyManualBlowerSpeedStatus.status = 'ENUM_STATUS_OK'
        When NotifyManualBlowerSpeedStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyManualBlowerSpeedStatus.manual_blower_status = 'ENUM_BLOWER_SPEED_OFF'
        When NotifyManualBlowerSpeedStatus is sent

    Scenario:
        When NotifyManualBlowerSpeedStatus.status = 'ENUM_STATUS_OK'
        When NotifyManualBlowerSpeedStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyManualBlowerSpeedStatus.manual_blower_status = 'ENUM_BLOWER_SPEED_LEVEL1'
        When NotifyManualBlowerSpeedStatus is sent
        Then HMI shows:  DI_GUI.transClimateFanSpeed.eTransClimateFanSpeed 'CLIMATE_FAN_SPEED_NUMBER' DI_GUI.transClimateFanSpeed.vTransClimateFanSpeed == TRUE DI_GUI.transClimateFanSpeed.iFanSpeed_Value == 1

    Scenario:
        When NotifyManualBlowerSpeedStatus.status = 'ENUM_STATUS_OK'
        When NotifyManualBlowerSpeedStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyManualBlowerSpeedStatus.manual_blower_status = 'ENUM_BLOWER_SPEED_LEVEL2'
        When NotifyManualBlowerSpeedStatus is sent
        Then HMI shows:  DI_GUI.transClimateFanSpeed.eTransClimateFanSpeed == 'CLIMATE_FAN_SPEED_NUMBER' DI_GUI.transClimateFanSpeed.vTransClimateFanSpeed == TRUE DI_GUI.transClimateFanSpeed.iFanSpeed_Value == 2

    Scenario:
        When NotifyManualBlowerSpeedStatus.status = 'ENUM_STATUS_OK'
        When NotifyManualBlowerSpeedStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyManualBlowerSpeedStatus.manual_blower_status = 'ENUM_BLOWER_SPEED_LEVEL3'
        When NotifyManualBlowerSpeedStatus is sent
        Then HMI shows:  DI_GUI.transClimateFanSpeed.eTransClimateFanSpeed == 'CLIMATE_FAN_SPEED_NUMBER' DI_GUI.transClimateFanSpeed.vTransClimateFanSpeed == TRUE DI_GUI.transClimateFanSpeed.iFanSpeed_Value == 3

    Scenario:
        When NotifyManualBlowerSpeedStatus.status = 'ENUM_STATUS_OK'
        When NotifyManualBlowerSpeedStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyManualBlowerSpeedStatus.manual_blower_status = 'ENUM_BLOWER_SPEED_LEVEL4'
        When NotifyManualBlowerSpeedStatus is sent
        Then HMI shows:  DI_GUI.transClimateFanSpeed.eTransClimateFanSpeed == 'CLIMATE_FAN_SPEED_NUMBER' DI_GUI.transClimateFanSpeed.vTransClimateFanSpeed == TRUE DI_GUI.transClimateFanSpeed.iFanSpeed_Value == 4

    Scenario:
        When NotifyManualBlowerSpeedStatus.status = 'ENUM_STATUS_OK'
        When NotifyManualBlowerSpeedStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyManualBlowerSpeedStatus.manual_blower_status = 'ENUM_BLOWER_SPEED_LEVEL5'
        When NotifyManualBlowerSpeedStatus is sent
        Then HMI shows:  DI_GUI.transClimateFanSpeed.eTransClimateFanSpeed == 'CLIMATE_FAN_SPEED_NUMBER' DI_GUI.transClimateFanSpeed.vTransClimateFanSpeed == TRUE DI_GUI.transClimateFanSpeed.iFanSpeed_Value == 5
    
    Scenario:
        When NotifyManualBlowerSpeedStatus.status = 'ENUM_STATUS_OK'
        When NotifyManualBlowerSpeedStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyManualBlowerSpeedStatus.manual_blower_status = 'ENUM_BLOWER_SPEED_LEVEL6'
        When NotifyManualBlowerSpeedStatus is sent
        Then HMI shows:  DI_GUI.transClimateFanSpeed.eTransClimateFanSpeed == 'CLIMATE_FAN_SPEED_NUMBER' DI_GUI.transClimateFanSpeed.vTransClimateFanSpeed == TRUE DI_GUI.transClimateFanSpeed.iFanSpeed_Value == 6
    
    Scenario:
        When NotifyManualBlowerSpeedStatus.status = 'ENUM_STATUS_OK'
        When NotifyManualBlowerSpeedStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyManualBlowerSpeedStatus.manual_blower_status = 'ENUM_BLOWER_SPEED_LEVEL7'
        When NotifyManualBlowerSpeedStatus is sent
        Then HMI shows:  DI_GUI.transClimateFanSpeed.eTransClimateFanSpeed == 'CLIMATE_FAN_SPEED_NUMBER' DI_GUI.transClimateFanSpeed.vTransClimateFanSpeed == TRUE DI_GUI.transClimateFanSpeed.iFanSpeed_Value == 7
    
    Scenario:
        When NotifyManualBlowerSpeedStatus.status = 'ENUM_STATUS_OK'
        When NotifyManualBlowerSpeedStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyManualBlowerSpeedStatus.manual_blower_status = 'ENUM_BLOWER_SPEED_LEVEL8'
        When NotifyManualBlowerSpeedStatus is sent
        Then HMI shows:  DI_GUI.transClimateFanSpeed.eTransClimateFanSpeed == 'CLIMATE_FAN_SPEED_UNSPECIFIED' DI_GUI.transClimateFanSpeed.vTransClimateFanSpeed == FALSE DI_GUI.transClimateFanSpeed.iFanSpeed_Value == 0
    
    Scenario:
        When NotifyManualBlowerSpeedStatus.status = 'ENUM_STATUS_OK'
        When NotifyManualBlowerSpeedStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyManualBlowerSpeedStatus.manual_blower_status = 'ENUM_BLOWER_SPEED_LEVEL9'
        When NotifyManualBlowerSpeedStatus is sent
        Then HMI shows:  DI_GUI.transClimateFanSpeed.eTransClimateFanSpeed == 'CLIMATE_FAN_SPEED_UNSPECIFIED' DI_GUI.transClimateFanSpeed.vTransClimateFanSpeed == FALSE DI_GUI.transClimateFanSpeed.iFanSpeed_Value == 0
    
    Scenario:
        When NotifyManualBlowerSpeedStatus.status = 'ENUM_STATUS_OK'
        When NotifyManualBlowerSpeedStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyManualBlowerSpeedStatus.manual_blower_status = 'ENUM_BLOWER_SPEED_LEVEL10'
        When NotifyManualBlowerSpeedStatus is sent
        Then HMI shows:  DI_GUI.transClimateFanSpeed.eTransClimateFanSpeed == 'CLIMATE_FAN_SPEED_UNSPECIFIED' DI_GUI.transClimateFanSpeed.vTransClimateFanSpeed == FALSE DI_GUI.transClimateFanSpeed.iFanSpeed_Value == 0
    
    Scenario: # LOC_Steering_Position = LEFT, DEFL_VEHICLE_STATE = 'ENUM_STATE_COMFORT' and 'ENUM_BLOWER_SPEED_AUTO_BLOWER'
        When NotifyManualBlowerSpeedStatus.status = 'ENUM_STATUS_OK'
        When NotifyManualBlowerSpeedStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyManualBlowerSpeedStatus.manual_blower_status = 'ENUM_BLOWER_SPEED_AUTO_BLOWER' 
        When NotifyManualBlowerSpeedStatus is sent
        When NotifyAutoBlowerIntensityStatus.status = 'ENUM_STATUS_OK'
        When NotifyAutoBlowerIntensityStatus.auto_blower_intensity = 'ENUM_AUTO_BLOWER_INTENSITY_OFF'
        When NotifyAutoBlowerIntensityStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyAutoBlowerIntensityStatus is sent
        Then HMI shows:  DI_GUI.transClimateFanSpeed.eTransClimateFanSpeed == 'CLIMATE_FAN_SPEED_OFF' DI_GUI.transClimateFanSpeed.vTransClimateFanSpeed == TRUE DI_GUI.transClimateFanSpeed.iFanSpeed_Value == 0
    
    Scenario:
        When NotifyManualBlowerSpeedStatus.status = 'ENUM_STATUS_OK'
        When NotifyManualBlowerSpeedStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyManualBlowerSpeedStatus.manual_blower_status = 'ENUM_BLOWER_SPEED_AUTO_BLOWER' 
        When NotifyManualBlowerSpeedStatus is sent
        When NotifyAutoBlowerIntensityStatus.status = 'ENUM_STATUS_OK'
        When NotifyAutoBlowerIntensityStatus.auto_blower_intensity = 'ENUM_AUTO_BLOWER_INTENSITY_LEVEL1'
        When NotifyAutoBlowerIntensityStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyAutoBlowerIntensityStatus is sent
        Then HMI shows:  DI_GUI.transClimateFanSpeed.eTransClimateFanSpeed == 'CLIMATE_FAN_SPEED_LOWEST' DI_GUI.transClimateFanSpeed.vTransClimateFanSpeed == TRUE DI_GUI.transClimateFanSpeed.iFanSpeed_Value == 0
    
    Scenario:
        When NotifyManualBlowerSpeedStatus.status = 'ENUM_STATUS_OK'
        When NotifyManualBlowerSpeedStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyManualBlowerSpeedStatus.manual_blower_status = 'ENUM_BLOWER_SPEED_AUTO_BLOWER' 
        When NotifyManualBlowerSpeedStatus is sent
        When NotifyAutoBlowerIntensityStatus.status = 'ENUM_STATUS_OK'
        When NotifyAutoBlowerIntensityStatus.auto_blower_intensity = 'ENUM_AUTO_BLOWER_INTENSITY_LEVEL2'
        When NotifyAutoBlowerIntensityStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyAutoBlowerIntensityStatus is sent
        Then HMI shows:  DI_GUI.transClimateFanSpeed.eTransClimateFanSpeed == 'CLIMATE_FAN_SPEED_LOW' DI_GUI.transClimateFanSpeed.vTransClimateFanSpeed == TRUE DI_GUI.transClimateFanSpeed.iFanSpeed_Value == 0
    
    Scenario:
        When NotifyManualBlowerSpeedStatus.status = 'ENUM_STATUS_OK'
        When NotifyManualBlowerSpeedStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyManualBlowerSpeedStatus.manual_blower_status = 'ENUM_BLOWER_SPEED_AUTO_BLOWER' 
        When NotifyManualBlowerSpeedStatus is sent
        When NotifyAutoBlowerIntensityStatus.status = 'ENUM_STATUS_OK'
        When NotifyAutoBlowerIntensityStatus.auto_blower_intensity = 'ENUM_AUTO_BLOWER_INTENSITY_LEVEL3'
        When NotifyAutoBlowerIntensityStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyAutoBlowerIntensityStatus is sent
        Then HMI shows:  DI_GUI.transClimateFanSpeed.eTransClimateFanSpeed == 'CLIMATE_FAN_SPEED_MEDIUM' DI_GUI.transClimateFanSpeed.vTransClimateFanSpeed == TRUE DI_GUI.transClimateFanSpeed.iFanSpeed_Value == 0
    
    Scenario:
        When NotifyManualBlowerSpeedStatus.status = 'ENUM_STATUS_OK'
        When NotifyManualBlowerSpeedStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyManualBlowerSpeedStatus.manual_blower_status = 'ENUM_BLOWER_SPEED_AUTO_BLOWER' 
        When NotifyManualBlowerSpeedStatus is sent
        When NotifyAutoBlowerIntensityStatus.status = 'ENUM_STATUS_OK'
        When NotifyAutoBlowerIntensityStatus.auto_blower_intensity = 'ENUM_AUTO_BLOWER_INTENSITY_LEVEL4'
        When NotifyAutoBlowerIntensityStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyAutoBlowerIntensityStatus is sent
        Then HMI shows:  DI_GUI.transClimateFanSpeed.eTransClimateFanSpeed == 'CLIMATE_FAN_SPEED_HIGH' DI_GUI.transClimateFanSpeed.vTransClimateFanSpeed == TRUE DI_GUI.transClimateFanSpeed.iFanSpeed_Value == 0
    
    Scenario:
        When NotifyManualBlowerSpeedStatus.status = 'ENUM_STATUS_OK'
        When NotifyManualBlowerSpeedStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyManualBlowerSpeedStatus.manual_blower_status = 'ENUM_BLOWER_SPEED_AUTO_BLOWER' 
        When NotifyManualBlowerSpeedStatus is sent
        When NotifyAutoBlowerIntensityStatus.status = 'ENUM_STATUS_OK'
        When NotifyAutoBlowerIntensityStatus.auto_blower_intensity = 'ENUM_AUTO_BLOWER_INTENSITY_LEVEL5'
        When NotifyAutoBlowerIntensityStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyAutoBlowerIntensityStatus is sent
        Then HMI shows:  DI_GUI.transClimateFanSpeed.eTransClimateFanSpeed == 'CLIMATE_FAN_SPEED_HIGHEST' DI_GUI.transClimateFanSpeed.vTransClimateFanSpeed == TRUE DI_GUI.transClimateFanSpeed.iFanSpeed_Value == 0
    
    Scenario:
        When NotifyManualBlowerSpeedStatus.status = 'ENUM_STATUS_OK'
        When NotifyManualBlowerSpeedStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyManualBlowerSpeedStatus.manual_blower_status = 'ENUM_BLOWER_SPEED_AUTO_BLOWER' 
        When NotifyManualBlowerSpeedStatus is sent
        When NotifyAutoBlowerIntensityStatus.status = 'ENUM_STATUS_OK'
        When NotifyAutoBlowerIntensityStatus.auto_blower_intensity = 'ENUM_AUTO_BLOWER_INTENSITY_LEVEL6'
        When NotifyAutoBlowerIntensityStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyAutoBlowerIntensityStatus is sent
        Then HMI shows:  DI_GUI.transClimateFanSpeed.eTransClimateFanSpeed == 'CLIMATE_FAN_SPEED_UNSPECIFIED' DI_GUI.transClimateFanSpeed.vTransClimateFanSpeed == FALSE DI_GUI.transClimateFanSpeed.iFanSpeed_Value == 0
    
    Scenario:
        When NotifyManualBlowerSpeedStatus.status = 'ENUM_STATUS_OK'
        When NotifyManualBlowerSpeedStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyManualBlowerSpeedStatus.manual_blower_status = 'ENUM_BLOWER_SPEED_AUTO_BLOWER' 
        When NotifyManualBlowerSpeedStatus is sent
        When NotifyAutoBlowerIntensityStatus.status = 'ENUM_STATUS_OK'
        When NotifyAutoBlowerIntensityStatus.auto_blower_intensity = 'ENUM_AUTO_BLOWER_INTENSITY_LEVEL7'
        When NotifyAutoBlowerIntensityStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyAutoBlowerIntensityStatus is sent
        Then HMI shows:  DI_GUI.transClimateFanSpeed.eTransClimateFanSpeed == 'CLIMATE_FAN_SPEED_UNSPECIFIED' DI_GUI.transClimateFanSpeed.vTransClimateFanSpeed == FALSE DI_GUI.transClimateFanSpeed.iFanSpeed_Value == 0
    
    Scenario:
        When NotifyManualBlowerSpeedStatus.status = 'ENUM_STATUS_OK'
        When NotifyManualBlowerSpeedStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyManualBlowerSpeedStatus.manual_blower_status = 'ENUM_BLOWER_SPEED_AUTO_BLOWER' 
        When NotifyManualBlowerSpeedStatus is sent
        When NotifyAutoBlowerIntensityStatus.status = 'ENUM_STATUS_OK'
        When NotifyAutoBlowerIntensityStatus.auto_blower_intensity = 'ENUM_AUTO_BLOWER_INTENSITY_LEVEL8'
        When NotifyAutoBlowerIntensityStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyAutoBlowerIntensityStatus is sent
        Then HMI shows:  DI_GUI.transClimateFanSpeed.eTransClimateFanSpeed == 'CLIMATE_FAN_SPEED_UNSPECIFIED' DI_GUI.transClimateFanSpeed.vTransClimateFanSpeed == FALSE DI_GUI.transClimateFanSpeed.iFanSpeed_Value == 0
    
    Scenario:
        When NotifyManualBlowerSpeedStatus.status = 'ENUM_STATUS_OK'
        When NotifyManualBlowerSpeedStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyManualBlowerSpeedStatus.manual_blower_status = 'ENUM_BLOWER_SPEED_AUTO_BLOWER' 
        When NotifyManualBlowerSpeedStatus is sent
        When NotifyAutoBlowerIntensityStatus.status = 'ENUM_STATUS_OK'
        When NotifyAutoBlowerIntensityStatus.auto_blower_intensity = 'ENUM_AUTO_BLOWER_INTENSITY_LEVEL9'
        When NotifyAutoBlowerIntensityStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyAutoBlowerIntensityStatus is sent
        Then HMI shows:  DI_GUI.transClimateFanSpeed.eTransClimateFanSpeed == 'CLIMATE_FAN_SPEED_UNSPECIFIED' DI_GUI.transClimateFanSpeed.vTransClimateFanSpeed == FALSE DI_GUI.transClimateFanSpeed.iFanSpeed_Value == 0
    
    Scenario:
        When NotifyManualBlowerSpeedStatus.status = 'ENUM_STATUS_OK'
        When NotifyManualBlowerSpeedStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyManualBlowerSpeedStatus.manual_blower_status = 'ENUM_BLOWER_SPEED_AUTO_BLOWER' 
        When NotifyManualBlowerSpeedStatus is sent
        When NotifyAutoBlowerIntensityStatus.status = 'ENUM_STATUS_OK'
        When NotifyAutoBlowerIntensityStatus.auto_blower_intensity = 'ENUM_AUTO_BLOWER_INTENSITY_LEVEL10'
        When NotifyAutoBlowerIntensityStatus.seat_selection = 'ENUM_SEAT_SELECTION_FIRST_ROW_LEFT'
        When NotifyAutoBlowerIntensityStatus is sent
        Then HMI shows:  DI_GUI.transClimateFanSpeed.eTransClimateFanSpeed == 'CLIMATE_FAN_SPEED_UNSPECIFIED' DI_GUI.transClimateFanSpeed.vTransClimateFanSpeed == FALSE DI_GUI.transClimateFanSpeed.iFanSpeed_Value == 0
    

    
