Feature: Frost Indicator
    Scenario: Start server/clients
        When Start server for lifecycle_cccmuserapps_vlca_service
        And Start server for exterior_lighting_service
    
    Scenario:
        When NotifyFogLightStatus.status = 'ENUM_STATUS_OK'
        When NotifyFogLightStatus.fog_light_status = 'ENUM_FOG_LIGHT_STATUS_OFF'
        Then HMI Shows: DI_GUI.indExtLights.bRearFog_IsOn==FALSE DI_GUI.indExtLights.bFrontFog_IsOn==FALSE
    
    Scenario: # Check response to rear fog on
        When NotifyFogLightStatus.status = 'ENUM_STATUS_OK'
        When NotifyFogLightStatus.fog_light_status = 'ENUM_FOG_LIGHT_STATUS_REAR'
        When NotifyFogLightStatus is sent
        Then HMI Shows: DI_GUI.indExtLights.bRearFog_IsOn==TRUE DI_GUI.indExtLights.bFrontFog_IsOn==FALSE
    
    Scenario: # Check response to front fog on
        When NotifyFogLightStatus.status = 'ENUM_STATUS_OK'
        When NotifyFogLightStatus.fog_light_status = 'ENUM_FOG_LIGHT_STATUS_FRONT'
        When NotifyFogLightStatus is sent
        Then HMI Shows: DI_GUI.indExtLights.bRearFog_IsOn==FALSE DI_GUI.indExtLights.bFrontFog_IsOn==TRUE
    
    Scenario: # Check response to both of the fogs on
        When NotifyFogLightStatus.status = 'ENUM_STATUS_OK'
        When NotifyFogLightStatus.fog_light_status = 'ENUM_FOG_LIGHT_STATUS_BOTH'
        When NotifyFogLightStatus is sent
        Then HMI Shows: DI_GUI.indExtLights.bRearFog_IsOn==TRUE DI_GUI.indExtLights.bFrontFog_IsOn==TRUE
    
    Scenario: # Check response to NotifyFogLightStatus.status = ENUM_STATUS_NOT_OK
        When NotifyFogLightStatus.status = 'ENUM_STATUS_NOT_OK'
        When NotifyFogLightStatus.fog_light_status = 'ENUM_FOG_LIGHT_STATUS_BOTH'
        When NotifyFogLightStatus is sent
        Then HMI Shows: DI_GUI.indExtLights.bRearFog_IsOn==FALSE DI_GUI.indExtLights.bFrontFog_IsOn==FALSE
    
    Scenario: # Check response to NotifyFogLightStatus.status = ENUM_STATUS_UNSPECIFIED
        When NotifyFogLightStatus.status = 'ENUM_STATUS_UNSPECIFIED'
        When NotifyFogLightStatus.fog_light_status = 'ENUM_FOG_LIGHT_STATUS_BOTH'
        When NotifyFogLightStatus is sent
        Then HMI Shows: DI_GUI.indExtLights.bRearFog_IsOn==FALSE DI_GUI.indExtLights.bFrontFog_IsOn==FALSE
    
    Scenario: # Check response to NotifyFogLightStatus.status = ENUM_STATUS_DATA_DEGRADED
        When NotifyFogLightStatus.status = 'ENUM_STATUS_DATA_DEGRADED'
        When NotifyFogLightStatus.fog_light_status = 'ENUM_FOG_LIGHT_STATUS_BOTH'
        When NotifyFogLightStatus is sent
        Then HMI Shows: DI_GUI.indExtLights.bRearFog_IsOn==FALSE DI_GUI.indExtLights.bFrontFog_IsOn==FALSE
    
    Scenario: # Check response to NotifyFogLightStatus.status = ENUM_STATUS_DATA_UNRELIABLE
        When NotifyFogLightStatus.status = 'ENUM_STATUS_DATA_UNRELIABLE'
        When NotifyFogLightStatus.fog_light_status = 'ENUM_FOG_LIGHT_STATUS_BOTH'
        When NotifyFogLightStatus is sent
        Then HMI Shows: DI_GUI.indExtLights.bRearFog_IsOn==FALSE DI_GUI.indExtLights.bFrontFog_IsOn==FALSE
    
    Scenario: # Check response to NotifyFogLightStatus.status = ENUM_STATUS_DATA_UNAVAILABLE
        When NotifyFogLightStatus.status = 'ENUM_STATUS_DATA_UNAVAILABLE'
        When NotifyFogLightStatus.fog_light_status = 'ENUM_FOG_LIGHT_STATUS_BOTH'
        When NotifyFogLightStatus is sent
        Then HMI Shows: DI_GUI.indExtLights.bRearFog_IsOn==FALSE DI_GUI.indExtLights.bFrontFog_IsOn==FALSE
    
    Scenario: # Check response to NotifyFogLightStatus.status = ENUM_STATUS_ERROR_INVALID_SERVICE_STATE
        When NotifyFogLightStatus.status = 'ENUM_STATUS_ERROR_INVALID_SERVICE_STATE'
        When NotifyFogLightStatus.fog_light_status = 'ENUM_FOG_LIGHT_STATUS_BOTH'
        When NotifyFogLightStatus is sent
        Then HMI Shows: DI_GUI.indExtLights.bRearFog_IsOn==FALSE DI_GUI.indExtLights.bFrontFog_IsOn==FALSE
    
    Scenario: # Check response to NotifyFogLightStatus.status = ENUM_STATUS_ERROR_INVALID_VEHICLE_STATE
        When NotifyFogLightStatus.status = 'ENUM_STATUS_ERROR_INVALID_VEHICLE_STATE'
        When NotifyFogLightStatus.fog_light_status = 'ENUM_FOG_LIGHT_STATUS_BOTH'
        When NotifyFogLightStatus is sent
        Then HMI Shows: DI_GUI.indExtLights.bRearFog_IsOn==FALSE DI_GUI.indExtLights.bFrontFog_IsOn==FALSE
    
    Scenario: # Check response to NotifyFogLightStatus.status = ENUM_STATUS_ERROR_INVALID_CAR_CONFIGURATION
        When NotifyFogLightStatus.status = 'ENUM_STATUS_ERROR_INVALID_CAR_CONFIGURATION'
        When NotifyFogLightStatus.fog_light_status = 'ENUM_FOG_LIGHT_STATUS_BOTH'
        When NotifyFogLightStatus is sent
        Then HMI Shows: DI_GUI.indExtLights.bRearFog_IsOn==FALSE DI_GUI.indExtLights.bFrontFog_IsOn==FALSE
    
    Scenario: # Check response to NotifyFogLightStatus.status = ENUM_STATUS_ERROR_MISSING_INPUT_FIELD
        When NotifyFogLightStatus.status = 'ENUM_STATUS_ERROR_MISSING_INPUT_FIELD'
        When NotifyFogLightStatus.fog_light_status = 'ENUM_FOG_LIGHT_STATUS_BOTH'
        When NotifyFogLightStatus is sent
        Then HMI Shows: DI_GUI.indExtLights.bRearFog_IsOn==FALSE DI_GUI.indExtLights.bFrontFog_IsOn==FALSE
    
    Scenario: # Check response to NotifyFogLightStatus.status = ENUM_STATUS_ERROR_INVALID_INPUT_FIELD
        When NotifyFogLightStatus.status = 'ENUM_STATUS_ERROR_INVALID_INPUT_FIELD'
        When NotifyFogLightStatus.fog_light_status = 'ENUM_FOG_LIGHT_STATUS_BOTH'
        When NotifyFogLightStatus is sent
        Then HMI Shows: DI_GUI.indExtLights.bRearFog_IsOn==FALSE DI_GUI.indExtLights.bFrontFog_IsOn==FALSE
    
