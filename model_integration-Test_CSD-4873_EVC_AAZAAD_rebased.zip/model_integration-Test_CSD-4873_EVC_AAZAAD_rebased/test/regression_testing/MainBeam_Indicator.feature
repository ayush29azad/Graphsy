    
Feature: MainBeam Indicator 
    Scenario: Start server/clients
        When Start server for exterior_lighting_service
       
    Scenario: Check Initial Value
        When NotifyExtLightIndicatorStatus.status = 'ENUM_STATUS_OK'
        When NotifyExtLightIndicatorStatus.main_beam_status = 'ENUM_MAIN_BEAM_STATUS_OFF'
        Then HMI Shows: topic DI_GUI.indExtLights

    Scenario: SOME-IP notification NotifyExtLightingIndicatorStatus
        When NotifyExtLightIndicatorStatus.status = 'ENUM_STATUS_OK'
        When NotifyExtLightIndicatorStatus.main_beam_status = 'ENUM_MAIN_BEAM_STATUS_OFF'
        When NotifyExtLightIndicatorStatus is sent
        Then HMI Shows: topic DI_GUI.indExtLights is received 0 time since it was last checked

    Scenario: Check ON value when the ENUM_MAIN_BEAM_STATUS_ON
        When NotifyExtLightIndicatorStatus.status = 'ENUM_STATUS_OK'
        When NotifyExtLightIndicatorStatus.main_beam_status = 'ENUM_MAIN_BEAM_STATUS_ON'
        When NotifyExtLightIndicatorStatus is sent
        Then HMI Shows: DI_GUI.indExtLights.eExtLights_BeamStatus == 'EXT_LIGHTS_BEAM_MAIN' 

    Scenario: Check OFF when the ENUM_MAIN_BEAM_STATUS_OFF
        When NotifyExtLightIndicatorStatus.status = 'ENUM_STATUS_OK'
        When NotifyExtLightIndicatorStatus.main_beam_status = 'ENUM_MAIN_BEAM_STATUS_OFF'
        When NotifyExtLightIndicatorStatus is sent
        Then HMI Shows: DI_GUI.indExtLights.eExtLights_BeamStatus == 'EXT_LIGHTS_BEAM_NONE'

    Scenario: Check OFF value when the ENUM_MAIN_BEAM_UNSPECIFIED
        When NotifyExtLightIndicatorStatus.status = 'ENUM_STATUS_OK'
        When NotifyExtLightIndicatorStatus.main_beam_status = 'ENUM_MAIN_BEAM_UNSPECIFIED'
        When NotifyExtLightIndicatorStatus is sent
