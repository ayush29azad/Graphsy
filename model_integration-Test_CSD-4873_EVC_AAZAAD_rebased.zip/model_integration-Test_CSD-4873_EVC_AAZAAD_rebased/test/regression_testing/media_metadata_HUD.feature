Feature:
    Scenario: Start server/clients
        When Start server for lifecycle_cccmuserapps_vlca_service
        And Start server for infotainment_metadata_service 
        And Start server for display_control_service

    Scenario: 
        When NotifyMediaMetaDataInfo.status = 'ENUM_STATUS_OK'  
        When NotifyMediaMetaDataInfo.primary_media_text = "Song Title" 
        When NotifyMediaMetaDataInfo.secondary_media_text = "Artist"
        When NotifyMediaMetaDataInfo is sent
        Then HMI shows:  DI_GUI.transMedia.vTransMedia_Enable == TRUE DI_GUI.transMedia.sTransMediaPrimary_Text == "Song Title" DI_GUI.transMedia.sTransMediaSecondary_Text == "Artis"
        
    Scenario: #Info.status = 'ENUM_STATUS_NOT_OK' - DEFL_Media_Primary_Text shall be set to a string data type that contain no charcaters
        When NotifyMediaMetaDataInfo.status = 'ENUM_STATUS_NOT_OK'  
        When NotifyMediaMetaDataInfo.primary_media_text = "Radio" 
        When NotifyMediaMetaDataInfo.secondary_media_text = "Frequency"
        When NotifyMediaMetaDataInfo is sent
        Then HMI shows:  DI_GUI.transMedia.vTransMedia_Enable == FALSE DI_GUI.transMedia.sTransMediaPrimary_Text == "" DI_GUI.transMedia.sTransMediaSecondary_Text == ""
        
    Scenario: #DEFL_Media_Primary_Text == DEFL_Primary_Media_Text_Prev & DEFL_Media_Secondary_Text == DEFL_Secondary_Media_Text_Prev #DEFL_Media_Transient_Enable = FALSE
        When NotifyMediaMetaDataInfo.status = 'ENUM_STATUS_OK'  
        When NotifyMediaMetaDataInfo.primary_media_text = "Radio"
        When NotifyMediaMetaDataInfo.secondary_media_text = "Frequency"
        When NotifyMediaMetaDataInfo is sent
        Then HMI shows:  DI_GUI.transMedia.vTransMedia_Enable == FALSE DI_GUI.transMedia.sTransMediaPrimary_Text == "Radio" DI_GUI.transMedia.sTransMediaSecondary_Text == "Frequency"
        
    Scenario: #DEFL_Media_Primary_Text != DEFL_Primary_Media_Text_Prev & DEFL_Media_Secondary_Text == DEFL_Secondary_Media_Text_Prev #DEFL_Media_Transient_Enable = TRUE
        When NotifyMediaMetaDataInfo.status = 'ENUM_STATUS_OK'  
        When NotifyMediaMetaDataInfo.primary_media_text = "Song Title"
        When NotifyMediaMetaDataInfo.secondary_media_text = "Frequency"
        When NotifyMediaMetaDataInfo is sent
        Then HMI shows:  DI_GUI.transMedia.vTransMedia_Enable == TRUE DI_GUI.transMedia.sTransMediaPrimary_Text == "Song Title" DI_GUI.transMedia.sTransMediaSecondary_Text == "Frequency"
        
    Scenario: #DEFL_Media_Primary_Text == DEFL_Primary_Media_Text_Prev & DEFL_Media_Secondary_Text != DEFL_Secondary_Media_Text_Prev #DEFL_Media_Transient_Enable = TRUE
        When NotifyMediaMetaDataInfo.status = 'ENUM_STATUS_OK'  
        When NotifyMediaMetaDataInfo.primary_media_text = "Song Title"
        When NotifyMediaMetaDataInfo.secondary_media_text = "Artist"
        When NotifyMediaMetaDataInfo is sent
        Then HMI shows:  DI_GUI.transMedia.vTransMedia_Enable == TRUE DI_GUI.transMedia.sTransMediaPrimary_Text == "Song Title" DI_GUI.transMedia.sTransMediaSecondary_Text == "Artis"
        
    Scenario: #DEFL_Media_Primary_Text == DEFL_Primary_Media_Text_Prev & DEFL_Media_Secondary_Text == DEFL_Secondary_Media_Text_Prev #DEFL_Media_Transient_Enable = FALSE
        When NotifyMediaMetaDataInfo.status = 'ENUM_STATUS_OK'  
        When NotifyMediaMetaDataInfo.primary_media_text = "Song Title"
        When NotifyMediaMetaDataInfo.secondary_media_text = "Artist"
        When NotifyMediaMetaDataInfo is sent
        Then HMI shows:  DI_GUI.transMedia.vTransMedia_Enable == FALSE DI_GUI.transMedia.sTransMediaPrimary_Text == "Song Title" DI_GUI.transMedia.sTransMediaSecondary_Text == "Artis"
        
    Scenario: #DEFL_Media_Primary_Font_Id  & DEFL_Media_Secondary_Font_Id 
        When NotifyMediaMetaDataInfo.status = 'ENUM_STATUS_OK'
        When NotifyMediaMetaDataInfo.primary_media_text = "歌曲名称"
        When NotifyMediaMetaDataInfo.secondary_media_text = "艺术家"
        When NotifyMediaMetaDataInfo.primary_media_font_id = 'ENUM_FONT_ID_PRC'
        When NotifyMediaMetaDataInfo.secondary_media_font_id = 'ENUM_FONT_ID_PRC'
        When NotifyMediaMetaDataInfo is sent
        Then HMI shows:  DI_GUI.transMedia.eTransPrimaryMediaFont_Id == 'ENUM_FONT_ID_PRC' DI_GUI.transMedia.eTransSecondaryMediaFont_Id == 'ENUM_FONT_ID_PRC'
        
    Scenario: #DEFL_Media_Primary_Font_Id  & DEFL_Media_Secondary_Font_Id 
        When NotifyMediaMetaDataInfo.status = 'ENUM_STATUS_OK' 
        When NotifyMediaMetaDataInfo.primary_media_text = "عنوان الأغنية"
        When NotifyMediaMetaDataInfo.secondary_media_text = "فنان"
        When NotifyMediaMetaDataInfo.primary_media_font_id = 'ENUM_FONT_ID_ARABIC'
        When NotifyMediaMetaDataInfo.secondary_media_font_id = 'ENUM_FONT_ID_ARABIC'
        When NotifyMediaMetaDataInfo is sent
        Then HMI shows:  DI_GUI.transMedia.eTransPrimaryMediaFont_Id == 'ENUM_FONT_ID_ARABIC' DI_GUI.transMedia.eTransSecondaryMediaFont_Id == 'ENUM_FONT_ID_ARABIC'
        
    Scenario: #DEFL_Media_Primary_Font_Id  & DEFL_Media_Secondary_Font_Id 
        When NotifyMediaMetaDataInfo.status = 'ENUM_STATUS_OK'
        When NotifyMediaMetaDataInfo.primary_media_text = "歌名"
        When NotifyMediaMetaDataInfo.secondary_media_text = "藝術家" 
        When NotifyMediaMetaDataInfo.primary_media_font_id = 'ENUM_FONT_ID_HKTW'
        When NotifyMediaMetaDataInfo.secondary_media_font_id = 'ENUM_FONT_ID_HKTW'
        When NotifyMediaMetaDataInfo is sent
        Then HMI shows:  DI_GUI.transMedia.eTransPrimaryMediaFont_Id == 'ENUM_FONT_ID_HKTW' DI_GUI.transMedia.eTransSecondaryMediaFont_Id == 'ENUM_FONT_ID_HKTW'
        
    Scenario: #DEFL_Media_Primary_Font_Id  & DEFL_Media_Secondary_Font_Id 
        When NotifyMediaMetaDataInfo.status = 'ENUM_STATUS_OK'
        When NotifyMediaMetaDataInfo.primary_media_text = "शीर्षक गीत"
        When NotifyMediaMetaDataInfo.secondary_media_text = "कलाकार" 
        When NotifyMediaMetaDataInfo.primary_media_font_id = 'ENUM_FONT_ID_INDIC'
        When NotifyMediaMetaDataInfo.secondary_media_font_id = 'ENUM_FONT_ID_INDIC'
        When NotifyMediaMetaDataInfo is sent
        Then HMI shows:  DI_GUI.transMedia.eTransPrimaryMediaFont_Id == 'ENUM_FONT_ID_INDIC' DI_GUI.transMedia.eTransSecondaryMediaFont_Id == 'ENUM_FONT_ID_INDIC'
        
    Scenario: #DEFL_Media_Primary_Font_Id  & DEFL_Media_Secondary_Font_Id 
        When NotifyMediaMetaDataInfo.status = 'ENUM_STATUS_OK' 
        When NotifyMediaMetaDataInfo.primary_media_text = "曲名"
        When NotifyMediaMetaDataInfo.secondary_media_text = "アーティスト"
        When NotifyMediaMetaDataInfo.primary_media_font_id = 'ENUM_FONT_ID_JAPANESE'
        When NotifyMediaMetaDataInfo.secondary_media_font_id = 'ENUM_FONT_ID_JAPANESE'
        When NotifyMediaMetaDataInfo is sent
        Then HMI shows:  DI_GUI.transMedia.eTransPrimaryMediaFont_Id == 'ENUM_FONT_ID_JAPANESE' DI_GUI.transMedia.eTransSecondaryMediaFont_Id == 'ENUM_FONT_ID_JAPANESE'
        
    Scenario: #DEFL_Media_Primary_Font_Id  & DEFL_Media_Secondary_Font_Id 
        When NotifyMediaMetaDataInfo.status = 'ENUM_STATUS_OK'
        When NotifyMediaMetaDataInfo.primary_media_text = "노래 제목"
        When NotifyMediaMetaDataInfo.secondary_media_text = "아티스트" 
        When NotifyMediaMetaDataInfo.primary_media_font_id = 'ENUM_FONT_ID_KOREAN'
        When NotifyMediaMetaDataInfo.secondary_media_font_id = 'ENUM_FONT_ID_KOREAN'
        When NotifyMediaMetaDataInfo is sent
        Then HMI shows:  DI_GUI.transMedia.eTransPrimaryMediaFont_Id == 'ENUM_FONT_ID_KOREAN' DI_GUI.transMedia.eTransSecondaryMediaFont_Id == 'ENUM_FONT_ID_KOREAN'
        
    Scenario: #DEFL_Media_Primary_Font_Id  & DEFL_Media_Secondary_Font_Id 
        When NotifyMediaMetaDataInfo.status = 'ENUM_STATUS_NOT_OK' 
        When NotifyMediaMetaDataInfo.primary_media_text = "歌曲名称"
        When NotifyMediaMetaDataInfo.secondary_media_text = "艺术家"
        When NotifyMediaMetaDataInfo.primary_media_font_id = 'ENUM_FONT_ID_PRC'
        When NotifyMediaMetaDataInfo.secondary_media_font_id = 'ENUM_FONT_ID_PRC'
        When NotifyMediaMetaDataInfo is sent
        Then HMI shows:  DI_GUI.transMedia.eTransPrimaryMediaFont_Id == 'ENUM_FONT_ID_UNSPECIFIED' DI_GUI.transMedia.eTransSecondaryMediaFont_Id == 'ENUM_FONT_ID_UNSPECIFIED'
        
    Scenario: #DEFL_Media_Primary_Font_Id  & DEFL_Media_Secondary_Font_Id 
        When NotifyMediaMetaDataInfo.status = 'ENUM_STATUS_NOT_OK'
        When NotifyMediaMetaDataInfo.primary_media_text = "عنوان الأغنية"
        When NotifyMediaMetaDataInfo.secondary_media_text = "فنان" 
        When NotifyMediaMetaDataInfo.primary_media_font_id = 'ENUM_FONT_ID_ARABIC'
        When NotifyMediaMetaDataInfo.secondary_media_font_id = 'ENUM_FONT_ID_ARABIC'
        When NotifyMediaMetaDataInfo is sent
        Then HMI shows:  DI_GUI.transMedia.eTransPrimaryMediaFont_Id == 'ENUM_FONT_ID_UNSPECIFIED' DI_GUI.transMedia.eTransSecondaryMediaFont_Id == 'ENUM_FONT_ID_UNSPECIFIED'
        
    Scenario: #DEFL_Media_Primary_Font_Id  & DEFL_Media_Secondary_Font_Id 
        When NotifyMediaMetaDataInfo.status = 'ENUM_STATUS_NOT_OK' 
        When NotifyMediaMetaDataInfo.primary_media_text = "歌名"
        When NotifyMediaMetaDataInfo.secondary_media_text = "藝術家"
        When NotifyMediaMetaDataInfo.primary_media_font_id = 'ENUM_FONT_ID_HKTW'
        When NotifyMediaMetaDataInfo.secondary_media_font_id = 'ENUM_FONT_ID_HKTW'
        When NotifyMediaMetaDataInfo is sent
        Then HMI shows:  DI_GUI.transMedia.eTransPrimaryMediaFont_Id == 'ENUM_FONT_ID_UNSPECIFIED' DI_GUI.transMedia.eTransSecondaryMediaFont_Id == 'ENUM_FONT_ID_UNSPECIFIED'
        
    Scenario: #DEFL_Media_Primary_Font_Id  & DEFL_Media_Secondary_Font_Id 
        When NotifyMediaMetaDataInfo.status = 'ENUM_STATUS_NOT_OK' 
        When NotifyMediaMetaDataInfo.primary_media_text = "शीर्षक गीत"
        When NotifyMediaMetaDataInfo.secondary_media_text = "कलाकार"
        When NotifyMediaMetaDataInfo.primary_media_font_id = 'ENUM_FONT_ID_INDIC'
        When NotifyMediaMetaDataInfo.secondary_media_font_id = 'ENUM_FONT_ID_INDIC'
        When NotifyMediaMetaDataInfo is sent
        Then HMI shows:  DI_GUI.transMedia.eTransPrimaryMediaFont_Id == 'ENUM_FONT_ID_UNSPECIFIED' DI_GUI.transMedia.eTransSecondaryMediaFont_Id == 'ENUM_FONT_ID_UNSPECIFIED'
        
    Scenario: #DEFL_Media_Primary_Font_Id  & DEFL_Media_Secondary_Font_Id 
        When NotifyMediaMetaDataInfo.status = 'ENUM_STATUS_NOT_OK' 
        When NotifyMediaMetaDataInfo.primary_media_text = "曲名"
        When NotifyMediaMetaDataInfo.secondary_media_text = "アーティスト"
        When NotifyMediaMetaDataInfo.primary_media_font_id = 'ENUM_FONT_ID_JAPANESE'
        When NotifyMediaMetaDataInfo.secondary_media_font_id = 'ENUM_FONT_ID_JAPANESE'
        When NotifyMediaMetaDataInfo is sent
        Then HMI shows:  DI_GUI.transMedia.eTransPrimaryMediaFont_Id == 'ENUM_FONT_ID_UNSPECIFIED' DI_GUI.transMedia.eTransSecondaryMediaFont_Id == 'ENUM_FONT_ID_UNSPECIFIED'
        
    Scenario: #DEFL_Media_Primary_Font_Id  & DEFL_Media_Secondary_Font_Id 
        When NotifyMediaMetaDataInfo.status = 'ENUM_STATUS_NOT_OK' 
        When NotifyMediaMetaDataInfo.primary_media_text = "노래 제목"
        When NotifyMediaMetaDataInfo.secondary_media_text = "아티스트"
        When NotifyMediaMetaDataInfo.primary_media_font_id = 'ENUM_FONT_ID_KOREAN'
        When NotifyMediaMetaDataInfo.secondary_media_font_id = 'ENUM_FONT_ID_KOREAN'
        When NotifyMediaMetaDataInfo is sent
        Then HMI shows:  DI_GUI.transMedia.eTransPrimaryMediaFont_Id == 'ENUM_FONT_ID_UNSPECIFIED' DI_GUI.transMedia.eTransSecondaryMediaFont_Id == 'ENUM_FONT_ID_UNSPECIFIED'
        
    Scenario: #DEFL_Metadata_Image_Id = NotifyMediaMetaDataInfo.image_id
        When NotifyMediaMetaDataInfo.status = 'ENUM_STATUS_OK' 
        When NotifyMediaMetaDataInfo.primary_media_text = "노래 제목"
        When NotifyMediaMetaDataInfo.secondary_media_text = "아티스트"
        When NotifyMediaMetaDataInfo.primary_media_font_id = 'ENUM_FONT_ID_KOREAN'
        When NotifyMediaMetaDataInfo.secondary_media_font_id = 'ENUM_FONT_ID_KOREAN' 
        When NotifyMediaMetaDataInfo.image_id = "2bdf3625-4354-4eb4-b913-05335a385407"
        When NotifyMediaMetaDataInfo is sent
        Then HMI shows:  DI_GUI.transMedia.sTransImage_Id == "2bdf3625-4354-4eb4-b913-05335a385407"
        
    Scenario: #Info.status = 'ENUM_STATUS_NOT_OK' - DEFL_Metadata_Image_Id shall be set to a string data type that contain no charcaters.
        When NotifyMediaMetaDataInfo.status = 'ENUM_STATUS_NOT_OK' 
        When NotifyMediaMetaDataInfo.primary_media_text = "노래 제목"
        When NotifyMediaMetaDataInfo.secondary_media_text = "아티스트"
        When NotifyMediaMetaDataInfo.primary_media_font_id = 'ENUM_FONT_ID_KOREAN'
        When NotifyMediaMetaDataInfo.secondary_media_font_id = 'ENUM_FONT_ID_KOREAN' 
        When NotifyMediaMetaDataInfo.image_id = "2bdf3625-4354-4eb4-b913-05335a385407"
        When NotifyMediaMetaDataInfo is sent
        Then HMI shows:  DI_GUI.transMedia.sTransImage_Id == ""
    
    Scenario: 
        Given Receive request GetHUDStateRequest
        When GetHUDStateResponse.status = 'ENUM_STATUS_OK'
        When GetHUDStateResponse.hud_type = 'ENUM_HUDTYPE_DRIVER_HUD'
        When GetHUDStateResponse.hud_state = 'ENUM_HUD_STATE_ON'
        When GetHUDStateResponse is sent
    
    Scenario: 
        When NotifyMediaMetaDataInfo.status = 'ENUM_STATUS_OK'  
        When NotifyMediaMetaDataInfo.primary_media_text = "Song Title" 
        When NotifyMediaMetaDataInfo.secondary_media_text = "Artist"
        When NotifyMediaMetaDataInfo is sent
        Then HMI shows:  DI_GUI.transMedia.vTransMedia_Enable == TRUE DI_GUI.transMedia.sTransMediaPrimary_Text == "Song Title" DI_GUI.transMedia.sTransMediaSecondary_Text == "Artis"
        
    Scenario: #Info.status = 'ENUM_STATUS_NOT_OK' - DEFL_Media_Primary_Text shall be set to a string data type that contain no charcaters
        When NotifyMediaMetaDataInfo.status = 'ENUM_STATUS_NOT_OK'  
        When NotifyMediaMetaDataInfo.primary_media_text = "Radio" 
        When NotifyMediaMetaDataInfo.secondary_media_text = "Frequency"
        When NotifyMediaMetaDataInfo is sent
        Then HMI shows:  DI_GUI.transMedia.vTransMedia_Enable == FALSE DI_GUI.transMedia.sTransMediaPrimary_Text == "" DI_GUI.transMedia.sTransMediaSecondary_Text == ""
        
    Scenario: #DEFL_Media_Primary_Text == DEFL_Primary_Media_Text_Prev & DEFL_Media_Secondary_Text == DEFL_Secondary_Media_Text_Prev #DEFL_Media_Transient_Enable = FALSE
        When NotifyMediaMetaDataInfo.status = 'ENUM_STATUS_OK'  
        When NotifyMediaMetaDataInfo.primary_media_text = "Radio"
        When NotifyMediaMetaDataInfo.secondary_media_text = "Frequency"
        When NotifyMediaMetaDataInfo is sent
        Then HMI shows:  DI_GUI.transMedia.vTransMedia_Enable == FALSE DI_GUI.transMedia.sTransMediaPrimary_Text == "Radio" DI_GUI.transMedia.sTransMediaSecondary_Text == "Frequency"
        
    Scenario: #DEFL_Media_Primary_Text != DEFL_Primary_Media_Text_Prev & DEFL_Media_Secondary_Text == DEFL_Secondary_Media_Text_Prev #DEFL_Media_Transient_Enable = TRUE
        When NotifyMediaMetaDataInfo.status = 'ENUM_STATUS_OK'  
        When NotifyMediaMetaDataInfo.primary_media_text = "Song Title"
        When NotifyMediaMetaDataInfo.secondary_media_text = "Frequency"
        When NotifyMediaMetaDataInfo is sent
        Then HMI shows:  DI_GUI.transMedia.vTransMedia_Enable == TRUE DI_GUI.transMedia.sTransMediaPrimary_Text == "Song Title" DI_GUI.transMedia.sTransMediaSecondary_Text == "Frequency"
        
    Scenario: #DEFL_Media_Primary_Text == DEFL_Primary_Media_Text_Prev & DEFL_Media_Secondary_Text != DEFL_Secondary_Media_Text_Prev #DEFL_Media_Transient_Enable = TRUE
        When NotifyMediaMetaDataInfo.status = 'ENUM_STATUS_OK'  
        When NotifyMediaMetaDataInfo.primary_media_text = "Song Title"
        When NotifyMediaMetaDataInfo.secondary_media_text = "Artist"
        When NotifyMediaMetaDataInfo is sent
        Then HMI shows:  DI_GUI.transMedia.vTransMedia_Enable == TRUE DI_GUI.transMedia.sTransMediaPrimary_Text == "Song Title" DI_GUI.transMedia.sTransMediaSecondary_Text == "Artis"
        
    Scenario: #DEFL_Media_Primary_Text == DEFL_Primary_Media_Text_Prev & DEFL_Media_Secondary_Text == DEFL_Secondary_Media_Text_Prev #DEFL_Media_Transient_Enable = FALSE
        When NotifyMediaMetaDataInfo.status = 'ENUM_STATUS_OK'  
        When NotifyMediaMetaDataInfo.primary_media_text = "Song Title"
        When NotifyMediaMetaDataInfo.secondary_media_text = "Artist"
        When NotifyMediaMetaDataInfo is sent
        Then HMI shows:  DI_GUI.transMedia.vTransMedia_Enable == FALSE DI_GUI.transMedia.sTransMediaPrimary_Text == "Song Title" DI_GUI.transMedia.sTransMediaSecondary_Text == "Artis"
        
    Scenario: #DEFL_Media_Primary_Font_Id  & DEFL_Media_Secondary_Font_Id 
        When NotifyMediaMetaDataInfo.status = 'ENUM_STATUS_OK'
        When NotifyMediaMetaDataInfo.primary_media_text = "歌曲名称"
        When NotifyMediaMetaDataInfo.secondary_media_text = "艺术家"
        When NotifyMediaMetaDataInfo.primary_media_font_id = 'ENUM_FONT_ID_PRC'
        When NotifyMediaMetaDataInfo.secondary_media_font_id = 'ENUM_FONT_ID_PRC'
        When NotifyMediaMetaDataInfo is sent
        Then HMI shows:  DI_GUI.transMedia.eTransPrimaryMediaFont_Id == 'ENUM_FONT_ID_PRC' DI_GUI.transMedia.eTransSecondaryMediaFont_Id == 'ENUM_FONT_ID_PRC'
        
    Scenario: #DEFL_Media_Primary_Font_Id  & DEFL_Media_Secondary_Font_Id 
        When NotifyMediaMetaDataInfo.status = 'ENUM_STATUS_OK' 
        When NotifyMediaMetaDataInfo.primary_media_text = "عنوان الأغنية"
        When NotifyMediaMetaDataInfo.secondary_media_text = "فنان"
        When NotifyMediaMetaDataInfo.primary_media_font_id = 'ENUM_FONT_ID_ARABIC'
        When NotifyMediaMetaDataInfo.secondary_media_font_id = 'ENUM_FONT_ID_ARABIC'
        When NotifyMediaMetaDataInfo is sent
        Then HMI shows:  DI_GUI.transMedia.eTransPrimaryMediaFont_Id == 'ENUM_FONT_ID_ARABIC' DI_GUI.transMedia.eTransSecondaryMediaFont_Id == 'ENUM_FONT_ID_ARABIC'
        
    Scenario: #DEFL_Media_Primary_Font_Id  & DEFL_Media_Secondary_Font_Id 
        When NotifyMediaMetaDataInfo.status = 'ENUM_STATUS_OK'
        When NotifyMediaMetaDataInfo.primary_media_text = "歌名"
        When NotifyMediaMetaDataInfo.secondary_media_text = "藝術家" 
        When NotifyMediaMetaDataInfo.primary_media_font_id = 'ENUM_FONT_ID_HKTW'
        When NotifyMediaMetaDataInfo.secondary_media_font_id = 'ENUM_FONT_ID_HKTW'
        When NotifyMediaMetaDataInfo is sent
        Then HMI shows:  DI_GUI.transMedia.eTransPrimaryMediaFont_Id == 'ENUM_FONT_ID_HKTW' DI_GUI.transMedia.eTransSecondaryMediaFont_Id == 'ENUM_FONT_ID_HKTW'
        
    Scenario: #DEFL_Media_Primary_Font_Id  & DEFL_Media_Secondary_Font_Id 
        When NotifyMediaMetaDataInfo.status = 'ENUM_STATUS_OK'
        When NotifyMediaMetaDataInfo.primary_media_text = "शीर्षक गीत"
        When NotifyMediaMetaDataInfo.secondary_media_text = "कलाकार" 
        When NotifyMediaMetaDataInfo.primary_media_font_id = 'ENUM_FONT_ID_INDIC'
        When NotifyMediaMetaDataInfo.secondary_media_font_id = 'ENUM_FONT_ID_INDIC'
        When NotifyMediaMetaDataInfo is sent
        Then HMI shows:  DI_GUI.transMedia.eTransPrimaryMediaFont_Id == 'ENUM_FONT_ID_INDIC' DI_GUI.transMedia.eTransSecondaryMediaFont_Id == 'ENUM_FONT_ID_INDIC'
        
    Scenario: #DEFL_Media_Primary_Font_Id  & DEFL_Media_Secondary_Font_Id 
        When NotifyMediaMetaDataInfo.status = 'ENUM_STATUS_OK' 
        When NotifyMediaMetaDataInfo.primary_media_text = "曲名"
        When NotifyMediaMetaDataInfo.secondary_media_text = "アーティスト"
        When NotifyMediaMetaDataInfo.primary_media_font_id = 'ENUM_FONT_ID_JAPANESE'
        When NotifyMediaMetaDataInfo.secondary_media_font_id = 'ENUM_FONT_ID_JAPANESE'
        When NotifyMediaMetaDataInfo is sent
        Then HMI shows:  DI_GUI.transMedia.eTransPrimaryMediaFont_Id == 'ENUM_FONT_ID_JAPANESE' DI_GUI.transMedia.eTransSecondaryMediaFont_Id == 'ENUM_FONT_ID_JAPANESE'
        
    Scenario: #DEFL_Media_Primary_Font_Id  & DEFL_Media_Secondary_Font_Id 
        When NotifyMediaMetaDataInfo.status = 'ENUM_STATUS_OK'
        When NotifyMediaMetaDataInfo.primary_media_text = "노래 제목"
        When NotifyMediaMetaDataInfo.secondary_media_text = "아티스트" 
        When NotifyMediaMetaDataInfo.primary_media_font_id = 'ENUM_FONT_ID_KOREAN'
        When NotifyMediaMetaDataInfo.secondary_media_font_id = 'ENUM_FONT_ID_KOREAN'
        When NotifyMediaMetaDataInfo is sent
        Then HMI shows:  DI_GUI.transMedia.eTransPrimaryMediaFont_Id == 'ENUM_FONT_ID_KOREAN' DI_GUI.transMedia.eTransSecondaryMediaFont_Id == 'ENUM_FONT_ID_KOREAN'
        
    Scenario: #DEFL_Media_Primary_Font_Id  & DEFL_Media_Secondary_Font_Id 
        When NotifyMediaMetaDataInfo.status = 'ENUM_STATUS_NOT_OK' 
        When NotifyMediaMetaDataInfo.primary_media_text = "歌曲名称"
        When NotifyMediaMetaDataInfo.secondary_media_text = "艺术家"
        When NotifyMediaMetaDataInfo.primary_media_font_id = 'ENUM_FONT_ID_PRC'
        When NotifyMediaMetaDataInfo.secondary_media_font_id = 'ENUM_FONT_ID_PRC'
        When NotifyMediaMetaDataInfo is sent
        Then HMI shows:  DI_GUI.transMedia.eTransPrimaryMediaFont_Id == 'ENUM_FONT_ID_UNSPECIFIED' DI_GUI.transMedia.eTransSecondaryMediaFont_Id == 'ENUM_FONT_ID_UNSPECIFIED'
        
    Scenario: #DEFL_Media_Primary_Font_Id  & DEFL_Media_Secondary_Font_Id 
        When NotifyMediaMetaDataInfo.status = 'ENUM_STATUS_NOT_OK'
        When NotifyMediaMetaDataInfo.primary_media_text = "عنوان الأغنية"
        When NotifyMediaMetaDataInfo.secondary_media_text = "فنان" 
        When NotifyMediaMetaDataInfo.primary_media_font_id = 'ENUM_FONT_ID_ARABIC'
        When NotifyMediaMetaDataInfo.secondary_media_font_id = 'ENUM_FONT_ID_ARABIC'
        When NotifyMediaMetaDataInfo is sent
        Then HMI shows:  DI_GUI.transMedia.eTransPrimaryMediaFont_Id == 'ENUM_FONT_ID_UNSPECIFIED' DI_GUI.transMedia.eTransSecondaryMediaFont_Id == 'ENUM_FONT_ID_UNSPECIFIED'
        
    Scenario: #DEFL_Media_Primary_Font_Id  & DEFL_Media_Secondary_Font_Id 
        When NotifyMediaMetaDataInfo.status = 'ENUM_STATUS_NOT_OK' 
        When NotifyMediaMetaDataInfo.primary_media_text = "歌名"
        When NotifyMediaMetaDataInfo.secondary_media_text = "藝術家"
        When NotifyMediaMetaDataInfo.primary_media_font_id = 'ENUM_FONT_ID_HKTW'
        When NotifyMediaMetaDataInfo.secondary_media_font_id = 'ENUM_FONT_ID_HKTW'
        When NotifyMediaMetaDataInfo is sent
        Then HMI shows:  DI_GUI.transMedia.eTransPrimaryMediaFont_Id == 'ENUM_FONT_ID_UNSPECIFIED' DI_GUI.transMedia.eTransSecondaryMediaFont_Id == 'ENUM_FONT_ID_UNSPECIFIED'
        
    Scenario: #DEFL_Media_Primary_Font_Id  & DEFL_Media_Secondary_Font_Id 
        When NotifyMediaMetaDataInfo.status = 'ENUM_STATUS_NOT_OK' 
        When NotifyMediaMetaDataInfo.primary_media_text = "शीर्षक गीत"
        When NotifyMediaMetaDataInfo.secondary_media_text = "कलाकार"
        When NotifyMediaMetaDataInfo.primary_media_font_id = 'ENUM_FONT_ID_INDIC'
        When NotifyMediaMetaDataInfo.secondary_media_font_id = 'ENUM_FONT_ID_INDIC'
        When NotifyMediaMetaDataInfo is sent
        Then HMI shows:  DI_GUI.transMedia.eTransPrimaryMediaFont_Id == 'ENUM_FONT_ID_UNSPECIFIED' DI_GUI.transMedia.eTransSecondaryMediaFont_Id == 'ENUM_FONT_ID_UNSPECIFIED'
        
    Scenario: #DEFL_Media_Primary_Font_Id  & DEFL_Media_Secondary_Font_Id 
        When NotifyMediaMetaDataInfo.status = 'ENUM_STATUS_NOT_OK' 
        When NotifyMediaMetaDataInfo.primary_media_text = "曲名"
        When NotifyMediaMetaDataInfo.secondary_media_text = "アーティスト"
        When NotifyMediaMetaDataInfo.primary_media_font_id = 'ENUM_FONT_ID_JAPANESE'
        When NotifyMediaMetaDataInfo.secondary_media_font_id = 'ENUM_FONT_ID_JAPANESE'
        When NotifyMediaMetaDataInfo is sent
        Then HMI shows:  DI_GUI.transMedia.eTransPrimaryMediaFont_Id == 'ENUM_FONT_ID_UNSPECIFIED' DI_GUI.transMedia.eTransSecondaryMediaFont_Id == 'ENUM_FONT_ID_UNSPECIFIED'
        
    Scenario: #DEFL_Media_Primary_Font_Id  & DEFL_Media_Secondary_Font_Id 
        When NotifyMediaMetaDataInfo.status = 'ENUM_STATUS_NOT_OK' 
        When NotifyMediaMetaDataInfo.primary_media_text = "노래 제목"
        When NotifyMediaMetaDataInfo.secondary_media_text = "아티스트"
        When NotifyMediaMetaDataInfo.primary_media_font_id = 'ENUM_FONT_ID_KOREAN'
        When NotifyMediaMetaDataInfo.secondary_media_font_id = 'ENUM_FONT_ID_KOREAN'
        When NotifyMediaMetaDataInfo is sent
        Then HMI shows:  DI_GUI.transMedia.eTransPrimaryMediaFont_Id == 'ENUM_FONT_ID_UNSPECIFIED' DI_GUI.transMedia.eTransSecondaryMediaFont_Id == 'ENUM_FONT_ID_UNSPECIFIED'
        
    Scenario: #DEFL_Metadata_Image_Id = NotifyMediaMetaDataInfo.image_id
        When NotifyMediaMetaDataInfo.status = 'ENUM_STATUS_OK' 
        When NotifyMediaMetaDataInfo.primary_media_text = "노래 제목"
        When NotifyMediaMetaDataInfo.secondary_media_text = "아티스트"
        When NotifyMediaMetaDataInfo.primary_media_font_id = 'ENUM_FONT_ID_KOREAN'
        When NotifyMediaMetaDataInfo.secondary_media_font_id = 'ENUM_FONT_ID_KOREAN' 
        When NotifyMediaMetaDataInfo.image_id = "2bdf3625-4354-4eb4-b913-05335a385407"
        When NotifyMediaMetaDataInfo is sent
        Then HMI shows:  DI_GUI.transMedia.sTransImage_Id == "2bdf3625-4354-4eb4-b913-05335a385407"
        
    Scenario: #Info.status = 'ENUM_STATUS_NOT_OK' - DEFL_Metadata_Image_Id shall be set to a string data type that contain no charcaters.
        When NotifyMediaMetaDataInfo.status = 'ENUM_STATUS_NOT_OK' 
        When NotifyMediaMetaDataInfo.primary_media_text = "노래 제목"
        When NotifyMediaMetaDataInfo.secondary_media_text = "아티스트"
        When NotifyMediaMetaDataInfo.primary_media_font_id = 'ENUM_FONT_ID_KOREAN'
        When NotifyMediaMetaDataInfo.secondary_media_font_id = 'ENUM_FONT_ID_KOREAN' 
        When NotifyMediaMetaDataInfo.image_id = "2bdf3625-4354-4eb4-b913-05335a385407"
        When NotifyMediaMetaDataInfo is sent
        Then HMI shows:  DI_GUI.transMedia.sTransImage_Id == ""
        
        
