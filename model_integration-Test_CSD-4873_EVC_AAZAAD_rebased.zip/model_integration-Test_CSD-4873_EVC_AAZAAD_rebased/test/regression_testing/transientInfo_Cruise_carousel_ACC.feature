Feature:

    Scenario: Start server/clients
        When Start server for lifecycle_cccmuserapps_vlca_service
        And Start server for motion_setting_service
        And Start server for steering_wheel_switch_service
        And Start server for cockpit_settings_service
	    And Start server for display_control_service
    
    Scenario: Set Vehicle_State = 'ENUM_STATE_RUNNING'
        Given Receive request GetVLCAStateRequest
        When GetVLCAStateResponse.vlca_state = "ENUM_VLCA_STATE_UNSPECIFIED"
        When GetVLCAStateResponse.vehicle_mode = "ENUM_VEHICLE_MODE_UNSPECIFIED"
        When GetVLCAStateResponse.vehicle_state = "ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL"
        When Send response GetVLCAStateResponse
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_STATE_COMFORT' 
    
    Scenario: 
        Given Receive request GetHUDStateRequest
        When GetHUDStateResponse.status = 'ENUM_STATUS_OK'
        When GetHUDStateResponse.hud_type = 'ENUM_HUDTYPE_DRIVER_HUD'
        When GetHUDStateResponse.hud_state = 'ENUM_HUD_STATE_ON'
        When GetHUDStateResponse is sent
    
    Scenario:
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_READY_TO_ACTIVATE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 0
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 5
        When Send NotifyCruiseConfiguratorModeStatus
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC

    Scenario:
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 1
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 4
        When Send NotifyCruiseConfiguratorModeStatus
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC

    Scenario:
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_FAILURE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 2
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 0
        When Send NotifyCruiseConfiguratorModeStatus
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC
    
    Scenario:
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_ACTIVE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_READY_TO_ACTIVATE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 0
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 5
        When Send NotifyCruiseConfiguratorModeStatus
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC
    
    Scenario:
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_ACTIVE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 1
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 4
        When Send NotifyCruiseConfiguratorModeStatus
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC
    
    Scenario:
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_ACTIVE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_FAILURE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 2
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 0
        When Send NotifyCruiseConfiguratorModeStatus
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC

    Scenario:
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_NOT_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_READY_TO_ACTIVATE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 0
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 5
        When Send NotifyCruiseConfiguratorModeStatus
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC
    
    Scenario:
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_NOT_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 1
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 4
        When Send NotifyCruiseConfiguratorModeStatus
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC
    
    Scenario:
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_NOT_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_FAILURE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 2
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 0
        When Send NotifyCruiseConfiguratorModeStatus
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC

    Scenario: Check Cruise Mode Carousel is updated when 'ENUM_STATE_COMFORT' and 'ENUM_CC_MODE_TYPE_ACC_AVAILABLE' and 'ENUM_DA_FEATURE_SUBSTATE_READY_TO_ACTIVATE'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_READY_TO_ACTIVATE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 5
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 3
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC
    
    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_RUNNING'
        When NotifyVLCAState.vlca_state = "ENUM_VLCA_STATE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_mode = "ENUM_VEHICLE_MODE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_state = "ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL"
        When Send notify NotifyVLCAState
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_VEHICLE_RUNNING' 


    Scenario:Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_ACC_AVAILABLE' and 'ENUM_DA_FEATURE_SUBSTATE_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 4
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 2
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC


    Scenario:Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_ACC_AVAILABLE' and 'ENUM_DA_FEATURE_SUBSTATE_FAILURE'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_FAILURE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 3
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 1
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC

    Scenario:Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_ACC_ACTIVE' and 'ENUM_DA_FEATURE_SUBSTATE_READY_TO_ACTIVATE'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_ACTIVE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_READY_TO_ACTIVATE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 5
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 3
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC == TRUE

    Scenario:Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_ACC_ACTIVE' and 'ENUM_DA_FEATURE_SUBSTATE_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_ACTIVE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 4
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 2
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC

    Scenario: Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_ACC_ACTIVE' and 'ENUM_DA_FEATURE_SUBSTATE_FAILURE'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_ACTIVE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_FAILURE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 3
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 1
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC

    Scenario:Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_ACC_NOT_AVAILABLE' and 'ENUM_DA_FEATURE_SUBSTATE_READY_TO_ACTIVATE'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_NOT_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_READY_TO_ACTIVATE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 5
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 3
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC


    Scenario: Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_ACC_NOT_AVAILABLE' and 'ENUM_DA_FEATURE_SUBSTATE_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_NOT_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 4
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 2
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC

    Scenario: Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_ACC_NOT_AVAILABLE' and 'ENUM_DA_FEATURE_SUBSTATE_FAILURE'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_NOT_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_FAILURE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 3
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 1
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC.vTransCruiseCarousel

    Scenario: Check Cruise Mode Carousel is not updated when 'ENUM_STATE_DUTY'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_NOT_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_FAILURE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 3
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 1
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC
    
    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_STATE_DUTY'
        When NotifyVLCAState.vlca_state = "ENUM_VLCA_STATE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_mode = "ENUM_VEHICLE_MODE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_state = "ENUM_VEHICLE_STATE_DUTY"
        When Send notify NotifyVLCAState
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_VEHICLE_STATE_DUTY' 

    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_RUNNING'
        When NotifyVLCAState.vlca_state = "ENUM_VLCA_STATE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_mode = "ENUM_VEHICLE_MODE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_state = "ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL"
        When Send notify NotifyVLCAState
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_VEHICLE_RUNNING' 


    Scenario: Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_ACC_AVAILABLE' and 'ENUM_DA_FEATURE_SUBSTATE_NORMAL'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_NORMAL' 
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 2
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 0
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC

    Scenario: Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_ACC_ACTIVE' and 'ENUM_DA_FEATURE_SUBSTATE_COUNTRY_NOT_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_ACTIVE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_COUNTRY_NOT_AVAILABLE' 
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 3
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 0
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC

    Scenario: Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_ACC_NOT_AVAILABLE' and 'ENUM_DA_FEATURE_SUBSTATE_SENSOR_BLOCKED'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_NOT_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_SENSOR_BLOCKED' 
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 4
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 0
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC
    
    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_SLEEP'
        When NotifyVLCAState.vlca_state = "ENUM_VLCA_STATE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_mode = "ENUM_VEHICLE_MODE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_state = "ENUM_VEHICLE_STATE_SLEEP"
        When Send notify NotifyVLCAState
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_VEHICLE_SLEEP' 

    Scenario:Check Cruise Mode Carousel is updated when 'ENUM_STATE_SLEEP'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_ACTIVE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 4
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 2
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC
    
    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_RUNNING'
        When NotifyVLCAState.vlca_state = "ENUM_VLCA_STATE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_mode = "ENUM_VEHICLE_MODE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_state = "ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL"
        When Send notify NotifyVLCAState
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_VEHICLE_RUNNING' 

    Scenario: Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_ACC_AVAILABLE' and 'ENUM_DA_FEATURE_SUBSTATE_READY_TO_ACTIVATE'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_READY_TO_ACTIVATE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 0
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 5
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC

    Scenario: Check Cruise Mode Carousel is not updated when status = 'ENUM_STATUS_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC

    Scenario: # Check Cruise Mode Carousel is not updated when status = 'ENUM_STATUS_DATA_DEGRADED'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_DATA_DEGRADED'
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC 

    Scenario: 
        When NotifyCurrentSystemTheme.status = 'ENUM_STATUS_OK'
        When NotifyCurrentSystemTheme.current_system_theme = 'ENUM_CURRENT_THEME_LIGHT'
        When Send notify NotifyCurrentSystemTheme

    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_STATE_COMFORT'
        When NotifyVLCAState.vlca_state = "ENUM_VLCA_STATE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_mode = "ENUM_VEHICLE_MODE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_state = "ENUM_VEHICLE_STATE_COMFORT"
        When Send notify NotifyVLCAState
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_VEHICLE_COMFORT' 
    
    Scenario:
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_READY_TO_ACTIVATE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 0
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 5
        When Send NotifyCruiseConfiguratorModeStatus
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC

    Scenario:
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 1
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 4
        When Send NotifyCruiseConfiguratorModeStatus
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC

    Scenario:
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_FAILURE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 2
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 0
        When Send NotifyCruiseConfiguratorModeStatus
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC
    
    Scenario:
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_ACTIVE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_READY_TO_ACTIVATE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 0
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 5
        When Send NotifyCruiseConfiguratorModeStatus
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC
    
    Scenario:
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_ACTIVE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 1
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 4
        When Send NotifyCruiseConfiguratorModeStatus
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC
    
    Scenario:
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_ACTIVE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_FAILURE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 2
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 0
        When Send NotifyCruiseConfiguratorModeStatus
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC

    Scenario:
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_NOT_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_READY_TO_ACTIVATE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 0
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 5
        When Send NotifyCruiseConfiguratorModeStatus
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC
    
    Scenario:
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_NOT_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 1
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 4
        When Send NotifyCruiseConfiguratorModeStatus
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC
    
    Scenario:
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_NOT_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_FAILURE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 2
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 0
        When Send NotifyCruiseConfiguratorModeStatus
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC

    Scenario: Check Cruise Mode Carousel is updated when 'ENUM_STATE_COMFORT' and 'ENUM_CC_MODE_TYPE_ACC_AVAILABLE' and 'ENUM_DA_FEATURE_SUBSTATE_READY_TO_ACTIVATE'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_READY_TO_ACTIVATE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 5
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 3
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC
    
    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_RUNNING'
        When NotifyVLCAState.vlca_state = "ENUM_VLCA_STATE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_mode = "ENUM_VEHICLE_MODE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_state = "ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL"
        When Send notify NotifyVLCAState
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_VEHICLE_RUNNING' 


    Scenario:Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_ACC_AVAILABLE' and 'ENUM_DA_FEATURE_SUBSTATE_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 4
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 2
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC


    Scenario:Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_ACC_AVAILABLE' and 'ENUM_DA_FEATURE_SUBSTATE_FAILURE'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_FAILURE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 3
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 1
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC

    Scenario:Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_ACC_ACTIVE' and 'ENUM_DA_FEATURE_SUBSTATE_READY_TO_ACTIVATE'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_ACTIVE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_READY_TO_ACTIVATE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 5
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 3
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC == TRUE

    Scenario:Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_ACC_ACTIVE' and 'ENUM_DA_FEATURE_SUBSTATE_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_ACTIVE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 4
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 2
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC

    Scenario: Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_ACC_ACTIVE' and 'ENUM_DA_FEATURE_SUBSTATE_FAILURE'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_ACTIVE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_FAILURE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 3
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 1
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC

    Scenario:Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_ACC_NOT_AVAILABLE' and 'ENUM_DA_FEATURE_SUBSTATE_READY_TO_ACTIVATE'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_NOT_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_READY_TO_ACTIVATE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 5
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 3
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC


    Scenario: Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_ACC_NOT_AVAILABLE' and 'ENUM_DA_FEATURE_SUBSTATE_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_NOT_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 4
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 2
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC

    Scenario: Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_ACC_NOT_AVAILABLE' and 'ENUM_DA_FEATURE_SUBSTATE_FAILURE'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_NOT_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_FAILURE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 3
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 1
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC.vTransCruiseCarousel

    Scenario: Check Cruise Mode Carousel is not updated when 'ENUM_STATE_DUTY'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_NOT_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_FAILURE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 3
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 1
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC
    
    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_STATE_DUTY'
        When NotifyVLCAState.vlca_state = "ENUM_VLCA_STATE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_mode = "ENUM_VEHICLE_MODE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_state = "ENUM_VEHICLE_STATE_DUTY"
        When Send notify NotifyVLCAState
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_VEHICLE_STATE_DUTY' 

    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_RUNNING'
        When NotifyVLCAState.vlca_state = "ENUM_VLCA_STATE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_mode = "ENUM_VEHICLE_MODE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_state = "ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL"
        When Send notify NotifyVLCAState
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_VEHICLE_RUNNING' 


    Scenario: Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_ACC_AVAILABLE' and 'ENUM_DA_FEATURE_SUBSTATE_NORMAL'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_NORMAL' 
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 2
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 0
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC

    Scenario: Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_ACC_ACTIVE' and 'ENUM_DA_FEATURE_SUBSTATE_COUNTRY_NOT_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_ACTIVE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_COUNTRY_NOT_AVAILABLE' 
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 3
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 0
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC

    Scenario: Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_ACC_NOT_AVAILABLE' and 'ENUM_DA_FEATURE_SUBSTATE_SENSOR_BLOCKED'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_NOT_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_SENSOR_BLOCKED' 
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 4
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 0
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC
    
    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_SLEEP'
        When NotifyVLCAState.vlca_state = "ENUM_VLCA_STATE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_mode = "ENUM_VEHICLE_MODE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_state = "ENUM_VEHICLE_STATE_SLEEP"
        When Send notify NotifyVLCAState
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_VEHICLE_SLEEP' 

    Scenario:Check Cruise Mode Carousel is updated when 'ENUM_STATE_SLEEP'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_ACTIVE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 4
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 2
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC
    
    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_RUNNING'
        When NotifyVLCAState.vlca_state = "ENUM_VLCA_STATE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_mode = "ENUM_VEHICLE_MODE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_state = "ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL"
        When Send notify NotifyVLCAState
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_VEHICLE_RUNNING' 

    Scenario: Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_ACC_AVAILABLE' and 'ENUM_DA_FEATURE_SUBSTATE_READY_TO_ACTIVATE'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_READY_TO_ACTIVATE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 0
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 5
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC

    Scenario: Check Cruise Mode Carousel is not updated when status = 'ENUM_STATUS_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC

    Scenario: # Check Cruise Mode Carousel is not updated when status = 'ENUM_STATUS_DATA_DEGRADED'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_DATA_DEGRADED'
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC



    ################################################################################################
    
    Scenario: Go to Navigation mode
        When NotifyFeatureMode.feature_mode = 'ENUM_FEATURE_MODE_CLUSTER'
        And NotifyFeatureMode.status = 'ENUM_STATUS_OK'
        And NotifyFeatureMode is sent
        When NotifyClusterControlLeftState.button_state = 'ENUM_JOYPAD_STATUS_PRESSED'
        And NotifyClusterControlLeftState.status = 'ENUM_STATUS_OK'
        And NotifyClusterControlLeftState is sent
        And wait for 200ms
        And NotifyClusterControlLeftState.button_state = 'ENUM_JOYPAD_STATUS_RELEASED'
        And NotifyClusterControlLeftState.status = 'ENUM_STATUS_OK'
        And NotifyClusterControlLeftState is sent
        When NotifyJoypadOkButtonStatus.button_state = 'ENUM_JOYPAD_STATUS_PRESSED'
        And NotifyJoypadOkButtonStatus.status = 'ENUM_STATUS_OK'
        And NotifyJoypadOkButtonStatus is sent
        And wait for 200ms
        And NotifyJoypadOkButtonStatus.button_state = 'ENUM_JOYPAD_STATUS_RELEASED'
        And NotifyJoypadOkButtonStatus.status = 'ENUM_STATUS_OK'
        And NotifyJoypadOkButtonStatus is sent

    Scenario: 
        When NotifyCurrentSystemTheme.status = 'ENUM_STATUS_OK'
        When NotifyCurrentSystemTheme.current_system_theme = 'ENUM_CURRENT_THEME_DARK'
        When Send notify NotifyCurrentSystemTheme

    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_STATE_COMFORT'
        When NotifyVLCAState.vlca_state = "ENUM_VLCA_STATE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_mode = "ENUM_VEHICLE_MODE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_state = "ENUM_VEHICLE_STATE_COMFORT"
        When Send notify NotifyVLCAState
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_VEHICLE_COMFORT' 
    
    Scenario:
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_READY_TO_ACTIVATE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 0
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 5
        When Send NotifyCruiseConfiguratorModeStatus
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC

    Scenario:
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 1
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 4
        When Send NotifyCruiseConfiguratorModeStatus
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC

    Scenario:
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_FAILURE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 2
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 0
        When Send NotifyCruiseConfiguratorModeStatus
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC
    
    Scenario:
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_ACTIVE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_READY_TO_ACTIVATE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 0
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 5
        When Send NotifyCruiseConfiguratorModeStatus
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC
    
    Scenario:
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_ACTIVE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 1
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 4
        When Send NotifyCruiseConfiguratorModeStatus
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC
    
    Scenario:
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_ACTIVE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_FAILURE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 2
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 0
        When Send NotifyCruiseConfiguratorModeStatus
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC

    Scenario:
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_NOT_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_READY_TO_ACTIVATE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 0
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 5
        When Send NotifyCruiseConfiguratorModeStatus
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC
    
    Scenario:
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_NOT_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 1
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 4
        When Send NotifyCruiseConfiguratorModeStatus
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC
    
    Scenario:
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_NOT_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_FAILURE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 2
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 0
        When Send NotifyCruiseConfiguratorModeStatus
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC

    Scenario: Check Cruise Mode Carousel is updated when 'ENUM_STATE_COMFORT' and 'ENUM_CC_MODE_TYPE_ACC_AVAILABLE' and 'ENUM_DA_FEATURE_SUBSTATE_READY_TO_ACTIVATE'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_READY_TO_ACTIVATE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 5
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 3
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC
    
    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_RUNNING'
        When NotifyVLCAState.vlca_state = "ENUM_VLCA_STATE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_mode = "ENUM_VEHICLE_MODE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_state = "ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL"
        When Send notify NotifyVLCAState
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_VEHICLE_RUNNING' 


    Scenario:Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_ACC_AVAILABLE' and 'ENUM_DA_FEATURE_SUBSTATE_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 4
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 2
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC


    Scenario:Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_ACC_AVAILABLE' and 'ENUM_DA_FEATURE_SUBSTATE_FAILURE'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_FAILURE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 3
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 1
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC

    Scenario:Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_ACC_ACTIVE' and 'ENUM_DA_FEATURE_SUBSTATE_READY_TO_ACTIVATE'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_ACTIVE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_READY_TO_ACTIVATE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 5
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 3
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC == TRUE

    Scenario:Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_ACC_ACTIVE' and 'ENUM_DA_FEATURE_SUBSTATE_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_ACTIVE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 4
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 2
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC

    Scenario: Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_ACC_ACTIVE' and 'ENUM_DA_FEATURE_SUBSTATE_FAILURE'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_ACTIVE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_FAILURE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 3
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 1
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC

    Scenario:Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_ACC_NOT_AVAILABLE' and 'ENUM_DA_FEATURE_SUBSTATE_READY_TO_ACTIVATE'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_NOT_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_READY_TO_ACTIVATE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 5
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 3
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC


    Scenario: Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_ACC_NOT_AVAILABLE' and 'ENUM_DA_FEATURE_SUBSTATE_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_NOT_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 4
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 2
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC

    Scenario: Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_ACC_NOT_AVAILABLE' and 'ENUM_DA_FEATURE_SUBSTATE_FAILURE'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_NOT_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_FAILURE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 3
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 1
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC.vTransCruiseCarousel

    Scenario: Check Cruise Mode Carousel is not updated when 'ENUM_STATE_DUTY'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_NOT_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_FAILURE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 3
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 1
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC
    
    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_STATE_DUTY'
        When NotifyVLCAState.vlca_state = "ENUM_VLCA_STATE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_mode = "ENUM_VEHICLE_MODE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_state = "ENUM_VEHICLE_STATE_DUTY"
        When Send notify NotifyVLCAState
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_VEHICLE_STATE_DUTY' 

    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_RUNNING'
        When NotifyVLCAState.vlca_state = "ENUM_VLCA_STATE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_mode = "ENUM_VEHICLE_MODE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_state = "ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL"
        When Send notify NotifyVLCAState
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_VEHICLE_RUNNING' 


    Scenario: Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_ACC_AVAILABLE' and 'ENUM_DA_FEATURE_SUBSTATE_NORMAL'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_NORMAL' 
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 2
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 0
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC

    Scenario: Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_ACC_ACTIVE' and 'ENUM_DA_FEATURE_SUBSTATE_COUNTRY_NOT_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_ACTIVE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_COUNTRY_NOT_AVAILABLE' 
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 3
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 0
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC

    Scenario: Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_ACC_NOT_AVAILABLE' and 'ENUM_DA_FEATURE_SUBSTATE_SENSOR_BLOCKED'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_NOT_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_SENSOR_BLOCKED' 
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 4
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 0
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC
    
    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_SLEEP'
        When NotifyVLCAState.vlca_state = "ENUM_VLCA_STATE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_mode = "ENUM_VEHICLE_MODE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_state = "ENUM_VEHICLE_STATE_SLEEP"
        When Send notify NotifyVLCAState
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_VEHICLE_SLEEP' 

    Scenario:Check Cruise Mode Carousel is updated when 'ENUM_STATE_SLEEP'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_ACTIVE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 4
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 2
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC
    
    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_RUNNING'
        When NotifyVLCAState.vlca_state = "ENUM_VLCA_STATE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_mode = "ENUM_VEHICLE_MODE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_state = "ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL"
        When Send notify NotifyVLCAState
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_VEHICLE_RUNNING' 

    Scenario: Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_ACC_AVAILABLE' and 'ENUM_DA_FEATURE_SUBSTATE_READY_TO_ACTIVATE'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_READY_TO_ACTIVATE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 0
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 5
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC

    Scenario: Check Cruise Mode Carousel is not updated when status = 'ENUM_STATUS_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC

    Scenario: # Check Cruise Mode Carousel is not updated when status = 'ENUM_STATUS_DATA_DEGRADED'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_DATA_DEGRADED'
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC


    Scenario: 
        When NotifyCurrentSystemTheme.status = 'ENUM_STATUS_OK'
        When NotifyCurrentSystemTheme.current_system_theme = 'ENUM_CURRENT_THEME_LIGHT'
        When Send notify NotifyCurrentSystemTheme

    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_STATE_COMFORT'
        When NotifyVLCAState.vlca_state = "ENUM_VLCA_STATE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_mode = "ENUM_VEHICLE_MODE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_state = "ENUM_VEHICLE_STATE_COMFORT"
        When Send notify NotifyVLCAState
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_VEHICLE_COMFORT' 
    
    Scenario:
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_READY_TO_ACTIVATE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 0
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 5
        When Send NotifyCruiseConfiguratorModeStatus
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC

    Scenario:
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 1
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 4
        When Send NotifyCruiseConfiguratorModeStatus
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC

    Scenario:
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_FAILURE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 2
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 0
        When Send NotifyCruiseConfiguratorModeStatus
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC
    
    Scenario:
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_ACTIVE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_READY_TO_ACTIVATE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 0
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 5
        When Send NotifyCruiseConfiguratorModeStatus
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC
    
    Scenario:
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_ACTIVE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 1
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 4
        When Send NotifyCruiseConfiguratorModeStatus
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC
    
    Scenario:
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_ACTIVE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_FAILURE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 2
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 0
        When Send NotifyCruiseConfiguratorModeStatus
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC

    Scenario:
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_NOT_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_READY_TO_ACTIVATE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 0
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 5
        When Send NotifyCruiseConfiguratorModeStatus
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC
    
    Scenario:
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_NOT_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 1
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 4
        When Send NotifyCruiseConfiguratorModeStatus
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC
    
    Scenario:
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_NOT_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_FAILURE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 2
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 0
        When Send NotifyCruiseConfiguratorModeStatus
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC

    Scenario: Check Cruise Mode Carousel is updated when 'ENUM_STATE_COMFORT' and 'ENUM_CC_MODE_TYPE_ACC_AVAILABLE' and 'ENUM_DA_FEATURE_SUBSTATE_READY_TO_ACTIVATE'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_READY_TO_ACTIVATE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 5
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 3
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC
    
    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_RUNNING'
        When NotifyVLCAState.vlca_state = "ENUM_VLCA_STATE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_mode = "ENUM_VEHICLE_MODE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_state = "ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL"
        When Send notify NotifyVLCAState
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_VEHICLE_RUNNING' 


    Scenario:Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_ACC_AVAILABLE' and 'ENUM_DA_FEATURE_SUBSTATE_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 4
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 2
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC


    Scenario:Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_ACC_AVAILABLE' and 'ENUM_DA_FEATURE_SUBSTATE_FAILURE'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_FAILURE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 3
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 1
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC

    Scenario:Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_ACC_ACTIVE' and 'ENUM_DA_FEATURE_SUBSTATE_READY_TO_ACTIVATE'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_ACTIVE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_READY_TO_ACTIVATE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 5
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 3
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC == TRUE

    Scenario:Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_ACC_ACTIVE' and 'ENUM_DA_FEATURE_SUBSTATE_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_ACTIVE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 4
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 2
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC

    Scenario: Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_ACC_ACTIVE' and 'ENUM_DA_FEATURE_SUBSTATE_FAILURE'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_ACTIVE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_FAILURE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 3
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 1
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC

    Scenario:Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_ACC_NOT_AVAILABLE' and 'ENUM_DA_FEATURE_SUBSTATE_READY_TO_ACTIVATE'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_NOT_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_READY_TO_ACTIVATE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 5
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 3
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC


    Scenario: Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_ACC_NOT_AVAILABLE' and 'ENUM_DA_FEATURE_SUBSTATE_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_NOT_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 4
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 2
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC

    Scenario: Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_ACC_NOT_AVAILABLE' and 'ENUM_DA_FEATURE_SUBSTATE_FAILURE'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_NOT_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_FAILURE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 3
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 1
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC.vTransCruiseCarousel

    Scenario: Check Cruise Mode Carousel is not updated when 'ENUM_STATE_DUTY'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_NOT_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_FAILURE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 3
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 1
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC
    
    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_STATE_DUTY'
        When NotifyVLCAState.vlca_state = "ENUM_VLCA_STATE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_mode = "ENUM_VEHICLE_MODE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_state = "ENUM_VEHICLE_STATE_DUTY"
        When Send notify NotifyVLCAState
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_VEHICLE_STATE_DUTY' 

    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_RUNNING'
        When NotifyVLCAState.vlca_state = "ENUM_VLCA_STATE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_mode = "ENUM_VEHICLE_MODE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_state = "ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL"
        When Send notify NotifyVLCAState
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_VEHICLE_RUNNING' 


    Scenario: Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_ACC_AVAILABLE' and 'ENUM_DA_FEATURE_SUBSTATE_NORMAL'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_NORMAL' 
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 2
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 0
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC

    Scenario: Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_ACC_ACTIVE' and 'ENUM_DA_FEATURE_SUBSTATE_COUNTRY_NOT_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_ACTIVE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_COUNTRY_NOT_AVAILABLE' 
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 3
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 0
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC

    Scenario: Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_ACC_NOT_AVAILABLE' and 'ENUM_DA_FEATURE_SUBSTATE_SENSOR_BLOCKED'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_NOT_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_SENSOR_BLOCKED' 
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 4
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 0
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC
    
    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_SLEEP'
        When NotifyVLCAState.vlca_state = "ENUM_VLCA_STATE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_mode = "ENUM_VEHICLE_MODE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_state = "ENUM_VEHICLE_STATE_SLEEP"
        When Send notify NotifyVLCAState
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_VEHICLE_SLEEP' 

    Scenario:Check Cruise Mode Carousel is updated when 'ENUM_STATE_SLEEP'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_ACTIVE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 4
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 2
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC
    
    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_RUNNING'
        When NotifyVLCAState.vlca_state = "ENUM_VLCA_STATE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_mode = "ENUM_VEHICLE_MODE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_state = "ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL"
        When Send notify NotifyVLCAState
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_VEHICLE_RUNNING' 

    Scenario: Check Cruise Mode Carousel is updated when 'ENUM_STATE_RUNNING' and 'ENUM_CC_MODE_TYPE_ACC_AVAILABLE' and 'ENUM_DA_FEATURE_SUBSTATE_READY_TO_ACTIVATE'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_OK'
        When NotifyCruiseConfiguratorModeStatus.cc_mode = 'ENUM_CC_MODE_TYPE_ACC_AVAILABLE'
        When NotifyCruiseConfiguratorModeStatus.driver_assist_feature_substate = 'ENUM_DA_FEATURE_SUBSTATE_READY_TO_ACTIVATE'
        When NotifyCruiseConfiguratorModeStatus.cc_mode_id = 0
        When NotifyCruiseConfiguratorModeStatus.cc_number_of_modes = 5
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC

    Scenario: Check Cruise Mode Carousel is not updated when status = 'ENUM_STATUS_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_UNSPECIFIED'
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC

    Scenario: # Check Cruise Mode Carousel is not updated when status = 'ENUM_STATUS_DATA_DEGRADED'
        When NotifyCruiseConfiguratorModeStatus.status = 'ENUM_STATUS_DATA_DEGRADED'
        When NotifyCruiseConfiguratorModeStatus is sent
        Then HMI shows: DI_GUI.transCruiseCarousel_ACC 




    

    



    
