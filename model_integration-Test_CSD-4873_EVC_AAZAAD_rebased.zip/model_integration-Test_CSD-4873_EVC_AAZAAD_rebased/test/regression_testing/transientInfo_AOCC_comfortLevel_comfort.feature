Feature: AOCC comfort level

  Scenario: Start server/clients
        When Start server for lifecycle_cccmuserapps_vlca_service
        And Start server for motion_setting_service
        And Start server for steering_wheel_switch_service
        And Start server for cockpit_settings_service
        And Start server for propulsion_service
        And Start server for pps_climate_service
        And Start server for steering_service
        And Start server for display_control_service

    Scenario:
        When GetHUDStateRequest.hud_type = 'ENUM_HUDTYPE_DRIVER_HUD'
        When Send request GetHUDStateRequest

    Scenario: Set Vehicle_State = 'ENUM_STATE_COMFORT'
        Given Receive request GetVLCAStateRequest
        When GetVLCAStateResponse.vlca_state = "ENUM_VLCA_STATE_UNSPECIFIED"
        When GetVLCAStateResponse.vehicle_mode = "ENUM_VEHICLE_MODE_UNSPECIFIED"
        When GetVLCAStateResponse.vehicle_state = "ENUM_VEHICLE_STATE_COMFORT"
        When Send response GetVLCAStateResponse
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_STATE_COMFORT' 
    
    Scenario:
        When NotifyATPCProComfortSetting.status = 'ENUM_STATUS_OK'
        When NotifyATPCProComfortSetting.atpc_pro_comfort_setting = 'ENUM_ATPC_PRO_COMFORT_SETTING_OFF'
        When Send NotifyHeatedSteeringWheelStatus
        Then HMI shows: DI_GUI.transAtpcComfortLevels.eTransAtpcComfortLevel == 'ATPC_COMFORT_OFF'
        Then HMI shows: DI_GUI.transAtpcComfortLevels.vTransAtpcComfortLevel == 'TRUE'

    Scenario:
        When NotifyATPCProComfortSetting.status = 'ENUM_STATUS_OK'
        When NotifyATPCProComfortSetting.atpc_pro_comfort_setting = 'ENUM_ATPC_PRO_COMFORT_SETTING_LOW'
        When Send NotifyHeatedSteeringWheelStatus
        Then HMI shows: DI_GUI.transAtpcComfortLevels.eTransAtpcComfortLevel == 'ATPC_COMFORT_LOW'
        Then HMI shows: DI_GUI.transAtpcComfortLevels.vTransAtpcComfortLevel == 'TRUE'


    Scenario:
        When NotifyATPCProComfortSetting.status = 'ENUM_STATUS_OK'
        When NotifyATPCProComfortSetting.atpc_pro_comfort_setting = 'ENUM_ATPC_PRO_COMFORT_SETTING_MEDIUM'
        When Send NotifyHeatedSteeringWheelStatus
        Then HMI shows: DI_GUI.transAtpcComfortLevels.eTransAtpcComfortLevel == 'ATPC_COMFORT_MEDIUM'
        Then HMI shows: DI_GUI.transAtpcComfortLevels.vTransAtpcComfortLevel == 'TRUE'

    Scenario:
        When NotifyATPCProComfortSetting.status = 'ENUM_STATUS_OK'
        When NotifyATPCProComfortSetting.atpc_pro_comfort_setting = 'ENUM_ATPC_PRO_COMFORT_SETTING_HIGH'
        When Send NotifyHeatedSteeringWheelStatus
        Then HMI shows: DI_GUI.transAtpcComfortLevels.eTransAtpcComfortLevel == 'ATPC_COMFORT_HIGH'
        Then HMI shows: DI_GUI.transAtpcComfortLevels.vTransAtpcComfortLevel == 'TRUE'

   

   
