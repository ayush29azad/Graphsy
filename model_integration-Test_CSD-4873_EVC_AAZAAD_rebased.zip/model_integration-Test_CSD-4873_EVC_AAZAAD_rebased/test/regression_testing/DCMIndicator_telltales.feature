Feature: DCM Indicator

    Scenario: Start server/clients
        When Start server for lifecycle_cccmuserapps_vlca_service
        And Start client for telltale_service
        And Start server for cockpit_settings_service
        And Start server for featureconfig_cccmuserapps_service
    
    Scenario: Set Vehicle_State = 'ENUM_STATE_RUNNING'
        Given Receive request GetVLCAStateRequest
        When GetVLCAStateResponse.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When GetVLCAStateResponse.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When GetVLCAStateResponse.vehicle_state = 'ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL'
        When Send response GetVLCAStateResponse
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_STATE_RUNNING' 

    Scenario: DEFL_DCM_IND = 'DCM_NO_DISPLAY'
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_UNSPECIFIED'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_UNSPECIFIED'
        When SetIndicatorRequest is sent
    
    Scenario: DEFL_DCM_IND = 'DCM_NO_DISPLAY'
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_DCM_COMBINED_YELLOW'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.driverAssistTelltales
    
    Scenario: DEFL_DCM_IND = 'DCM_NO_DISPLAY'
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_DCM_FATIGUE_YELLOW'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.driverAssistTelltales
    
    Scenario: DEFL_DCM_IND = 'DCM_NO_DISPLAY'
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_DCM_DISTRACTION_YELLOW'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.driverAssistTelltales
    
    Scenario: DEFL_DCM_IND = 'DCM_NO_DISPLAY'
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_DCM_DISTRACTION_GREY'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.driverAssistTelltales
    
    Scenario: DEFL_DCM_IND = 'DCM_NO_DISPLAY'
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_DCM_DISTRACTION_GREEN'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.driverAssistTelltales
    
    Scenario: DEFL_DCM_IND = 'DCM_DISTRACTION_GREEN_IND'
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_DCM_DISTRACTION_GREEN'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.driverAssistTelltales
    
    Scenario: DEFL_DCM_IND = 'DCM_DISTRACTION_GREY_IND'
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_DCM_DISTRACTION_GREY'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.driverAssistTelltales
    
    Scenario: DEFL_DCM_IND = 'DCM_DISTRACTION_YELLOW_IND'
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_DCM_DISTRACTION_YELLOW'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.driverAssistTelltales
    
    Scenario: DEFL_DCM_IND = 'DCM_FATIGUE_YELLOW_IND'
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_DCM_FATIGUE_YELLOW'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.driverAssistTelltales
    
    Scenario: DEFL_DCM_IND = 'DCM_COMBINED_YELLOW_IND'
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_DCM_COMBINED_YELLOW'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.driverAssistTelltales
    
    Scenario: DEFL_DCM_IND = 'DCM_COMBINED_YELLOW_IND'
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_DCM_COMBINED_YELLOW'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.driverAssistTelltales
    
    Scenario: DEFL_DCM_IND = 'DCM_FATIGUE_YELLOW_IND'
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_DCM_FATIGUE_YELLOW'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.driverAssistTelltales

    Scenario: DEFL_DCM_IND = 'DCM_DISTRACTION_YELLOW_IND'
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_DCM_DISTRACTION_YELLOW'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.driverAssistTelltales
    
    Scenario: DEFL_DCM_IND = 'DCM_DISTRACTION_GREY_IND'
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_DCM_DISTRACTION_GREY'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.driverAssistTelltales
    
    Scenario: DEFL_DCM_IND = 'DCM_DISTRACTION_GREEN_IND'
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_DCM_DISTRACTION_GREEN'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.driverAssistTelltales
    
    
    
    
