Feature: HV Charging Status
    Scenario: Start server/clients
            When Start server for charging_service
            And Start server for featureconfig_cccmuserapps_service
            And Start server for lifecycle_cccmuserapps_vlca_service
            And Start server for cockpit_settings_service
            And Start server for vehiclemessaging_service

    #### Comfort Mode
    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_STATE_COMFORT'
            When NotifyVLCAState.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
            When NotifyVLCAState.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
            When NotifyVLCAState.vehicle_state = 'ENUM_VEHICLE_STATE_COMFORT'
            When Send notify NotifyVLCAState
            Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_VEHICLE_STATE_COMFORT' 

    ####### ENUM_CHARGE_STATE_INITIALIZING #############
    Scenario:    
        When NotifyChargeState.status = 'ENUM_STATUS_OK'
        When NotifyChargeState.charging_status = 'ENUM_CHARGE_STATE_INITIALIZING'
        When NotifyChargeState.charge_error_state = 'ENUM_CHARGE_ERROR_MODE_NO_ERROR'
        When NotifyChargeState.charging_inlet_state = 'ENUM_CHARGING_INLET_STATE_PLUGGED'
        When Send notify NotifyChargeState
        Then HMI shows: WHITE_CHARGE_BAR
    
    Scenario: 
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_HYBRID_BATTERY_OVERHEAT'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_OFF'
        When SetWarnMsgRequest is sent

    Scenario:  DS_HV_CHARGING_STATUS_INITIALISING display in ODO area
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_HYBRID_BATTERY_OVERHEAT'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_ON'
        When SetWarnMsgRequest is sent
        Then HMI shows: DI_GUI.messageCentre.ENUM_MSG_HYBRID_BATTERY_OVERHEAT
        
    Scenario: 
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_HYBRID_BATTERY_OVERHEAT'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_OFF'
        When SetWarnMsgRequest is sent
        Then HMI shows: DI_GUI.messageCentre.ENUM_MSG_HYBRID_BATTERY_OVERHEAT_OFF
    
    Scenario:  DS_HV_CHARGING_STATUS_INITIALISING display in Message Centre area
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_UNSPECIFIED'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_ON'
        When SetWarnMsgRequest is sent
        Then HMI shows: Charging shown in messagecentre
        
    Scenario:  DS_HV_CHARGING_STATUS_INITIALISING display in Message Centre area
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_UNSPECIFIED'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_OFF'
        When SetWarnMsgRequest is sent
    
##################  Schedule charging Status : Hour & Minute Boundary value Test #################
    #### eChargeState_Status = DS_HV_CHARGING_STATUS_CHARGING_START_12HR_AM  #####
    
    Scenario: 
        When NotifyChargeState.status = 'ENUM_STATUS_OK'
        When NotifyChargeState.charging_status = 'ENUM_CHARGE_STATE_WAITING_TO_CHARGE'
        When NotifyChargeState.charge_error_state = 'ENUM_CHARGE_ERROR_MODE_NO_ERROR'
        When NotifyChargeState.charging_inlet_state = 'ENUM_CHARGING_INLET_STATE_PLUGGED'
        When Send notify NotifyChargeState
    
    Scenario:    
        When NotifyChargeSettings.status = 'ENUM_STATUS_OK'
        When NotifyChargeSettings.charge_type = 'ENUM_CHARGE_TYPE_FIXED_SCHEDULE'
        When Send notify NotifyChargeSettings
        
    Scenario: LOC_TimeDisplay_Format =  12 HR
        When NotifyTimeDisplayFormatStatus.status = 'ENUM_STATUS_OK'
        When NotifyTimeDisplayFormatStatus.time_format = 'ENUM_TIME_DISPLAY_FORMAT_12_HR'
        When Send notify NotifyTimeDisplayFormatStatus 
        
    Scenario: DEFL_ChargingStart_Hours 12 hour pm
        When NotifyPredictedCharge.status = 'ENUM_STATUS_OK'
        When NotifyPredictedCharge.next_charge_start_local_time_seconds = 12352105 
        When Send notify NotifyPredictedCharge
        
    Scenario: DEFL_ChargingStart_Hours 12 hour am
        When NotifyPredictedCharge.status = 'ENUM_STATUS_OK'
        When NotifyPredictedCharge.next_charge_start_local_time_seconds = 123 
        When Send notify NotifyPredictedCharge
        
    Scenario: 
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_HYBRID_BATTERY_OVERHEAT'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_OFF'
        When SetWarnMsgRequest is sent

    Scenario: 
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_HYBRID_BATTERY_OVERHEAT'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_ON'
        When SetWarnMsgRequest is sent
        
    Scenario: LOC_TimeDisplay_Format =  24 HR
        When NotifyTimeDisplayFormatStatus.status = 'ENUM_STATUS_OK'
        When NotifyTimeDisplayFormatStatus.time_format = 'ENUM_TIME_DISPLAY_FORMAT_24_HR'
        When Send notify NotifyTimeDisplayFormatStatus 
    #### ENUM_CHARGE_TYPE_SCHEDULE_PLUS
    Scenario:    
        When NotifyChargeSettings.status = 'ENUM_STATUS_OK'
        When NotifyChargeSettings.charge_type = 'ENUM_CHARGE_TYPE_SCHEDULE_PLUS'
        When Send notify NotifyChargeSettings
    
      Scenario: LOC_TimeDisplay_Format =  12 HR
        When NotifyTimeDisplayFormatStatus.status = 'ENUM_STATUS_OK'
        When NotifyTimeDisplayFormatStatus.time_format = 'ENUM_TIME_DISPLAY_FORMAT_12_HR'
        When Send notify NotifyTimeDisplayFormatStatus 
        
    Scenario: DEFL_ChargingStart_Hours 12 hour pm
        When NotifyPredictedCharge.status = 'ENUM_STATUS_OK'
        When NotifyPredictedCharge.next_charge_start_local_time_seconds = 12351105 
        When Send notify NotifyPredictedCharge

    Scenario: LOC_TimeDisplay_Format =  24 HR
        When NotifyTimeDisplayFormatStatus.status = 'ENUM_STATUS_OK'
        When NotifyTimeDisplayFormatStatus.time_format = 'ENUM_TIME_DISPLAY_FORMAT_24_HR'
        When Send notify NotifyTimeDisplayFormatStatus 
        
    
    #### DUTY Mode
    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_STATE_DUTY'
            When NotifyVLCAState.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
            When NotifyVLCAState.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
            When NotifyVLCAState.vehicle_state = 'ENUM_VEHICLE_STATE_DUTY'
            When Send notify NotifyVLCAState
            Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_VEHICLE_STATE_DUTY' 
                
    # #### RUNNING Mode
    # Scenario: Set Vehicle_State = 'ENUM_VEHICLE_STATE_RUNNING'
    #         When NotifyVLCAState.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
    #         When NotifyVLCAState.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
    #         When NotifyVLCAState.vehicle_state = 'ENUM_VEHICLE_STATE_RUNNING'
    #         When Send notify NotifyVLCAState
    #         Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_VEHICLE_STATE_RUNNING' 
            
    #### Sleep Mode
    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_STATE_SLEEP'
            When NotifyVLCAState.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
            When NotifyVLCAState.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
            When NotifyVLCAState.vehicle_state = 'ENUM_VEHICLE_STATE_SLEEP'
            When Send notify NotifyVLCAState
            Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_VEHICLE_STATE_SLEEP' 
            
    Scenario:  DS_HV_CHARGING_STATUS_INITIALISING display in Message Centre area
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_HYBRID_BATTERY_OVERHEAT'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_OFF'
        When SetWarnMsgRequest is sent
    
#################################### SET VLCA COMFORT TO TEST ALL HV CHARGING SCENARIOS ####################################
    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_STATE_COMFORT'
            When NotifyVLCAState.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
            When NotifyVLCAState.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
            When NotifyVLCAState.vehicle_state = 'ENUM_VEHICLE_STATE_COMFORT'
            When Send notify NotifyVLCAState
                
#################### 382-16 HV Charging Status - DS_HV_CHARGING_STATUS_CHARGING ###################################
#### DS_HV_CHARGING_STATUS_CHARGING display in ODO area ####
    
    Scenario:    
        When NotifyChargeState.status = 'ENUM_STATUS_OK'
        When NotifyChargeState.charging_status = 'ENUM_CHARGE_STATE_CHARGE_IN_PROGRESS'
        When NotifyChargeState.charge_error_state = 'ENUM_CHARGE_ERROR_MODE_NO_ERROR'
        When NotifyChargeState.charging_inlet_state = 'ENUM_CHARGING_INLET_STATE_PLUGGED'
        When Send notify NotifyChargeState
        Then HMI shows: ENUM_CHARGE_STATE_CHARGING_IN_PROGRESS
    
     Scenario:    
        When NotifyChargeSettings.status = 'ENUM_STATUS_OK'
        When NotifyChargeSettings.charge_type = 'ENUM_CHARGE_TYPE_SMART_SCHEDULE'
        When Send notify NotifyChargeSettings
       
    Scenario: 
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_HYBRID_BATTERY_OVERHEAT'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_OFF'
        When SetWarnMsgRequest is sent

    Scenario: 
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_HYBRID_BATTERY_OVERHEAT'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_ON'
        When SetWarnMsgRequest is sent
        
        Scenario: 
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_HYBRID_BATTERY_OVERHEAT'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_OFF'
        When SetWarnMsgRequest is sent
        
#### DS_HV_CHARGING_STATUS_CHARGING display in message centre area ####
        
    Scenario:  DS_HV_CHARGING_STATUS_INITIALISING display in Message Centre area
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_UNSPECIFIED'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_ON'
        When SetWarnMsgRequest is sent
        Then HMI shows: Charging shown in messagecentre
        
    Scenario:  DS_HV_CHARGING_STATUS_INITIALISING display in Message Centre area
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_UNSPECIFIED'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_OFF'
        When SetWarnMsgRequest is sent
        
### OTHER POSSIBLE SCENARIOS FOR CHARGING #####
Scenario:    
        When NotifyChargeState.status = 'ENUM_STATUS_OK'
        When NotifyChargeState.charging_status = 'ENUM_CHARGE_STATE_FORCED_CHARGE_IN_PROGRESS'
        When NotifyChargeState.charge_error_state = 'ENUM_CHARGE_ERROR_MODE_NO_ERROR'
        When NotifyChargeState.charging_inlet_state = 'ENUM_CHARGING_INLET_STATE_PLUGGED'
        When Send notify NotifyChargeState
        Then HMI shows: CHARGING
        
 Scenario:    
        When NotifyChargeSettings.status = 'ENUM_STATUS_OK'
        When NotifyChargeSettings.charge_type = 'ENUM_CHARGE_TYPE_IMMEDIATE'
        When Send notify NotifyChargeSettings
        Then HMI shows: CHARGING
  
  Scenario:
        When NotifyPredictedCharge.status = 'ENUM_STATUS_OK'
        When NotifyPredictedCharge.next_charge_start_local_time_seconds = 2376926 
        When Send notify NotifyPredictedCharge
        Then HMI shows: DI_GUI.chargingInfo.eChargeState_Status == 'DS_HV_CHARGING_STATUS_CHARGING_START_12HR_PM'
#################### 382-16 HV Charging Status - DS_HV_CHARGING_STATUS_COMPLETE ###################################
### DS_HV_CHARGING_STATUS_COMPLETE display in ODO area ###
Scenario:    
        When NotifyChargeState.status = 'ENUM_STATUS_OK'
        When NotifyChargeState.charging_status = 'ENUM_CHARGE_STATE_CHARGE_COMPLETE'
        When NotifyChargeState.charge_error_state = 'ENUM_CHARGE_ERROR_MODE_NO_ERROR'
        When NotifyChargeState.charging_inlet_state = 'ENUM_CHARGING_INLET_STATE_PLUGGED'
        When Send notify NotifyChargeState
        Then HMI shows: WHITE_CHARGE_BAR
          
    Scenario: 
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_HYBRID_BATTERY_OVERHEAT'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_OFF'
        When SetWarnMsgRequest is sent

    Scenario: 
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_HYBRID_BATTERY_OVERHEAT'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_ON'
        When SetWarnMsgRequest is sent
        
        Scenario: 
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_HYBRID_BATTERY_OVERHEAT'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_OFF'
        When SetWarnMsgRequest is sent
        
#### DS_HV_CHARGING_STATUS_COMPLETE display in message centre area ####
        
    Scenario: 
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_UNSPECIFIED'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_ON'
        When SetWarnMsgRequest is sent
        Then HMI shows: Charging shown in messagecentre
        
    Scenario: 
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_UNSPECIFIED'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_OFF'
        When SetWarnMsgRequest is sent
    
 # Test 11
    Scenario:
        When NotifyPredictedCharge.status = 'ENUM_STATUS_OK'
        When NotifyPredictedCharge.next_charge_start_local_time_seconds = 2376926 
        When Send notify NotifyPredictedCharge
        Then HMI shows: DI_GUI.chargingInfo.eChargeState_Status == 'DS_HV_CHARGING_STATUS_CHARGING_START_12HR_PM'
            
#################### 382-16 HV Charging Status - DS_HV_CHARGING_STATUS_WAIT_PWR ###################################
### DS_HV_CHARGING_STATUS_WAIT_PWR display in ODO area ###
Scenario:    
        When NotifyChargeState.status = 'ENUM_STATUS_OK'
        When NotifyChargeState.charging_status = 'ENUM_CHARGE_STATE_WAITING_FOR_CHARGE_STATION'
        When NotifyChargeState.charge_error_state = 'ENUM_CHARGE_ERROR_MODE_NO_ERROR'
        When NotifyChargeState.charging_inlet_state = 'ENUM_CHARGING_INLET_STATE_PLUGGED'
        When Send notify NotifyChargeState
        Then HMI shows: WHITE_CHARGE_BAR
          
    Scenario: 
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_HYBRID_BATTERY_OVERHEAT'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_OFF'
        When SetWarnMsgRequest is sent

    Scenario: 
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_HYBRID_BATTERY_OVERHEAT'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_ON'
        When SetWarnMsgRequest is sent
        
        Scenario: 
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_HYBRID_BATTERY_OVERHEAT'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_OFF'
        When SetWarnMsgRequest is sent
        
#### DS_HV_CHARGING_STATUS_WAIT_PWR display in message centre area ####
        
    Scenario:
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_UNSPECIFIED'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_ON'
        When SetWarnMsgRequest is sent
        Then HMI shows: Charging shown in messagecentre
        
    Scenario: 
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_UNSPECIFIED'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_OFF'
        When SetWarnMsgRequest is sent
        
        
#################### 382-16 HV Charging Status - DS_HV_CHARGING_STATUS_SMART_CHARGING ###################################
### DS_HV_CHARGING_STATUS_SMART_CHARGING display in ODO area ###
Scenario:    
        When NotifyChargeState.status = 'ENUM_STATUS_OK'
        When NotifyChargeState.charging_status = 'ENUM_CHARGE_STATE_CHARGE_IN_PROGRESS'
        When NotifyChargeState.charge_error_state = 'ENUM_CHARGE_ERROR_MODE_NO_ERROR'
        When NotifyChargeState.charging_inlet_state = 'ENUM_CHARGING_INLET_STATE_PLUGGED'
        When Send notify NotifyChargeState
        Then HMI shows: WHITE_CHARGE_BAR
          
    Scenario: 
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_HYBRID_BATTERY_OVERHEAT'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_OFF'
        When SetWarnMsgRequest is sent

    Scenario: 
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_HYBRID_BATTERY_OVERHEAT'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_ON'
        When SetWarnMsgRequest is sent
        
        Scenario: 
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_HYBRID_BATTERY_OVERHEAT'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_OFF'
        When SetWarnMsgRequest is sent
        
#### DS_HV_CHARGING_STATUS_SMART_CHARGING display in message centre area ####
        
    Scenario:
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_UNSPECIFIED'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_ON'
        When SetWarnMsgRequest is sent
        Then HMI shows: Charging shown in messagecentre
        
    Scenario: 
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_UNSPECIFIED'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_OFF'
        When SetWarnMsgRequest is sent
        
####other scenarios ###

   Scenario:    
        When NotifyChargeSettings.status = 'ENUM_STATUS_OK'
        When NotifyChargeSettings.charge_type = 'ENUM_CHARGE_TYPE_FIXED_SCHEDULE'
        When Send notify NotifyChargeSettings
        Then HMI shows: SMART Charging
       
    Scenario:    
        When NotifyChargeSettings.status = 'ENUM_STATUS_OK'
        When NotifyChargeSettings.charge_type = 'ENUM_CHARGE_TYPE_SCHEDULE_PLUS'
        When Send notify NotifyChargeSettings
        Then HMI shows: SMART Charging shown
       
        
#################### 382-16 HV Charging Status - DS_HV_CHARGING_STATUS_ERROR ###################################
### DS_HV_CHARGING_STATUS_ERROR display in ODO area ###
Scenario:    
        When NotifyChargeState.status = 'ENUM_STATUS_OK'
        When NotifyChargeState.charging_status = 'ENUM_CHARGE_STATE_CHARGE_ERROR'
        When NotifyChargeState.charge_error_state = 'ENUM_CHARGE_ERROR_MODE_NO_ERROR'
        When NotifyChargeState.charging_inlet_state = 'ENUM_CHARGING_INLET_STATE_PLUGGED'
        When Send notify NotifyChargeState
        Then HMI shows: WHITE_CHARGE_BAR
          
    Scenario: 
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_HYBRID_BATTERY_OVERHEAT'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_OFF'
        When SetWarnMsgRequest is sent

    Scenario: 
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_HYBRID_BATTERY_OVERHEAT'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_ON'
        When SetWarnMsgRequest is sent
        Then HMI shows: DS_HV_CHARGING_STATUS_ERROR display in ODO area
        
        Scenario: 
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_HYBRID_BATTERY_OVERHEAT'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_OFF'
        When SetWarnMsgRequest is sent
        
#### DS_HV_CHARGING_STATUS_ERROR display in message centre area ####
        
    Scenario:
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_UNSPECIFIED'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_ON'
        When SetWarnMsgRequest is sent
        Then HMI shows: Charging shown in messagecentre
        
    Scenario: 
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_UNSPECIFIED'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_OFF'
        When SetWarnMsgRequest is sent
        
#################### 382-16 HV Charging Status - DS_HV_CHARGING_STATUS_SMART_CHARGING_WAIT ###################################
### DS_HV_CHARGING_STATUS_SMART_CHARGING_WAIT display in ODO area ###
Scenario:    
        When NotifyChargeState.status = 'ENUM_STATUS_OK'
        When NotifyChargeState.charging_status = 'ENUM_CHARGE_STATE_WAITING_TO_CHARGE'
        When NotifyChargeState.charge_error_state = 'ENUM_CHARGE_ERROR_MODE_NO_ERROR'
        When NotifyChargeState.charging_inlet_state = 'ENUM_CHARGING_INLET_STATE_PLUGGED'
        When Send notify NotifyChargeState
        Then HMI shows: WHITE_CHARGE_BAR
          
    Scenario: 
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_HYBRID_BATTERY_OVERHEAT'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_OFF'
        When SetWarnMsgRequest is sent

    Scenario: 
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_HYBRID_BATTERY_OVERHEAT'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_ON'
        When SetWarnMsgRequest is sent
        Then HMI shows: DS_HV_CHARGING_STATUS_SMART_CHARGING_WAIT display in ODO area
        
        Scenario: 
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_HYBRID_BATTERY_OVERHEAT'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_OFF'
        When SetWarnMsgRequest is sent
        
#### DS_HV_CHARGING_STATUS_SMART_CHARGING_WAIT display in message centre area ####
        
    Scenario:
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_UNSPECIFIED'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_ON'
        When SetWarnMsgRequest is sent
        Then HMI shows: SMART_CHARGING_WAIT shown in messagecentre
        
    Scenario: 
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_UNSPECIFIED'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_OFF'
        When SetWarnMsgRequest is sent
        
#################### 382-16 HV Charging Status - DS_HV_CHARGING_STATUS_CHARGING_START_12HR_AMT ###################################
### DS_HV_CHARGING_STATUS_CHARGING_START_12HR_AM is Display with HOUR& & MINUTE part in ODO area
Scenario:    
        When NotifyChargeState.status = 'ENUM_STATUS_OK'
        When NotifyChargeState.charging_status = 'ENUM_CHARGE_STATE_WAITING_TO_CHARGE'
        When NotifyChargeState.charge_error_state = 'ENUM_CHARGE_ERROR_MODE_NO_ERROR'
        When NotifyChargeState.charging_inlet_state = 'ENUM_CHARGING_INLET_STATE_PLUGGED'
        When Send notify NotifyChargeState
        Then HMI shows: WHITE_CHARGE_BAR
          
    Scenario: 
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_HYBRID_BATTERY_OVERHEAT'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_OFF'
        When SetWarnMsgRequest is sent

    Scenario: 
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_HYBRID_BATTERY_OVERHEAT'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_ON'
        When SetWarnMsgRequest is sent
        Then HMI shows: DS_HV_CHARGING_STATUS_SMART_CHARGING_WAIT display in ODO area
        
        Scenario: 
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_HYBRID_BATTERY_OVERHEAT'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_OFF'
        When SetWarnMsgRequest is sent
        
#### DS_HV_CHARGING_STATUS_SMART_CHARGING_WAIT display in message centre area ####
        
    Scenario:
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_UNSPECIFIED'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_ON'
        When SetWarnMsgRequest is sent
        Then HMI shows: SMART_CHARGING_WAIT shown in messagecentre
        
    Scenario: 
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_UNSPECIFIED'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_OFF'
        When SetWarnMsgRequest is sent
    
