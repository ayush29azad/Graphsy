Feature: Auto Engine Start Stop

    Scenario: Start server/clients
        When Start server for lifecycle_cccmuserapps_vlca_service
        And Start client for telltale_service
    
    Scenario: Set Vehicle_State = 'ENUM_STATE_RUNNING'
        Given Receive request GetVLCAStateRequest
        When GetVLCAStateResponse.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When GetVLCAStateResponse.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When GetVLCAStateResponse.vehicle_state = 'ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL'
        When Send response GetVLCAStateResponse
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_STATE_RUNNING' 
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_MIL'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON'
        When SetIndicatorRequest is sent

    Scenario: 
        When GetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_MIL'
        When GetIndicatorRequest is sent
        Then HMI shows: DI_GUI.telltaleService1.bOBD2CheckEngineMIL_IsOn == TRUE

    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_MIL'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetIndicatorRequest is sent

    Scenario: 
        When GetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_MIL'
        When GetIndicatorRequest is sent
        Then HMI shows:  DI_GUI.telltaleService1.bOBD2CheckEngineMIL_IsOn == FALSE
    
    
