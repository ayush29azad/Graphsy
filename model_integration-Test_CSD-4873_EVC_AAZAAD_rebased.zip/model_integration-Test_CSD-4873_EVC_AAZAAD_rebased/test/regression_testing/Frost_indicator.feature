
Feature: Frost Indicator
    Scenario: Start server/clients
        When Start server for lifecycle_cccmuserapps_vlca_service
        And Start server for cockpit_settings_service
        And Start server for climate_service

    Scenario:
        Given Receive request GetTemperatureUnitsRequest
        When GetTemperatureUnitsResponse.status = "ENUM_STATUS_OK"
        When GetTemperatureUnitsResponse.temperature_units = "ENUM_TEMPERATURE_UNITS_CELSIUS"
        When Send response GetTemperatureUnitsResponse
    
    Scenario: 
        When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_NOT_OK'
        When NotifyTemperatureUnitsStatus.temperature_units = 'ENUM_TEMPERATURE_UNITS_CELSIUS'
        When NotifyTemperatureUnitsStatus is sent
    
    Scenario: 
        When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureUnitsStatus.temperature_units = 'ENUM_TEMPERATURE_UNITS_UNSPECIFIED'
        When NotifyTemperatureUnitsStatus is sent
    
    #### Comfort Mode
    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_STATE_COMFORT'
        When NotifyVLCAState.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_state = 'ENUM_VEHICLE_STATE_COMFORT'
        When Send notify NotifyVLCAState
        Then HMI Shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_VEHICLE_STATE_COMFORT' 
    
    Scenario: 
        When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureUnitsStatus.temperature_units = 'ENUM_TEMPERATURE_UNITS_CELSIUS'
        When NotifyTemperatureUnitsStatus is sent
        Then HMI Shows: DI_GUI.outsideTempFrostInd.eOutsideAirTemp_Units == 'OUTSIDETEMP_UNITS_CELSIUS'_iOutsideAirTemp_Value == 263 bFrostIndicator_IsOn == FALSE
    
    Scenario: 
        When NotifyOutsideTemp.status = 'ENUM_STATUS_OK'
        When NotifyOutsideTemp.outsidetemp = 4.6
        When NotifyOutsideTemp is sent
        Then HMI Shows: DI_GUI.outsideTempFrostInd.eOutsideAirTemp_Units == 'OUTSIDETEMP_UNITS_CELSIUS'_iOutsideAirTemp_Value==5_bFrostIndicator_IsOn==FALSE
    
    Scenario: 
        When NotifyOutsideTemp.status = 'ENUM_STATUS_OK'
        When NotifyOutsideTemp.outsidetemp = 4.4
        When NotifyOutsideTemp is sent
        Then HMI Shows: DI_GUI.outsideTempFrostInd.eOutsideAirTemp_Units == 'OUTSIDETEMP_UNITS_CELSIUS'_iOutsideAirTemp_Value==4_bFrostIndicator_IsOn == TRUE
    
    Scenario: 
        When NotifyOutsideTemp.status = 'ENUM_STATUS_OK'
        When NotifyOutsideTemp.outsidetemp = 4.5
        When NotifyOutsideTemp is sent
        Then HMI Shows: DI_GUI.outsideTempFrostInd.eOutsideAirTemp_Units == 'OUTSIDETEMP_UNITS_CELSIUS'_iOutsideAirTemp_Value == 5_bFrostIndicator_IsOn == TRUE
    
    #### Duty Mode
    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_STATE_COMFORT'
        When NotifyVLCAState.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_state = 'ENUM_VEHICLE_STATE_DUTY'
        When Send notify NotifyVLCAState
        When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureUnitsStatus.temperature_units = 'ENUM_TEMPERATURE_UNITS_CELSIUS'
        When NotifyTemperatureUnitsStatus is sent
        Then HMI Shows: DI_GUI.vehicleLifecycleInt.eVehicle_State
    
    #### FULL running Mode
    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_STATE_FULL'
        When NotifyVLCAState.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_state = 'ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL'
        When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureUnitsStatus.temperature_units = 'ENUM_TEMPERATURE_UNITS_CELSIUS'
        When NotifyTemperatureUnitsStatus is sent
        When Send notify NotifyVLCAState
    
    Scenario:
        When NotifyTemperatureUnitsStatus.status = 'ENUM_STATUS_OK'
        When NotifyTemperatureUnitsStatus.temperature_units = 'ENUM_TEMPERATURE_UNITS_FAHRENHEIT'
        When NotifyTemperatureUnitsStatus is sent
        Then HMI Shows: DI_GUI.outsideTempFrostInd.eOutsideAirTemp_Units=='OUTSIDETEMP_UNITS_FAHRENHEIT'_DI_GUI.outsideTempFrostInd.iOutsideAirTemp_Value== 40_DI_GUI.outsideTempFrostInd.bFrostIndicator_IsOn == TRUE
    
    Scenario: 
        When NotifyOutsideTemp.status = 'ENUM_STATUS_OK'
        When NotifyOutsideTemp.outsidetemp = 127.5
        When NotifyOutsideTemp is sent
        Then HMI Shows: DI_GUI.outsideTempFrostInd.eOutsideAirTemp_Units == 'OUTSIDETEMP_UNITS_FAHRENHEIT'.iOutsideAirTemp_Value==262.outsideTempFrostInd.bFrostIndicator_IsOn == FALSE
    
    Scenario: 
        When NotifyOutsideTemp.status = 'ENUM_STATUS_OK'
        When NotifyOutsideTemp.outsidetemp = -127.6
        When NotifyOutsideTemp is sent
        Then HMI Shows: DI_GUI.outsideTempFrostInd.eOutsideAirTemp_Units == 'OUTSIDETEMP_UNITS_FAHRENHEIT'.iOutsideAirTemp_Value==-198.outsideTempFrostInd.bFrostIndicator_IsOn == TRUE
    
    Scenario: 
        When NotifyOutsideTemp.status = 'ENUM_STATUS_OK'
        When NotifyOutsideTemp.outsidetemp = 128.2
        When NotifyOutsideTemp is sent
        Then HMI Shows: DI_GUI.outsideTempFrostInd.eOutsideAirTemp_Units == 'OUTSIDETEMP_UNITS_FAHRENHEIT'.iOutsideAirTemp_Value == 263.bFrostIndicator_IsOn == FALSE
