Feature: Auto Engine Start Stop

    Scenario: Start server/clients
        When Start server for lifecycle_cccmuserapps_vlca_service
        And Start client for telltale_service
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_ENGINE_AUTO_START_STOP_ACTIVE'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetIndicatorRequest is sent

    Scenario: 
        When GetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_ENGINE_AUTO_START_STOP_ACTIVE'
        When GetIndicatorRequest is sent

    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_ENGINE_AUTO_START_STOP_INHIBITED'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON'
        When SetIndicatorRequest is sent

    Scenario: 
        When GetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_ENGINE_AUTO_START_STOP_INHIBITED'
        When GetIndicatorRequest is sent
        Then HMI shows: DI_GUI.telltaleService1.eEngineAutoStartStop == 'ENUM_AUTO_START_STOP_INHIBITED'

    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_ENGINE_AUTO_START_STOP_INHIBITED'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetIndicatorRequest is sent

    Scenario: 
        When GetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_ENGINE_AUTO_START_STOP_INHIBITED'
        When GetIndicatorRequest is sent
        Then HMI shows: DI_GUI.telltaleService1.eEngineAutoStartStop == 'ENUM_AUTO_START_STOP_INHIBITED'

    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_ENGINE_AUTO_START_STOP_OFF'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON'
        When SetIndicatorRequest is sent

    Scenario: 
        When GetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_ENGINE_AUTO_START_STOP_OFF'
        When GetIndicatorRequest is sent
        Then HMI shows: DI_GUI.telltaleService1.eEngineAutoStartStop == 'ENUM_AUTO_START_STOP_OFF' 

    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_ENGINE_AUTO_START_STOP_ACTIVE'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON'
        When SetIndicatorRequest is sent

    Scenario: 
        When GetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_ENGINE_AUTO_START_STOP_ACTIVE'
        When GetIndicatorRequest is sent
        Then HMI shows: DI_GUI.telltaleService1.eEngineAutoStartStop == 'ENUM_AUTO_START_STOP_ACTIVE' 

    
