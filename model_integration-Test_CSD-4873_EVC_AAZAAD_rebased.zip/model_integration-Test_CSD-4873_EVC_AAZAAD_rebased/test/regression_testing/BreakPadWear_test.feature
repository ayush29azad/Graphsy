Feature: Break Pad wear

    Scenario: Start server/clients
        When Start server for lifecycle_cccmuserapps_vlca_service
        And Start client for motion_service
        And Start server for cockpit_settings_service
        And Start server for featureconfig_cccmuserapps_service

    Scenario: Set Vehicle_State = 'ENUM_STATE_RUNNING'
        Given Receive request GetVLCAStateRequest
        When GetVLCAStateResponse.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When GetVLCAStateResponse.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When GetVLCAStateResponse.vehicle_state = 'ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL'
        When Send response GetVLCAStateResponse
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_STATE_RUNNING' 

    Scenario: 
        When NotifyCurrentSystemTheme.status = 'ENUM_STATUS_OK'
        When NotifyCurrentSystemTheme.current_system_theme = 'ENUM_CURRENT_THEME_DARK'
        When Send notify NotifyCurrentSystemTheme
    
    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 28213},{"mdf_id" : 22322}]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 28213, "value" : 2},{"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 22322, "value" : 2}] 
        When Send response GetParamResponse
    
    
    Scenario: 
        When NotifyBrakePadWearStatus.status = 'ENUM_STATUS_OK'  
        When NotifyBrakePadWearStatus.front_brake_pad_wear_status = 'ENUM_BRAKE_PAD_WEAR_STATUS_UNSPECIFIED'
        When NotifyBrakePadWearStatus.rear_brake_pad_wear_status = 'ENUM_BRAKE_PAD_WEAR_STATUS_UNSPECIFIED'
        When NotifyBrakePadWearStatus is sent
        Then HMI shows: DI_GUI
    
    Scenario: 
        When NotifyBrakePadWearStatus.status = 'ENUM_STATUS_OK'  
        When NotifyBrakePadWearStatus.front_brake_pad_wear_status = 'ENUM_BRAKE_PAD_WEAR_STATUS_UNSPECIFIED'
        When NotifyBrakePadWearStatus.rear_brake_pad_wear_status = 'ENUM_BRAKE_PAD_WEAR_STATUS_WORN'
        When NotifyBrakePadWearStatus is sent
        Then HMI shows: DI_GUI

    Scenario: 
        When NotifyBrakePadWearStatus.status = 'ENUM_STATUS_OK'  
        When NotifyBrakePadWearStatus.front_brake_pad_wear_status = 'ENUM_BRAKE_PAD_WEAR_STATUS_OK'
        When NotifyBrakePadWearStatus.rear_brake_pad_wear_status = 'ENUM_BRAKE_PAD_WEAR_STATUS_OK'
        When NotifyBrakePadWearStatus is sent
        Then HMI shows: DI_GUI
    
    Scenario: 
        When NotifyBrakePadWearStatus.status = 'ENUM_STATUS_OK'  
        When NotifyBrakePadWearStatus.front_brake_pad_wear_status = 'ENUM_BRAKE_PAD_WEAR_STATUS_OK'
        When NotifyBrakePadWearStatus.rear_brake_pad_wear_status = 'ENUM_BRAKE_PAD_WEAR_STATUS_WORN'
        When NotifyBrakePadWearStatus is sent
        Then HMI shows: DI_GUI

    Scenario: 
        When NotifyBrakePadWearStatus.status = 'ENUM_STATUS_OK'  
        When NotifyBrakePadWearStatus.front_brake_pad_wear_status = 'ENUM_BRAKE_PAD_WEAR_STATUS_WORN'
        When NotifyBrakePadWearStatus.rear_brake_pad_wear_status = 'ENUM_BRAKE_PAD_WEAR_STATUS_WORN'
        When NotifyBrakePadWearStatus is sent
        Then HMI shows: DI_GUI
    
    Scenario: 
        When NotifyBrakePadWearStatus.status = 'ENUM_STATUS_OK'  
        When NotifyBrakePadWearStatus.front_brake_pad_wear_status = 'ENUM_BRAKE_PAD_WEAR_STATUS_WORN'
        When NotifyBrakePadWearStatus.rear_brake_pad_wear_status = 'ENUM_BRAKE_PAD_WEAR_STATUS_WORN'
        When NotifyBrakePadWearStatus is sent
        Then HMI shows: DI_GUI
    
    Scenario: 
        When NotifyBrakePadWearStatus.status = 'ENUM_STATUS_OK'  
        When NotifyBrakePadWearStatus.front_brake_pad_wear_status = 'ENUM_BRAKE_PAD_WEAR_STATUS_PARTIAL_WORN'
        When NotifyBrakePadWearStatus.rear_brake_pad_wear_status = 'ENUM_BRAKE_PAD_WEAR_STATUS_WORN'
        When NotifyBrakePadWearStatus is sent
        Then HMI shows: DI_GUI
    
    Scenario: 
        When NotifyBrakePadWearStatus.status = 'ENUM_STATUS_OK'  
        When NotifyBrakePadWearStatus.front_brake_pad_wear_status = 'ENUM_BRAKE_PAD_WEAR_STATUS_PARTIAL_WORN'
        When NotifyBrakePadWearStatus.rear_brake_pad_wear_status = 'ENUM_BRAKE_PAD_WEAR_STATUS_PARTIAL_WORN'
        When NotifyBrakePadWearStatus is sent
        Then HMI shows: DI_GUI

    Scenario:
        When restart featureconfig_cccmuserapps_service

    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 28213},{"mdf_id" : 22322}]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 28213, "value" : 2},{"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 22322, "value" : 3}] 
        When Send response GetParamResponse
    
        Scenario: 
        When NotifyBrakePadWearStatus.status = 'ENUM_STATUS_OK'  
        When NotifyBrakePadWearStatus.front_brake_pad_wear_status = 'ENUM_BRAKE_PAD_WEAR_STATUS_UNSPECIFIED'
        When NotifyBrakePadWearStatus.rear_brake_pad_wear_status = 'ENUM_BRAKE_PAD_WEAR_STATUS_UNSPECIFIED'
        When NotifyBrakePadWearStatus is sent
        Then HMI shows: DI_GUI
    
    Scenario: 
        When NotifyBrakePadWearStatus.status = 'ENUM_STATUS_OK'  
        When NotifyBrakePadWearStatus.front_brake_pad_wear_status = 'ENUM_BRAKE_PAD_WEAR_STATUS_UNSPECIFIED'
        When NotifyBrakePadWearStatus.rear_brake_pad_wear_status = 'ENUM_BRAKE_PAD_WEAR_STATUS_WORN'
        When NotifyBrakePadWearStatus is sent
        Then HMI shows: DI_GUI

    Scenario: 
        When NotifyBrakePadWearStatus.status = 'ENUM_STATUS_OK'  
        When NotifyBrakePadWearStatus.front_brake_pad_wear_status = 'ENUM_BRAKE_PAD_WEAR_STATUS_OK'
        When NotifyBrakePadWearStatus.rear_brake_pad_wear_status = 'ENUM_BRAKE_PAD_WEAR_STATUS_OK'
        When NotifyBrakePadWearStatus is sent
        Then HMI shows: DI_GUI
    
    Scenario: 
        When NotifyBrakePadWearStatus.status = 'ENUM_STATUS_OK'  
        When NotifyBrakePadWearStatus.front_brake_pad_wear_status = 'ENUM_BRAKE_PAD_WEAR_STATUS_OK'
        When NotifyBrakePadWearStatus.rear_brake_pad_wear_status = 'ENUM_BRAKE_PAD_WEAR_STATUS_WORN'
        When NotifyBrakePadWearStatus is sent
        Then HMI shows: DI_GUI

    Scenario: 
        When NotifyBrakePadWearStatus.status = 'ENUM_STATUS_OK'  
        When NotifyBrakePadWearStatus.front_brake_pad_wear_status = 'ENUM_BRAKE_PAD_WEAR_STATUS_WORN'
        When NotifyBrakePadWearStatus.rear_brake_pad_wear_status = 'ENUM_BRAKE_PAD_WEAR_STATUS_WORN'
        When NotifyBrakePadWearStatus is sent
        Then HMI shows: DI_GUI
    
    Scenario: 
        When NotifyBrakePadWearStatus.status = 'ENUM_STATUS_OK'  
        When NotifyBrakePadWearStatus.front_brake_pad_wear_status = 'ENUM_BRAKE_PAD_WEAR_STATUS_WORN'
        When NotifyBrakePadWearStatus.rear_brake_pad_wear_status = 'ENUM_BRAKE_PAD_WEAR_STATUS_WORN'
        When NotifyBrakePadWearStatus is sent
        Then HMI shows: DI_GUI
    
    Scenario: 
        When NotifyBrakePadWearStatus.status = 'ENUM_STATUS_OK'  
        When NotifyBrakePadWearStatus.front_brake_pad_wear_status = 'ENUM_BRAKE_PAD_WEAR_STATUS_PARTIAL_WORN'
        When NotifyBrakePadWearStatus.rear_brake_pad_wear_status = 'ENUM_BRAKE_PAD_WEAR_STATUS_WORN'
        When NotifyBrakePadWearStatus is sent
        Then HMI shows: DI_GUI
    
    Scenario: 
        When NotifyBrakePadWearStatus.status = 'ENUM_STATUS_OK'  
        When NotifyBrakePadWearStatus.front_brake_pad_wear_status = 'ENUM_BRAKE_PAD_WEAR_STATUS_PARTIAL_WORN'
        When NotifyBrakePadWearStatus.rear_brake_pad_wear_status = 'ENUM_BRAKE_PAD_WEAR_STATUS_PARTIAL_WORN'
        When NotifyBrakePadWearStatus is sent
        Then HMI shows: DI_GUI
