
Feature: Trailor Indicators 
    Scenario: Start server/clients
        When Start client for telltale_service
        And Start server for lifecycle_cccmuserapps_vlca_service

    #### Sleep Mode
    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_STATE_SLEEP'
        When NotifyVLCAState.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_state = 'ENUM_VEHICLE_STATE_SLEEP'
        When Send notify NotifyVLCAState
        Then HMI Shows:  DI_GUI.vehicleLifecycleInt.eVehicle_State = ENUM_VEHICLE_STATE_SLEEP   

    Scenario: 1: checking sleep state eIndTrailerAndParkAssist  = TRAILER_AND_PARK_ASSIST_NO_DISPLAY
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_UNSPECIFIED'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_UNSPECIFIED'
        When SetIndicatorRequest is sent
        Then HMI Shows:  DI_GUI.genericTelltales.eIndTrailerAndParkAssist == TRAILER_AND_PARK_ASSIST_NO_DISPLAY
    
    #### FULL running Mode
    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_STATE_FULL'
        When NotifyVLCAState.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_state = 'ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL'
        When Send notify NotifyVLCAState

    Scenario: 2: checking eIndTrailerAndParkAssist = PARK_ASSIST_BOTH_IND
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PARK_ASSIST_BOTH_VALID'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON'
        When SetIndicatorRequest is sent
        Then HMI Shows:  DI_GUI.genericTelltales.eIndTrailerAndParkAssist == 'PARK_ASSIST_BOTH_IND'

    Scenario: 3: checking eIndTrailerAndParkAssist = PARK_ASSIST_RIGHT_IND
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PARK_ASSIST_RIGHT_VALID'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON'
        When SetIndicatorRequest is sent
        Then HMI Shows:  DI_GUI.genericTelltales.eIndTrailerAndParkAssist == 'PARK_ASSIST_RIGHT_IND'

    Scenario: 4: checking eIndTrailerAndParkAssist = PARK_ASSIST_LEFT_IND
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PARK_ASSIST_LEFT_VALID'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON'
        When SetIndicatorRequest is sent
        Then HMI Shows:  DI_GUI.genericTelltales.eIndTrailerAndParkAssist == 'PARK_ASSIST_LEFT_IND'

    Scenario: 5: checking eIndTrailerAndParkAssist = PARK_ASSIST_SERACHING_IND
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PARK_ASSIST_SEARCHING'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON'
        When SetIndicatorRequest is sent
        Then HMI Shows:  DI_GUI.genericTelltales.eIndTrailerAndParkAssist == 'PARK_ASSIST_SERACHING_IND'

    Scenario: 6: checking eIndTrailerAndParkAssist = TRAILER_GREEN_IND
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_TRAILER_GREEN'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON'
        When SetIndicatorRequest is sent
        Then HMI Shows:  DI_GUI.genericTelltales.eIndTrailerAndParkAssist == 'TRAILER_GREEN_IND'

    Scenario: 7: checking eIndTrailerAndParkAssist = TRAILER_GREEN_IND
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_TRAILER_GREEN'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetIndicatorRequest is sent
        Then HMI Shows:  DI_GUI.genericTelltales.eIndTrailerAndParkAssist == 'TRAILER_GREEN_IND'

    Scenario: 8: checking eIndTrailerAndParkAssist = PARK_ASSIST_SERACHING_IND
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PARK_ASSIST_SEARCHING'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetIndicatorRequest is sent
        Then HMI Shows:  DI_GUI.genericTelltales.eIndTrailerAndParkAssist == 'PARK_ASSIST_SERACHING_IND'

    Scenario: 9: checking eIndTrailerAndParkAssist = PARK_ASSIST_LEFT_IND
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PARK_ASSIST_LEFT_VALID'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetIndicatorRequest is sent
        Then HMI Shows:  DI_GUI.genericTelltales.eIndTrailerAndParkAssist == 'PARK_ASSIST_LEFT_IND'

    Scenario: 10: checking eIndTrailerAndParkAssist = PARK_ASSIST_BOTH_IND
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PARK_ASSIST_RIGHT_VALID'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetIndicatorRequest is sent
        Then HMI Shows:  DI_GUI.genericTelltales.eIndTrailerAndParkAssist == 'PARK_ASSIST_BOTH_IND'

    Scenario: 11: checking eIndTrailerAndParkAssist = PARK_ASSIST_BOTH_IND
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PARK_ASSIST_BOTH_VALID'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetIndicatorRequest is sent
