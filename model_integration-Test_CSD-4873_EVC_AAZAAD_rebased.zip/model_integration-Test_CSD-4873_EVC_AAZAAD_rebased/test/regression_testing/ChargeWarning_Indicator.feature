Feature: Charge warning Indicators 
    Scenario: Start server/clients
        When Start server for lifecycle_cccmuserapps_vlca_service
        And Start server for featureconfig_cccmuserapps_service
        And Start server for energymanagement_service

    Scenario:
        When NotifyPowerSupplyStatus.status = "ENUM_STATUS_OK"
        When NotifyPowerSupplyStatus.power_supply_status = "ENUM_POWER_SUPPLY_STATUS_UNSPECIFIED"
        When NotifyPowerSupplyStatus is sent

    Scenario:
        When NotifyPowerSupplyStatus.status = "ENUM_STATUS_OK"
        When NotifyPowerSupplyStatus.power_supply_status = "ENUM_POWER_SUPPLY_STATUS_OK"
        When NotifyPowerSupplyStatus is sent
        Then HMI Shows: DI_GUI.miscTelltales.bBatteryNotCharging_IsOn == FALSE

    Scenario:
        When NotifyPowerSupplyStatus.status = "ENUM_STATUS_OK"
        When NotifyPowerSupplyStatus.power_supply_status = "ENUM_POWER_SUPPLY_STATUS_FAULT"
        When NotifyPowerSupplyStatus is sent
        Then HMI Shows: DI_GUI.miscTelltales.bBatteryNotCharging_IsOn == TRUE

    #Check by changing the Notify status.
    Scenario:
        When NotifyPowerSupplyStatus.status = "ENUM_STATUS_DATA_DEGRADED"
        When NotifyPowerSupplyStatus is sent
        Then HMI Shows: DI_GUI.miscTelltales.bBatteryNotCharging_IsOn == FALSE

    Scenario:
        When NotifyPowerSupplyStatus.status = "ENUM_STATUS_DATA_UNRELIABLE"
        When NotifyPowerSupplyStatus is sent

    Scenario:
        When NotifyPowerSupplyStatus.status = "ENUM_STATUS_DATA_UNAVAILABLE"
        When NotifyPowerSupplyStatus is sent

    Scenario:
        When NotifyPowerSupplyStatus.status = "ENUM_STATUS_ERROR_INVALID_VEHICLE_STATE"
        When NotifyPowerSupplyStatus is sent

    Scenario:
        When NotifyPowerSupplyStatus.status = "ENUM_STATUS_ERROR_INVALID_CAR_CONFIGURATION"
        When NotifyPowerSupplyStatus is sent

    Scenario:
        When NotifyPowerSupplyStatus.status = "ENUM_STATUS_ERROR_MISSING_INPUT_FIELD"
        When NotifyPowerSupplyStatus is sent

    Scenario:
        When NotifyPowerSupplyStatus.status = "ENUM_STATUS_ERROR_INVALID_INPUT_FIELD"
        When NotifyPowerSupplyStatus is sent

    Scenario:
        When NotifyPowerSupplyStatus.status = "ENUM_STATUS_NOT_OK"
        When NotifyPowerSupplyStatus is sent

    Scenario:
        When NotifyPowerSupplyStatus.status = "ENUM_STATUS_OK"
        When NotifyPowerSupplyStatus.power_supply_status = "ENUM_POWER_SUPPLY_STATUS_FAULT"
        When NotifyPowerSupplyStatus is sent
        Then HMI Shows: DI_GUI.miscTelltales.bBatteryNotCharging_IsOn == TRUE
