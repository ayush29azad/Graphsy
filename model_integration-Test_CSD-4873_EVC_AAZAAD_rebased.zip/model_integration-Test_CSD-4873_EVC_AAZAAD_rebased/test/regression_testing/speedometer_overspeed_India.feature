Feature:

    Scenario: Start server/clients
        When Start server for lifecycle_cccmuserapps_vlca_service
        And Start server for vehiclespeed_service
        And Start server for featureconfig_cccmuserapps_service
        And Start server for audio_service


    Scenario: Set Vehicle_State = 'ENUM_STATE_RUNNING'
        Given Receive request GetVLCAStateRequest
        When GetVLCAStateResponse.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When GetVLCAStateResponse.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When GetVLCAStateResponse.vehicle_state = 'ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL'
        When Send response GetVLCAStateResponse
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_STATE_RUNNING'
    
    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 28466},{"mdf_id" : 26455},{"mdf_id" : 29060}]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 28466, "value" : 1},{"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 26455, "value" : 2}] 
        When Send response GetParamResponse
        Then HMI shows: DI_GUI.MPH_MODE

    Scenario:
        When NotifyVehicleSpeed.status = 'ENUM_STATUS_OK'
        When NotifyVehicleSpeed.vehicle_speed_raw = 10
        When Send notify NotifyVehicleSpeed
        Then HMI shows: DI_GUI.MPH_MODE 
    
    Scenario:
        When NotifyVehicleSpeed.status = 'ENUM_STATUS_OK'
        When NotifyVehicleSpeed.vehicle_speed_raw = 20
        When Send notify NotifyVehicleSpeed 
        Then HMI shows: DI_GUI.MPH_MODE
    
    Scenario:
        When NotifyVehicleSpeed.status = 'ENUM_STATUS_OK'
        When NotifyVehicleSpeed.vehicle_speed_raw = 30
        When Send notify NotifyVehicleSpeed
        Then HMI shows: DI_GUI.MPH_MODE 
    
    Scenario:
        When NotifyVehicleSpeed.status = 'ENUM_STATUS_OK'
        When NotifyVehicleSpeed.vehicle_speed_raw = 40
        When Send notify NotifyVehicleSpeed
        Then HMI shows: DI_GUI.MPH_MODE
    
    Scenario:
        When NotifyVehicleSpeed.status = 'ENUM_STATUS_OK'
        When NotifyVehicleSpeed.vehicle_speed_raw = 50
        When Send notify NotifyVehicleSpeed
        Then HMI shows: DI_GUI.MPH_MODE
    
    Scenario:
        When NotifyVehicleSpeed.status = 'ENUM_STATUS_OK'
        When NotifyVehicleSpeed.vehicle_speed_raw = 100
        When Send notify NotifyVehicleSpeed
    
    Scenario:
        When NotifyVehicleSpeed.status = 'ENUM_STATUS_OK'
        When NotifyVehicleSpeed.vehicle_speed_raw = 200
        When Send notify NotifyVehicleSpeed
        Then HMI shows: DI_GUI.MPH_MODE
    
    Scenario:
        When NotifyVehicleSpeed.status = 'ENUM_STATUS_OK'
        When NotifyVehicleSpeed.vehicle_speed_raw = 400
        When Send notify NotifyVehicleSpeed
        Then HMI shows: DI_GUI.MPH_MODE

    Scenario:
        When NotifyVehicleSpeed.status = 'ENUM_STATUS_OK'
        When NotifyVehicleSpeed.vehicle_speed_raw = 600
        When Send notify NotifyVehicleSpeed
        Then HMI shows: DI_GUI.MPH_MODE

    Scenario:
        When NotifyVehicleSpeed.status = 'ENUM_STATUS_OK'
        When NotifyVehicleSpeed.vehicle_speed_raw = 800
        When Send notify NotifyVehicleSpeed
        Then HMI shows: DI_GUI.MPH_MODE
    
    Scenario:
        When NotifyVehicleSpeed.status = 'ENUM_STATUS_OK'
        When NotifyVehicleSpeed.vehicle_speed_raw = 1000
        When Send notify NotifyVehicleSpeed
        Then HMI shows: DI_GUI.MPH_MODE

    Scenario:
        When restart featureconfig_cccmuserapps_service
    
    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 28466},{"mdf_id" : 26455}]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 28466, "value" : 2},{"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 26455, "value" : 2}] 
        When Send response GetParamResponse
        Then HMI shows: DI_GUI.KMPH_MODE
    
    Scenario:
        When NotifyVehicleSpeed.status = 'ENUM_STATUS_OK'
        When NotifyVehicleSpeed.vehicle_speed_raw = 10
        When Send notify NotifyVehicleSpeed 
        Then HMI shows: DI_GUI.KMPH_MODE
    
    Scenario:
        When NotifyVehicleSpeed.status = 'ENUM_STATUS_OK'
        When NotifyVehicleSpeed.vehicle_speed_raw = 20
        When Send notify NotifyVehicleSpeed 
        Then HMI shows: DI_GUI.KMPH_MODE
    
    Scenario:
        When NotifyVehicleSpeed.status = 'ENUM_STATUS_OK'
        When NotifyVehicleSpeed.vehicle_speed_raw = 30
        When Send notify NotifyVehicleSpeed 
        Then HMI shows: DI_GUI.KMPH_MODE
    
    Scenario:
        When NotifyVehicleSpeed.status = 'ENUM_STATUS_OK'
        When NotifyVehicleSpeed.vehicle_speed_raw = 40
        When Send notify NotifyVehicleSpeed
        Then HMI shows: DI_GUI.KMPH_MODE
    
    Scenario:
        When NotifyVehicleSpeed.status = 'ENUM_STATUS_OK'
        When NotifyVehicleSpeed.vehicle_speed_raw = 50
        When Send notify NotifyVehicleSpeed
        Then HMI shows: DI_GUI.KMPH_MODE
    
    Scenario:
        When NotifyVehicleSpeed.status = 'ENUM_STATUS_OK'
        When NotifyVehicleSpeed.vehicle_speed_raw = 100
        When Send notify NotifyVehicleSpeed
        Then HMI shows: DI_GUI.KMPH_MODE
        
    Scenario:
        When NotifyVehicleSpeed.status = 'ENUM_STATUS_OK'
        When NotifyVehicleSpeed.vehicle_speed_raw = 200
        When Send notify NotifyVehicleSpeed
        Then HMI shows: DI_GUI.KMPH_MODE
    
    Scenario:
        When NotifyVehicleSpeed.status = 'ENUM_STATUS_OK'
        When NotifyVehicleSpeed.vehicle_speed_raw = 400
        When Send notify NotifyVehicleSpeed
        Then HMI shows: DI_GUI.KMPH_MODE

    Scenario:
        When NotifyVehicleSpeed.status = 'ENUM_STATUS_OK'
        When NotifyVehicleSpeed.vehicle_speed_raw = 600
        When Send notify NotifyVehicleSpeed
        Then HMI shows: DI_GUI.KMPH_MODE

    Scenario:
        When NotifyVehicleSpeed.status = 'ENUM_STATUS_OK'
        When NotifyVehicleSpeed.vehicle_speed_raw = 800
        When Send notify NotifyVehicleSpeed
        Then HMI shows: DI_GUI.KMPH_MODE
    
    Scenario:
        When NotifyVehicleSpeed.status = 'ENUM_STATUS_OK'
        When NotifyVehicleSpeed.vehicle_speed_raw = 1000
        When Send notify NotifyVehicleSpeed
        Then HMI shows: DI_GUI.KMPH_MODE
    
    Scenario:
        When NotifyVehicleSpeed.status = 'ENUM_STATUS_OK'
        When NotifyVehicleSpeed.vehicle_speed_raw = 10000
        When Send notify NotifyVehicleSpeed
        Then HMI shows: DI_GUI.KMPH_MODE
    
    Scenario:
        When NotifyVehicleSpeed.status = 'ENUM_STATUS_OK'
        When NotifyVehicleSpeed.vehicle_speed_raw = 20000
        When Send notify NotifyVehicleSpeed
        Then HMI shows: DI_GUI.KMPH_MODE
    
    Scenario:
        When NotifyVehicleSpeed.status = 'ENUM_STATUS_OK'
        When NotifyVehicleSpeed.vehicle_speed_raw = 70000
        When Send notify NotifyVehicleSpeed
        Then HMI shows: DI_GUI.KMPH_MODE
    
    Scenario:
        When NotifyVehicleSpeed.status = 'ENUM_STATUS_OK'
        When NotifyVehicleSpeed.vehicle_speed_raw = 80000
        When Send notify NotifyVehicleSpeed
    
    Scenario:
        When NotifyVehicleSpeed.status = 'ENUM_STATUS_OK'
        When NotifyVehicleSpeed.vehicle_speed_raw = 81000
        When Send notify NotifyVehicleSpeed
        Then HMI shows: DI_GUI.KMPH_MODE
    
    Scenario:
        When NotifyVehicleSpeed.status = 'ENUM_STATUS_OK'
        When NotifyVehicleSpeed.vehicle_speed_raw = 90000
        When Send notify NotifyVehicleSpeed
        Then HMI shows: DI_GUI.KMPH_MODE
    
    Scenario:
        When NotifyVehicleSpeed.status = 'ENUM_STATUS_OK'
        When NotifyVehicleSpeed.vehicle_speed_raw = 100000
        When Send notify NotifyVehicleSpeed
        Then HMI shows: DI_GUI.KMPH_MODE
