Feature:

    Scenario: Start server/clients
        When Start server for lifecycle_cccmuserapps_vlca_service
        And Start server for motion_service
        And Start server for featureconfig_cccmuserapps_service
        And Start server for pps_climate_service

    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 295}]
        When GetParamResponse.status = 'ENUM_STATUS_CCF_OK'
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 295, "value" : 66} ]
        When Send response GetParamResponse
        Then HMI shows: Screenshot
    
    Scenario:
        When NotifyVLCAState.vehicle_state = 'ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL' 
        When NotifyVLCAState.vehicle_mode = 'ENUM_VEHICLE_MODE_NORMAL'
        When NotifyVLCAState is sent
    
    Scenario:
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_LIM_CRUISE'
        When SetCombinedIndicatorRequest is sent

    Scenario:
        When NotifyATPCMode.status = 'ENUM_STATUS_OK'
        When NotifyATPCMode.current_atpc_status = 'ENUM_OFFROAD_DRIVERASSISTANCE_ATPC_ON'
        When NotifyATPCMode.atpc_indicate_colour = 'ENUM_OFFROAD_DRIVERASSISTANCE_INDICATION_ATPC_DESCENT_CONTROL_COLOUR_1'
        When NotifyATPCMode.atpc_set_speed_value = 15000 
        When NotifyATPCMode is sent
        Then HMI shows: Screenshot 

    Scenario:
        When wait for 1000msec

    Scenario:
        When NotifyATPCMode.status = 'ENUM_STATUS_OK'
        When NotifyATPCMode.current_atpc_status = 'ENUM_OFFROAD_DRIVERASSISTANCE_ATPC_ON'
        When NotifyATPCMode.atpc_indicate_colour = 'ENUM_OFFROAD_DRIVERASSISTANCE_INDICATION_ATPC_DESCENT_CONTROL_COLOUR_2'
        When NotifyATPCMode.atpc_set_speed_value = 3000 
        When NotifyATPCMode is sent
        Then HMI shows: Screenshot 

    Scenario:
        When wait for 1000msec
    
    Scenario:
        When NotifyVehiclePreconditionState.status = 'ENUM_STATUS_OK'
        When NotifyVehiclePreconditionState.precondition_indicator_state = 'ENUM_PRECON_INDICATOR_STATE_ACTIVE_CABIN_VENTING'
        When Send notify NotifyVehiclePreconditionState

    Scenario:
        When NotifyATPCMode.status = 'ENUM_STATUS_OK'
        When NotifyATPCMode.current_atpc_status = 'ENUM_OFFROAD_DRIVERASSISTANCE_ATPC_ON'
        When NotifyATPCMode.atpc_indicate_colour = 'ENUM_OFFROAD_DRIVERASSISTANCE_INDICATION_ATPC_DESCENT_CONTROL_COLOUR_3'
        When NotifyATPCMode.atpc_set_speed_value = 2000
        When NotifyATPCMode is sent
        Then HMI shows: Screenshot

    Scenario:
        When wait for 1000msec

    Scenario:
        When NotifyATPCMode.status = 'ENUM_STATUS_OK'
        When NotifyATPCMode.current_atpc_status = 'ENUM_OFFROAD_DRIVERASSISTANCE_ATPC_ON'
        When NotifyATPCMode.atpc_indicate_colour = 'ENUM_OFFROAD_DRIVERASSISTANCE_INDICATION_ATPC_FULL_FUNCTION_COLOUR_1'
        When NotifyATPCMode.atpc_set_speed_value = 15000
        When NotifyATPCMode is sent
        Then HMI shows: Screenshot

    Scenario:
        When wait for 1000msec

    Scenario:
        When NotifyATPCMode.status = 'ENUM_STATUS_OK'
        When NotifyATPCMode.current_atpc_status = 'ENUM_OFFROAD_DRIVERASSISTANCE_ATPC_ON'
        When NotifyATPCMode.atpc_indicate_colour = 'ENUM_OFFROAD_DRIVERASSISTANCE_INDICATION_ATPC_FULL_FUNCTION_COLOUR_2'
        When NotifyATPCMode.atpc_set_speed_value = 3000
        When NotifyATPCMode is sent
        Then HMI shows: Screenshot

    Scenario:
        When wait for 1000msec
    
    Scenario:
        When NotifyVehiclePreconditionState.status = 'ENUM_STATUS_OK'
        When NotifyVehiclePreconditionState.precondition_indicator_state = 'ENUM_PRECON_INDICATOR_STATE_ACTIVE_CABIN_VENTING'
        When Send notify NotifyVehiclePreconditionState

    Scenario:
        When NotifyATPCMode.status = 'ENUM_STATUS_OK'
        When NotifyATPCMode.current_atpc_status = 'ENUM_OFFROAD_DRIVERASSISTANCE_ATPC_ON'
        When NotifyATPCMode.atpc_indicate_colour = 'ENUM_OFFROAD_DRIVERASSISTANCE_INDICATION_ATPC_FULL_FUNCTION_COLOUR_3'
        When NotifyATPCMode.atpc_set_speed_value = 1000
        When NotifyATPCMode is sent
        Then HMI shows: Screenshot
    
    Scenario:
        When wait for 1000msec
    
    Scenario:
        When NotifyATPCMode.status = 'ENUM_STATUS_OK'
        When NotifyATPCMode.current_atpc_status = 'ENUM_OFFROAD_DRIVERASSISTANCE_ATPC_OFF'
        When NotifyATPCMode.atpc_indicate_colour = 'ENUM_OFFROAD_DRIVERASSISTANCE_INDICATION_ATPC_FULL_FUNCTION_COLOUR_3'
        When NotifyATPCMode.atpc_set_speed_value = 1000
        When NotifyATPCMode is sent
        Then HMI shows: Screenshot

    Scenario:
        When wait for 1000msec


    Scenario:
        When NotifyHDCMode.status = 'ENUM_STATUS_OK'
        When NotifyHDCMode.current_hdc_status = 'ENUM_OFFROAD_DRIVERASSISTANCE_HDC_ON'
        When NotifyHDCMode.hdc_indicate_colour = 'ENUM_OFFROAD_DRIVERASSISTANCE_INDICATION_HDC_COLOUR_1'
        When NotifyHDCMode.hdc_set_speed_value = 15000 
        When NotifyHDCMode is sent
        Then HMI shows: Screenshot 

    Scenario:
        When wait for 1000msec

    Scenario:
        When NotifyHDCMode.status = 'ENUM_STATUS_OK'
        When NotifyHDCMode.current_hdc_status = 'ENUM_OFFROAD_DRIVERASSISTANCE_HDC_ON'
        When NotifyHDCMode.hdc_indicate_colour = 'ENUM_OFFROAD_DRIVERASSISTANCE_INDICATION_HDC_COLOUR_2'
        When NotifyHDCMode.hdc_set_speed_value = 2000 
        When NotifyHDCMode is sent
        Then HMI shows: Screenshot 

    Scenario:
        When wait for 1000msec
    
    Scenario:
        When NotifyVehiclePreconditionState.status = 'ENUM_STATUS_OK'
        When NotifyVehiclePreconditionState.precondition_indicator_state = 'ENUM_PRECON_INDICATOR_STATE_ACTIVE_CABIN_VENTING'
        When Send notify NotifyVehiclePreconditionState

    Scenario:
        When NotifyHDCMode.status = 'ENUM_STATUS_OK'
        When NotifyHDCMode.current_hdc_status = 'ENUM_OFFROAD_DRIVERASSISTANCE_HDC_ON'
        When NotifyHDCMode.hdc_indicate_colour = 'ENUM_OFFROAD_DRIVERASSISTANCE_INDICATION_HDC_COLOUR_3'
        When NotifyHDCMode.hdc_set_speed_value = 5000
        When NotifyHDCMode is sent
        Then HMI shows: Screenshot

    Scenario:
        When wait for 1000msec
    
    Scenario:
        When NotifyHDCMode.status = 'ENUM_STATUS_OK'
        When NotifyHDCMode.current_hdc_status = 'ENUM_OFFROAD_DRIVERASSISTANCE_HDC_OFF'
        When NotifyHDCMode.hdc_indicate_colour = 'ENUM_OFFROAD_DRIVERASSISTANCE_INDICATION_COLOUR_OFF'
        When NotifyHDCMode.hdc_set_speed_value = 5000
        When NotifyHDCMode is sent
        Then HMI shows: Screenshot
