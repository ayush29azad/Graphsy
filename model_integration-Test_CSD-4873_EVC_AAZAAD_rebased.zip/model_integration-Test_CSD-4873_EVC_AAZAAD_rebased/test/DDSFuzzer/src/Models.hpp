#include <CombinedTopicsPubSubTypes.h>

#ifdef CUSTOM_DDS_MANAGER
#include "dds_helper/DDSEntityManager.hpp"
#else
#include <DDSManager.hpp>
using DDSManager = jlr::cccm::di::dds::DDSManager;
using DDSManagerInterface = jlr::cccm::di::dds::DDSManagerInterface;
#endif

#include "RandomGenerator.hpp"

class ITestModel
{
public:
#ifdef CUSTOM_DDS_MANAGER
  virtual void init(DDSEntityManager* manager) = 0;
#else
  virtual void init(DDSManagerInterface* manager) = 0;
#endif
  virtual void update_data(RandomDataGenerator& generator) = 0;

  virtual void sendSignal() = 0;

  virtual ~ITestModel() = default;
};

template <typename PubSubType>
class TestModel : public ITestModel
{
protected:
  size_t num_sent = 0LL;
  typename PubSubType::type data_;
  std::string type_name;

#ifdef CUSTOM_DDS_MANAGER
protected:
  DataWriter* writer_ = nullptr;
  DDSEntityManager* manager_ = nullptr;

public:
  void init(DDSEntityManager* manager) override
  {
    TypeSupport type_(new PubSubType());
    // should tell the type of data it is sending
    // optionally allow to set a specific topic name
    writer_ = manager->create_writer(type_);
    type_name = type_->getName();
    manager_ = manager;
  }

  ~TestModel()
  {
    if (writer_ != nullptr)
    {
      manager_->delete_writer(writer_);
      writer_ = nullptr;
    }
  }

#else
protected:
  DDSManagerInterface* manager_ = nullptr;

public:
  void init(DDSManagerInterface* manager) override
  {
    type_name = std::string(PubSubType().getName());
    manager->register_publisher(type_name, new PubSubType());
    manager_ = manager;
  }

#endif

public:
  void init_data(typename PubSubType::type& data)
  {
    data_ = data;
  }

  // To be defined specific to the type
  void update_data(RandomDataGenerator& generator) override;

  void sendSignal() override
  {
#ifdef CUSTOM_DDS_MANAGER
    writer_->write(&data_);
#else
    manager_->send_data(&data_, type_name);
#endif
    std::cout << "[" << type_name << "]" << " Message sent: " << ++num_sent << '\n';
  }
};
