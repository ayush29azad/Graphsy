#ifndef DATA_RECEIVERS_HPP
#define DATA_RECEIVERS_HPP

#include <fastdds/dds/domain/DomainParticipant.hpp>
#include <fastdds/dds/domain/DomainParticipantListener.hpp>
#include <fastdds/dds/domain/DomainParticipantFactory.hpp>
#include <fastdds/dds/publisher/DataWriter.hpp>
#include <fastdds/dds/publisher/DataWriterListener.hpp>
#include <fastdds/dds/publisher/qos/DataWriterQos.hpp>
#include <fastdds/dds/publisher/Publisher.hpp>
#include <fastdds/dds/topic/TypeSupport.hpp>
#include <fastdds/rtps/transport/shared_mem/SharedMemTransportDescriptor.h>
#include <fastdds/dds/subscriber/DataReader.hpp>
#include <fastdds/dds/subscriber/DataReaderListener.hpp>
#include <fastdds/dds/subscriber/qos/DataReaderQos.hpp>
#include <fastdds/dds/subscriber/SampleInfo.hpp>
#include <fastdds/dds/subscriber/Subscriber.hpp>
#include <fastdds/dds/core/condition/WaitSet.hpp>

#include <unordered_map>

using namespace eprosima::fastdds::dds;
using namespace eprosima::fastdds::rtps;

char const* return_code_to_string(eprosima::fastrtps::types::ReturnCode_t return_code)
{
  switch (return_code())
  {
    case eprosima::fastrtps::types::ReturnCode_t::RETCODE_OK:
      return "RETCODE_OK";
    case eprosima::fastrtps::types::ReturnCode_t::RETCODE_ERROR:
      return "RETCODE_ERROR";
    case eprosima::fastrtps::types::ReturnCode_t::RETCODE_UNSUPPORTED:
      return "RETCODE_UNSUPPORTED";
    case eprosima::fastrtps::types::ReturnCode_t::RETCODE_BAD_PARAMETER:
      return "RETCODE_BAD_PARAMETER";
    case eprosima::fastrtps::types::ReturnCode_t::RETCODE_PRECONDITION_NOT_MET:
      return "RETCODE_PRECONDITION_NOT_MET";
    case eprosima::fastrtps::types::ReturnCode_t::RETCODE_OUT_OF_RESOURCES:
      return "RETCODE_OUT_OF_RESOURCES";
    case eprosima::fastrtps::types::ReturnCode_t::RETCODE_NOT_ENABLED:
      return "RETCODE_NOT_ENABLED";
    case eprosima::fastrtps::types::ReturnCode_t::RETCODE_IMMUTABLE_POLICY:
      return "RETCODE_IMMUTABLE_POLICY";
    case eprosima::fastrtps::types::ReturnCode_t::RETCODE_INCONSISTENT_POLICY:
      return "RETCODE_INCONSISTENT_POLICY";
    case eprosima::fastrtps::types::ReturnCode_t::RETCODE_ALREADY_DELETED:
      return "RETCODE_ALREADY_DELETED";
    case eprosima::fastrtps::types::ReturnCode_t::RETCODE_TIMEOUT:
      return "RETCODE_TIMEOUT";
    case eprosima::fastrtps::types::ReturnCode_t::RETCODE_NO_DATA:
      return "RETCODE_NO_DATA";
    case eprosima::fastrtps::types::ReturnCode_t::RETCODE_ILLEGAL_OPERATION:
      return "RETCODE_ILLEGAL_OPERATION";
    case eprosima::fastrtps::types::ReturnCode_t::RETCODE_NOT_ALLOWED_BY_SECURITY:
      return "RETCODE_NOT_ALLOWED_BY_SECURITY";
    default:
      return "UNKNOWN_RETCODE";
  }
}

template <typename DataObjectType>
class DDSDataReceiver : public DataReaderListener
{
private:
  std::function<void(DataObjectType*, SampleInfo*)> callback_;
  DataObjectType data;
  SampleInfo info;

public:
  void register_callback(std::function<void(DataObjectType*, SampleInfo*)> callback)
  {
    this->callback_ = callback;
  }

  void on_data_available(DataReader* reader)
  {
    ReturnCode_t retcode = reader->read_next_sample(&data, &info);
    if (retcode == ReturnCode_t::RETCODE_OK)
    {
      this->callback_(&data, &info);
    }
    else
    {
      std::cerr << "Error while reading data" << '\n';
    }
  }

  void deregister_callback()
  {
    this->callback_ = nullptr;
  }
};

class DDSGenericDataReceiver : public DataReaderListener
{
private:
  std::unordered_map<DataReader*, std::function<void(void*, SampleInfo*)>> callback_;
  std::unordered_map<DataReader*, ReadCondition*> m_read_condition;
  WaitSet waitset_;
  SampleInfo info;

public:
  void on_data_available(DataReader* reader)
  {
    void* data = reader->type()->createData();

    ReturnCode_t retcode = reader->read_next_sample(data, &info);
    if (retcode == ReturnCode_t::RETCODE_OK)
    {
      if (this->callback_.count(reader))
      {
        this->callback_[reader](data, &info);
      }
      else
      {
        std::cerr << "No callback registered for reader on topic: " << reader->type()->getName() << '\n';
      }
    }
    else
    {
      std::cerr << "Error while reading data for reader on topic: " << reader->type()->getName() << '\n';
    }

    reader->type()->deleteData(data);
  }

  // void register_callback(DataReader* reader, std::function<void (void *, SampleInfo*)> callback)
  // {
  //     this->callback_[reader] = callback;
  // }

  // void deregister_callback(DataReader* reader)
  // {
  //     this->callback_[reader] = nullptr;
  // }

  void attach(DataReader* reader, bool as_listener, std::function<void(void*, SampleInfo*)> callback)
  {
    if (this->callback_.count(reader) > 0)
    {
      std::cout << "DataReader already attached to receiver. Skipping..." << std::endl;
      return;
    }

    this->callback_[reader] = callback;

    if (as_listener)
    {
      reader->set_listener(this);
    }
    else
    {
      ReadCondition* condition =
          reader->create_readcondition(NOT_READ_SAMPLE_STATE, ANY_VIEW_STATE, ANY_INSTANCE_STATE);
      m_read_condition[reader] = condition;
      waitset_.attach_condition(*condition);
    }
  }

  void detach(DataReader* reader)
  {
    if (this->callback_.count(reader) == 0)
    {
      std::cout << "DataReader not attached to receiver. Cannot detach..." << std::endl;
      return;
    }

    if (m_read_condition.count(reader))
    {
      ReadCondition* condition = m_read_condition[reader];
      waitset_.detach_condition(*condition);
      reader->delete_readcondition(condition);
    }
    reader->set_listener(nullptr);

    this->callback_[reader] = nullptr;
  }

  // exits after a given timeout
  void main_loop(Duration_t timeout = Duration_t::INFINITE_SECONDS)  // can be renamed to start ?
  {
    while (true)
    {
      ConditionSeq active_conditions;
      ReturnCode_t ret = waitset_.wait(active_conditions, timeout);

      if (ret == ReturnCode_t::RETCODE_OK)
      {
        for (Condition* cond : active_conditions)
        {
          ReadCondition* condition = static_cast<ReadCondition*>(cond);
          DataReader* reader = condition->get_datareader();
          on_data_available(reader);
        }
      }
      else if (ret == ReturnCode_t::RETCODE_TIMEOUT)
      {
        break;
      }
    }
  }
};

class TopicDataReceiver : public DataReaderListener
{
private:
  std::map<std::string, std::function<void(void*, SampleInfo*)>> callback_map_;

public:
  void register_callback(std::string& topicName, std::function<void(void*, SampleInfo*)> callback)
  {
    this->callback_map_[topicName] = callback;
  }

  void on_data_available(DataReader* reader)
  {
    void* data = reader->type()->createData();
    SampleInfo info;
    ReturnCode_t retcode = reader->read_next_sample(&data, &info);

    char const* type = reader->type()->getName();
    if (retcode == ReturnCode_t::RETCODE_OK)
    {
      this->callback_map_[type](&data, &info);
    }
    else
    {
      std::cerr << "Error while reading data" << '\n';
    }

    reader->type()->deleteData(data);
  }

  void deregister_callback(std::string& topicName)
  {
    this->callback_map_.erase(topicName);
  }
};

#endif
