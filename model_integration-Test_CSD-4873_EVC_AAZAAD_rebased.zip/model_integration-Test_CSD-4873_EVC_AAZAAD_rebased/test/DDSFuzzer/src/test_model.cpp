#include <iostream>
#include <fstream>
#include <chrono>
#include <thread>

#include <boost/program_options.hpp>
namespace po = boost::program_options;

#include "nlohmann/json.hpp"
#include "Models.generated.hpp"

#ifndef CUSTOM_DDS_MANAGER
#include <DDSEntityFactory.hpp>
#endif

int main(int argc, char** argv)
{
  std::string json_file;
  uint64_t num_samples;
  uint64_t sleep_us;
  uint_fast32_t seed;

  po::options_description desc("Simulate models sending random data on DI_GUI Topics.\nAllowed options:");
  desc.add_options()("help,h", "produce this help message")(
      "topic_info",
      po::value<std::string>(&json_file),
      "topic_info.json containing the \"activate\" list of topics to be fuzzed")(
      "num_samples,n",
      po::value<uint64_t>(&num_samples)->default_value(100),
      "Number of total samples to be sent per model/topic")(
      "sleep_us,s",
      po::value<uint64_t>(&sleep_us)->default_value(1000000),
      "Sleep duration between two iterations (signal on a topic) in microseconds")(
      "seed,s", po::value<uint_fast32_t>(&seed)->default_value(0), "Seed value for random engine");

  po::positional_options_description p;
  p.add("topic_info", 1);

  po::variables_map vm;
  po::store(po::command_line_parser(argc, argv).options(desc).positional(p).run(), vm);
  po::notify(vm);

  if (vm.count("help"))
  {
    std::cout << desc << "\n";
    return 1;
  }

  std::cout << "Starting publisher\n"
            << "Topic info: " << json_file << '\n'
            << "Sleep duration: " << sleep_us << " us\n"
            << "Total Samples per topic: " << num_samples << '\n'
            << std::endl;

  nlohmann::json data;
  {
    std::ifstream input_file(json_file);
    data = nlohmann::json::parse(input_file);
    input_file.close();
  }

  // set info log level for debugging puposes
  eprosima::fastdds::dds::Log::SetVerbosity(eprosima::fastdds::dds::Log::Kind::Info);

#ifdef CUSTOM_DDS_MANAGER
  DDSEntityManager manager;
#else
  using namespace jlr::cccm::di::dds;
  DDSEntityFactoryInterface* factory = new DDSEntityFactory(DEFAULT_TRANSPORT);
  DDSManagerInterface* manager = factory->create_manager(nullptr, "TestModel");
#endif

  std::vector<std::string> active_models = data["activate"].get<std::vector<std::string>>();
  {
    AllModels models(active_models);
    // time_s = std::chrono::steady_clock::now();
    // time_i = std::chrono::steady_clock::now();
    // std::cout << "Time to init: " << std::chrono::duration<double, std::milli>(time_i - time_s).count() << " ms" <<
    // std::endl; std::cin.get();

#ifdef CUSTOM_DDS_MANAGER
    models.init_all(&manager);
#else
    models.init_all(manager);
#endif

    RandomDataGenerator generator(seed);

    for (uint64_t s = 0; s < num_samples; s++)
    {
      auto start_time = std::chrono::steady_clock::now();
      models.update_and_send_all(generator);
      std::this_thread::sleep_until(start_time + std::chrono::microseconds(sleep_us));
    }

    // Ample Sleep to ensure that all samples are received by subscribers
    std::this_thread::sleep_for(std::chrono::seconds(2));
  }

#ifndef CUSTOM_DDS_MANAGER
  delete manager;
  manager = nullptr;

  delete factory;
  factory = nullptr;
#endif

  return 0;
}
