#include <CombinedTopicsPubSubTypes.h>

#ifdef CUSTOM_DDS_MANAGER
#include "dds_helper/DDSEntityManager.hpp"
#else
#include <DDSManager.hpp>
using DDSManager = jlr::cccm::di::dds::DDSManager;
using DDSManagerInterface = jlr::cccm::di::dds::DDSManagerInterface;
#endif

#include "dds_helper/DataReceivers.hpp"

template <typename PubSubType>
class TestGUI
{
public:
  uint64_t num_samples = 0;
  std::string type_name = "";

#ifdef CUSTOM_DDS_MANAGER
protected:
  DDSEntityManager* manager_ = nullptr;
  DataReader* reader_ = nullptr;

public:
  void init(DDSEntityManager* manager, bool use_listener)
  {
    TypeSupport type_(new PubSubType());
    reader_ = manager->create_reader(type_);

    DDSGenericDataReceiver* receiver = manager->get_generic_receiver();
    receiver->attach(
        reader_,
        use_listener,
        [this](void* data, SampleInfo* info)
        {
          this->on_data_available(data, info);
        });

    type_name = type_->getName();
    manager_ = manager;
  }

  ~TestGUI()
  {
    DDSGenericDataReceiver* receiver = manager_->get_generic_receiver();
    receiver->detach(reader_);

    if (reader_ != nullptr)
    {
      reader_->delete_contained_entities();
      manager_->delete_reader(reader_);
      reader_ = nullptr;
    }
  }

#else
protected:
  DDSManagerInterface* manager_ = nullptr;

public:
  void init(DDSManagerInterface* manager, TopicDataReceiver* receiver)
  {
    type_name = std::string(PubSubType().getName());
    manager->register_subscriber(type_name, new PubSubType());

    receiver->register_callback(
        type_name,
        [this](void* data, SampleInfo* info)
        {
          this->on_data_available(data, info);
        });

    manager_ = manager;
  }
#endif

  void on_data_available(typename PubSubType::type*, SampleInfo* info)
  {
    if (info->valid_data)
    {
      std::cout << "[" << type_name << "]" << " Message received: " << ++num_samples << '\n';
    }
  }

  void on_data_available(void* data, SampleInfo* info)
  {
    typename PubSubType::type* type_data = static_cast<typename PubSubType::type*>(data);
    this->on_data_available(type_data, info);
  }
};
