/// @file NotifyChannel.hpp
/// @brief Defines NotifyChannel class for both provider and consumer
/// applications
///
/// @copyright "Copyright (C) 2023, Jaguar Land Rover
/// All rights reserved.
/// CONFIDENTIAL INFORMATION - DO NOT DISTRIBUTE"
///
/// @date July 2023

#ifndef NOTIFY_CHANNEL_HEADER_H
#define NOTIFY_CHANNEL_HEADER_H

#include <memory>
#include <vector>
#include <thread>

#include "SomeipChannel.hpp"
#include <vsomeip/enumeration_types.hpp>
#include <vsomeip/vsomeip.hpp>
#include "soa.h"
#include "ModelExports.hpp"

// todo : thread safety for data member

/// @brief Alias for the SomeipChannel type
///
/// @details This type alias provides a simplified name for
/// jlr::cccm::di::SomeipChannel
using SomeipChannel = jlr::cccm::di::SomeipChannel;

namespace provider
{

  /// @brief NotifyChannel interface for vsomeip provider. provider is an
  /// entity that related to the vsomeip application offering a service
  ///
  /// @details Singleton class binding a vsomeip notify event with the corresponding
  /// proto message. Object of each such notify event will be created
  ///
  /// @param T The corresponding proto message associated with the Notify event
  ///
  template <class T>
  class SYMBOL_HIDDEN NotifyChannel
  {
    /// @brief  Stores the service_id, instance_id and vsomeip application ptr
    std::shared_ptr<SomeipChannel> channel;

    /// @brief Stores event_id for the notify event
    vsomeip::event_t event_id = 0;

    /// @brief Stores all group ids to which the notify event belongs
    std::set<vsomeip::eventgroup_t> group_ids;

    /// @brief Temporary storage for the notify event to be sent. Can
    /// be used to fetch the last sent message for the event
    T data;

    /// @brief Private constructor
    NotifyChannel()
    {
    }

  public:
    NotifyChannel(NotifyChannel const&) = delete;
    NotifyChannel& operator=(NotifyChannel const&) = delete;

    /// @brief Getter method for the singleton class
    /// @return Returns the provider::NotifyChannel static object initialized with some
    /// template parameter
    static NotifyChannel& get_instance()
    {
      static NotifyChannel notify_channel;
      return notify_channel;
    }

    /// @brief Method to set the values of service_id, instance_id, event_id and group_ids
    /// @param _channel Associated channel object specifying the service_id
    /// @param _event_id The event id for the notify event
    /// @param _group_ids vector of int group ids
    void initNotifyChannel(
        std::shared_ptr<SomeipChannel> _channel, vsomeip::event_t const& _event_id,
        std::set<vsomeip::eventgroup_t> const& _group_ids)
    {
      this->channel = _channel;
      this->event_id = _event_id;
      this->group_ids = _group_ids;
    }

    /// @brief destroy the channel
    void deinitNotifyChannel()
    {
      channel.reset();
    }

    /// @brief Getter method for member event_id
    /// @return Returns int (decimal) event_id
    vsomeip::event_t getEventID() const
    {
      return this->event_id;
    }

    /// @brief Setter method for member event_id
    /// @param _event_id Takes int (decimal) as input
    void setEventID(vsomeip::event_t const& _event_id)
    {
      this->event_id = _event_id;
    }

    /// @brief  Getter method for the member group_ids
    /// @return Returns group_ids
    std::set<vsomeip::eventgroup_t> getGroupIds() const
    {
      return this->group_ids;
    }

    /// @brief Setter method for member group_id
    /// @param _group_ids Reference of const vector<int>
    void setGroupIds(std::set<vsomeip::eventgroup_t> const& _group_ids)
    {
      this->group_ids = _group_ids;
    }

    /// @brief Wrapper method to offer an event , calls
    /// vsomeip::application->offer_event()
    /// @satisfy{Requirement01340698}
    void offerEvent()
    {
      DI_MODEL_LOG_MCTX_INFO << "[Info] : Offering event for service_id=" << channel->getServiceID()
                             << ", instance_id=" << channel->getInstanceID() << ",event_id=" << event_id;

      channel->get_app()->offer_event(
          channel->getServiceID(), channel->getInstanceID(), event_id, group_ids, vsomeip::event_type_e::ET_EVENT);
    }

    /// @brief stop offering the event
    /// @satisfy{Requirement01403331}
    void stopOfferEvent()
    {
      channel->get_app()->stop_offer_event(channel->getServiceID(), channel->getInstanceID(), event_id);
    }

    /// @brief Setter method for the member data
    /// @param _data Protobuf message to be sent
    void setData(T const& _data)
    {
      this->data = _data;
    }

    /// @brief Serializes the protobuf Message into string, converts the string
    /// to byte array, creates and sets the payload and sends. ServiceID, instanceID,
    /// eventID and eventgrpIDs, all are already stored as members
    /// Wrapper for vsomeip::application->notify().
    void send()
    {
      std::string msg;
      this->data.SerializeToString(&msg);

      auto payload = soa_payload::create_soa_payload(msg);

      channel->get_app()->notify(channel->getServiceID(), channel->getInstanceID(), event_id, payload);
      DI_MODEL_LOG_MCTX_DEBUG << "[Debug] : Sent : " << typeid(T).name() << std::endl;
      DI_MODEL_LOG_MCTX_DEBUG << "[Sent]" << data.DebugString() << std::endl;
    }

    /// @brief Sets the data member of the class before calling the send() method
    /// @param _data Protobuf message to be sent
    void send(T& _data)
    {
      this->data = _data;
      this->send();
    }

    /// @brief Getter method for the member data
    /// @return Returns the last last Sent/Set message
    T const& getLastSentData() const
    {
      return this->data;
    }
  };

}  // namespace provider

namespace consumer
{

  /// @brief NotifyChannel interface for vsomeip consumer. consumer is an
  /// entity that related to the vsomeip application requesting a service
  ///
  /// @details Class for handling vsomeip notify events. Singleton class
  /// binding a vsomeip notify event with the corresponding proto message.
  /// Object of each such notify event will be created.
  ///
  /// @param T The corresponding proto message associated with the Notify event
  ///
  template <class T>
  class SYMBOL_HIDDEN NotifyChannel
  {

    /// @brief  Stores the service_id, instance_id and vsomeip application ptr
    std::shared_ptr<SomeipChannel> channel;

    /// @brief Stores event_id for the notify event
    vsomeip::event_t event_id;

    /// @brief Stores all group ids to which the notify event belongs
    std::set<vsomeip::eventgroup_t> group_ids;

    /// @brief Temporary storage for the notify event to be received. Can
    /// be used to fetch the last received message for the event
    T data;

    /// @brief Callback method stored as std::function object for the
    /// reception of vsomeip messages. Specifies what operation to do
    /// after the received byte array has been converted into the
    /// protobuf Message type. Default value is nullptr. In this case just
    /// the log will be printed
    std::function<void(T const&)> event_callback{};

    /// @brief Private constructor
    NotifyChannel()
    {
    }

  public:
    NotifyChannel(NotifyChannel const&) = delete;
    NotifyChannel& operator=(NotifyChannel const&) = delete;

    /// @brief Getter method for the singleton class
    /// @return Returns the consumer::NotifyChannel static object initialized with some
    /// template parameter
    static NotifyChannel& get_instance()
    {
      static NotifyChannel notify_channel;
      return notify_channel;
    }

    /// @brief Method to set the values of service_id, instance_id, event_id and group_ids
    /// @param _channel Associated channel object specifying the service_id
    /// @param _event_id The event id for the notify event
    /// @param _group_ids vector of int group ids
    void initNotifyChannel(
        std::shared_ptr<SomeipChannel> const _channel, vsomeip::event_t const& _event_id,
        std::set<vsomeip::eventgroup_t> const& _group_ids)
    {
      this->channel = _channel;
      this->event_id = _event_id;
      this->group_ids = _group_ids;
    }

    /// @brief destroy the channel
    void deinitNotifyChannel()
    {
      channel.reset();
    }

    /// @brief Getter method for member event_id
    /// @return Returns int (decimal) event_id
    vsomeip::event_t getEventID() const
    {
      return this->event_id;
    }

    /// @brief Setter method for member event_id
    /// @param _event_id Takes int (decimal) as input
    void setEventID(vsomeip::event_t const& _event_id)
    {
      this->event_id = _event_id;
    }

    /// @brief  Getter method for the member group_ids
    /// @return Returns group_ids
    std::set<vsomeip::eventgroup_t> getGroupIds() const
    {
      return this->group_ids;
    }

    /// @brief Setter method for member group_id
    /// @param _group_ids Reference of const vector<int>
    void setGroupIds(std::set<vsomeip::eventgroup_t> const& _group_ids)
    {
      this->group_ids = _group_ids;
    }

    /// @brief Setter method for the member event_callback
    /// @param fun_ptr Callable object to be set as callback
    void setOnEventCallback(std::function<void(T const&)> const fun_ptr)
    {
      this->event_callback = fun_ptr;
    }

    /// @brief Callback method to be called when vsomeip notify event
    /// is received. Converts the received vsomeip byte array to string
    /// then the string is deserialized into protubuf Message object. The
    /// type of the protobuf Message is specified by the class template
    /// parameter T. If the event_callback event is nullptr,
    /// The logs will just be printed else the callable event_callback
    /// will be called. If the value of the member workExecutor
    /// is not nullptr, the callable event_callback will be executed on the
    /// worker thread. If the value is nullptr, which is the default value,
    /// event_callback will be executed on the vsomeip listener thread itself.
    /// @param msg Pointer to the received vsomeip::message
    void onEvent(std::shared_ptr<vsomeip::message> const msg)
    {
      DI_MODEL_LOG_MCTX_DEBUG << "[Info] : onEvent Recvd : " << typeid(T).name()
                              << "on thread : " << std::this_thread::get_id() << std::endl;

      // check if message return code is ok
      {
        auto retcode = msg->get_return_code();
        if (retcode != vsomeip::return_code_e::E_OK)
        {
          DI_MODEL_LOG_MCTX_ERROR << "[Error] : Message return code is " << static_cast<uint32_t>(retcode)
                                  << ", Dropping the message" << std::endl;
          return;
        }
      }

      std::shared_ptr<vsomeip::payload> const payload = msg->get_payload();
      T notify_msg;

      if (soa_payload::is_malformed(payload) == true)
      {
        DI_MODEL_LOG_MCTX_ERROR << "[Error] : Event payload is malformed, Dropping the message" << std::endl;
        return;
      }
      notify_msg.ParseFromString(soa_payload::extract_protobuf(payload));
      DI_MODEL_LOG_MCTX_DEBUG << notify_msg.DebugString() << std::endl;

      setData(notify_msg);

      if (event_callback != nullptr)
      {
        event_callback(notify_msg);
        DI_MODEL_LOG_MCTX_DEBUG << "[Info] : Success!!, onEvent Executed on thread : " << std::this_thread::get_id()
                                << ":" << typeid(T).name() << std::endl;
      }
      else
      {
        DI_MODEL_LOG_MCTX_DEBUG << "[Debug] : event callback not implemented : " << typeid(T).name() << std::endl;
      }
    }

    /// @brief Registers the onEvent method with the vsomeip application. Wrapper
    /// for vsomeip::application->register_message_handler()
    void registerEventHandler()
    {
      auto app_ptr = channel->get_app();
      if (app_ptr == nullptr)
      {
        DI_MODEL_LOG_MCTX_ERROR << "[Error] : Vsomeip application ptr was null" << std::endl;
        return;
      }
      app_ptr->register_message_handler(
          channel->getServiceID(),
          channel->getInstanceID(),
          event_id,
          [this](auto const& msg)
          {
            this->onEvent(msg);
          });
    }

    /// @brief deregister the event handler
    /// @satisfy{Requirement01403332}
    void deregisterEventHandler()
    {
      channel->get_app()->unregister_message_handler(channel->getServiceID(), channel->getInstanceID(), event_id);
    }

    /// @brief Wrapper method to request an event , calls
    /// vsomeip::application->request_event()
    /// @satisfy{Requirement01321457}
    void requestEvent()
    {
      auto app_ptr = channel->get_app();
      if (app_ptr == nullptr)
      {
        DI_MODEL_LOG_MCTX_ERROR << "[Error] : Vsomeip application ptr was null" << std::endl;
        return;
      }
      DI_MODEL_LOG_MCTX_INFO << "[Info] : Requesting event for ServiceID =" << channel->getServiceID()
                             << ",InstanceId=" << channel->getInstanceID();

      app_ptr->request_event(
          channel->getServiceID(),
          channel->getInstanceID(),
          event_id,
          this->group_ids,
          vsomeip::event_type_e::ET_EVENT);
    }

    /// @brief releases the event with vsomeip
    /// @satisfy{Requirement01403291}
    void releaseEvent()
    {
      channel->get_app()->release_event(channel->getServiceID(), channel->getInstanceID(), event_id);
    }

    /// @brief Getter method for the member data
    /// @return Returns the stored protobuf message object
    T const& getData() const
    {
      return this->data;
    }

    /// @brief Setter method for the member data
    /// @param _data Protobuf message object to be set
    void setData(T const& _data)
    {
      this->data = _data;
    }
  };

}  // namespace consumer

#endif
