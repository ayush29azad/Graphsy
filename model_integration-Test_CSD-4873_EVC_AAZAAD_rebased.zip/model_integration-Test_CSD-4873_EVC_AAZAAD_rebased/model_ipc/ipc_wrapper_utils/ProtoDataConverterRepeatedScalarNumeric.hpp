#ifndef PROTO_DATA_CONVERTER_REPEATED_SCALAR_NUMERIC
#define PROTO_DATA_CONVERTER_REPEATED_SCALAR_NUMERIC

#include <google/protobuf/repeated_field.h>

#include <stdexcept>

#include "ProtoDataConverterScalarNumeric.hpp"
#include "ArrayUtils.hpp"

namespace jlr::cccm::di
{
  /// @brief converts proto repeated numeric to model repeated numeric
  /// @tparam model_rep_type model repeated type
  /// @tparam scalar_type proto numeric type
  /// @param proto_rep_data const reference to proto data
  /// @param model_rep_data out param for model data
  /// @satisfy{Requirement01184576}
  template <typename model_rep_type, typename scalar_type>
  void ProtoToModelDataConverterRepeatedScalarNumeric(
      google::protobuf::RepeatedField<scalar_type> const& proto_rep_data, model_rep_type& model_rep_data)
  {

    // model_rep_type model_rep_data{};

    size_t max_size;

    if (static_cast<std::size_t>(proto_rep_data.size()) <= array_size(model_rep_data.payload))
    {
      max_size = static_cast<std::size_t>(proto_rep_data.size());
    }
    else
    {
      max_size = array_size(model_rep_data.payload);
    }

    model_rep_data.payload_length = max_size;

    for (size_t i = 0; i < max_size; ++i)
    {
      ProtoToModelDataConverterScalarNumeric<scalar_type>(proto_rep_data[i], model_rep_data.payload[i]);
    }

    // return model_rep_data;
  }

  /// @brief converts model repeated numeric to proto repeated numeric
  /// @tparam model_rep_type model repeated type
  /// @tparam scalar_type proto numeric type
  /// @param model_rep_data const reference to model data
  /// @param proto_rep_data out param for proto data
  /// @satisfy{Requirement01184576}
  template <typename model_rep_type, typename scalar_type>
  void ModelToProtoDataConverterRepeatedScalarNumeric(
      model_rep_type const& model_rep_data, google::protobuf::RepeatedField<scalar_type>& proto_rep_data)
  {

    if (model_rep_data.payload_length > array_size(model_rep_data.payload))
    {
      throw std::invalid_argument("Model repeated input has invalid payload_length");
    }

    proto_rep_data.Clear();

    for (size_t i = 0; i < model_rep_data.payload_length; ++i)
    {

      auto setter = [prd = &proto_rep_data](scalar_type const tempData)
      {
        prd->Add(tempData);
      };
      ModelToProtoDataConverterScalarNumeric<scalar_type>(model_rep_data.payload[i], setter);
      // proto_rep_data.Add(tempData);
    }
  }
}  // namespace jlr::cccm::di

#endif  // PROTO_DATA_CONVERTER_REPEATED_SCALAR_NUMERIC
