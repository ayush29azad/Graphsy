#ifndef PROTO_DATA_CONVERTER_REPEATED_ENUM
#define PROTO_DATA_CONVERTER_REPEATED_ENUM

#include <google/protobuf/repeated_field.h>

#include <stdexcept>
#include <type_traits>

#include "ProtoDataConverterEnum.hpp"
#include "ArrayUtils.hpp"

namespace jlr::cccm::di
{
  /// @brief converts proto repeated enum to model repeated enum
  /// @tparam model_rep_type model repeated type
  /// @param proto_rep_data const reference to proto data
  /// @param model_rep_data out param for model data
  /// @satisfy{Requirement01184576}
  template <typename model_rep_type>
  void ProtoToModelDataConverterRepeatedEnum(
      google::protobuf::RepeatedField<int32_t> const& proto_rep_data, model_rep_type& model_rep_data)
  {

    // model_rep_type model_rep_data{};

    using model_enum_type = typename std::remove_all_extents<decltype(model_rep_data.payload)>::type;

    size_t max_size;

    if (static_cast<std::size_t>(proto_rep_data.size()) <= array_size(model_rep_data.payload))
    {
      max_size = static_cast<std::size_t>(proto_rep_data.size());
    }
    else
    {
      max_size = array_size(model_rep_data.payload);
    }

    model_rep_data.payload_length = max_size;

    for (size_t i = 0; i < max_size; ++i)
    {
      ProtoToModelDataConverterEnum<model_enum_type>(proto_rep_data[i], model_rep_data.payload[i]);
    }

    // return model_rep_data;
  }

  /// @brief converts model repeated enum to proto repeated enum
  /// @tparam model_rep_type  model repeated type
  /// @param model_rep_data const reference to model data
  /// @param proto_rep_data out param for proto data
  /// @satisfy{Requirement01184576}
  template <typename model_rep_type>
  void ModelToProtoDataConverterRepeatedEnum(
      model_rep_type const& model_rep_data, google::protobuf::RepeatedField<int32_t>& proto_rep_data)
  {

    if (model_rep_data.payload_length > array_size(model_rep_data.payload))
    {
      throw std::invalid_argument("Model repeated input has invalid payload_length");
    }

    proto_rep_data.Clear();

    for (size_t i = 0; i < model_rep_data.payload_length; ++i)
    {

      auto setter = [prd = &proto_rep_data](int32_t const proto_enum_value)
      {
        prd->Add(proto_enum_value);
      };

      ModelToProtoDataConverterEnum<int32_t>(model_rep_data.payload[i], setter);
    }
  }
}  // namespace jlr::cccm::di

#endif  // PROTO_DATA_CONVERTER_REPEATED_ENUM
