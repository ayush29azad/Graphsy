#ifndef PROTO_DATA_CONVERTER_SCALAR_BYTES_HEADER
#define PROTO_DATA_CONVERTER_SCALAR_BYTES_HEADER

#include <string>
#include <string.h>
#include <stdint.h>
#include <stdexcept>
#include "ArrayUtils.hpp"

namespace jlr::cccm::di
{
  /// @brief converts proto  bytes to model bytes
  /// @tparam model_bytes_type model bytes type
  /// @param proto_bytes const reference to proto data
  /// @param model_bytes out param for model data
  /// @satisfy{Requirement01184552}
  template <typename model_bytes_type>
  void ProtoToModelDataConverterScalarBytes(std::string const& proto_bytes, model_bytes_type& model_bytes)
  {

    // model_bytes_type model_bytes{};
    memset(model_bytes.payload, 0, sizeof(model_bytes.payload));
    if (proto_bytes.size() <= array_size(model_bytes.payload))
    {
      model_bytes.payload_length = proto_bytes.size();
      for (size_t i = 0; i < proto_bytes.size(); ++i)
      {
        model_bytes.payload[i] = proto_bytes[i];
      }
    }
    else
    {
      model_bytes.payload_length = array_size(model_bytes.payload);
      for (size_t i = 0; i < array_size(model_bytes.payload); ++i)
      {
        model_bytes.payload[i] = proto_bytes[i];
      }
    }

    // return model_bytes;
  }

  /// @brief converts model bytes to proto bytes
  /// @tparam model_bytes_type  model bytes type
  /// @param model_bytes const reference to model data
  /// @param proto_bytes out param for proto data
  /// @satisfy{Requirement01184552}
  template <typename model_bytes_type>
  void ModelToProtoDataConverterScalarBytes(model_bytes_type const& model_bytes, std::string& proto_bytes)
  {

    if (model_bytes.payload_length > array_size(model_bytes.payload))
    {
      throw std::invalid_argument("Model bytes input has invalid payload_length");
    }

    // std::string proto_bytes;
    proto_bytes.clear();

    for (size_t i = 0; i < model_bytes.payload_length; ++i)
    {
      proto_bytes.push_back(model_bytes.payload[i]);
    }

    // return proto_bytes;
  }
}  // namespace jlr::cccm::di

#endif  // PROTO_DATA_CONVERTER_SCALAR_BYTES_HEADER
