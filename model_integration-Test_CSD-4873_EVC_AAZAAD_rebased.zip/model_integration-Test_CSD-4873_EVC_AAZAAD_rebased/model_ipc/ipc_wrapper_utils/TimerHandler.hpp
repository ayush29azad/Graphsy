/// @file TimerHandler.hpp
/// @brief Contains Model Timer class declaration and definition
///
/// @copyright "Copyright (C) 2023, Jaguar Land Rover
/// All rights reserved.
/// CONFIDENTIAL INFORMATION - DO NOT DISTRIBUTE"
///
/// @date July 2023

#ifndef TIMER_HANDLER_MODEL_H
#define TIMER_HANDLER_MODEL_H

#include <atomic>
#include <chrono>
#include <condition_variable>
#include <ctime>
#include <iostream>
#include <math.h>
#include <memory>
#include <mutex>
#include <thread>
#include <string>
#include <pthread.h>

namespace jlr
{
  namespace cccm
  {
    namespace di
    {
      /// @brief Class for generating periodic notifications on
      /// a new thread
      class Timer final
      {

        /// @brief model mutex for synchronization
        std::mutex& modelMutex;

        /// @brief Pointer to the lambda wrapping the model function
        std::function<void()> mModelTickFun;

        /// @brief The time period for the timer
        uint16_t const timePeriod;

        /// @brief Synchronization flag
        std::atomic_bool is_halt;

        /// @brief model timer thread name
        std::string const threadName;

        /// @brief The thread on which the interrupts are generated
        std::thread timerThread;

      public:
        /// @brief Sets the period and the conditional variable required
        /// for synchronization
        /// @param modelMutex_ Model mutex for synchronization
        /// @param modelTickFun Model tick function to be invoked periodically
        /// @param period The period at which function is to be invoked in milliseconds
        /// @param timerThreadName timer thread name
        Timer(
            std::mutex& modelMutex_, std::function<void()> const modelTickFun, uint16_t const period,
            std::string const timerThreadName)
            : modelMutex(modelMutex_)
            , mModelTickFun(modelTickFun)
            , timePeriod(period)
            , is_halt(false)
            , threadName(timerThreadName)
        {
        }

        /// @brief Starts the timer with the set periodic values
        void start()
        {
          is_halt = {false};
          timerThread = std::thread(
              [this]()
              {
                pthread_setname_np(pthread_self(), threadName.c_str());
                auto startTime = std::chrono::steady_clock::now();
                while (!static_cast<bool>(is_halt))
                {
                  auto wakeupTime = startTime + std::chrono::milliseconds(timePeriod);
                  std::this_thread::sleep_until(wakeupTime);

                  if (mModelTickFun != nullptr)
                  {
                    std::lock_guard<std::mutex> lck(modelMutex);
                    mModelTickFun();
                  }
                  else
                  {
                    DI_MODEL_LOG_MCTX_ERROR << "[Error] : Model Tick Function was null" << std::endl;
                  }

                  startTime = wakeupTime;
                }
              });
        }

        /// @brief Stops the timer, joins the timer thread
        void stop()
        {
          is_halt = {true};
          if (timerThread.joinable() == true)
          {
            timerThread.join();
          }
        }

        /// @brief Default destructor
        ~Timer()
        {
          stop();
        }
      };
    }  // namespace di
  }  // namespace cccm
}  // namespace jlr
#endif
