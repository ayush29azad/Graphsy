
#ifndef SOA_H
#define SOA_H
#include <vsomeip/vsomeip.hpp>
#include <cstring>
#include <string>
#include <cstdint>
#include <arpa/inet.h>

/// @brief Helpers to Extract Protobuf from SOME/IP payload - STJLR 18.269
///
/// @details This namespace contains helper functions to process
/// the SOME/IP payload that constitutes JLR on wire format as
/// defined in STJLR.18.269
///
/// The requirements from the STJLR are given below.
/// Please note that these requirements may not follow the exact wording
/// of the STJLR
///
/// 1. When sending any message via vsomeip (request, response or event)
///    for a protobuf encoded message n bytes in length, pass vsomeip a
///    buffer of length n + 2 bytes.
///      a. The first two bytes of the buffer shall represent a big endian
///         encoded integer with a value between 0 and 1398 defining the
///         length of the Protobuf encoded message that follows.
///      b. For zero length Protobuf messages the two byte prefix shall
///         still be sent with a value of 0x0000.
/// 2. On receiving a message confirm that the first two bytes of the message,
///    where the message is n bytes long, contains the value n - 2.
///      a. For a zero length message the prefix can be 0x0000 or alternatively
///         the prefix can be omitted. Both formats shall be accepted by the client.
///
///
/// This implementation DOES NOT check the MTU constraints described above!
///
/// We will not be checking whether the protobuf payload is a valid payload.
/// That is the responsibility of upper layer applications.
namespace soa_payload_v1
{

  /// @brief Check whether JLROnWire Payload is Malformed - STJLR.18.269
  ///
  /// @satisfy{Requirement01402153}
  ///
  /// @details This function checks whether the SOME/IP payload
  /// that constitutes JLR on wire format as defined in STJLR.18.269
  /// is malformed.
  ///
  /// @param[in] _payload The SOME/IP payload with JLR on wire data
  /// @return true if it is a malformed packet
  bool is_malformed(std::shared_ptr<vsomeip::payload> const& _payload);

  /// @brief Extract protobuf Data from JLR on wire format - STJLR.18.269
  ///
  /// @satisfy{Requirement01402153}
  ///
  /// @details This function extracts protobuf data from JLR on wire
  /// format as defined in STJLR.18.269.
  ///
  /// We will NOT be checking whether the protobuf payload is a valid payload.
  /// That is the responsibility of upper layer applications. What we will do
  /// is return what the protobuf payload is as per the specification.
  ///
  /// We will be assuming that the payload is not malformed
  ///
  /// @param[in] _payload The SOME/IP payload with JLR on wire data
  ///
  /// @return The payload in std::string container
  std::string extract_protobuf(std::shared_ptr<vsomeip::payload> const& _payload);

  /// @brief Create vsomeip payload from serialized protobuf - STJLR.18.269
  ///
  /// @satisfy{Requirement01402148}
  ///
  /// @details This function creates a vsomeip payload from
  /// protobuf data as defined in STJLR.18.269
  ///
  /// @param[in] _protobuf serialized protobuf data
  /// @return payload vsomeip payload with protobuf data appropriately packed
  std::shared_ptr<vsomeip::payload> create_soa_payload(std::string const& _protobuf);

}  // namespace soa_payload_v1

/// @brief Helpers to Extract Protobuf from SOME/IP payload - naive
///
/// @details This namespace contains helper functions to process
/// the SOME/IP payload without any further encapsulation.
/// This is the naive implementation where the protobuf serialised data
/// is directly written to payload section of SOME/IP packet
///
/// The intention of this namespace is to provide a similar interface
/// to process someip payloads even if one wants to process a naive payload.
///
/// We will not be checking whether the protobuf payload is a valid payload.
/// That is the responsibility of upper layer applications.
namespace soa_payload_v0
{

  /// @brief Check whether JLROnWire Payload is Malformed - naive
  ///
  /// @param[in] _payload The SOME/IP payload with JLR on wire data
  /// @return true if it is a malformed packet
  bool is_malformed(std::shared_ptr<vsomeip::payload> const& _payload);

  /// @brief Extract protobuf Data from JLR on wire format - naive
  ///
  /// @param[in] _payload The SOME/IP payload with JLR on wire data
  ///
  /// @return The payload in std::string container
  std::string extract_protobuf(std::shared_ptr<vsomeip::payload> const& _payload);

  /// @brief Create vsomeip payload from serialized protobuf - naive
  ///
  /// @param[in] _protobuf serialized protobuf data
  /// @return payload vsomeip payload with protobuf data appropriately packed
  std::shared_ptr<vsomeip::payload> create_soa_payload(std::string const& _protobuf);

}  // namespace soa_payload_v0

namespace soa_payload = soa_payload_v1;
#endif
