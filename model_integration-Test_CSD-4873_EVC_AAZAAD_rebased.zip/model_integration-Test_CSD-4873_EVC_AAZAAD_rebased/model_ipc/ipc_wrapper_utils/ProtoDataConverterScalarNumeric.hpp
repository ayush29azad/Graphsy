#ifndef PROTO_DATA_CONVERTER_SCALAR_NUMERIC_HEADER
#define PROTO_DATA_CONVERTER_SCALAR_NUMERIC_HEADER

namespace jlr::cccm::di
{
  /// @brief converts proto numeric to model numeric
  /// @tparam proto_scalar_type proto numeric type
  /// @tparam model_scalar_type model numeric type
  /// @param dataIn const reference to proto data
  /// @param dataOut out param for model data
  /// @satisfy{Requirement01184540}
  template <typename proto_scalar_type, typename model_scalar_type>
  void ProtoToModelDataConverterScalarNumeric(proto_scalar_type const& dataIn, model_scalar_type& dataOut)
  {
    dataOut = dataIn;
  }

  /// @brief converts model numeric to proto numeric
  /// @tparam scalar_type model numeric type
  /// @tparam Setter closure type for the setter
  /// @param dataIn const reference to model data
  /// @param setter closure that will set the value in proto
  /// @satisfy{Requirement01184540}
  template <typename scalar_type, typename Setter>
  void ModelToProtoDataConverterScalarNumeric(scalar_type const& dataIn, Setter& setter)
  {  // scalar_type& dataOut){
    setter(dataIn);
  }
}  // namespace jlr::cccm::di

#endif  // PROTO_DATA_CONVERTER_SCALAR_NUMERIC_HEADER
