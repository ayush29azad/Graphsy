/// @file SomeipServiceConsumer.hpp
/// @brief Contains SomeipServiceConsumer class declaration and definition
///
/// @copyright "Copyright (C) 2023, Jaguar Land Rover
/// All rights reserved.
/// CONFIDENTIAL INFORMATION - DO NOT DISTRIBUTE"
///
/// @date July 2023

#ifndef SOMEIP_SERVICE_CONSUMER_HEADER_H
#define SOMEIP_SERVICE_CONSUMER_HEADER_H

#include <functional>
#include <iostream>
#include <memory>
#include <string>
#include <vector>
#include <unordered_map>
#include <mutex>
#include <vsomeip/vsomeip.hpp>

#include "MessageChannel.hpp"
#include "NotifyChannel.hpp"

namespace jlr
{
  namespace cccm
  {
    namespace di
    {
      /// @brief Class representing a vsomeip client (service consumer), one
      /// object per vsomeip service should be created
      class SomeipServiceConsumer
      {

      private:
        /// @brief Stores the service_id, instance_id and vsomeip application ptr
        std::shared_ptr<SomeipChannel> service_channel = nullptr;

        /// @brief Stores the state of service availibility
        bool service_available = false;

        std::vector<std::function<void(vsomeip::service_t, vsomeip::instance_t, bool)>> on_available_funcs;
        mutable std::mutex mutex_on_available_funcs;

        /// @brief stores all the event ids required for destruction
        std::vector<vsomeip::event_t> event_ids;

        /// @brief stores all the method ids required for destruction
        std::vector<vsomeip::method_t> method_ids;

        /// @brief stores all the eventgroups required for destructions
        std::set<vsomeip::eventgroup_t> eventgroups;

        /// @brief stores lambdas to call for "destructions" of message channel singletons
        std::vector<void (*)(void)> message_channel_destructors;

        /// @brief stores lambdas to call for "destructions" of notify channel singletons
        std::vector<void (*)(void)> notify_channel_destructors;

        /// @brief mutex to protect event_groups
        mutable std::mutex mutex_eventgroups;

        /// @brief update eventgroups
        /// @param _eventgroups
        inline void updateEventgroups(std::set<vsomeip::eventgroup_t> const& _eventgroups)
        {
          // for now we will subscribe to all eventgroups we know of
          // TODO: optimise to subscribe to the minimal number of eventgroups
          std::lock_guard<std::mutex> lock(this->mutex_eventgroups);
          this->eventgroups.insert(_eventgroups.begin(), _eventgroups.end());
        }

        /// @brief Helper emthod to register on availability handlers with vsomeip
        ///
        /// @details This method registers a lambda that calls all functions
        /// in on_available_funs private member with vsomeip.
        ///
        /// This is a private method which is meant to be called only in the
        /// constructor of this class
        ///
        /// Modification of on_available_funcs after registration with vsomeip
        /// will lead to the new function being called!
        /// This function registers a reference to this with vsomeip, therefore we
        /// need to take ownership of that reference and make sure that that
        /// reference is cleared when destruction this object
        ///
        /// the corresponding method that handles the clearing of the reference
        /// is unregisterAvailabilityHandler()
        inline void registerAvailibilityHandler() const
        {
          if (service_channel != nullptr)
          {
            service_channel->get_app()->register_availability_handler(
                service_channel->getServiceID(),
                service_channel->getInstanceID(),
                [this](
                    vsomeip::service_t const _service_id,
                    vsomeip::instance_t const _instance_id,
                    bool const _is_available)
                {
                  std::lock_guard<std::mutex> lock(this->mutex_on_available_funcs);
                  for (auto& func : this->on_available_funcs)
                  {
                    func(_service_id, _instance_id, _is_available);
                  }
                });
          }
          else
          {
            DI_MODEL_LOG_MCTX_ERROR << "[Error] : service_channel object was null" << std::endl;
          }
        }

        /// @brief Helper method to unregister on availability handlers with vsomeip
        ///
        /// @details This method unregisters the function registered by
        /// registerAvailabilityHandler with vsomeip
        ///
        /// This is a private method which is meant to be called only in the
        /// destructor of this class
        ///
        /// This helper method when called in the destructor ensures that
        /// there are no dangling references to an instance of this class
        ///
        /// @satisfy{Requirement01403295}
        inline void unregisterAvailabilityHandler() const
        {
          if (service_channel != nullptr)
          {
            service_channel->get_app()->unregister_availability_handler(
                service_channel->getServiceID(), service_channel->getInstanceID());
          }
        }

        ///@brief this method will add a callback to print logs on availability
        inline void addOnAvailableLOGS()
        {
          addOnAvailableCallback(
              [this](
                  vsomeip::service_t const _service_id, vsomeip::instance_t const _instance_id, bool const is_available)
              {
                if (is_available)
                {
                  DI_MODEL_LOG_MCTX_INFO << "[Info] : vsomeip : service is available " << _service_id << " "
                                         << _instance_id << std::endl;
                  service_available = true;
                }
                else
                {
                  DI_MODEL_LOG_MCTX_INFO << "[Info] : vsomeip : service is NOT available " << _service_id << " "
                                         << _instance_id << std::endl;
                  service_available = false;
                }
              });
        }

        ///@brief this method will add a callback to save the availability of service
        /// in a private member
        inline void addRecordServiceAvailabilityCallback()
        {
          addOnAvailableCallback(
              [this](
                  vsomeip::service_t const _service_id,
                  vsomeip::instance_t const _instance_id,
                  bool const _is_available)
              {
                (void)_service_id;
                (void)_instance_id;
                this->service_available = _is_available;
              });
        }

        /// @brief this method will subscribe to eventgroups on availability of service with major version
        /// @satisfy{Requirement01340695,Requirement01340696}
        inline void addSubscribeCallback()
        {
          addOnAvailableCallback(
              [this](
                  vsomeip::service_t const _service_id, vsomeip::instance_t const _instance_id, bool const is_available)
              {
                if (is_available)
                {
                  std::lock_guard<std::mutex> lock(this->mutex_eventgroups);
                  for (auto it = this->eventgroups.begin(); it != this->eventgroups.end(); ++it)
                  {
                    vsomeip::eventgroup_t const& eventgroup = *it;
                    this->service_channel->get_app()->subscribe(
                        _service_id, _instance_id, eventgroup, this->service_channel->getMajorVersion());
                  }
                }
              });
        }

        /// @brief This method will add a callback to save major version of service
        /// @satisfy{Requirement01340692}
        inline void addSOMEIPInterfaceVersionSettingCallback()
        {
          addOnAvailableCallback(
              [this](
                  vsomeip::service_t const _service_id, vsomeip::instance_t const _instance_id, bool const is_available)
              {
                // Set Major Version to that offered by service
                if (is_available)
                {
                  vsomeip::application::available_t _available_map;
                  this->service_channel->get_app()->are_available(_available_map, _service_id, _instance_id);
                  // Assuming that there are no service/instance pairs with more than one
                  // version. It does not make sense from a SOME/IP PoV for this to happen
                  //
                  // Assuming that if is_available is true, the following actions will not fail.
                  auto it = _available_map[_service_id][_instance_id].begin();
                  this->service_channel->setMajorVersion(it->first);
                }
              });
        }

      public:
        /// @brief Method to add a function to the list of callbacks owned by this class
        /// @param[in] func An std::function object that takes service_id, instance_id and is_available as args
        /// @satisfy{Requirement01321608}
        void addOnAvailableCallback(std::function<void(vsomeip::service_t, vsomeip::instance_t, bool)> const func)
        {
          std::lock_guard<std::mutex> lock(this->mutex_on_available_funcs);
          this->on_available_funcs.push_back(func);
        }

        /// @brief Wrapper function over vsomeip::application->request_service() function
        /// @satisfy{Requirement01321452, Requirement01321456}
        void requestService() const
        {
          if (service_channel == nullptr)
          {
            DI_MODEL_LOG_MCTX_ERROR << "[Error] : service_channel pointer was null in provider object" << std::endl;
            return;
          }
          std::shared_ptr<vsomeip::application> const m_app = service_channel->get_app();
          if (m_app == nullptr)
          {
            DI_MODEL_LOG_MCTX_ERROR << "[Error] : vsomeip_application pointer was null in provider object" << std::endl;
            return;
          }
          DI_MODEL_LOG_MCTX_INFO << "[Info] : Request service for ServiceId=" << service_channel->getServiceID()
                                 << ", InstanceId=" << service_channel->getInstanceID() << std::endl;
          m_app->request_service(service_channel->getServiceID(), service_channel->getInstanceID());
        }

        /// @brief Getter method for the member service_available
        /// @return The current state if the service availibility
        bool getServiceAvailable() const
        {
          return this->service_available;
        }

        SomeipServiceConsumer() = delete;

        ~SomeipServiceConsumer(){

        };

        /// @brief Only allowed constructor with two parameters
        /// @param _channel Pointer to the SomeipChannel object
        SomeipServiceConsumer(std::shared_ptr<SomeipChannel> const _channel)
        {
          this->service_channel = _channel;
          // The following needs to be first in the list of callbacks
          addSOMEIPInterfaceVersionSettingCallback();
          registerAvailibilityHandler();
          addRecordServiceAvailabilityCallback();
          addOnAvailableLOGS();
          addSubscribeCallback();
          requestService();
        }

        /// @brief Getter method for SomeipChannel object
        /// @return Returns the ptr to SomeipChannel object
        std::shared_ptr<SomeipChannel> getSomeipChannel() const
        {
          return this->service_channel;
        }

        /// @brief Setter method for SomeipChannel object
        /// @param _service_channel Takes the ptr to the SomeipChannel object
        void setSomeipChannel(std::shared_ptr<SomeipChannel> _service_channel)
        {
          this->service_channel = _service_channel;
        }

        /// @brief Creates a channel through which vsomeip notify events could be received
        /// @tparam NotifyType DataType of notification event data which we want to
        /// receive using the client application
        /// @param event_id Event ID for the vsomeip notify event
        /// @param event_groups List of all the group IDs the event belongs to
        /// @param func function that calls the model method after converting to model struct
        /// @satisfy{Requirement01321463}
        template <typename NotifyType>
        void addNotifyChannel(
            vsomeip::event_t const& event_id, std::set<vsomeip::eventgroup_t> const& event_groups,
            std::function<void(NotifyType const&)> const& func)
        {
          if (service_channel == nullptr)
          {
            DI_MODEL_LOG_MCTX_ERROR << "[Error] : Service Channel ptr was nullptr" << std::endl;
            return;
          }

          event_ids.push_back(event_id);

          updateEventgroups(event_groups);

          consumer::NotifyChannel<NotifyType>::get_instance().initNotifyChannel(
              service_channel, event_id, event_groups);

          consumer::NotifyChannel<NotifyType>::get_instance().requestEvent();
          consumer::NotifyChannel<NotifyType>::get_instance().setOnEventCallback(func);
          consumer::NotifyChannel<NotifyType>::get_instance().registerEventHandler();

          notify_channel_destructors.push_back(
              []()
              {
                consumer::NotifyChannel<NotifyType>::get_instance().deregisterEventHandler();
                consumer::NotifyChannel<NotifyType>::get_instance().setOnEventCallback({});
                consumer::NotifyChannel<NotifyType>::get_instance().releaseEvent();
                consumer::NotifyChannel<NotifyType>::get_instance().deinitNotifyChannel();
              });
        }

        /// @brief Creates a channel through which vsomeip request/response events could be
        /// sent/received
        /// @tparam RequestType Type of request event data which we want to send using
        /// the server application
        /// @tparam ResponseType Type of response event data which we want to receive using
        /// the server application
        /// @param _method_id
        /// @param func function that calls the model method after converting to model struct
        /// @satisfy{Requirement01321460}
        template <typename RequestType, typename ResponseType>
        void addMessageChannel(
            vsomeip::method_t const& _method_id, std::function<void(ResponseType const&)> const& func)
        {

          consumer::MessageChannel<RequestType, ResponseType>::get_instance().initMessageChannel(
              service_channel, _method_id);
          consumer::MessageChannel<RequestType, ResponseType>::get_instance().setResponseCallback(func);
          consumer::MessageChannel<RequestType, ResponseType>::get_instance().registerMessageHandler();

          method_ids.push_back(_method_id);

          // what if this method gets called twice in init function... check in a test

          message_channel_destructors.push_back(
              []()
              {
                consumer::MessageChannel<RequestType, ResponseType>::get_instance().deregisterMessageHandler();
                consumer::MessageChannel<RequestType, ResponseType>::get_instance().setResponseCallback({});
                consumer::MessageChannel<RequestType, ResponseType>::get_instance().deinitMessageChannel();
              });
        }

        /// @brief Function to send the actual data as vsomeip request event
        /// @tparam RequestType Type of request event data.
        /// @tparam ResponseType Needed because the request and the response
        /// are binded together
        /// @param _request The data of type RequestType we want to send
        template <typename RequestType, typename ResponseType>
        void sendRequest(RequestType const& _request)
        {
          consumer::MessageChannel<RequestType, ResponseType>::get_instance().sendRequest(_request);
        }

        /// @brief Releases the service
        /// @satisfy{Requirement01403282,Requirement01403289,Requirement01403291,Requirement01403332,Requirement01403295}
        void releaseService()
        {
          DI_MODEL_LOG_MCTX_INFO << "SomeipServiceConsumer::releaseService()" << std::endl;

          std::shared_ptr<vsomeip::application> const& m_app = service_channel->get_app();
          vsomeip::service_t const service_id = service_channel->getServiceID();
          vsomeip::instance_t const instance_id = service_channel->getInstanceID();

          // unregister the availability handler
          unregisterAvailabilityHandler();

          // unsubscribe to all eventgroups
          {
            std::lock_guard<std::mutex> lock(this->mutex_eventgroups);
            for (auto it = this->eventgroups.begin(); it != this->eventgroups.end(); ++it)
            {
              vsomeip::eventgroup_t const& eventgroup = *it;
              m_app->unsubscribe(service_id, instance_id, eventgroup);
            }
          }

          // "destroy" all notify channels
          for (void (*const destructor)(void) : notify_channel_destructors)
          {
            (*destructor)();
          }

          // "destroy" all message channels
          for (void (*const destructor)(void) : message_channel_destructors)
          {
            (*destructor)();
          }

          // release service
          m_app->release_service(service_id, instance_id);
        }
      };
    }  // namespace di
  }  // namespace cccm
}  // namespace jlr
#endif
