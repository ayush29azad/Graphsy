#include "soa.h"

using namespace std::string_literals;

namespace soa_payload_v1
{

  bool is_malformed(std::shared_ptr<vsomeip::payload> const& _payload)
  {
    if (_payload != nullptr)
    {
      if (0 == _payload->get_length())
      {
        return false;
      }
      else if (_payload->get_length() < sizeof(uint16_t))
      {
        return true;
      }
      else
      {
        uint16_t length_from_header;
        {
          uint16_t length_header;
          std::memcpy(&length_header, _payload->get_data(), sizeof(uint16_t));
          length_from_header = ntohs(length_header);
        }

        return static_cast<size_t>(_payload->get_length()) !=
               (static_cast<size_t>(length_from_header) + sizeof(uint16_t));
      }
    }
    else
    {
      return false;
    }
  }

  std::string extract_protobuf(std::shared_ptr<vsomeip::payload> const& _payload)
  {
    // Assumption is that Payload is wellformed
    if ((_payload == nullptr) || (_payload->get_length() <= sizeof(uint16_t)))
    {
      return ""s;
    }
    uint8_t const* const data = _payload->get_data();
    uint32_t const length = _payload->get_length();
    std::string result;
    result.reserve(length - sizeof(uint16_t));
    for (uint32_t i = sizeof(uint16_t); i < length; ++i)
    {
      result.push_back(static_cast<char>(data[i]));
    }
    return result;
  }

  std::shared_ptr<vsomeip::payload> create_soa_payload(std::string const& _protobuf)
  {
    // Assumption is that Payload is wellformed
    std::vector<vsomeip::byte_t> vec;
    vec.reserve(sizeof(uint16_t) + _protobuf.size());

    uint16_t const length_header = htons(static_cast<uint16_t>(_protobuf.size()));

    vec.resize(sizeof(length_header));
    std::memcpy(vec.data(), &length_header, sizeof(length_header));

    // implicit type conversion from char to vsomeip::byte_t
    vec.insert(vec.end(), _protobuf.begin(), _protobuf.end());

    auto _payload = vsomeip::runtime::get()->create_payload();
    _payload->set_data(std::move(vec));

    return _payload;
  }
}  // namespace soa_payload_v1

namespace soa_payload_v0
{

  bool is_malformed(std::shared_ptr<vsomeip::payload> const& _payload)
  {
    (void)_payload;
    return false;
  }

  std::string extract_protobuf(std::shared_ptr<vsomeip::payload> const& _payload)
  {
    // Assumption is that Payload is wellformed
    if (_payload != nullptr)
    {
      return std::string(_payload->get_data(), _payload->get_data() + _payload->get_length());
    }
    else
    {
      using namespace std::string_literals;
      return ""s;
    }
  }

  std::shared_ptr<vsomeip::payload> create_soa_payload(std::string const& _protobuf)
  {
    std::vector<vsomeip::byte_t> vec;
    vec.reserve(_protobuf.size());
    // implicit type conversion from char to vsomeip::byte_t
    vec.insert(vec.end(), _protobuf.begin(), _protobuf.end());
    auto _payload = vsomeip::runtime::get()->create_payload();
    _payload->set_data(std::move(vec));
    return _payload;
  }

}  // namespace soa_payload_v0
