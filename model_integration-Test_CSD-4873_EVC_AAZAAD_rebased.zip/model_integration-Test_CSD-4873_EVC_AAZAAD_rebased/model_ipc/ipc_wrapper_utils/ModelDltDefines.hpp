
#ifndef JLRCCCM_MODEL_INTEGRATION_DLT_DEFINES_H
#define JLRCCCM_MODEL_INTEGRATION_DLT_DEFINES_H
#include <cstring>
namespace models_dlt
{
  std::string const BATTERYSTATEOFCHARGEDISP = "MBSC";
  std::string const CHARGINGINFO = "MCIF";
  std::string const DISPLAYODOMETERTRIPCOMPUTER = "MDOC";
  std::string const GAUGESPEEDOMETER = "MGOS";
  std::string const GAUGES = "MGUS";
  std::string const VEHICLELIFECYCLE = "MVLC";
  std::string const INDEXTLIGHTS = "MIEL";
  std::string const INDEXTLIGHTSFLASHING = "MILF";
  std::string const MESSAGECENTRE = "MMGC";
  std::string const MISCTELLTALES = "MMTT";
  std::string const TELLTALESERVICE = "MTTS";
  std::string const STEERINGWHEELSWITCH = "MSWS";
  std::string const DISPLAYZONEFEATURE = "MDZF";
  std::string const INDFLASHING = "MINF";
  std::string const DOORSTATUS = "MDRS";
  std::string const STATICDISPLAYCONFIG = "MSDC";
  std::string const STATUSTPMS = "MTPM";
  std::string const TRANSIENTINFO = "MTRI";
  std::string const MESSAGECENTREDATA = "MMCD";
  std::string const GOLDEN = "MGLD";
  std::string const OUTSIDETEMPFROSTIND = "MOTI";
  std::string const CLOCKDISPLAY = "MCLK";
  std::string const QUICKCONTROLS = "MQCL";
  std::string const TELLTALESERVICE1 = "MTS1";
};  // namespace models_dlt

#endif
