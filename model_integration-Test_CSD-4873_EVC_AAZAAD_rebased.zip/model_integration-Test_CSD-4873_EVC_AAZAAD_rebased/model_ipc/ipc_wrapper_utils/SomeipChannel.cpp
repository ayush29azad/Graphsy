#include "SomeipChannel.hpp"
namespace jlr
{
  namespace cccm
  {
    namespace di
    {
      SomeipChannel::SomeipChannel(std::shared_ptr<vsomeip::application> const app)
      {
        this->m_app = app;
        this->service_id = 0;
        this->instance_id = 0;
      }

      SomeipChannel::SomeipChannel(
          std::shared_ptr<vsomeip::application> const app, vsomeip::service_t const& _service_id,
          vsomeip::instance_t const& _instance_id, vsomeip::major_version_t const _major_version)
      {
        this->m_app = app;
        this->service_id = _service_id;
        this->instance_id = _instance_id;
        this->major_version = _major_version;
      }

      vsomeip::service_t SomeipChannel::getServiceID() const
      {
        return this->service_id;
      }

      void SomeipChannel::setServiceID(vsomeip::service_t const& _service_id)
      {
        this->service_id = _service_id;
      }

      vsomeip::instance_t SomeipChannel::getInstanceID() const
      {
        return this->instance_id;
      }

      void SomeipChannel::setInstanceID(vsomeip::instance_t const& _instance_id)
      {
        this->instance_id = _instance_id;
      }

      vsomeip::major_version_t SomeipChannel::getMajorVersion() const
      {
        return this->major_version;
      }

      void SomeipChannel::setMajorVersion(vsomeip::major_version_t const _major_version)
      {
        this->major_version = _major_version;
      }

      std::shared_ptr<vsomeip::application> SomeipChannel::get_app() const
      {
        return this->m_app;
      }
    }  // namespace di
  }  // namespace cccm
}  // namespace jlr
