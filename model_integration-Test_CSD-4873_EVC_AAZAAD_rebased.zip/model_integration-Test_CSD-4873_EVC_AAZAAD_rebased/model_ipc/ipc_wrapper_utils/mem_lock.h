/// @file mem_lock.h
/// @brief Contains mem_lock function declacations
///
/// @copyright "Copyright (C) 2023, Jaguar Land Rover
/// All rights reserved.
/// CONFIDENTIAL INFORMATION - DO NOT DISTRIBUTE"
///
/// @date July 2023
#ifndef MODEL_MEM_LOCK_H
#define MODEL_MEM_LOCK_H
#include <pthread.h>

namespace model_mem_lock
{
  ///@brief brief description
  void mem_lock(pthread_mutex_t* lock);

  ///@brief brief description
  void mem_unlock(pthread_mutex_t* lock);

  ///@brief brief description
  ///@return description of the return value
  pthread_mutex_t* mem_lock_initialize();

  ///@brief brief description
  void mem_lock_destroy(pthread_mutex_t* lock);
};  // namespace model_mem_lock
#endif
