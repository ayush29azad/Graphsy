/// @file SomeipCommunicationHandler.hpp
/// @brief Contains SomeipCommunicationHandler class declaration and definition
///
/// @copyright "Copyright (C) 2023, Jaguar Land Rover
/// All rights reserved.
/// CONFIDENTIAL INFORMATION - DO NOT DISTRIBUTE"
///
/// @date July 2023

#ifndef SOMEIP_COMMUNICATION_HANDLER_HEADER_H
#define SOMEIP_COMMUNICATION_HANDLER_HEADER_H

#include <SomeipServiceConsumer.hpp>
#include <SomeipServiceProvider.hpp>
#include <iostream>
#include <cstdint>
#include <map>

#include "ProtoDataConverterMessage.hpp"

// todo : ensure thread safety
namespace jlr
{
  namespace cccm
  {
    namespace di
    {
      /// @brief Handles the vsomeip communication for the model
      /// object data to model class object data
      class SomeipCommunicationHandler
      {

      private:
        // public:
        /// @brief Pointer to the vsomeip application
        std::shared_ptr<vsomeip::application> app;

        /// @brief List of all the vsomeip consumers created
        std::vector<std::shared_ptr<SomeipServiceConsumer>> consumers;

        /// @brief List of all the vsomeip providers created
        std::vector<std::shared_ptr<SomeipServiceProvider>> providers;

        /// @brief Mutex to sync model memory block
        std::mutex* const modelMutex;

      public:
        /// @brief Only allowed constructor
        /// @param _app Pointer to the vsomeip::application object
        /// @param _mutex mutex for synchronisation
        SomeipCommunicationHandler(std::shared_ptr<vsomeip::application> const _app, std::mutex* const _mutex)
            : app(_app)
            , modelMutex(_mutex)
        {
        }

        /// @brief Wrapper method over SomeipServiceConsumer::setOnAvailableCallback() method
        /// @param consumer Pointer to the vsomeip consumer object
        /// @param model_func The callback method for the state change in service availibility
        void set_on_available(
            std::shared_ptr<SomeipServiceConsumer> consumer,
            std::function<void(vsomeip::service_t, vsomeip::instance_t, bool)> const model_func) const
        {
          // This is a public interface used outside in generated code
          // This is where a model registers a function to be called on availabilty of
          // service.
          consumer->addOnAvailableCallback(
              [this, model_func](
                  vsomeip::service_t const _service_id,
                  vsomeip::instance_t const _instance_id,
                  bool const _is_available)
              {
                std::lock_guard<std::mutex> lck(*(this->modelMutex));
                model_func(_service_id, _instance_id, _is_available);
              });
        }

        /// @brief Creates a vsomeip service provider (server) object
        /// @param service_id Service ID for the server
        /// @param instance_id Instance ID for the server
        /// @return  Pointer to the created object
        std::shared_ptr<SomeipServiceProvider> create_provider(
            vsomeip::service_t const service_id, vsomeip::instance_t const instance_id)
        {
          auto const channel = std::make_shared<SomeipChannel>(app, service_id, instance_id);
          auto const provider = std::make_shared<SomeipServiceProvider>(channel);
          providers.push_back(provider);
          DI_MODEL_LOG_MCTX_INFO << "[Info]  : Created provider with service id " << service_id << ", instance id "
                                 << instance_id << std::endl;
          return provider;
        }

        /// @brief Creates a vsomeip service consumer (client) object
        /// @param service_id Service ID for the client
        /// @param instance_id Instance ID for the client
        /// @return  Pointer to the created object
        std::shared_ptr<SomeipServiceConsumer> create_consumer(
            vsomeip::service_t const service_id, vsomeip::instance_t const instance_id)
        {
          auto const channel = std::make_shared<SomeipChannel>(app, service_id, instance_id);
          auto const consumer = std::make_shared<SomeipServiceConsumer>(channel);
          consumers.push_back(consumer);
          DI_MODEL_LOG_MCTX_INFO << "[Info]  : Created consumer with service id " << service_id << ", instance id "
                                 << instance_id << std::endl;
          return consumer;
        }

        /// @brief Does the initializations and defines the operations to be done when
        /// the model receives some vsomeip notification event as an input to the model
        /// @tparam ProtoNotifyType The type of the received data
        /// @tparam ModelNotifyType The corresponding data type in the model
        /// @param service_ptr Pointer to the vsomeip client object associated
        /// with the model
        /// @param event_id Event ID for the vsomeip notify event
        /// @param grps List of all the group IDs the event belongs to
        /// @param model_fun Model function ti be called upon receiving the data
        template <typename ProtoNotifyType, typename ModelNotifyType>
        void notify_in(
            std::shared_ptr<SomeipServiceConsumer> service_ptr, vsomeip::event_t event_id, std::vector<uint16_t> grps,
            std::function<void(ModelNotifyType const*)> const& model_fun) const
        {
          // Ideally the input should also be a set. But I am not breaking the external interface for now
          std::set<vsomeip::eventgroup_t> const event_groups(grps.begin(), grps.end());

          service_ptr->addNotifyChannel<ProtoNotifyType>(
              event_id,
              event_groups,
              [this, model_fun](ProtoNotifyType const& data)
              {
                std::lock_guard<std::mutex> lck(*(this->modelMutex));
                ModelNotifyType model_data;
                proto_to_model_dataconverter_message(data, model_data);
                model_fun(&model_data);
              });
        }

        /// @brief Does the initializations and defines the operations to be done when
        /// the model receives some vsomeip notification event as an input to the model
        /// @tparam ProtoNotifyType The type of the received data
        /// @tparam ModelNotifyType The corresponding data type in the model
        /// @param service_ptr Pointer to the vsomeip client object associated
        /// with the model
        /// @param event_id Event ID for the vsomeip notify event
        /// @param grps List of all the group IDs the event belongs to
        /// @param model_fun Model function to be called upon receiving the empty notify in
        template <typename ProtoNotifyType>
        void notify_in(
            std::shared_ptr<SomeipServiceConsumer> service_ptr, vsomeip::event_t event_id, std::vector<uint16_t> grps,
            std::function<void()> const& model_fun) const
        {
          // Ideally the input should also be a set. But I am not breaking the external interface for now
          std::set<vsomeip::eventgroup_t> const event_groups(grps.begin(), grps.end());

          service_ptr->addNotifyChannel<ProtoNotifyType>(
              event_id,
              event_groups,
              [this, model_fun](ProtoNotifyType const&)
              {
                std::lock_guard<std::mutex> lck(*(this->modelMutex));
                model_fun();
              });
        }

        /// @brief Does the initializations and defines the operations to be done
        /// when the model receives some vsomeip response event as an input to the model
        /// @tparam ProtoGetRequest Proto side type of the related request
        /// @tparam ProtoGetResponse The type of the received data
        /// @tparam ModelGetResponse The corresponding data type in the model
        /// @param service_ptr Pointer to the vsomeip client object associated
        /// with the model
        /// @param method_id Method ID for the vsomeip request/response event
        /// @param model_fun Model function to be called upon receiving the data
        template <typename ProtoGetRequest, typename ProtoGetResponse, typename ModelGetResponse>
        void response_in(
            std::shared_ptr<SomeipServiceConsumer> const service_ptr, vsomeip::method_t const method_id,
            std::function<void(ModelGetResponse const*)> const& model_fun) const
        {
          service_ptr->addMessageChannel<ProtoGetRequest, ProtoGetResponse>(
              method_id,
              [this, model_fun](ProtoGetResponse const& data)
              {
                std::lock_guard<std::mutex> lck(*(this->modelMutex));
                ModelGetResponse model_data;
                proto_to_model_dataconverter_message(data, model_data);
                model_fun(&model_data);
              });
        }

        /// @brief Does the initializations for Requests without any response
        /// @tparam ProtoGetRequest Proto side type of the related request
        /// @tparam ProtoGetResponse The type of the received data
        /// @tparam ModelGetResponse The corresponding data type in the model
        /// @param service_ptr Pointer to the vsomeip client object associated
        /// with the model
        /// @param method_id Method ID for the vsomeip request/response event
        template <typename ProtoGetRequest, typename ProtoGetResponse>
        void unpaired_response_in(
            std::shared_ptr<SomeipServiceConsumer> const service_ptr, vsomeip::method_t const method_id)
        {
          service_ptr->addMessageChannel<ProtoGetRequest, ProtoGetResponse>(method_id, {});
        }

        /// @brief Initializations to be done for the model to sends
        /// some vsomeip notification event as an output for the model
        /// @tparam ProtoNotifyType The type associated with the notification
        /// event
        /// @param service_ptr Pointer to the vsomeip server object associated
        /// with the model
        /// @param event_id Event ID for the vsomeip notify event
        /// @param grps List of all the group IDs the event belongs to
        template <typename ProtoNotifyType>
        void notify_out(
            std::shared_ptr<SomeipServiceProvider> service_ptr, vsomeip::event_t event_id, std::vector<uint16_t> grps)
        {
          // Ideally the input should also be a set. But I am not breaking the external interface for now
          std::set<vsomeip::eventgroup_t> const event_groups(grps.begin(), grps.end());
          service_ptr->addNotifyChannel<ProtoNotifyType>(event_id, event_groups);
        }

        /// @brief Does the initializations and defines the operations to be done
        /// when the model receives vsomeip request event as an input. This function
        /// will be used for non empty requests.
        /// @tparam ProtoGetRequest Data type of the received request
        /// @tparam ProtoGetResponse Data type of associated response
        /// @tparam ModelGetRequest Corresponding model data type
        /// @param service_ptr  Pointer to the vsomeip server object associated
        /// with the model
        /// @param method_id Method ID for the vsomeip request event
        /// @param model_fun Model function to be called upon receiving the request data
        template <typename ProtoGetRequest, typename ProtoGetResponse, typename ModelGetRequest>
        void request_in(
            std::shared_ptr<SomeipServiceProvider> const service_ptr, vsomeip::method_t const method_id,
            std::function<void(ModelGetRequest const*)> const& model_fun) const
        {
          service_ptr->addMessageChannel<ProtoGetRequest, ProtoGetResponse>(
              method_id,
              [this, model_fun](ProtoGetRequest const& data)
              {
                std::lock_guard<std::mutex> lck(*(this->modelMutex));
                ModelGetRequest model_data;
                proto_to_model_dataconverter_message(data, model_data);
                model_fun(&model_data);
              });
        }

        /// @brief Does the initializations and defines the operations to be done
        /// when the model receives vsomeip request event as an input. This function
        /// will be used for non requests.
        /// @tparam ProtoGetRequest Data type of the received request
        /// @tparam ProtoGetResponse Data type of associated response
        /// @param service_ptr  Pointer to the vsomeip server object associated
        /// with the model
        /// @param method_id Method ID for the vsomeip request event
        /// @param model_fun Model function to be called upon receiving the request data
        template <typename ProtoGetRequest, typename ProtoGetResponse>
        void request_in(
            std::shared_ptr<SomeipServiceProvider> const service_ptr, vsomeip::method_t const method_id,
            std::function<void()> model_fun) const
        {
          service_ptr->addMessageChannel<ProtoGetRequest, ProtoGetResponse>(
              method_id,
              [this, model_fun](ProtoGetRequest const&)
              {
                std::lock_guard<std::mutex> lck(*(this->modelMutex));
                // Ignore empty request
                model_fun();
              });
        }

        /// @brief terminate SomeipCommunicationHandler
        void terminate() const
        {
          for (auto ptr : providers)
          {
            ptr->releaseService();
            ptr.reset();
          }

          for (auto ptr : consumers)
          {
            ptr->releaseService();
            ptr.reset();
          }
        }
      };
    }  // namespace di
  }  // namespace cccm
}  // namespace jlr
#endif
