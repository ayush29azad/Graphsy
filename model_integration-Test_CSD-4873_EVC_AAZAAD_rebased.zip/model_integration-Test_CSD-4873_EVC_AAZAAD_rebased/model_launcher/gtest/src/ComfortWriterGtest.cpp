/// @file ComfortWriterGtest.cpp
/// @brief Google Test unit tests for ComfortWriter class
/// @copyright "Copyright (C) 2025, Jaguar Land Rover
/// All rights reserved.
/// CONFIDENTIAL INFORMATION - DO NOT DISTRIBUTE"

#include <DDSEntityFactoryMock.h>
#include <gtest/gtest.h>
#include <gmock/gmock.h>
#include <fstream>
#include <string>
#include <memory>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <WorkExecutor.h>
#include <CombinedTopicsPubSubTypes.h>
#include "DDSManagerMock.h"

#define private public
#define protected public
#include "ComfortWriter.h"
#include "ComfortDdsCommunicationHandler.hpp"
#undef private
#undef protected

using namespace jlr::cccm::di::dds;
using namespace cccm::di::launcher;
using namespace testing;

// ============================================================================
// CUSTOM GMOCK ACTION
// ============================================================================

/// @brief Custom action to fill vehicleLifecycle message with test data
ACTION_P(FillLifecycleMsg, msg)
{
  *static_cast<dds_ipc::vehicleLifecycle*>(arg0) = msg;
  return true;
}

// ============================================================================
// TEST FIXTURE
// ============================================================================

/// @satisfy{Requirement01487704, Requirement01487710, Requirement01493726}
class ComfortWriterTest : public ::testing::Test
{
protected:
  void SetUp() override
  {
    auto executor = std::make_shared<jlr::cccm::di::work_executor::WorkExecutor>("TEST_APP");
    auto mockFactory = std::make_shared<MockDDSEntityFactory>();
    mockManager = new DDSManagerMock();

    // Setup factory to return our mock manager
    ON_CALL(*mockFactory, create_manager_proxy_2(_, _)).WillByDefault(Return(mockManager));
    ON_CALL(*mockFactory, create_manager_proxy_3(_, _, _)).WillByDefault(Return(mockManager));

    // Default expectation for init
    EXPECT_CALL(*mockManager, init()).WillRepeatedly(Return(true));

    writer = std::make_unique<ComfortWriter>(mockFactory, executor, "TEST_DLT");

    // Clean up any existing test file
    unlink(ComfortWriter::COMFORT_FILE_PATH);
  }

  void TearDown() override
  {
    // Clean up test file
    unlink(ComfortWriter::COMFORT_FILE_PATH);
  }

  DDSManagerMock* mockManager;
  std::unique_ptr<ComfortWriter> writer;
};

// ============================================================================
// TEST CASES: Constructor
// ============================================================================

/// @satisfy{Requirement01487704}
TEST_F(ComfortWriterTest, Constructor_InitializesDdsHandler_Success)
{
  RecordProperty("requirements", "Requirement01487704");

  ASSERT_NE(writer->mDdsHandler, nullptr);
  EXPECT_FALSE(writer->mIsComfortReached.load());
}

/// @satisfy{Requirement01487704}
TEST_F(ComfortWriterTest, Constructor_HandlesInitFailure_LogsError)
{
  RecordProperty("requirements", "Requirement01487704");

  auto executor = std::make_shared<jlr::cccm::di::work_executor::WorkExecutor>("TEST_APP");
  auto mockFactory = std::make_shared<MockDDSEntityFactory>();
  auto mockMgr = new DDSManagerMock();

  ON_CALL(*mockFactory, create_manager_proxy_2(_, _)).WillByDefault(Return(mockMgr));
  EXPECT_CALL(*mockMgr, init()).WillOnce(Return(false));

  auto testWriter = std::make_unique<ComfortWriter>(mockFactory, executor, "TEST_DLT");

  // Constructor completes even if init fails
  ASSERT_NE(testWriter->mDdsHandler, nullptr);
}

// ============================================================================
// TEST CASES: Initialize
// ============================================================================

/// @satisfy{Requirement01487705, Requirement01487706}
TEST_F(ComfortWriterTest, Initialize_Success_ReturnsTrue)
{
  RecordProperty("requirements", "Requirement01487705, Requirement01487706");

  EXPECT_CALL(*mockManager, register_subscriber(_, _)).WillOnce(Return(true));

  bool result = writer->initialize();

  EXPECT_TRUE(result);
  ASSERT_NE(writer->mDdsHandler->workExecutor, nullptr);
}

/// @satisfy{Requirement01487705}
TEST_F(ComfortWriterTest, Initialize_SubscriptionFails_ReturnsFalse)
{
  RecordProperty("requirements", "Requirement01487705");

  EXPECT_CALL(*mockManager, register_subscriber(_, _)).WillOnce(Return(false));

  bool result = writer->initialize();

  EXPECT_FALSE(result);
}

/// @satisfy{Requirement01487706}
TEST_F(ComfortWriterTest, Initialize_RegistersCallbackInMap_Success)
{
  RecordProperty("requirements", "Requirement01487706");

  EXPECT_CALL(*mockManager, register_subscriber(_, _)).WillOnce(Return(true));

  writer->initialize();

  auto& callbackMap = writer->mDdsHandler->m_dataAvailableCallback;
  EXPECT_EQ(callbackMap.size(), 1);
  EXPECT_NE(callbackMap.find("dds_ipc::vehicleLifecycle"), callbackMap.end());
}

/// @satisfy{Requirement01487705, Requirement01487706}
TEST_F(ComfortWriterTest, Initialize_SetsWorkExecutor_Success)
{
  RecordProperty("requirements", "Requirement01487705, Requirement01487706");

  ASSERT_EQ(writer->mDdsHandler->workExecutor, nullptr);

  EXPECT_CALL(*mockManager, register_subscriber(_, _)).WillOnce(Return(true));

  writer->initialize();

  ASSERT_NE(writer->mDdsHandler->workExecutor, nullptr);
}

/// @satisfy{Requirement01487706}
TEST_F(ComfortWriterTest, Initialize_PassesNonNullTopicDataType_Success)
{
  RecordProperty("requirements", "Requirement01487706");

  eprosima::fastdds::dds::TopicDataType* capturedTypePtr = nullptr;

  EXPECT_CALL(*mockManager, register_subscriber(_, _)).WillOnce(DoAll(SaveArg<1>(&capturedTypePtr), Return(true)));

  writer->initialize();

  ASSERT_NE(capturedTypePtr, nullptr);
}

/// @satisfy{Requirement01487705}
TEST_F(ComfortWriterTest, Initialize_RegistersCorrectTopicName_Success)
{
  RecordProperty("requirements", "Requirement01487705");

  std::string capturedTopic;
  EXPECT_CALL(*mockManager, register_subscriber(_, _)).WillOnce(DoAll(SaveArg<0>(&capturedTopic), Return(true)));

  writer->initialize();

  EXPECT_EQ(capturedTopic, "dds_ipc::vehicleLifecycle");
}

// ============================================================================
// TEST CASES: Lambda Callback Execution (Line Coverage)
// ============================================================================

/// @satisfy{Requirement01487707, Requirement01487706}
TEST_F(ComfortWriterTest, InitializeAndTriggerCallback_Line52Coverage_Success)
{
  RecordProperty("requirements", "Requirement01487707, Requirement01487706");

  EXPECT_CALL(*mockManager, register_subscriber(_, _)).WillOnce(Return(true));
  writer->initialize();

  auto topic = "dds_ipc::vehicleLifecycle";

  if (writer->mDdsHandler && writer->mDdsHandler->m_dataAvailableCallback.count(topic))
  {
    dds_ipc::vehicleLifecycle comfortMsg;
    comfortMsg.eVehicle_State(dds_ipc::enmVehicleState::ENUM_STATE_COMFORT);
    EXPECT_CALL(*mockManager, recv_data(_, _)).WillOnce(FillLifecycleMsg(comfortMsg));

    writer->mDdsHandler->m_dataAvailableCallback[topic]();

    EXPECT_TRUE(std::ifstream(ComfortWriter::COMFORT_FILE_PATH).good());
  }
  else
  {
    FAIL() << "Callback map is empty or topic name is wrong!";
  }
}

// ============================================================================
// TEST CASES: Complete File Lifecycle
// ============================================================================

/// @satisfy{Requirement01487707, Requirement01493726}
TEST_F(ComfortWriterTest, VerifyComfortFileCycle_CreateAndDelete_Success)
{
  RecordProperty("requirements", "Requirement01487707, Requirement01493726");

  // 1. Test COMFORT state - File should be created
  dds_ipc::vehicleLifecycle comfortMsg;
  comfortMsg.eVehicle_State(dds_ipc::enmVehicleState::ENUM_STATE_COMFORT);
  EXPECT_CALL(*mockManager, recv_data(_, _)).WillOnce(FillLifecycleMsg(comfortMsg));

  writer->on_comfort_data_available();
  ASSERT_TRUE(std::ifstream(ComfortWriter::COMFORT_FILE_PATH).good());

  // 2. Second time: Already in COMFORT - File should still exist
  EXPECT_CALL(*mockManager, recv_data(_, _)).WillOnce(FillLifecycleMsg(comfortMsg));
  writer->on_comfort_data_available();
  ASSERT_TRUE(std::ifstream(ComfortWriter::COMFORT_FILE_PATH).good());

  // 3. Test DUTY state - File should be deleted
  dds_ipc::vehicleLifecycle dutyMsg;
  dutyMsg.eVehicle_State(dds_ipc::enmVehicleState::ENUM_STATE_DUTY);
  EXPECT_CALL(*mockManager, recv_data(_, _)).WillOnce(FillLifecycleMsg(dutyMsg));

  writer->on_comfort_data_available();
  std::ifstream f(ComfortWriter::COMFORT_FILE_PATH);
  EXPECT_FALSE(f.good());
}

/// @satisfy{Requirement01487707, Requirement01493726}
TEST_F(ComfortWriterTest, OnComfortDataAvailable_ComfortState_CreatesFile)
{
  RecordProperty("requirements", "Requirement01487707, Requirement01493726");

  dds_ipc::vehicleLifecycle comfortMsg;
  comfortMsg.eVehicle_State(dds_ipc::enmVehicleState::ENUM_STATE_COMFORT);
  EXPECT_CALL(*mockManager, recv_data(_, _)).WillOnce(FillLifecycleMsg(comfortMsg));

  writer->on_comfort_data_available();

  EXPECT_TRUE(std::ifstream(ComfortWriter::COMFORT_FILE_PATH).good());
  EXPECT_TRUE(writer->mIsComfortReached.load());
}

/// @satisfy{Requirement01487707}
TEST_F(ComfortWriterTest, OnComfortDataAvailable_CalledTwice_CreatesFileOnlyOnce)
{
  RecordProperty("requirements", "Requirement01487707");

  dds_ipc::vehicleLifecycle comfortMsg;
  comfortMsg.eVehicle_State(dds_ipc::enmVehicleState::ENUM_STATE_COMFORT);

  EXPECT_CALL(*mockManager, recv_data(_, _)).Times(2).WillRepeatedly(FillLifecycleMsg(comfortMsg));

  writer->on_comfort_data_available();
  EXPECT_TRUE(std::ifstream(ComfortWriter::COMFORT_FILE_PATH).good());
  EXPECT_TRUE(writer->mIsComfortReached.load());

  writer->on_comfort_data_available();
  EXPECT_TRUE(std::ifstream(ComfortWriter::COMFORT_FILE_PATH).good());
  EXPECT_TRUE(writer->mIsComfortReached.load());
}

// ============================================================================
// TEST CASES: File Deletion in DUTY State
// ============================================================================

/// @satisfy{Requirement01493726}
TEST_F(ComfortWriterTest, OnComfortDataAvailable_DutyStateAfterComfort_DeletesFile)
{
  RecordProperty("requirements", "Requirement01493726");

  // Create file first
  dds_ipc::vehicleLifecycle comfortMsg;
  comfortMsg.eVehicle_State(dds_ipc::enmVehicleState::ENUM_STATE_COMFORT);
  EXPECT_CALL(*mockManager, recv_data(_, _)).WillOnce(FillLifecycleMsg(comfortMsg));

  writer->on_comfort_data_available();
  ASSERT_TRUE(std::ifstream(ComfortWriter::COMFORT_FILE_PATH).good());

  // Transition to DUTY
  dds_ipc::vehicleLifecycle dutyMsg;
  dutyMsg.eVehicle_State(dds_ipc::enmVehicleState::ENUM_STATE_DUTY);
  EXPECT_CALL(*mockManager, recv_data(_, _)).WillOnce(FillLifecycleMsg(dutyMsg));

  writer->on_comfort_data_available();

  std::ifstream f(ComfortWriter::COMFORT_FILE_PATH);
  EXPECT_FALSE(f.good());
  EXPECT_FALSE(writer->mIsComfortReached.load());
}

/// @satisfy{Requirement01487708, Requirement01487709, Requirement01493726}
TEST_F(ComfortWriterTest, OnComfortDataAvailable_DutyStateAfterComfort_CallsDeinitialize)
{
  RecordProperty("requirements", "Requirement01487708, Requirement01487709, Requirement01493726");

  // Create file first
  dds_ipc::vehicleLifecycle comfortMsg;
  comfortMsg.eVehicle_State(dds_ipc::enmVehicleState::ENUM_STATE_COMFORT);
  EXPECT_CALL(*mockManager, recv_data(_, _)).WillOnce(FillLifecycleMsg(comfortMsg));
  writer->on_comfort_data_available();

  // Transition to DUTY
  dds_ipc::vehicleLifecycle dutyMsg;
  dutyMsg.eVehicle_State(dds_ipc::enmVehicleState::ENUM_STATE_DUTY);
  EXPECT_CALL(*mockManager, recv_data(_, _)).WillOnce(FillLifecycleMsg(dutyMsg));

  writer->on_comfort_data_available();

  EXPECT_EQ(writer->mDdsHandler, nullptr);
}

// ============================================================================
// TEST CASES: DDS Buffer Failures
// ============================================================================

/// @satisfy{Requirement01487705, Requirement01487706, Requirement01487709, Requirement01487707}
TEST_F(ComfortWriterTest, HandleDdsBufferFailure_NoFileCreated)
{
  RecordProperty("requirements", "Requirement01487705, Requirement01487706, Requirement01487709, Requirement01487707");

  EXPECT_CALL(*mockManager, recv_data(_, _)).WillOnce(Return(false));

  writer->on_comfort_data_available();

  std::ifstream f(ComfortWriter::COMFORT_FILE_PATH);
  EXPECT_FALSE(f.good());
}

/// @satisfy{Requirement01487707}
TEST_F(ComfortWriterTest, OnComfortDataAvailable_MultipleRecvDataFailures_StateUnchanged)
{
  RecordProperty("requirements", "Requirement01487707");

  EXPECT_CALL(*mockManager, recv_data(_, _)).Times(3).WillRepeatedly(Return(false));

  writer->on_comfort_data_available();
  writer->on_comfort_data_available();
  writer->on_comfort_data_available();

  std::ifstream f(ComfortWriter::COMFORT_FILE_PATH);
  EXPECT_FALSE(f.good());
  EXPECT_FALSE(writer->mIsComfortReached.load());
}

// ============================================================================
// TEST CASES: File Deletion Edge Cases
// ============================================================================

/// @satisfy{Requirement01487707, Requirement01493726}
TEST_F(ComfortWriterTest, DeleteFileFailure_FileAlreadyDeleted_HandlesGracefully)
{
  RecordProperty("requirements", "Requirement01487707, Requirement01493726");

  // Enter COMFORT state
  dds_ipc::vehicleLifecycle comfortMsg;
  comfortMsg.eVehicle_State(dds_ipc::enmVehicleState::ENUM_STATE_COMFORT);
  EXPECT_CALL(*mockManager, recv_data(_, _)).WillOnce(FillLifecycleMsg(comfortMsg));
  writer->on_comfort_data_available();

  ASSERT_TRUE(std::ifstream(ComfortWriter::COMFORT_FILE_PATH).good());

  // Delete the file manually
  std::remove(ComfortWriter::COMFORT_FILE_PATH);

  // Trigger DUTY state
  dds_ipc::vehicleLifecycle dutyMsg;
  dutyMsg.eVehicle_State(dds_ipc::enmVehicleState::ENUM_STATE_DUTY);
  EXPECT_CALL(*mockManager, recv_data(_, _)).WillOnce(FillLifecycleMsg(dutyMsg));

  writer->on_comfort_data_available();

  EXPECT_FALSE(writer->mIsComfortReached.load());
}

/// @satisfy{Requirement01487707, Requirement01493726}
TEST_F(ComfortWriterTest, DoesNotRetryIfAlreadyMarked_DirectoryConflict)
{
  RecordProperty("requirements", "Requirement01487707, Requirement01493726");

  dds_ipc::vehicleLifecycle comfortMsg;
  comfortMsg.eVehicle_State(dds_ipc::enmVehicleState::ENUM_STATE_COMFORT);

  // Create a folder with the same name as the file
  system("rm -rf /dev/shmem/VehicleStateComfort.txt");
  system("mkdir /dev/shmem/VehicleStateComfort.txt");

  EXPECT_CALL(*mockManager, recv_data(_, _)).WillOnce(FillLifecycleMsg(comfortMsg));
  writer->on_comfort_data_available();

  // Verify the file was NOT created (the folder is still there)
  struct stat s;
  stat("/dev/shmem/VehicleStateComfort.txt", &s);
  EXPECT_TRUE(S_ISDIR(s.st_mode));

  EXPECT_TRUE(writer->mIsComfortReached.load());

  // Cleanup
  system("rm -rf /dev/shmem/VehicleStateComfort.txt");
}

/// @satisfy{Requirement01487707}
TEST_F(ComfortWriterTest, ExecuteComfortLogic_FileAlreadyExists_OverwritesFile)
{
  RecordProperty("requirements", "Requirement01487707");

  // Pre-create the file
  std::ofstream preFile(ComfortWriter::COMFORT_FILE_PATH);
  preFile << "existing content";
  preFile.close();
  ASSERT_TRUE(std::ifstream(ComfortWriter::COMFORT_FILE_PATH).good());

  writer->execute_comfort_logic_and_cleanup();

  EXPECT_TRUE(std::ifstream(ComfortWriter::COMFORT_FILE_PATH).good());
  EXPECT_TRUE(writer->mIsComfortReached.load());
}

// ============================================================================
// TEST CASES: Deinitialize
// ============================================================================

/// @satisfy{Requirement01487708, Requirement01487709}
TEST_F(ComfortWriterTest, Deinitialize_ResetsDdsHandler_Success)
{
  RecordProperty("requirements", "Requirement01487708, Requirement01487709");

  EXPECT_CALL(*mockManager, register_subscriber(_, _)).WillOnce(Return(true));
  writer->initialize();
  ASSERT_NE(writer->mDdsHandler, nullptr);

  writer->deinitialize();

  EXPECT_EQ(writer->mDdsHandler, nullptr);
}

/// @satisfy{Requirement01487708}
TEST_F(ComfortWriterTest, Deinitialize_CalledMultipleTimes_NoError)
{
  RecordProperty("requirements", "Requirement01487708");

  EXPECT_CALL(*mockManager, register_subscriber(_, _)).WillOnce(Return(true));
  writer->initialize();

  writer->deinitialize();
  EXPECT_EQ(writer->mDdsHandler, nullptr);

  writer->deinitialize();
  EXPECT_EQ(writer->mDdsHandler, nullptr);
}

// ============================================================================
// TEST CASES: Non-COMFORT States
// ============================================================================

/// @satisfy{Requirement01487707}
TEST_F(ComfortWriterTest, OnComfortDataAvailable_DutyStateInitially_NoFileCreated)
{
  RecordProperty("requirements", "Requirement01487707");

  dds_ipc::vehicleLifecycle dutyMsg;
  dutyMsg.eVehicle_State(dds_ipc::enmVehicleState::ENUM_STATE_DUTY);
  EXPECT_CALL(*mockManager, recv_data(_, _)).WillOnce(FillLifecycleMsg(dutyMsg));

  writer->on_comfort_data_available();

  std::ifstream f(ComfortWriter::COMFORT_FILE_PATH);
  EXPECT_FALSE(f.good());
  EXPECT_FALSE(writer->mIsComfortReached.load());
}

/// @satisfy{Requirement01487707}
TEST_F(ComfortWriterTest, OnComfortDataAvailable_MultipleNonComfortStates_NoFileOperations)
{
  RecordProperty("requirements", "Requirement01487707");

  dds_ipc::vehicleLifecycle dutyMsg;
  dutyMsg.eVehicle_State(dds_ipc::enmVehicleState::ENUM_STATE_DUTY);

  EXPECT_CALL(*mockManager, recv_data(_, _)).Times(3).WillRepeatedly(FillLifecycleMsg(dutyMsg));

  writer->on_comfort_data_available();
  writer->on_comfort_data_available();
  writer->on_comfort_data_available();

  std::ifstream f(ComfortWriter::COMFORT_FILE_PATH);
  EXPECT_FALSE(f.good());
  EXPECT_FALSE(writer->mIsComfortReached.load());
}

// ============================================================================
// TEST CASES: Atomic Flag Behavior
// ============================================================================

/// @satisfy{Requirement01487707, Requirement01493726}
TEST_F(ComfortWriterTest, AtomicFlag_IdempotentFileCreation_Success)
{
  RecordProperty("requirements", "Requirement01487707, Requirement01493726");

  dds_ipc::vehicleLifecycle comfortMsg;
  comfortMsg.eVehicle_State(dds_ipc::enmVehicleState::ENUM_STATE_COMFORT);

  EXPECT_CALL(*mockManager, recv_data(_, _)).Times(2).WillRepeatedly(FillLifecycleMsg(comfortMsg));

  writer->on_comfort_data_available();
  EXPECT_TRUE(std::ifstream(ComfortWriter::COMFORT_FILE_PATH).good());
  EXPECT_TRUE(writer->mIsComfortReached.load());

  writer->on_comfort_data_available();
  EXPECT_TRUE(std::ifstream(ComfortWriter::COMFORT_FILE_PATH).good());
  EXPECT_TRUE(writer->mIsComfortReached.load());
}
TEST_F(ComfortWriterTest, StateTransition_ComfortToDutyToComfort_WithReinitialize)
{
  RecordProperty("requirements", "Requirement01487707, Requirement01493726");

  // 1. COMFORT state
  dds_ipc::vehicleLifecycle comfortMsg;
  comfortMsg.eVehicle_State(dds_ipc::enmVehicleState::ENUM_STATE_COMFORT);
  EXPECT_CALL(*mockManager, register_subscriber(_, _)).WillOnce(Return(true));
  writer->initialize();
  EXPECT_CALL(*mockManager, recv_data(_, _)).WillOnce(FillLifecycleMsg(comfortMsg));
  writer->on_comfort_data_available();
  EXPECT_TRUE(std::ifstream(ComfortWriter::COMFORT_FILE_PATH).good());

  // 2. DUTY state - deletes file and deinitializes
  dds_ipc::vehicleLifecycle dutyMsg;
  dutyMsg.eVehicle_State(dds_ipc::enmVehicleState::ENUM_STATE_DUTY);
  EXPECT_CALL(*mockManager, recv_data(_, _)).WillOnce(FillLifecycleMsg(dutyMsg));
  writer->on_comfort_data_available();
  EXPECT_FALSE(std::ifstream(ComfortWriter::COMFORT_FILE_PATH).good());
  EXPECT_EQ(writer->mDdsHandler, nullptr);  // Verify deinitialize was called

  // 3. CANNOT use writer again without reinitialize
  // This is expected behavior - test ends here
}

/// @satisfy{Requirement01493726}
TEST_F(ComfortWriterTest, OnComfortDataAvailable_DeleteNonExistentFile_HandlesGracefully)
{
  RecordProperty("requirements", "Requirement01493726");

  writer->mIsComfortReached.store(true);
  ASSERT_FALSE(std::ifstream(ComfortWriter::COMFORT_FILE_PATH).good());

  dds_ipc::vehicleLifecycle dutyMsg;
  dutyMsg.eVehicle_State(dds_ipc::enmVehicleState::ENUM_STATE_DUTY);
  EXPECT_CALL(*mockManager, recv_data(_, _)).WillOnce(FillLifecycleMsg(dutyMsg));

  writer->on_comfort_data_available();

  EXPECT_FALSE(writer->mIsComfortReached.load());
}
