#include <iostream>
#include <gtest/gtest.h>
#include <gmock/gmock.h>
#include <WorkQueue.h>
#include <WorkQueueSTL.h>
#include <vsomeip/vsomeip.hpp>
#include <ModelLauncher.h>
#include <DDSEntityFactory.hpp>

#define GetCurrentDir getcwd

using namespace std;
using ModelLauncher = cccm::di::launcher::ModelLauncher;
using ::testing::_;
using ::testing::Eq;
using ::testing::Matcher;
using ::testing::Pointee;
using ::testing::Return;

using DDSEntityFactory = jlr::cccm::di::dds::DDSEntityFactory;

class ModelLauncherGtest : public ::testing::Test
{
  void SetUp()
  {
    mApp10 = make_shared<vsomeip::application>();
    mApp11 = make_shared<vsomeip::application>();
    someipApp_map.insert({"vid10", mApp10});
    someipApp_map.insert({"vid11", mApp11});
  }
  void TearDown()
  {
  }

public:
  int n;
  std::shared_ptr<vsomeip::application> mApp10 = nullptr;
  std::shared_ptr<vsomeip::application> mApp11 = nullptr;
  std::unordered_map<std::string, std::shared_ptr<vsomeip::application>> someipApp_map;
};

TEST_F(ModelLauncherGtest, set_context_test)
{
  RecordProperty("requirements", "Requirement01445543");
  auto ctx = std::make_shared<cccm::di::launcher::LauncherContext>();
  ctx->someipApp_map = someipApp_map;

  ModelLauncher::get_instance().set_context(ctx);
  auto result10 = ModelLauncher::get_instance().get_app("vid10");
  auto result11 = ModelLauncher::get_instance().get_app("vid11");
  EXPECT_EQ(someipApp_map["vid10"], result10);
  EXPECT_EQ(someipApp_map["vid11"], result11);
}

TEST_F(ModelLauncherGtest, init_application_test)
{
  auto ctx = std::make_shared<cccm::di::launcher::LauncherContext>();
  ctx->someipApp_map = someipApp_map;
  ctx->workExecutor = nullptr;

  EXPECT_CALL(*mApp10, init());
  EXPECT_CALL(*mApp11, init());

  ModelLauncher::get_instance().set_context(ctx);
  ModelLauncher::get_instance().init_applications();
}

TEST_F(ModelLauncherGtest, start_application_test)
{
  RecordProperty("requirements", "Requirement01445545");
  auto ctx = std::make_shared<cccm::di::launcher::LauncherContext>();
  ctx->someipApp_map = someipApp_map;
  ctx->workExecutor = nullptr;

  ModelLauncher::get_instance().set_context(ctx);

  EXPECT_CALL(*someipApp_map["vid10"], init());
  EXPECT_CALL(*someipApp_map["vid10"], start());
  EXPECT_CALL(*someipApp_map["vid11"], init());
  EXPECT_CALL(*someipApp_map["vid11"], start());

  ModelLauncher::get_instance().init_applications();
  ModelLauncher::get_instance().start_applications();
}

TEST_F(ModelLauncherGtest, load_all_models_Success)
{
  std::vector<std::string> modelLibs = {"batteryStateOfChargeDisp", "chargingInfo"};

  auto ctx = std::make_shared<cccm::di::launcher::LauncherContext>();
  ctx->someipApp_map = someipApp_map;
  ctx->workExecutor = nullptr;

  ModelLauncher::get_instance().set_context(ctx);
  auto result = ModelLauncher::get_instance().load_all_models(modelLibs);

  EXPECT_EQ(2, result);
}

TEST_F(ModelLauncherGtest, terminate_application_test)
{
  auto models_before = ModelLauncher::get_instance().get_models().size();
  ModelLauncher::get_instance().terminate();
  auto models_after = ModelLauncher::get_instance().get_models().size();

  EXPECT_EQ(2, models_before);
  EXPECT_EQ(0, models_after);
}

TEST_F(ModelLauncherGtest, dlclose_test)
{
  auto loaders = ModelLauncher::get_instance().get_loaders().size();
  auto dlcloseCount = ModelLauncher::get_instance().dlCloseAll();
  EXPECT_EQ(2, loaders);
  EXPECT_EQ(2, dlcloseCount);
}

TEST_F(ModelLauncherGtest, stop_application_test)
{
  auto ctx = std::make_shared<cccm::di::launcher::LauncherContext>();
  ctx->someipApp_map = someipApp_map;
  ctx->workExecutor = nullptr;

  ModelLauncher::get_instance().set_context(ctx);

  EXPECT_CALL(*someipApp_map["vid10"], init());
  EXPECT_CALL(*someipApp_map["vid10"], start());
  EXPECT_CALL(*someipApp_map["vid10"], stop());

  EXPECT_CALL(*someipApp_map["vid11"], init());
  EXPECT_CALL(*someipApp_map["vid11"], start());
  EXPECT_CALL(*someipApp_map["vid11"], stop());

  ModelLauncher::get_instance().init_applications();
  ModelLauncher::get_instance().start_applications();
  ModelLauncher::get_instance().stop_applications();
}

TEST_F(ModelLauncherGtest, load_all_models_Failure)
{
  std::vector<std::string> modelLibs = {"batteryStateOfChargeDisp", "IV"};

  auto ctx = std::make_shared<cccm::di::launcher::LauncherContext>();
  ctx->someipApp_map = someipApp_map;
  ctx->workExecutor = nullptr;

  ModelLauncher::get_instance().set_context(ctx);
  auto models_loaded = ModelLauncher::get_instance().load_all_models(modelLibs);
  if (models_loaded != modelLibs.size())
  {
    ModelLauncher::get_instance().terminate();
  }
  auto models_after = ModelLauncher::get_instance().get_models().size();

  // only 1 model is loaded properly out of the 2 models given
  EXPECT_EQ(1, models_loaded);
  EXPECT_EQ(0, models_after);
}

class ModelLauncherGtestFailureSuite : public ::testing::Test
{
  void SetUp()
  {
    mApp = make_shared<vsomeip::application>();
  }
  void TearDown()
  {
  }

public:
  int n;
  std::shared_ptr<vsomeip::application> mApp = nullptr;
};
