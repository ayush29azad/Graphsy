#ifndef DDS_MANAGER_MOCK_H
#define DDS_MANAGER_MOCK_H

#include <gmock/gmock.h>
#include <DDSEntityFactoryInterface.hpp>
#include <string>

class DDSManagerMock : public jlr::cccm::di::dds::DDSManagerInterface
{
public:
  DDSManagerMock() = default;
  virtual ~DDSManagerMock() = default;

  MOCK_METHOD(bool, init, (), (override));
  MOCK_METHOD(bool, deinit, (), (override));
  MOCK_METHOD(bool, register_subscriber, (std::string const&, eprosima::fastdds::dds::TopicDataType*), (override));
  MOCK_METHOD(bool, recv_data, (void*, std::string const&), (override));
  MOCK_METHOD(bool, register_publisher, (std::string const&, eprosima::fastdds::dds::TopicDataType*), (override));
  MOCK_METHOD(bool, send_data, (void*, std::string const&), (override));
  MOCK_METHOD(std::string, get_topic_name, (eprosima::fastdds::dds::DataReader*), (override));
};
#endif
