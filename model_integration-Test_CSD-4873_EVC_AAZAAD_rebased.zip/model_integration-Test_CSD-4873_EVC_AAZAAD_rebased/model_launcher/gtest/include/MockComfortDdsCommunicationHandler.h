#ifndef MOCK_COMFORT_DDS_COMMUNICATION_HANDLER_H
#define MOCK_COMFORT_DDS_COMMUNICATION_HANDLER_H

#include <gmock/gmock.h>
#include <memory>
#include <string>
#include <functional>
#include <WorkExecutor.h>

namespace jlr
{
  namespace cccm
  {
    namespace di
    {

      class MockComfortDdsCommunicationHandler
      {
      public:
        // Mocks for the methods initialize() calls
        MOCK_METHOD(void, set_work_executor, (std::shared_ptr<jlr::cccm::di::work_executor::WorkExecutor>));
        MOCK_METHOD(bool, topic_in, (std::string const& topic, void* data, std::function<void()> const& callback));
      };

    }  // namespace di
  }  // namespace cccm
}  // namespace jlr

#endif  // MOCK_COMFORT_DDS_COMMUNICATION_HANDLER_H
