/// @file SafeQueue.h
/// @brief SafeQueue for doxygen examples
///
/// @copyright "Copyright (C) 2020, Jaguar Land Rover
/// All rights reserved.
/// CONFIDENTIAL INFORMATION - DO NOT DISTRIBUTE"
///
/// @date October 2023

#ifndef JLRCCCM_SAFE_QUEUE_H
#define JLRCCCM_SAFE_QUEUE_H

#include <condition_variable>
#include <memory>
#include <mutex>
#include <queue>
#include <atomic>
#include "Work.h"
#include <unistd.h>  //Todo

namespace jlr
{
  namespace cccm
  {
    namespace di
    {
      namespace work_executor
      {
        /// @brief Custom child exception class for operation aborted
        class OperationAbortedException : public std::exception
        {
        };
        // class ModelWorkerThread;

        /// @brief Safe queue implementation class
        /// @tparam T Generic type for message queue
        template <typename T>
        class SafeQueue
        {
        private:
          mutable std::mutex mMutex;  ///< mutex to lock queue
          std::queue<T> mQueue;  ///< queue instance
          std::condition_variable mCondVar;  ///< condition variable for queue
          std::atomic<bool> mAbort{false};  ///< abort flag value

        public:
          /// @brief Abort function for queue operations

          void abort()
          {
          }

          /// @brief Function to push a message into queue
          /// @param message The message to be pushed into queue
          void push(T const& message)
          {
          }

          /// @brief Function to move a message into queue
          /// @param message The message to be pushed into queue
          void push(T&& message)
          {
          }

          /// @brief Function to pop a message from queue
          /// @return Popped message from queue
          /// @throw custom OperationAbortedException
          T pop()
          {
          }

          /// @brief Function to check if the queue is empty
          /// @return true if queue is empty, false if non-empty
          bool empty() const
          {
          }
        };

        //}  // namespace val
      }  // namespace work_executor
    }  // namespace di
  }  // namespace cccm
}  // namespace jlr

#endif  // JLRCCCM_SAFE_QUEUE_H
