/// @file WorkQueue.h
/// @brief WorkQueue for doxygen examples
///
/// @copyright "Copyright (C) 2020, Jaguar Land Rover
/// All rights reserved.
/// CONFIDENTIAL INFORMATION - DO NOT DISTRIBUTE"
///
/// @date October 2023

#ifndef _WORKQUEUE_HEADER_
#define _WORKQUEUE_HEADER_

#include <iostream>
#include <Work.h>

namespace jlr
{
  namespace cccm
  {
    namespace di
    {
      namespace work_executor
      {
        class WorkQueue
        {

        protected:
          int qSize = 0;
          std::string _qName;
          Work mWork;

        public:
          WorkQueue(){};

          virtual ~WorkQueue(){};

          WorkQueue(int _qSize, std::string _qName)
          {
            this->qSize = _qSize;
            this->_qName = _qName;
          };

          // Could be blocking
          virtual int8_t send(Work* work)
          {
            return 0;
          };

          // Could be Blocking
          virtual Work& recv()
          {
            return mWork;
          };

          virtual void stop()
          {
            return;
          };

          virtual bool checkForEmpty()
          {
            return false;
          };

          virtual void signalQueue() {};

          virtual bool getThreadStatus()
          {
            return false;
          };
          virtual void setThreadStatus(bool status) {};
        };
      }  // namespace work_executor
    }  // namespace di
  }  // namespace cccm
}  // namespace jlr

#endif
