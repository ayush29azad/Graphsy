/// @file WorkExecutor.h
/// @brief WorkExecutor for doxygen examples
///
/// @copyright "Copyright (C) 2020, Jaguar Land Rover
/// All rights reserved.
/// CONFIDENTIAL INFORMATION - DO NOT DISTRIBUTE"
///
/// @date October 2023

#ifndef _JLRWORKEXECUTOR_HEADER_
#define _JLRWORKEXECUTOR_HEADER_

#include <iostream>
#include <thread>
#include <functional>
#include <WorkQueueSTL.h>
// #include <WorkQueueMq.hpp>

namespace jlr
{
  namespace cccm
  {
    namespace di
    {
      namespace work_executor
      {
        class WorkExecutor
        {

        private:
          std::thread workerThread;
          std::shared_ptr<WorkQueue> mWorkQueue = nullptr;
          std::string qName;
          int const queueSize = 256;
          bool mIsHealthGood = true;
          bool mIsRunning = true;
          // condition_variable
          // std::mutex mExecThreadMtx;
          // std::condition_variable mExecThreadCv;

        public:
          WorkExecutor()
          {
            mWorkQueue = std::make_shared<WorkQueueSTL>();
          }

          WorkExecutor(std::string dlt_app_name)
          {
            mWorkQueue = std::make_shared<WorkQueueSTL>();
          }

          void stop()
          {
          }
          void run()
          {
          }
          void signalThread()
          {
          }
          void setThreadStatus(bool status)
          {
          }
          bool getThreadStatus()
          {
          }
          void stopThread()
          {
          }
          int8_t addWork(std::function<void()> funToBeExecuted)
          {
          }

          ~WorkExecutor()
          {
          }
        };
      }  // namespace work_executor
    }  // namespace di
  }  // namespace cccm
}  // namespace jlr

#endif
