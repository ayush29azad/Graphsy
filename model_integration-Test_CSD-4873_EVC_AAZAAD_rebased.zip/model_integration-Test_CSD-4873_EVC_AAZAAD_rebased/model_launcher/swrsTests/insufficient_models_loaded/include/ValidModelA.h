#include "gmock/gmock.h"
#include "ModelLibInterface.h"
#include <vsomeip/vsomeip.hpp>

class ValidModelA : public cccm::di::ModelLibInterface
{
public:
  ValidModelA(){};
  ~ValidModelA(){};
  MOCK_METHOD(void, init, (std::shared_ptr<cccm::di::launcher::LauncherContext> context), (override));
  MOCK_METHOD(void, terminate, (), (override));
};
