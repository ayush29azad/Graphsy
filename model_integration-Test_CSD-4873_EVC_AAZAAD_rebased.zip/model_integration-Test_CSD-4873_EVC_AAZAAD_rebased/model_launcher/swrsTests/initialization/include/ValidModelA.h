#include "gmock/gmock.h"
#include "ModelLibInterface.h"
#include <vsomeip/vsomeip.hpp>

class ValidModelA : public cccm::di::ModelLibInterface
{
public:
  std::unordered_map<std::string, std::shared_ptr<vsomeip::application>> someipApp_map;

  ValidModelA(){};
  ~ValidModelA(){};

  void init(std::shared_ptr<cccm::di::launcher::LauncherContext> context) override
  {
    someipApp_map = context->someipApp_map;
  }

  void terminate() override
  {
    for (auto& pair : someipApp_map)
    {
      pair.second.reset();
    }
  }
};
