/// @file dlt_logger.hpp
/// @brief Contains all function declaration required to launch models
///
/// @copyright "Copyright (C) 2023, Jaguar Land Rover
/// All rights reserved.
/// CONFIDENTIAL INFORMATION - DO NOT DISTRIBUTE"
///
/// @date November 2023
#ifndef _JLRCCCM_MODEL_INTEGRATION__TEST_DLT_HELPER_H_
#define _JLRCCCM_MODEL_INTEGRATION__TEST_DLT_HELPER_H_

#define DI_MODEL_LOG_MCTX_FATAL std::cout
#define DI_MODEL_LOG_MCTX_ERROR std::cout
#define DI_MODEL_LOG_MCTX_WARN std::cout
#define DI_MODEL_LOG_MCTX_INFO std::cout
#define DI_MODEL_LOG_MCTX_DEBUG std::cout

#endif
