#include <iostream>
#include <typeinfo>
#include <WorkExecutor.h>
#include <mutex>
#include <thread>
#include <chrono>
#include <vsomeip/vsomeip.hpp>
#include <ModelLauncher.h>
#include <ValidModelA.h>
#include <DDSEntityFactory.hpp>
#include <ArgParser.h>
#include <ModelContextFactoryInterface.h>
#include <Application.h>

#include <gtest/gtest.h>
#include <gmock/gmock.h>

using namespace std;
using namespace cccm::di::launcher;
using namespace jlr::cccm::di::dds;
using namespace eprosima::fastdds::dds;

using ::testing::_;
using ::testing::AtLeast;
using ::testing::Eq;
using ::testing::Invoke;
using ::testing::Matcher;
using ::testing::Pointee;
using ::testing::Return;

using DDSEntityFactoryInterface = jlr::cccm::di::dds::DDSEntityFactoryInterface;
using DDSEntityFactory = jlr::cccm::di::dds::DDSEntityFactory;
using WorkExecutor = jlr::cccm::di::work_executor::WorkExecutor;
using LauncherContext = cccm::di::launcher::LauncherContext;

namespace model_launcher_main
{
  void model_launcher_terminate();
}

class MockTopicDataType : public TopicDataType
{
};

namespace cccm::di::launcher
{
  class MockModelContextFactory : public ModelContextFactoryInterface
  {
  public:
    MockModelContextFactory(ArgParser& argParser)
    {
    }
    using SomeIpAppMap = std::unordered_map<std::string, std::shared_ptr<vsomeip::application>>;
    MOCK_METHOD(SomeIpAppMap, create_someip_applications, (), (override));
    MOCK_METHOD(std::shared_ptr<DDSEntityFactoryInterface>, create_dds_factory, (), (override));
    MOCK_METHOD(std::shared_ptr<WorkExecutor>, create_workexecutor, (), (override));
    MOCK_METHOD(std::shared_ptr<LauncherContext>, create_context, (), (override));
    MOCK_METHOD(ArgParser&, get_input_arguments, (), (const, override));
  };
}  // namespace cccm::di::launcher

class ModelLauncherWetInitTests : public ::testing::Test
{
  void SetUp()
  {
    RecordProperty("rsp_revision_number", "Rev_2");
    mockSomeipApp = make_shared<vsomeip::application>();
    someipApp_map.insert({"vid10", mockSomeipApp});
    mockDdsFactory = std::make_shared<DDSEntityFactory>(SHARED_MEM);
    mockWorkExecutor = std::make_shared<WorkExecutor>("workExecutorDLT");
  }
  void TearDown()
  {
  }

public:
  std::unordered_map<std::string, std::shared_ptr<vsomeip::application>> someipApp_map;
  std::shared_ptr<vsomeip::application> mockSomeipApp = nullptr;
  std::shared_ptr<DDSEntityFactoryInterface> mockDdsFactory = nullptr;
  std::shared_ptr<WorkExecutor> mockWorkExecutor = nullptr;
};

// Function to simulate threaded delay
void ThreadedDelay()
{
  std::this_thread::sleep_for(std::chrono::seconds(1));
}

/// @brief Application shall use workexecutorthread's run() api
TEST_F(ModelLauncherWetInitTests, workexecutorthread_api_usage)
{
  RecordProperty("requirements", "Requirement01165182, Requirement01165184");
  int argc = 8;
  char const* argv[] = {"model_launcher", "--models", "ValidModelA", "ValidModelB", "--dlt_id", "MD01", "--vid", "10"};

  ArgParser argParser;
  bool parsed = argParser.parse_args(argc, argv);

  EXPECT_EQ(parsed, true);

  std::unique_ptr<MockModelContextFactory> mockContextFactory = std::make_unique<MockModelContextFactory>(argParser);

  std::shared_ptr<LauncherContext> mockContext = std::make_shared<LauncherContext>();
  mockContext->someipApp_map = someipApp_map;
  mockContext->ddsFactory = mockDdsFactory;
  mockContext->workExecutor = mockWorkExecutor;

  EXPECT_CALL(*(mockContextFactory.get()), get_input_arguments())
      .Times(2)
      .WillRepeatedly(::testing::ReturnRef(argParser));

  EXPECT_CALL(*(mockContextFactory.get()), create_context()).Times(1).WillOnce(Return(mockContext));

  EXPECT_CALL(*someipApp_map["vid10"], init()).Times(1).WillOnce(Return(true));

  // WorkExecutorThread's run() should be called
  EXPECT_CALL(*mockWorkExecutor, run()).Times(1);
  EXPECT_CALL(*mockWorkExecutor, getThreadStatus()).WillRepeatedly(Return(false));

  std::thread blockingThread;

  EXPECT_CALL(*someipApp_map["vid10"], start())
      .Times(1)
      .WillOnce(Invoke(
          [&blockingThread]
          {
            blockingThread = std::thread(ThreadedDelay);
          }));

  EXPECT_CALL(*mockWorkExecutor, signalThread()).Times(AtLeast(1));
  EXPECT_CALL(*mockWorkExecutor, stop()).Times(AtLeast(1));

  int ret = model_launcher_main::model_launcher_main(std::move(mockContextFactory));
  if (blockingThread.joinable())
  {
    blockingThread.join();
  }
  EXPECT_EQ(ret, 0);
}
