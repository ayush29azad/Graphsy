#include "gmock/gmock.h"
#include "ModelLibInterface.h"

class ValidModelA : public cccm::di::ModelLibInterface
{
public:
  MOCK_METHOD(void, init, (std::shared_ptr<cccm::di::launcher::LauncherContext> context), (override));
  MOCK_METHOD(void, terminate, (), (override));
};
