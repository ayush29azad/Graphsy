#include <memory>
#include <string>
#include <vector>
#include <map>

#include <gmock/gmock.h>
#include <gtest/gtest.h>

#include "ModelLauncher.h"

using ::testing::_;
using ::testing::Eq;
using ::testing::Matcher;
using ::testing::Mock;
using ::testing::Pointee;
using ::testing::Return;
using ::testing::StrictMock;

using ModelLauncher = cccm::di::launcher::ModelLauncher;
/// @brief The Below suite of tests considers the below functionalities/libs
/// external to the system :
/// 1. dlopen(), dlsym(), dlclose() calls
/// 2. vsomeip libs
/// 3. workexecutorthread
/// 4. fastdds libs
class ModelLoaderTest : public ::testing::Test
{
public:
  // DDSEntityFactoryMock* entityFactory = nullptr;
  // DataReaderListener* listener = nullptr;
  // DDSManager* ddsManager = nullptr;

  void SetUp() override
  {
    RecordProperty("rsp_revision_number", "Rev_2");
  }

  void TearDown() override
  {
  }

  ~ModelLoaderTest()
  {
  }
};

/// @brief Tests that application uses dlopen() to load models
TEST_F(ModelLoaderTest, dl_open_test)
{
  RecordProperty("requirements", "Requirement01165123, Requirement01165125");

  // Prepare inputs
  std::vector<std::string> modelLibs = {"ValidModelA", "ValidModelB"};

  auto ctx = std::make_shared<cccm::di::launcher::LauncherContext>();
  ModelLauncher::get_instance().set_context(ctx);

  // Simulate model loading
  int result = ModelLauncher::get_instance().load_all_models(modelLibs);

  // Validate
  auto actualLibModes = DLLibMockHelper::getInstance().actualLibModes;
  auto actualLibHandles = DLLibMockHelper::getInstance().actualLibHandles;

  int numberOfDLOpenCalls = 0;
  for (auto& lib : modelLibs)
  {
    std::string expected_string = "lib" + lib + ".so";
    numberOfDLOpenCalls +=
        ((actualLibModes.find(expected_string) != actualLibModes.end()) &
         (actualLibHandles.find(expected_string) != actualLibHandles.end()));
  }

  EXPECT_EQ(numberOfDLOpenCalls, modelLibs.size());

  // Clear the DLLibMockHelper data structure to isolate tests
  DLLibMockHelper::getInstance().clear();
}

/// @brief Tests that application does not lazily load model libs
TEST_F(ModelLoaderTest, dl_open_lazy_load_lest)
{
  RecordProperty("requirements", "Requirement01165124");

  // Prepare inputs
  std::vector<std::string> modelLibs = {"ValidModelA", "ValidModelB"};

  auto ctx = std::make_shared<cccm::di::launcher::LauncherContext>();
  ModelLauncher::get_instance().set_context(ctx);

  // Simulate model loading
  int result = ModelLauncher::get_instance().load_all_models(modelLibs);

  // Validate
  auto actualLibModes = DLLibMockHelper::getInstance().actualLibModes;
  auto actualLibHandles = DLLibMockHelper::getInstance().actualLibHandles;

  int numberOfLazyLibs = 0;
  for (auto& lib : modelLibs)
  {
    std::string expected_string = "lib" + lib + ".so";
    if (actualLibModes.find(expected_string) != actualLibModes.end())
    {
      numberOfLazyLibs += ((actualLibModes[expected_string] & RTLD_LAZY) != 0);
    }
  }

  EXPECT_EQ(numberOfLazyLibs, 0);

  // Clear the DLLibMockHelper data structure to isolate tests
  DLLibMockHelper::getInstance().clear();
}

/// @brief Tests that application uses dlsym to find "creator" and invoke it
TEST_F(ModelLoaderTest, dlsym_test_creator_found)
{
  RecordProperty("requirements", "Requirement01165134");

  // Prepare inputs
  std::vector<std::string> modelLibs = {"ValidModelA", "ValidModelB"};

  auto ctx = std::make_shared<cccm::di::launcher::LauncherContext>();
  ModelLauncher::get_instance().set_context(ctx);

  // Simulate model loading
  int result = ModelLauncher::get_instance().load_all_models(modelLibs);

  // Validate
  auto dlsymCalls = DLLibMockHelper::getInstance().actualdlsymCalls;

  EXPECT_EQ(dlsymCalls["creator"], modelLibs.size());
  EXPECT_EQ(result, modelLibs.size());

  // Clear the DLLibMockHelper data structure to isolate tests
  DLLibMockHelper::getInstance().clear();
}

/// @brief Tests that application uses dlsym to find "creator" and invoke it
TEST_F(ModelLoaderTest, dlsym_test_creator_not_found)
{

  RecordProperty("requirements", "Requirement01165135");

  // Prepare inputs
  std::vector<std::string> modelLibs = {"ValidModelA", "InValidModelB"};

  auto ctx = std::make_shared<cccm::di::launcher::LauncherContext>();
  ModelLauncher::get_instance().set_context(ctx);

  // Simulate model loading
  int result = ModelLauncher::get_instance().load_all_models(modelLibs);

  // Validate
  auto dlsymCalls = DLLibMockHelper::getInstance().actualdlsymCalls;
  auto dlcloseCalls = DLLibMockHelper::getInstance().actualdlcloseCalls;

  EXPECT_EQ(dlsymCalls["creator"], modelLibs.size());
  EXPECT_EQ(result, 1);
  EXPECT_EQ(dlcloseCalls, 1);

  // Clear the DLLibMockHelper data structure to isolate tests
  DLLibMockHelper::getInstance().clear();
}
