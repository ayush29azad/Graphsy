#include <memory>
#include <string>
#include <vector>
#include <map>

#include <gmock/gmock.h>
#include <gtest/gtest.h>

#include <ArgParser.h>

using ::testing::_;
using ::testing::Eq;
using ::testing::Matcher;
using ::testing::Mock;
using ::testing::Pointee;
using ::testing::Return;
using ::testing::StrictMock;
using ArgParser = cccm::di::launcher::ArgParser;
class InputAndConfigTests : public ::testing::Test
{
public:
  void SetUp() override
  {
    RecordProperty("rsp_revision_number", "Rev_2");
  }

  void TearDown() override
  {
  }

  ~InputAndConfigTests()
  {
  }
};

// Ex : model_launcher --models batteryStateofChargeDisp --dlt_id MD01
TEST_F(InputAndConfigTests, positive_test1)
{
  RecordProperty(
      "requirements",
      "Requirement01165030, Requirement01165034, Requirement01165037, Requirement01165192, Requirement01445518");
  int argc = 7;
  char const* argv[] = {"model_launcher", "--models", "batteryStateofChargeDisp", "--dlt_id", "MD01", "--vid", "10"};

  ArgParser argParse;
  bool const parsed = argParse.parse_args(argc, argv);

  EXPECT_EQ(parsed, true);

  std::string dlt_app_name = argParse.get_dlt_id();
  std::vector<std::string> libs = argParse.get_model_libs();
  std::vector<std::string> vid = argParse.getvIds();

  EXPECT_EQ(dlt_app_name, "MD01");
  EXPECT_EQ(libs.size(), 1);
  EXPECT_EQ(libs[0], "batteryStateofChargeDisp");
  EXPECT_EQ(vid[0], "10");
}

// Ex : model_launcher --models batteryStateofChargeDisp chargingInfo --dlt_id MD01
TEST_F(InputAndConfigTests, positive_test2)
{
  RecordProperty(
      "requirements",
      "Requirement01165030, Requirement01165034, Requirement01165037, Requirement01165192, Requirement01445518");
  int argc = 9;
  char const* argv[] = {
      "model_launcher",
      "--models",
      "batteryStateofChargeDisp",
      "chargingInfo",
      "--dlt_id",
      "MD01",
      "--vid",
      "10",
      "11"};

  ArgParser argParse;
  bool const parsed = argParse.parse_args(argc, argv);

  EXPECT_EQ(parsed, true);

  std::string dlt_app_name = argParse.get_dlt_id();
  std::vector<std::string> libs = argParse.get_model_libs();
  std::vector<std::string> vid = argParse.getvIds();

  EXPECT_EQ(dlt_app_name, "MD01");
  EXPECT_EQ(libs.size(), 2);
  EXPECT_EQ(libs[0], "batteryStateofChargeDisp");
  EXPECT_EQ(libs[1], "chargingInfo");
  EXPECT_EQ(vid[0], "10");
  EXPECT_EQ(vid[1], "11");
}

// Ex : model_launcher --models batteryStateofChargeDisp chargingInfo gauges
TEST_F(InputAndConfigTests, positive_test3)
{
  RecordProperty("requirements", "Requirement01165034, Requirement01165039, Requirement01165194, Requirement01445518");
  int argc = 9;
  char const* argv[] = {
      "model_launcher", "--models", "batteryStateofChargeDisp", "chargingInfo", "gauges", "--vid", "10", "11", "12"};

  ArgParser argParse;
  bool const parsed = argParse.parse_args(argc, argv);

  EXPECT_EQ(parsed, true);

  std::string dlt_app_name = argParse.get_dlt_id();
  std::vector<std::string> libs = argParse.get_model_libs();
  std::vector<std::string> vid = argParse.getvIds();

  EXPECT_EQ(dlt_app_name, "MD00");
  EXPECT_EQ(libs.size(), 3);
  EXPECT_EQ(libs[0], "batteryStateofChargeDisp");
  EXPECT_EQ(libs[1], "chargingInfo");
  EXPECT_EQ(libs[2], "gauges");
  EXPECT_EQ(vid[0], "10");
  EXPECT_EQ(vid[1], "11");
  EXPECT_EQ(vid[2], "12");
}

// Ex : model_launcher --models batteryStateofChargeDisp chargingInfo gauges --dlt_id MD01 MD02
TEST_F(InputAndConfigTests, positive_test4)
{
  RecordProperty("requirements", "Requirement01445518");
  int argc = 10;
  char const* argv[] = {
      "model_launcher",
      "--models",
      "batteryStateofChargeDisp",
      "chargingInfo",
      "gauges",
      "--dlt_id",
      "MD01",
      "MD02",
      "--vid",
      "10"};

  ArgParser argParse;
  bool const parsed = argParse.parse_args(argc, argv);

  EXPECT_EQ(parsed, true);

  std::string dlt_app_name = argParse.get_dlt_id();
  std::vector<std::string> libs = argParse.get_model_libs();
  std::vector<std::string> vid = argParse.getvIds();
  EXPECT_EQ(dlt_app_name, "MD01");
  EXPECT_EQ(libs.size(), 3);
  EXPECT_EQ(libs[0], "batteryStateofChargeDisp");
  EXPECT_EQ(libs[1], "chargingInfo");
  EXPECT_EQ(libs[2], "gauges");
  EXPECT_EQ(vid[0], "10");
}

// Ex : model_launcher --models batteryStateofChargeDisp --dlt_id MD01 MD02
TEST_F(InputAndConfigTests, positive_test5)
{
  RecordProperty("requirements", "Requirement01445518");
  int argc = 8;
  char const* argv[] = {
      "model_launcher", "--models", "batteryStateofChargeDisp", "--dlt_id", "MD01", "MD02", "--vid", "10"};

  ArgParser argParse;
  bool const parsed = argParse.parse_args(argc, argv);

  EXPECT_EQ(parsed, true);

  std::string dlt_app_name = argParse.get_dlt_id();
  std::vector<std::string> libs = argParse.get_model_libs();
  std::vector<std::string> vid = argParse.getvIds();
  EXPECT_NE(dlt_app_name, "MD02");
  EXPECT_EQ(libs.size(), 1);
  EXPECT_EQ(libs[0], "batteryStateofChargeDisp");
  EXPECT_EQ(vid[0], "10");
}

// Ex : model_launcher --modes batteryStateofChargeDisp
TEST_F(InputAndConfigTests, negative_test1)
{
  RecordProperty("requirements", "Requirement01165031, Requirement01165040");
  int argc = 3;
  char const* argv[] = {"model_launcher", "--modes", "batteryStateofChargeDisp"};

  ArgParser argParse;
  bool const parsed = argParse.parse_args(argc, argv);

  EXPECT_EQ(parsed, false);
}

// Ex : model_launcher -models batteryStateofChargeDisp
TEST_F(InputAndConfigTests, negative_test2)
{
  RecordProperty("requirements", "Requirement01165031, Requirement01165040");
  int argc = 3;
  char const* argv[] = {"model_launcher", "-models", "batteryStateofChargeDisp"};

  ArgParser argParse;
  bool const parsed = argParse.parse_args(argc, argv);

  EXPECT_EQ(parsed, false);
}

// Ex : model_launcher --models
TEST_F(InputAndConfigTests, negative_test3)
{
  RecordProperty("requirements", "Requirement01165031, Requirement01165040, Requirement01165042");
  int argc = 2;
  char const* argv[] = {"model_launcher", "--models"};

  ArgParser argParse;
  bool const parsed = argParse.parse_args(argc, argv);

  EXPECT_EQ(parsed, false);
}

// Ex : model_launcher --models batteryStateofChargeDisp --dl_id MD01
TEST_F(InputAndConfigTests, negative_test4)
{
  int argc = 7;
  char const* argv[] = {"model_launcher", "--models", "batteryStateofChargeDisp", "-dlt_id", "MD01", "--vid", "10"};

  ArgParser argParse;
  bool const parsed = argParse.parse_args(argc, argv);

  EXPECT_EQ(parsed, false);
}

// Ex : model_launcher --models batteryStateofChargeDisp --dl_id MD01 -vid '10'
TEST_F(InputAndConfigTests, negative_test5)
{
  RecordProperty("requirements", "Requirement01445546");
  int argc = 7;
  char const* argv[] = {"model_launcher", "--models", "batteryStateofChargeDisp", "--dlt_id", "MD01", "-vid", "10"};

  ArgParser argParse;
  bool const parsed = argParse.parse_args(argc, argv);

  EXPECT_EQ(parsed, false);
}

// Ex : model_launcher --models batteryStateofChargeDisp --dl_id MD01 --vd '10'
TEST_F(InputAndConfigTests, negative_test6)
{
  RecordProperty("requirements", "Requirement01445546");
  int argc = 7;
  char const* argv[] = {"model_launcher", "--models", "batteryStateofChargeDisp", "--dlt_id", "MD01", "-vd", "10"};

  ArgParser argParse;
  bool const parsed = argParse.parse_args(argc, argv);

  EXPECT_EQ(parsed, false);
}

// Ex : model_launcher --models batteryStateofChargeDisp --dl_id MD01
TEST_F(InputAndConfigTests, negative_test7)
{
  RecordProperty("requirements", "Requirement01445546");
  int argc = 5;
  char const* argv[] = {"model_launcher", "--models", "batteryStateofChargeDisp", "--dlt_id", "MD01"};

  ArgParser argParse;
  bool const parsed = argParse.parse_args(argc, argv);

  EXPECT_EQ(parsed, false);
}
