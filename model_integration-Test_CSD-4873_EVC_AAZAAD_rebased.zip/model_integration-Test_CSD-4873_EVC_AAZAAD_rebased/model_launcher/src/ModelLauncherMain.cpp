#include <cstdlib>
#include <vector>
#include <iostream>
#include <pthread.h>

#include "ArgParser.h"
#include "ModelLauncherMain.h"
#include "ModelLauncher.h"
#include "ModelLauncherDltHelper.h"
#include <DDSEntityFactory.hpp>

#ifdef COMFORT_WRITER
#include <ComfortWriter.h>
#endif

using DDSEntityFactory = jlr::cccm::di::dds::DDSEntityFactory;
using ModelLauncher = cccm::di::launcher::ModelLauncher;

namespace model_launcher_main
{
  int64_t const HEART_BEAT_INTERVAL = static_cast<int64_t>(30);
  std::mutex mymutex;
  bool gIsRunnable = true;
  std::shared_ptr<WorkExecutor> gWorkExecutor = nullptr;
  std::condition_variable mycond;
  bool flag = false;
  std::atomic<bool> signal_handled(false);
}  // namespace model_launcher_main

void model_launcher_main::handle_signal(int32_t sig)
{
  ML_LOG_MCTX_INFO << "received signal : " << sig << std::endl;
  ML_LOG_MCTX_INFO << "shutting down gracefully..." << std::endl;
  if (signal_handled == false)
  {
    signal_handled = true;
    model_launcher_terminate();
    ML_LOG_MCTX_INFO << "signal handled" << std::endl;
  }
}

void model_launcher_main::model_launcher_terminate()
{
  ModelLauncher::get_instance().terminate();

#ifdef COMFORT_WRITER
  ModelLauncher::get_instance().terminate_comfort_writer();
#endif

  gIsRunnable = false;
  gWorkExecutor->stop();
  gWorkExecutor.reset();
  ModelLauncher::get_instance().stop_applications();
}

void model_launcher_main::model_launcher_early_terminate()
{
  ModelLauncher::get_instance().terminate();
}

void model_launcher_main::checkThreadHealth(std::shared_ptr<WorkExecutor> workExecutor)
{
  pthread_setname_np(pthread_self(), "ML_healthThread");
  while (gIsRunnable == true)  //@Todo KW warning infinite loop
  {
    std::unique_lock<std::mutex> lock(mymutex);
    int64_t const HEART_BEAT_DIVISOR = static_cast<int64_t>(2);
    mycond.wait_for(
        lock,
        std::chrono::seconds(HEART_BEAT_INTERVAL / HEART_BEAT_DIVISOR),
        []() -> bool
        {
          return flag;
        });
    workExecutor->signalThread();
    ML_LOG_MCTX_DEBUG << "model_launcher_main::checkThreadHealth::getThreadStatus=" << workExecutor->getThreadStatus()
                      << std::endl;
  }
}

void model_launcher_main::sendHeartbeat(std::shared_ptr<WorkExecutor> workExecutor)
{
  pthread_setname_np(pthread_self(), "ML_heartBeatThread");
  while (gIsRunnable == true)  //@Todo KW warning infinite loop
  {
    std::unique_lock<std::mutex> lock(mymutex);
    mycond.wait_for(
        lock,
        std::chrono::seconds(HEART_BEAT_INTERVAL),
        []()
        {
          return flag;
        });
    ML_LOG_MCTX_DEBUG << "sendHeartbeat::getThreadStatus=" << workExecutor->getThreadStatus() << std::endl;
    if (workExecutor->getThreadStatus() == false)
    {
      model_launcher_terminate();
    }
    workExecutor->setThreadStatus(false);
  }
}

int32_t model_launcher_main::model_launcher_main(
    std::unique_ptr<cccm::di::launcher::ModelContextFactoryInterface> contextFactory)
{
  int32_t const ret = static_cast<int32_t>(0);
  pthread_setname_np(pthread_self(), "ML_mainThread");

  std::string const dlt_app_name = contextFactory->get_input_arguments().get_dlt_id();
  std::vector<std::string> const modelLibs = contextFactory->get_input_arguments().get_model_libs();

#if defined(ENABLE_DLT_LOGGING)
  generic_logging::initialize_loggers(
      dlt_app_name,
      logging::g_ml_dlt_context,
      logging::dltAppDescription,
      "DI Model Launcher",
      std::vector<generic_logging::LoggerKind>{generic_logging::LoggerKind::dlt_log},
      true);
#endif

  ML_LOG_MCTX_INFO << "Release version information model_launcher: " << version::release_version << std::endl;
  ML_LOG_MCTX_INFO << "dlt_app_name:" << dlt_app_name << std::endl;

  for (std::string const& model : modelLibs)
  {
    ML_LOG_MCTX_INFO << model << std::endl;
  }

  if (!modelLibs.empty())
  {
    std::shared_ptr<LauncherContext> const context = contextFactory->create_context();
    model_launcher_main::gWorkExecutor = context->workExecutor;

    if (context->someipApp_map.empty())
    {
      ML_LOG_MCTX_ERROR << "vsomeip::application was null, exiting" << std::endl;
      return ret;
    }

    if (context->ddsFactory == nullptr)
    {
      ML_LOG_MCTX_ERROR << "dds factory was null, exiting" << std::endl;
      return ret;
    }

    ModelLauncher::get_instance().set_context(context);

    ModelLauncher::get_instance().init_applications();
    uint32_t loadedLibrary = ModelLauncher::get_instance().load_all_models(modelLibs);
    ML_LOG_MCTX_INFO << "Loaded " << loadedLibrary << " out of " << modelLibs.size() << std::endl;

    if (loadedLibrary != modelLibs.size())
    {
      ML_LOG_MCTX_ERROR << "Not able to load all models, exiting" << std::endl;
      model_launcher_early_terminate();
      return ret;
    }

#ifdef COMFORT_WRITER
    bool const enable_writer = contextFactory->get_input_arguments().get_comfort_writer();
    ModelLauncher::get_instance().init_comfort_writer(enable_writer);
#endif

    std::thread workerThread(
        []()
        {
          try
          {
            if (nullptr != model_launcher_main::gWorkExecutor)
            {
              pthread_setname_np(pthread_self(), "ML_workerThread");  // setting the name(workerThread) to thread
              model_launcher_main::gWorkExecutor->run();
            }
          }
          catch (std::exception const& e)
          {
            ML_LOG_MCTX_ERROR << "Exception in workerThread " << e.what() << std::endl;
          }
          catch (...)
          {
            ML_LOG_MCTX_ERROR << "Unknow exception in workerThread" << std::endl;
          }
        });
    std::thread healthThread(
        []()
        {
          try
          {
            model_launcher_main::checkThreadHealth(model_launcher_main::gWorkExecutor);
          }
          catch (std::exception const& e)
          {
            ML_LOG_MCTX_ERROR << "Exception in healthThread " << e.what() << std::endl;
          }
          catch (...)
          {
            ML_LOG_MCTX_ERROR << "Unknow exception in healthThread" << std::endl;
          }
        });
    std::thread heartBeatThread(
        []()
        {
          try
          {
            model_launcher_main::sendHeartbeat(model_launcher_main::gWorkExecutor);
          }
          catch (std::exception const& e)
          {
            ML_LOG_MCTX_ERROR << "Exception in heartBeatThread " << e.what() << std::endl;
          }
          catch (...)
          {
            ML_LOG_MCTX_ERROR << "Unknow exception in heartBeatThread" << std::endl;
          }
        });
    if (signal(SIGINT, model_launcher_main::handle_signal) == SIG_ERR)
    {
      ML_LOG_MCTX_ERROR << "Failed to register signal handler for SIGINT" << std::endl;
    }
    if (signal(SIGTERM, model_launcher_main::handle_signal) == SIG_ERR)
    {
      ML_LOG_MCTX_ERROR << "Failed to register signal handler for SIGTERM" << std::endl;
    }
    ModelLauncher::get_instance().start_applications();
    {
      std::lock_guard<std::mutex> lock(model_launcher_main::mymutex);
      model_launcher_main::flag = true;
      model_launcher_main::mycond.notify_all();
    }

    if (workerThread.joinable())
    {
      workerThread.join();
    }

    if (healthThread.joinable())
    {
      healthThread.join();
    }

    if (heartBeatThread.joinable())
    {
      heartBeatThread.join();
    }
  }
  else
  {
    ML_LOG_MCTX_ERROR << "ModelLibs is empty, exiting ...." << std::endl;
  }

  /*
  Not dlclosing the libs as it gives segmentation fault in qnx.
  The order of destruction of objects is a little different in qnx
  than linux. Could be static order initialization issue.
  todo : investigate on this
  */

  // ModelLauncher::get_instance().dlclose();

  return ret;
}
