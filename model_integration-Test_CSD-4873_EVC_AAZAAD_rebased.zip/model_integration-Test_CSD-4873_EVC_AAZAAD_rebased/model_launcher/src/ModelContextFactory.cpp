#include <ModelContextFactory.h>
#include <ProxySomeipApplication.hpp>
#include "ModelLauncherDltHelper.h"

using ModelContextFactory = cccm::di::launcher::ModelContextFactory;
using ArgParser = cccm::di::launcher::ArgParser;

ModelContextFactory::ModelContextFactory(ArgParser& argparse_)
{
  argparse = argparse_;
}
/// @brief
/// @return
/// @satisfy{Requirement01445543}
/// @satisfy{Requirement01446328}
/// @satisfy{Requirement01165180}
std::unordered_map<std::string, std::shared_ptr<vsomeip::application>> ModelContextFactory::create_someip_applications()
{
  std::unordered_map<std::string, std::shared_ptr<vsomeip::application>> vsomeip_map;
  std::vector<std::string> const vids = this->argparse.getvIds();
  std::string const dltId = this->argparse.get_dlt_id();
  for (size_t i = 0; i < vids.size(); i++)
  {
    auto realSomeipApp = vsomeip::runtime::get()->create_application("di_model_" + dltId + "_vlan" + vids[i]);
    vsomeip_map["vid" + vids[i]] = std::make_shared<vsomeip_v3_proxy::ProxyApplication>(realSomeipApp);
  }
  return vsomeip_map;
}

std::shared_ptr<DDSEntityFactoryInterface> ModelContextFactory::create_dds_factory()
{
#ifdef USE_DEFAULT_TRANSPORT
  return std::make_shared<DDSEntityFactory>(jlr::cccm::di::dds::DEFAULT_TRANSPORT);
#else
  return std::make_shared<DDSEntityFactory>(jlr::cccm::di::dds::SHARED_MEM);
#endif
}

std::shared_ptr<WorkExecutor> ModelContextFactory::create_workexecutor()
{
  return std::make_shared<WorkExecutor>(this->argparse.get_dlt_id(), logging::dltAppDescription);
}

ArgParser const& ModelContextFactory::get_input_arguments() const
{
  return argparse;
}

std::shared_ptr<LauncherContext> ModelContextFactory::create_context()
{
  auto context = std::make_shared<LauncherContext>();
  context->someipApp_map = this->create_someip_applications();
  context->dltApplication = std::make_pair(this->argparse.get_dlt_id(), logging::dltAppDescription);
  context->ddsFactory = this->create_dds_factory();
  context->workExecutor = this->create_workexecutor();
  return context;
}
