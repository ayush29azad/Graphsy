#ifndef JLRCCCM_MODEL_LAUNCHER_MAIN_H
#define JLRCCCM_MODEL_LAUNCHER_MAIN_H

#include "release_version.h"

#include <cstdlib>
#include <vector>
#include <iostream>
#include <mutex>
#include <atomic>
#include <memory>
#include <condition_variable>
#include <unordered_map>

#include <WorkExecutor.h>
#include <ModelContextFactoryInterface.h>

/// @brief using type WorkExecutor as jlr::cccm::di::work_executor::WorkExecutor
using WorkExecutor = jlr::cccm::di::work_executor::WorkExecutor;

namespace model_launcher_main
{
  /// @brief time gap between the heartbeats in seconds
  extern int64_t const HEART_BEAT_INTERVAL;

  /// @brief synchronization mutex
  extern std::mutex mymutex;

  /// @brief flag to check if health and heartbeat threads can be run
  extern bool gIsRunnable;

  /// @brief shared_ptr to the WorkExecutor instance
  extern std::shared_ptr<WorkExecutor> gWorkExecutor;

  /// @brief conditional variable for synchronization between threads
  extern std::condition_variable mycond;

  /// @brief boolean flag supporting the conditional variable
  extern bool flag;

  /// @brief To check if signal was handled already in case of many signals
  extern std::atomic<bool> signal_handled;

  /// @brief Method to handler signal
  /// @param signal number
  /// @retval None
  /// @satisfy{Requirement01165234}
  void handle_signal(int32_t sig);

  /// @brief Method to check work executor central thread health
  /// @param workExecutor object
  /// @retval None
  /// @satisfy{Requirement01165184}
  void checkThreadHealth(std::shared_ptr<WorkExecutor> workExecutor);

  /// @brief Method to send heartbeat notification to HAM
  /// @param workExecutor object
  /// @retval None
  void sendHeartbeat(std::shared_ptr<WorkExecutor> workExecutor);

  /// @brief Helper method to teminate the model launcher
  /// @retval None
  /// @satisfy{Requirement01165234}
  void model_launcher_terminate();

  /// @brief Helper method to teminate the model launcher early
  /// @retval None
  /// @satisfy{Requirement01165129}
  void model_launcher_early_terminate();

  /// @brief Method to execute the application logic
  /// @param contextFactory pointer to the model context factory instance
  /// @return blocking function, returns 0 if exited gracefully
  /// @satisfy{Requirement01165040, Requirement01165042, Requirement01165182, Requirement01165184}
  int32_t model_launcher_main(std::unique_ptr<cccm::di::launcher::ModelContextFactoryInterface> contextFactory);
};  // namespace model_launcher_main

#endif
