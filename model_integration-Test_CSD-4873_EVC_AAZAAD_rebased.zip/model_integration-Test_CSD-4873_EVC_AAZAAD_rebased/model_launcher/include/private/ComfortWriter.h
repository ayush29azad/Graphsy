/// @file ComfortWriter.h
/// @brief Declaration of the ComfortWriter class, responsible for monitoring the vehicle's state and performing a
/// one-time critical operation upon reaching the COMFORT state
/// @copyright "Copyright (C) 2023, Jaguar Land Rover
/// All rights reserved.
/// CONFIDENTIAL INFORMATION - DO NOT DISTRIBUTE"
///
/// @date July 2023

#ifndef COMFORT_WRITER_HEADER_H
#define COMFORT_WRITER_HEADER_H

#include <memory>
#include <atomic>
#include <fstream>
#include <functional>
#include <mutex>
#include <ModelLauncherDltHelper.h>
#include "ComfortDdsCommunicationHandler.hpp"

/** @brief Alias for the DDS Entity Factory Interface. */
using DDSEntityFactoryInterface = jlr::cccm::di::dds::DDSEntityFactoryInterface;
/** @brief Alias for the WorkExecutor class used for asynchronous thread execution. */
using WorkExecutor = jlr::cccm::di::work_executor::WorkExecutor;

namespace cccm
{
  namespace di
  {
    namespace launcher
    {
      /**
       * @class ComfortWriter
       * @brief Manages DDS subscription to the vehicle lifecycle topic and triggers
       * the comfort-specific logic.
       * @details This class initializes a DdsCommunicationHandler to subscribe to the
       * vehicle state, offloads the callback to a WorkExecutor thread, and uses an
       * atomic flag to ensure the file creation and subsequent cleanup happen only once.
       *
       * @satisfy{Requirement01487704, Requirement01487710 ,Requirement01493726}
       */
      class ComfortWriter
      {
      public:
        /// @brief Constructor receives all necessary dependencies.
        /// @param ddsFactory Shared pointer to the factory for creating DDS entities.
        /// @param workExecutor Shared pointer to the WorkExecutor for offloading subscription callbacks.
        /// @param comfortWriterDlt Dlt app ID for logging
        /// @satisfy{Requirement01487704}
        ComfortWriter(
            std::shared_ptr<DDSEntityFactoryInterface> ddsFactory, std::shared_ptr<WorkExecutor> workExecutor,
            std::string const& comfortWriterDlt);

        /// @brief Initializes communication by setting up the subscription via the handler.
        /// @return true on successful subscription setup, false otherwise.
        /// @satisfy{Requirement01487705, Requirement01487706, Requirement01487709}
        bool initialize();

        /// @brief Cleans up all managed DDS resources and resets the handler.
        /// @satisfy{Requirement01487708, Requirement01487709 ,Requirement01493726}
        void deinitialize();

        /** @brief DDS topic name for the vehicle lifecycle status. */
        // constexpr const char* COMFORT_TOPIC_NAME = "dds_ipc::vehicleLifecycle";
        /// @satisfy{Requirement01487705}
        static char const* const COMFORT_TOPIC_NAME;
        /** @brief File path for the signal file created upon reaching the COMFORT state. */
        // constexpr const char* COMFORT_FILE_PATH = "/dev/shmem/VehicleStateComfort.txt";
        static char const* const COMFORT_FILE_PATH;

      private:
        /// @brief The callback function executed on the Worker Thread when new comfort data is available.
        /// @details This method reads the data and checks if the vehicle state is ENUM_STATE_COMFORT.
        /// @satisfy{Requirement01487707}
        void on_comfort_data_available();

        /// @brief Core logic to be executed once the COMFORT state is reached.
        /// @details Performs an atomic check, creates the signal file, and initiates cleanup.
        /// @satisfy{Requirement01487707, Requirement01493726}
        void execute_comfort_logic_and_cleanup();

        /** @brief The work executor used to run callbacks off the main DDS thread. */
        std::shared_ptr<WorkExecutor> mWorkExecutor;

        /** @brief The centralized DDS handling object that manages DataReader and resource cleanup. */
        std::unique_ptr<jlr::cccm::di::ComfortDdsCommunicationHandler> mDdsHandler;

        /** @brief Atomic flag to ensure the comfort logic is executed only once. */
        std::atomic<bool> mIsComfortReached{false};
      };

    }  // namespace launcher

  }  // namespace di
}  // namespace cccm
#endif  // COMFORT_WRITER_HEADER_H
