/// @file ModelContextFactory.h
/// @brief Concrete Model launcher context factory
///
/// @copyright "Copyright (C) 2025, Jaguar Land Rover
/// All rights reserved.
/// CONFIDENTIAL INFORMATION - DO NOT DISTRIBUTE"
///
/// @date June 2025
#ifndef JLRCCCM_DI_MODEL_LAUNCHER_CONTEXT_FACTORY_H
#define JLRCCCM_DI_MODEL_LAUNCHER_CONTEXT_FACTORY_H

#include <ModelContextFactoryInterface.h>

/// @brief using type DDSEntityFactoryInterface as jlr::cccm::di::dds::DDSEntityFactoryInterface
using DDSEntityFactoryInterface = jlr::cccm::di::dds::DDSEntityFactoryInterface;

/// @brief using type DDSEntityFactory as jlr::cccm::di::dds::DDSEntityFactory
using DDSEntityFactory = jlr::cccm::di::dds::DDSEntityFactory;

/// @brief using type WorkExecutor as jlr::cccm::di::work_executor::WorkExecutor
using WorkExecutor = jlr::cccm::di::work_executor::WorkExecutor;

/// @brief using type LauncherContext as cccm::di::launcher::LauncherContext
using LauncherContext = cccm::di::launcher::LauncherContext;

namespace cccm::di::launcher
{
  /// @brief Factory class for LauncherContext, responsible for creating
  /// instances of the dependency classes
  class ModelContextFactory : public ModelContextFactoryInterface
  {

  public:
    /// @brief Ctor
    /// @param argparse_ Parsed input arguments
    ModelContextFactory(ArgParser& argparse_);

    /// @brief create separated vsomeip::application instance for each vlan Id mentioned
    /// @return std::unordered_map<std::string, <shared_ptr<vsomeip::application>>
    /// @satisfy{Requirement01165180}
    std::unordered_map<std::string, std::shared_ptr<vsomeip::application>> create_someip_applications() override;

    /// @brief creates DDSEntityFactory instance
    /// @return DDSEntityFactory shared pointer
    /// @satisfy{Requirement01165181}
    std::shared_ptr<DDSEntityFactoryInterface> create_dds_factory() override;

    /// @brief creates WorkExecutor instance
    /// @return WorKExecutor shared pointer
    /// @satisfy{Requirement01165182}
    std::shared_ptr<WorkExecutor> create_workexecutor() override;

    /// @brief returns the input parser instance
    /// @return reference to the stored input parser instance
    ArgParser const& get_input_arguments() const override;

    /// @brief creates context to be passed to each model
    /// @return shared pointer to the created instance
    /// @satisfy{Requirement01165180, Requirement01165181, Requirement01165182}
    std::shared_ptr<LauncherContext> create_context() override;

  private:
    /// @brief stores the input parser instance
    ArgParser argparse;
  };
};  // namespace cccm::di::launcher

#endif
