/// @file ModelLoader.h
/// @brief Contains class to Wrap dlopen and dlsym functionalities
///
/// @copyright "Copyright (C) 2023, Jaguar Land Rover
/// All rights reserved.
/// CONFIDENTIAL INFORMATION - DO NOT DISTRIBUTE"
///
/// @date June 2024
#ifndef JLRCCCM_DI_MODEL_LOADER_H
#define JLRCCCM_DI_MODEL_LOADER_H

#include <dlfcn.h>
#include <DLOpenInterface.h>

namespace cccm::di::dlopener
{

  /// @brief Class to Wrap dlopen and dlsym functionalities
  /// @tparam LibraryClass Type of the pointer returned by the allocator function of the library
  template <typename LibraryClass>
  class ModelLoader : public DLOpenInterface<LibraryClass>
  {

  private:
    /// @brief Allocator symbol name
    std::string createObjectSymbol;

  public:
    /// @brief Constructor
    /// @param _libPath Library path to be dlopened
    /// @param _createObjectSymbol allocator symbol string
    ModelLoader(std::string const& _libPath, std::string const& _createObjectSymbol)
        : DLOpenInterface<LibraryClass>(_libPath)
    {
      createObjectSymbol = _createObjectSymbol;
    }

    /// @brief Function to dlopen the library and storing the handle returned
    /// @return True is successful, false on failure
    /// @satisfy{Requirement01165123, Requirement01165124}
    bool dl_open() override
    {
      void* handle = dlopen(this->getlibName().c_str(), RTLD_NOW);
      if (!handle)
      {
        return false;
      }
      this->setHandle(handle);
      return true;
    }

    /// @brief Funtion to dlclose() the dynamic library using the handle
    /// @return True on success and False on failure
    bool dl_close() override
    {
      if (dlclose(this->getHandle()) != 0)
      {
        return false;
      }
      return true;
    }

    /// @brief Returns shared pointer to the model library. Does so by
    /// calling the allocator symbol
    /// @return Shared pointer to the model library object
    /// @satisfy{Requirement01165134, Requirement01165135}
    std::shared_ptr<LibraryClass> get_object() override
    {

      using createFuncType = std::shared_ptr<LibraryClass> (*)();

      // NOLINTNEXTLINE(AUTOSAR.CAST.REINTERPRET)
      // reinterpret_cast is required here: dlsym returns void* that must be cast to function pointer
      auto createFunc = reinterpret_cast<createFuncType>(dlsym(this->getHandle(), createObjectSymbol.c_str()));

      if (!createFunc)
      {
        dl_close();
        return nullptr;
      }

      return createFunc();
    }
  };

};  // namespace cccm::di::dlopener

#endif
