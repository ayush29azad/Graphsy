/// @file DdsCommunicationHandler.hpp
/// @brief Contains DdsCommunicationHandler class declaration
///
/// @copyright "Copyright (C) 2025, Jaguar Land Rover
/// All rights reserved.
/// CONFIDENTIAL INFORMATION - DO NOT DISTRIBUTE"
///
/// @date July 2023

#ifndef COMFORT_DDS_COMMUNICATION_HANDLER_HEADER_H
#define COMFORT_DDS_COMMUNICATION_HANDLER_HEADER_H

#include <DDSManager.hpp>
#include <iostream>
#include <map>
#include <string.h>
#include <WorkExecutor.h>
#include "ModelLauncherDltHelper.h"

using namespace jlr::cccm::di::work_executor;

/// @brief Using FastDDS DataReaderListener class
using DataReaderListener = eprosima::fastdds::dds::DataReaderListener;

/// @brief using fastdds TopicDescription
using TopicDescription = eprosima::fastdds::dds::TopicDescription;

/// @brief using jlrdds DDSEntityFactoryInterface
using DDSEntityFactoryInterface = jlr::cccm::di::dds::DDSEntityFactoryInterface;

/// @brief using jlrdds DDSManagerInterface
using DDSManagerInterface = jlr::cccm::di::dds::DDSManagerInterface;

/// @brief using jlrdds DDSManager
using DDSManager = jlr::cccm::di::dds::DDSManager;

namespace jlr
{
  namespace cccm
  {
    namespace di
    {
      /// @brief Class binding the DDS IPC class with the ModelClass
      /// @tparam ModelClass The class to be wrapper with DDS IPC
      class ComfortDdsCommunicationHandler : public DataReaderListener
      {

      private:
        /// @brief Map to store the registered callbacks for onDataAvailable on a topic
        std::map<std::string, std::function<void()>> m_dataAvailableCallback;

        /// @brief Pointer to the workExecutor object
        std::shared_ptr<WorkExecutor> workExecutor = nullptr;

        /// @brief Pointer to DDSEntityFactory object
        std::shared_ptr<DDSEntityFactoryInterface> ddsFactory = nullptr;

        /// @brief Pointer to DDSManager object
        std::shared_ptr<DDSManagerInterface> ddsManager = nullptr;

      public:
        /// @brief Initializes DDS communication, wrapper over init()
        /// @param mddsFactory DDSEntityFactory instance
        /// @param dltAppId DLT application name
        /// @satisfy{Requirement01165181}
        ComfortDdsCommunicationHandler(
            std::shared_ptr<DDSEntityFactoryInterface> const mddsFactory, std::string const& dltAppId)
        {
          this->ddsFactory = mddsFactory;
          this->ddsManager = std::shared_ptr<DDSManagerInterface>(ddsFactory->create_manager(this, dltAppId));
          bool const res = ddsManager->init();
          if (!res)
          {
            ML_LOG_MCTX_ERROR << "[DDSCommHandler] ddsManager->init() returned false" << std::endl;
          }
        }

        /// @brief Creates a topic to publish data over, wrapper over initTopicPubSub()
        /// @param topic Topic name as string
        /// @param typePtr TopicDataType object pointer
        /// @return Returns true on success else false
        /// @satisfy{Requirement01165181}
        bool topic_out(std::string const topic, TopicDataType* const typePtr)
        {
          return ddsManager->register_publisher(topic, typePtr);
        }

        /// @brief Creates a topic to subscribe to data, wrapper over initTopicPubSub()
        /// @param topic Topic name as string
        /// @param typePtr TopicDataType object pointer
        /// @param on_available_callback Pointer to the function that needs to be triggered when a data is available on
        /// the topic
        /// @return Returns true on success else false
        /// @satisfy{Requirement01165181}
        bool topic_in(
            std::string const& topic, TopicDataType* const typePtr,
            std::function<void(void)> const& on_available_callback)
        {
          bool const result = ddsManager->register_subscriber(topic, typePtr);
          if (result)
          {
            auto const fun_ptr = [this, on_available_callback]()
            {
              on_available_callback();
            };
            this->m_dataAvailableCallback[topic] = fun_ptr;
          }
          return result;
        }

        /// @brief on_subscription_matched
        ///
        /// @param reader Pointer to the DataReader object matched
        /// @param info Details for matched subscriber
        ///
        /// @retval true - on_subscription_matched is positive
        /// @retval false - on_subscription_matched is negative
        void on_subscription_matched(DataReader* reader, SubscriptionMatchedStatus const& info) override
        {
          static_cast<void>(reader);
          constexpr std::int32_t kIncrement = 1;
          constexpr std::int32_t kDecrement = -1;
          if (info.current_count_change == kIncrement)
          {
            ML_LOG_MCTX_INFO << "[ComfortDdsCommunicationHandler] Subscriber matched." << std::endl;
          }
          else if (info.current_count_change == kDecrement)
          {
            ML_LOG_MCTX_INFO << "[ComfortDdsCommunicationHandler] Subscriber unmatched." << std::endl;
          }
          else
          {
            ML_LOG_MCTX_ERROR << info.current_count_change
                              << " is not a valid value for SubscriptionMatchedStatus current count change"
                              << std::endl;
          }
        }

        /// @brief Callback that handles the behaviour when a data is available in the reader buffer
        /// @brief Calls the registered on_data_available methods for the corresponding topic
        /// @param reader Pointer to the data reader
        /// @satisfy{Requirement01415483}
        void on_data_available(DataReader* reader) override
        {
          std::string const topic_name = ddsManager->get_topic_name(reader);
          auto itr = this->m_dataAvailableCallback.find(topic_name);

          if (itr != m_dataAvailableCallback.end())
          {
            // check if work executor is allotted
            if (workExecutor != nullptr)
            {
              workExecutor->addWork(itr->second);
            }
            else
            {
              itr->second();
            }
          }
          else
          {
            // BOOST_LOG_TRIVIAL(info) << "DdsCommunicationHandler::onDataAvailable: Signal not found in map" <<
            // std::endl;
          }
        }

        /// @brief Add work Executor object to the ddsHandler to handle the OnDataAvailable callbacks
        /// @param _workExecutor Shared pointer to the work Executor object
        void set_work_executor(std::shared_ptr<WorkExecutor> const _workExecutor)
        {
          this->workExecutor = _workExecutor;
        }

        /// @brief Getter method for DDSManager instance
        /// @return Ptr to DDSManager instance
        std::shared_ptr<DDSManagerInterface> get_manager() const
        {
          return ddsManager;
        }

        /// @brief Synchronously publishes data on a topic, wrapper over DDSManager::sendData()
        /// @param data Pointer to the TopicDataType object to be sent
        /// @param topic Topic name as string
        /// @return Returns true on success else false
        /// @satisfy{Requirement01165181}
        bool send(void* data, std::string const topic)
        {
          bool const res = ddsManager->send_data(data, topic);
          if (res)
          {
            ML_LOG_MCTX_DEBUG << "[ComfortDdsCommunicationHandler] data sent to topic " << topic << std::endl;
          }
          else
          {
            ML_LOG_MCTX_ERROR << "[ComfortDdsCommunicationHandler] data send failed for topic " << topic << std::endl;
          }
          return res;
        }

        /// @brief Synchronously reads data on a topic, wrapper over DDSManager::recvData()
        /// @param data Pointer to the TopicDataType object to be received
        /// @param topic Topic name as string
        /// @return Returns true on success else false
        /// @satisfy{Requirement01165181}
        bool recv(void* data, std::string const topic)
        {
          bool const res = ddsManager->recv_data(data, topic);
          if (res)
          {
            ML_LOG_MCTX_DEBUG << "[ComfortDdsCommunicationHandler] data recvd on topic " << topic << std::endl;
          }
          else
          {
            ML_LOG_MCTX_ERROR << "[ComfortDdsCommunicationHandler] data recv failed for topic " << topic << std::endl;
          }
          return res;
        }
      };
    }  // namespace di
  }  // namespace cccm
}  // namespace jlr
#endif
