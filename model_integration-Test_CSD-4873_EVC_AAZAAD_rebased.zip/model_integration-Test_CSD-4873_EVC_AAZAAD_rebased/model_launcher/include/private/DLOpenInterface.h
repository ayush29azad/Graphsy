/// @file DLOpenInterface.h
/// @brief Interface declaration for the dlopening a dynamic lib
///
/// @copyright "Copyright (C) 2024, Jaguar Land Rover
/// All rights reserved.
/// CONFIDENTIAL INFORMATION - DO NOT DISTRIBUTE"
///
/// @date June 2024
#ifndef JLRCCCM_DI_INTERFACE_DLOPEN_H
#define JLRCCCM_DI_INTERFACE_DLOPEN_H

#include <memory>
#include <string>

namespace cccm::di::dlopener
{

  /// @brief Interface for loading a dynamic library at runtime and creating
  /// instance of the library class. The library is supposed to contain a
  /// class definition, and some function(symbol) to allow instantiation of
  /// that class
  /// @tparam LibraryClass The class defined in the library that we want to
  /// instantiate
  template <typename LibraryClass>
  class DLOpenInterface
  {

  private:
    /// @brief stores handle to the loaded dynamic library. The dlopen()
    /// system call return a pointer called handle.
    void* mHandle;

    /// @brief stores name of the library to be loaded as string
    std::string mLibName;

  protected:
    /// @brief getter for mHander
    /// @return mHandle pointer
    void* getHandle()
    {
      return mHandle;
    }
    /// @brief setter for mHander
    void setHandle(void* handle)
    {
      mHandle = handle;
    }
    /// @brief getter for library name
    /// @return return std::string library name
    std::string const& getlibName() const
    {
      return mLibName;
    }
    /// @brief setter for library name
    void setlibName(std::string const& libName)
    {
      mLibName = libName;
    }

  public:
    /// @brief Ctor
    /// @param _libName Name of the dynamic library. ex - libbSoC.so
    DLOpenInterface(std::string const& _libName)
    {
      setlibName(_libName);
    }

    /// @brief Defaut Dtor
    virtual ~DLOpenInterface() = default;

    /// @brief Calls the dlopen() method and stores handle
    /// @return true on success, false or failure
    virtual bool dl_open() = 0;

    /// @brief Creates an object of the Library class and returns a
    /// smart pointer instead of the raw pointer.
    /// @return The shared pointer to the library object
    virtual std::shared_ptr<LibraryClass> get_object() = 0;

    /// @brief Calls the dlclose() method
    /// @return true on success, false or failure
    virtual bool dl_close() = 0;
  };

};  // namespace cccm::di::dlopener

#endif
