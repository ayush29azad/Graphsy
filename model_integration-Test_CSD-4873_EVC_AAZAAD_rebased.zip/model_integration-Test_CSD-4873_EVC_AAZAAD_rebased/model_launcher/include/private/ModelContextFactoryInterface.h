/// @file ModelContextFactoryInterface.h
/// @brief Interface declaration for ModelLauncher context Factory
///
/// @copyright "Copyright (C) 2025, Jaguar Land Rover
/// All rights reserved.
/// CONFIDENTIAL INFORMATION - DO NOT DISTRIBUTE"
///
/// @date June 2025
#ifndef JLRCCCM_DI_MODEL_CONTEXT_FACTORY_INTERFACE_H
#define JLRCCCM_DI_MODEL_CONTEXT_FACTORY_INTERFACE_H

#include <memory>
#include <string>

#include <vsomeip/vsomeip.hpp>
#include <DDSEntityFactory.hpp>
#include <WorkExecutor.h>
#include <ArgParser.h>
#include <types.h>

/// @brief using type DDSEntityFactoryInterface as jlr::cccm::di::dds::DDSEntityFactoryInterface
using DDSEntityFactoryInterface = jlr::cccm::di::dds::DDSEntityFactoryInterface;

/// @brief using type DDSEntityFactory as jlr::cccm::di::dds::DDSEntityFactory
using DDSEntityFactory = jlr::cccm::di::dds::DDSEntityFactory;

/// @brief using type WorkExecutor as jlr::cccm::di::work_executor::WorkExecutor
using WorkExecutor = jlr::cccm::di::work_executor::WorkExecutor;

/// @brief using type LauncherContext as cccm::di::launcher::LauncherContext
using LauncherContext = cccm::di::launcher::LauncherContext;

namespace cccm::di::launcher
{
  /// @brief Abstract factory class for LauncherContext, responsible for creating
  /// instances of the dependency classes
  class ModelContextFactoryInterface
  {

  public:
    /// @brief abstract method to create std::unordered_map<std::string, std::shared_ptr<vsomeip::application>>
    /// @return std::unordered_map<std::string, std::shared_ptr<vsomeip::application>>
    virtual std::unordered_map<std::string, std::shared_ptr<vsomeip::application>> create_someip_applications() = 0;

    /// @brief abstract method to create DDSEntityFactory instance
    /// @return DDSEntityFactory shared pointer
    virtual std::shared_ptr<DDSEntityFactoryInterface> create_dds_factory() = 0;

    /// @brief abstract method to create WorkExecutor instance
    /// @return WorKExecutor shared pointer
    virtual std::shared_ptr<WorkExecutor> create_workexecutor() = 0;

    /// @brief abstract method to create context to be passed to each model
    /// @return shared pointer to the created instance
    virtual std::shared_ptr<LauncherContext> create_context() = 0;

    /// @brief abstract method to return the input parser instance
    /// @return reference to the stored input parser instance
    virtual ArgParser const& get_input_arguments() const = 0;

    /// @brief virtual Dtor
    virtual ~ModelContextFactoryInterface() = default;
  };
};  // namespace cccm::di::launcher

#endif
