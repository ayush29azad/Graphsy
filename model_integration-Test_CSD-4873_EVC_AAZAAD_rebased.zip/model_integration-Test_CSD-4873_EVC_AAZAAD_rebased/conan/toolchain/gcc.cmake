set(CMAKE_CXX_FLAGS_RELEASE
    "-Werror -Wall -Wextra -Wpedantic -Wconversion -Wshadow -Wold-style-cast \
     -Wimplicit-fallthrough -fdiagnostics-color=always -pthread")
set(CMAKE_CXX_FLAGS_DEBUG
    "-fsanitize=address,undefined,leak -fsanitize-undefined-trap-on-error -pthread -g3"
)
set(CMAKE_CXX_STANDARD 14)
set(CMAKE_POSITION_INDEPENDENT_CODE ON)
