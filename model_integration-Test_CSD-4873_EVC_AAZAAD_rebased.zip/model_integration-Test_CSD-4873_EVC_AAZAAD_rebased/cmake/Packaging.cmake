function(final_packaging)
  include(${CMAKE_SOURCE_DIR}/conan_paths.cmake)

  find_package(dds_idls REQUIRED)

  file(
    GLOB
    PKG_LIBS
    ${CONAN_DDS_IDLS_ROOT}/lib/lib*
    ${CONAN_DLT-DAEMON_ROOT}/lib/lib*
    ${CONAN_DDS_MANAGER_ROOT}/lib/lib*
    ${CONAN_LOGGING-API_ROOT}/lib/lib*
    ${CONAN_SOMEIP_INTERFACE_ROOT}/lib/lib*
    ${CONAN_WORKEXECUTORTHREAD_ROOT}/lib/lib*)

  file(GLOB PKG_BINS ${CMAKE_SOURCE_DIR}/model_grouping_strategy/*json
       ${CMAKE_SOURCE_DIR}/utils/someip_id_mapping.json)
  file(GLOB EXECS ${CONAN_DLT-DAEMON_ROOT}/bin/*)

  if(${CMAKE_SYSTEM_NAME} STREQUAL QNX)
    file(GLOB KANZI_LIBS ${CONAN_KANZI_APP_ROOT}/lib/lib*)
    file(GLOB KANZI_BINS ${CONAN_KANZI_APP_ROOT}/bin/*)
    list(APPEND PKG_LIBS ${KANZI_LIBS})
    list(APPEND PKG_BINS ${KANZI_BINS})
    list(APPEND EXECS ${CONAN_KANZI_APP_ROOT}/bin/hmi_app)
  endif()

  install(FILES ${PKG_LIBS} DESTINATION ${CUSTOM_LIB_INSTALL_DIR})
  install(FILES ${PKG_BINS} DESTINATION ${CUSTOM_BIN_INSTALL_DIR})
  install(PROGRAMS ${EXECS} DESTINATION ${CUSTOM_BIN_INSTALL_DIR})

  # install(IMPORTED_RUNTIME_ARTIFACTS dlt-daemon::dlt-daemon)
  # install(IMPORTED_RUNTIME_ARTIFACTS dds_idls::dds_idls) install(FILES
  # ${dds_idls_LIB_DIRS} DESTINATION ${CUSTOM_LIB_INSTALL_DIR}) install(EXPORT
  # dds_idls::dds_idls DESTINATION ${CUSTOM_LIB_INSTALL_DIR})

endfunction()
