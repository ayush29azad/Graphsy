find_package(jsoncpp REQUIRED)
find_package(someip_interface REQUIRED)
find_package(dds_idls REQUIRED)
find_package(non_safety_models REQUIRED)
find_package(jlr_early_conf REQUIRED)

function(model_build target)
  set(model_name ${target})

  set(MODEL_DIR ${CMAKE_SOURCE_DIR}/output/codegen/${model_name})
  set(IPC_UTILS_DIR ${CMAKE_SOURCE_DIR}/model_ipc/ipc_wrapper_utils)

  # These paths resolution happens when we call cmake
  set_source_files_properties(
    ${MODEL_DIR}/${model_name}_init.cpp
    ${MODEL_DIR}/${model_name}_out.cpp
    ${MODEL_DIR}/${model_name}_global_vars.cpp
    ${MODEL_DIR}/${model_name}_global_vars.hpp
    ${MODEL_DIR}/Wrapper${model_name}.h
    # ${MODEL_DIR}/DataConverter${model_name}.hpp
    ${MODEL_DIR}/PlaybackDataConverter${model_name}.hpp
    ${MODEL_DIR}/ProtoDataConverter${model_name}.cpp
    ${MODEL_DIR}/ProtoIncludes${model_name}.hpp
    ${MODEL_DIR}/dlt_logger.hpp
    PROPERTIES GENERATED TRUE)

  set(MODEL_SRCS
      ${MODEL_DIR}/${model_name}_init.cpp
      ${MODEL_DIR}/${model_name}_out.cpp
      ${MODEL_DIR}/${model_name}_global_vars.cpp
      ${MODEL_DIR}/ProtoDataConverter${model_name}.cpp
      ${IPC_UTILS_DIR}/SomeipInstanceIdMapping.cpp)

  add_library(${target} SHARED ${MODEL_SRCS})
  target_link_options(${target} PRIVATE
                      "LINKER:--unresolved-symbols=report-all")

  # Model lib depends on the python code generation target
  add_dependencies(${target} ${model_name}Gen)

  target_include_directories(
    ${target}
    PRIVATE ${MODEL_DIR}
    PRIVATE ${PROJECT_SOURCE_DIR}
    PRIVATE ${IPC_UTILS_DIR})

  target_link_libraries(
    ${target}
    PUBLIC jsoncpp
    PUBLIC ipc_wrapper
    PUBLIC ${model_name}Model
    PUBLIC someip_interface::someip_interface
    PUBLIC dds_idls::dds_idls
    PUBLIC jlr_early_conf::jlr_early_conf)

  install(TARGETS ${target} DESTINATION ${CUSTOM_LIB_INSTALL_DIR})

endfunction()

function(gtest_model_build model_name)

  add_definitions(-DENABLE_GTEST=ON)
  set(CMAKE_CXX_OUTPUT_EXTENSION_REPLACE ON)
  set(ROOTPATH ${CMAKE_SOURCE_DIR})
  file(GLOB SRC_DIR "${ROOTPATH}/model_ipc/ipc_wrapper_utils/*.hpp"
       "${ROOTPATH}/model_ipc/ipc_wrapper_utils/*.cpp")
  file(GLOB VSOMEIP_MOCK "${ROOTPATH}/utils/Mock/vsomeip/*.h"
       "${ROOTPATH}/utils/Mock/vsomeip/*.cpp")
  file(GLOB DDSMANAGER_MOCK "${ROOTPATH}/utils/Mock/ddsabs/*.h"
       "${ROOTPATH}/utils/Mock/ddsabs/*.cpp")
  set(MODEL_TESTGEN_DIR ${ROOTPATH}/output/testgen/${model_name})
  set(MODEL_DIR ${ROOTPATH}/output/codegen/${model_name})

  set(TEST_WITH_MAPPING_SRC_${model_name}
      "${MODEL_TESTGEN_DIR}/gtest${model_name}Init.cpp"
      "${MODEL_TESTGEN_DIR}/gtest${model_name}InitNoMapping.cpp"
      "${MODEL_TESTGEN_DIR}/gtest${model_name}MessageChannel.cpp"
      "${MODEL_TESTGEN_DIR}/gtest${model_name}NotifyChannel.cpp"
      "${MODEL_TESTGEN_DIR}/gtest${model_name}Init.cpp"
      "${MODEL_TESTGEN_DIR}/gtest${model_name}Out.cpp"
      "${MODEL_DIR}/${model_name}_global_vars.cpp"
      "${MODEL_DIR}/${model_name}_init.cpp"
      "${MODEL_DIR}/${model_name}_out.cpp"
      "${MODEL_DIR}/ProtoDataConverter${model_name}.cpp"
      "${ROOTPATH}/utils/ProtoRandomGen/ProtoRandomGen.cpp")

  set(TEST_WITH_TIMER_SRC_${model_name}
      "${MODEL_TESTGEN_DIR}/gtest${model_name}InitTimer.cpp"
      "${MODEL_DIR}/${model_name}_global_vars.cpp"
      "${MODEL_DIR}/${model_name}_init.cpp"
      "${MODEL_DIR}/${model_name}_out.cpp"
      "${MODEL_DIR}/ProtoDataConverter${model_name}.cpp"
      "${ROOTPATH}/utils/ProtoRandomGen/ProtoRandomGen.cpp")

  set_source_files_properties(${TEST_WITH_MAPPING_SRC_${model_name}}
                              PROPERTIES GENERATED TRUE)
  set_source_files_properties(${TEST_WITH_TIMER_SRC_${model_name}}
                              PROPERTIES GENERATED TRUE)

  set(sources_with_mapping_${model_name}
      ${SRC_DIR} ${VSOMEIP_MOCK} ${DDSMANAGER_MOCK}
      ${TEST_WITH_MAPPING_SRC_${model_name}})

  set(sources_with_timer_${model_name}
      ${SRC_DIR} ${VSOMEIP_MOCK} ${DDSMANAGER_MOCK}
      ${TEST_WITH_TIMER_SRC_${model_name}})

  add_executable(${model_name}TestsWithMapping
                 ${sources_with_mapping_${model_name}})
  add_executable(${model_name}TestsWithTimer
                 ${sources_with_timer_${model_name}})

  target_compile_definitions(${model_name}TestsWithMapping
                             PRIVATE INSTANCE_ID_MAPPING=ON)
  target_compile_definitions(${model_name}TestsWithTimer
                             PRIVATE INSTANCE_ID_MAPPING=ON)

  target_include_directories(
    ${model_name}TestsWithMapping
    PRIVATE ${ROOTPATH}/utils/ProtoRandomGen
            ${ROOTPATH}/utils/Mock
            ${ROOTPATH}/utils/Mock/jlrdds
            ${ROOTPATH}/utils/Mock/workexecutorthread
            ${ROOTPATH}/utils/Mock/ipc_wrapper_utils_timer_handler
            ${ROOTPATH}/test/unit/include
            ${ROOTPATH}/interface
            ${ROOTPATH}/model_ipc/ipc_wrapper_utils
            ${MODEL_DIR}
            ${ROOTPATH})
  target_include_directories(
    ${model_name}TestsWithTimer
    PRIVATE ${ROOTPATH}/utils/ProtoRandomGen
            ${ROOTPATH}/utils/Mock
            ${ROOTPATH}/utils/Mock/jlrdds
            ${ROOTPATH}/utils/Mock/workexecutorthread
            ${ROOTPATH}/test/unit/include
            ${ROOTPATH}/interface
            ${ROOTPATH}/model_ipc/ipc_wrapper_utils
            ${MODEL_DIR}
            ${ROOTPATH})

  target_link_libraries(
    ${model_name}TestsWithMapping
    PRIVATE someip_interface::someip_interface
            dds_idls::dds_idls
            jsoncpp
            dds_manager::dds_manager
            pthread
            ${GTEST_LIBS}
            ${model_name}Model
            vsomeip::vsomeip
    PUBLIC jlr_early_conf::jlr_early_conf)

  target_link_libraries(
    ${model_name}TestsWithTimer
    PRIVATE someip_interface::someip_interface
            dds_idls::dds_idls
            jsoncpp
            dds_manager::dds_manager
            pthread
            ${GTEST_LIBS}
            ${model_name}Model
            vsomeip::vsomeip
    PUBLIC jlr_early_conf::jlr_early_conf)

  add_test(
    NAME ${model_name}TestsWithMapping
    COMMAND ${CMAKE_CURRENT_BINARY_DIR}/${model_name}TestsWithMapping
            --gtest_output=json:jsonreports/${model_name}.json
    WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR})
  add_test(
    NAME ${model_name}TestsWithTimer
    COMMAND ${CMAKE_CURRENT_BINARY_DIR}/${model_name}TestsWithTimer
    WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR})

  add_dependencies(${model_name}TestsWithMapping ${model_name}GtestGen)
  add_dependencies(${model_name}TestsWithTimer ${model_name}GtestGen)

endfunction()
