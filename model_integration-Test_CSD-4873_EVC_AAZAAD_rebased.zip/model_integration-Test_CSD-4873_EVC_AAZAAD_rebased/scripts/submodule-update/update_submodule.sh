#!/usr/bin/env bash
# this script is written to run in pipeline as well as locally
set -e

source "$(dirname "$0")/../common/env_setup.sh"
if [[ -z  ${CI_REPOSITORY_URL} ]]; then
	url="$(git config --get "remote.origin.url" | sed 's/.*@//' | sed 's/.git//' | sed 's/:/\//')"	
	CI_REPOSITORY_URL="https://${auth_slug}@${url}"
else
    echo "scripts/update_submodule: Running in the pipeline"	
fi

submodule_config="$(cat "${ROOTPATH}"/dependencies_config/submodule_config.json)"
submodule_list="$(echo "$submodule_config" | jq -r '. | to_entries | .[] | .key')"

for submodule in $submodule_list; do	
	if [[ -z $CI ]]; then
		# locally, to avoid dubious ownership errors
		git config --global --add safe.directory "$ROOTPATH"/"$submodule"
	fi

	branch="$(echo "$submodule_config" | jq --raw-output --arg arg1 $submodule '.[$arg1].branch')"
	path="$(echo "$submodule_config" | jq --raw-output --arg arg1 $submodule '.[$arg1].path')"
	if [ ! -z "$branch" ]; then
		git ls-remote -q "${CI_REPOSITORY_URL}"/"$path" | grep "$branch" || (echo "Pls check for proper submodule path and branch name" && exit 1)
	else
		git ls-remote -q "${CI_REPOSITORY_URL}"/"$path" || (echo "Pls check for proper submodule path" && exit 1)
	fi
	git submodule set-url "$submodule" "$path" || echo "Warning: update_submodule: submodule set-url for $submodule failed"
	if [ ! -z "$branch" ]; then
		echo "Using branch for ${submodule}: ${branch}"
		git submodule add -b "$branch" "$path" || git submodule set-branch --branch "$branch" "$submodule";
	else
		git submodule add "$path" || echo "Warning: update_submodule: failed to add submodule $path"	# if branch not specified, use present branch if submodule present or use main branch if submodule not present
	fi
done


git submodule update --init --remote --recursive

for submodule in $submodule_list; do
	commit_id="$(echo "$submodule_config" | jq --raw-output --arg arg1 $submodule '.[$arg1].commit_id')"
	if [ ! -z "$commit_id" ]; then
		cd "$submodule"
		echo "Switching to commit ${commit_id} for ${submodule}"
		git checkout "$commit_id" || (echo "Pls. check for proper commit id" && exit 1)		
		cd ..;
	fi
done

set +e
