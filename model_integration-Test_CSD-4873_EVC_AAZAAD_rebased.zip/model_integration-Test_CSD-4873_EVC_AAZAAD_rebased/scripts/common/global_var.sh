#!/bin/bash
# Note since these are global variables please use carefully dont redfine them again.
simulink_models_artifact_config_file=${ROOTPATH}/dependencies_config/simulink_models_artifact_config.json
artifacts_fetched_path=$ROOTPATH/artifacts_fetched
generic_model_config_file=$ROOTPATH/model_ipc/config/generic_model_config.json
submodule_config_file=$ROOTPATH/dependencies_config/submodule_config.json
model_config_artifact_repo_path="$artifacts_fetched_path"/$(jq --raw-output '.models_repo.model_config_artifact_repo_path' "$simulink_models_artifact_config_file")
model_config_repo_path="$model_config_artifact_repo_path"
model_artifact_code_path=$(jq --raw-output '.models_repo.model_artifact_code_path' "$simulink_models_artifact_config_file")
models_aligned_path=$(jq --raw-output '.input_paths.model_path' "$generic_model_config_file")

# vsomeip and out components variables
vsomeip_repo=$(jq --raw-output '.input_paths.vsomeip_repo' "$generic_model_config_file")
val_vsomeip_servers_repo=$(jq --raw-output '.input_paths.val_vsomeip_servers_repo' "$generic_model_config_file")
val_vsomeip_servers_path=$ROOTPATH/$vsomeip_repo/$val_vsomeip_servers_repo
model_vsomeip_clients_repo=$(jq --raw-output '.input_paths.model_vsomeip_clients_repo' "$generic_model_config_file")
val_vsomeip_server_suffix=$(jq --raw-output '.val_vsomeip_server_suffix' "$generic_model_config_file")
out_bin_path_qnx=${ROOTPATH}/out/bin
out_bin_path_linux=${ROOTPATH}/out/bin


models_repo=$(jq --raw-output '.input_paths.model_path' "$generic_model_config_file")
# model_config_repo_path=$ROOTPATH/$models_repo/modelConfig
utils_repo=$(jq --raw-output '.input_paths.utils_repo' "$generic_model_config_file")
utils_repo_path=$ROOTPATH/$utils_repo
model_vsomeip_client_suffix=$(jq --raw-output '.model_vsomeip_client_suffix' "$generic_model_config_file")
proto_files_repo=$(jq --raw-output '.input_paths.proto_path' "$generic_model_config_file")
proto_files_path=$ROOTPATH/$proto_files_repo
submodule_config_file=$ROOTPATH/dependencies_config/submodule_config.json
models=$(jq --raw-output '.models[]' "$simulink_models_artifact_config_file")
model_config_path=$ROOTPATH/$models_aligned_path/modelConfig
service_protoDependency_file=${ROOTPATH}/service_protoDependency.json

models_release_version=$(jq --raw-output '.models_repo.release_version' "$simulink_models_artifact_config_file")
models_artifactory_path=$(jq --raw-output '.models_repo.artifactory_path' "$simulink_models_artifact_config_file")
models_repo_name=$(jq --raw-output '.models_repo.repo' "$simulink_models_artifact_config_file")
# models_artifactory_path="${models_artifactory_path}/${models_repo_name}:${models_release_version}.tar.gz"
dependencies_manifest_file_path="$artifacts_fetched_path"/$(jq --raw-output '.models_repo.deps_manifest' "$simulink_models_artifact_config_file")
model_someip_service_config_file=${ROOTPATH}/model_ipc/config/model_someip_service_config.json

debug_branch_config_file="$ROOTPATH/utils/debug_branch.config"
