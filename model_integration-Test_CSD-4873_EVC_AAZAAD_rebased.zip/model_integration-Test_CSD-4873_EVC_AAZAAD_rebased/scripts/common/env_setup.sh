#!/bin/bash
## This script has to be run from the scope of parent "model_integration" folder
set -e

export ROOTPATH="$(pwd)"
chmod u+x "${ROOTPATH}"/scripts/*


# ------- Error handling ----------------------
STATUS_FETCH_FAIL=1
STATUS_NO_ROOTPATH=2
STATUS_NO_LIB=3

# Check ROOTPATH variable
if [[ -z "${ROOTPATH}" ]]; then
    echo "\$ROOTPATH not set :("
    exit $STATUS_NO_ROOTPATH
else
    echo "env_setup.sh: \$ROOTPATH = ${ROOTPATH}"
fi

check_submodule_status() {
    if  git submodule status | grep '^-' 
    then 
        echo "check_submodule_status: Submodules Not Found. Cloning submodules"; 
        git submodule update --init --recursive
    else
        echo "check_submodule_status: Submodules Found";
    fi
}

check_local_githooks() {
    echo "env_setup.sh: check_local_githooks"
    cp $ROOTPATH/common-infrastructure/githooks/{commit-msg,pre-commit} $ROOTPATH/.git/hooks/
    cp $ROOTPATH/dependencies_config/.pre-commit-config.yaml $ROOTPATH
}

if [[ ! -n "$CI" ]]; then
    if [[ -d ".git/" ]]; then
        echo "env_setup.sh: Running locally"
        check_submodule_status
        check_local_githooks
    fi
fi
if [[ -f ${ROOTPATH}/common-infrastructure/code-quality/.clang-format ]]; then
    cp ${ROOTPATH}/common-infrastructure/code-quality/.clang-format ${ROOTPATH}
fi

# Set up local/CI credentials   NOTE: For local, CI variable should be undefined
if [[ -n "$CI" ]] ; then
    # set ci related variables and functionality here
    echo "env_setup.sh: Running in the Pipeline"

    git config --global user.name "${GITLAB_USER_NAME}"
    git config --global user.email "${GITLAB_USER_EMAIL}"
    auth_slug="gitlab-ci-token:${CI_JOB_TOKEN}"
    auth_header="JOB-TOKEN: ${CI_JOB_TOKEN}"
else
    PRIVATE_TOKEN="$(cat ~/gitlab_token.txt)" || (echo "env_setup.sh: Setup private token in ~/gitlab_token.txt file - Exiting" && exit 1)

    if [[ -z $PRIVATE_TOKEN ]]; then
        echo "env_setup.sh: gitlab_token is Null - Exiting" && exit 1
    fi

    auth_slug="oauth2:${PRIVATE_TOKEN}"
    auth_header="PRIVATE-TOKEN: ${PRIVATE_TOKEN}"
fi

GITLAB_CI_URL="https://${auth_slug}@git-gdd.sdo.jlrmotor.com"
ARTI_URL_PREFIX="https://git-gdd.sdo.jlrmotor.com/api/v4/projects"
GITLAB_URL="git-gdd.sdo.jlrmotor.com"


shopt -s expand_aliases # for alias command to work in scripts
alias curl='curl --location --silent --write-out %{http_code} > /tmp/http_code.txt'
check_fetch_status() {
    stat="$(cat /tmp/http_code.txt)"
    if (( !($stat >= 200 && $stat <= 299) )); then
        echo "check_fetch_status: Fetch failed with http status code: $stat"; exit $STATUS_FETCH_FAIL
    else
        echo "check_fetch_status: Fetch succeeded"
    fi
}


#JFrog utilities
if [[ -n "$CI" ]]; then
    if [[ -f /usr/local/lib/artifactory_utils.sh ]]; then
        source /usr/local/lib/artifactory_utils.sh
    fi
fi
