# -*- coding: utf-8 -*-
import json
import os
import argparse
import sys
from colorama import Fore, Style, init

# Initialize colorama
init(autoreset=True)

IGNOREABLE_STATUS = ["Ignore", "Defer"]


def sanitize_path(file_path):
    """
    Sanitize the input path to prevent path traversal.
    Convert the file path to an absolute path and ensure it is within a valid directory.
    :param file_path: Path provided by the user.
    :return: Sanitized absolute path.
    """
    base_directory = os.path.abspath(
        os.getcwd()
    )  # Define the base directory (e.g., current working directory)
    absolute_path = os.path.abspath(file_path)  # Convert the path to an absolute path
    normalized_path = os.path.normpath(
        absolute_path
    )  # Normalize the path to collapse any '../'

    # Ensure the file is within the base directory to avoid path traversal
    if not normalized_path.startswith(base_directory):
        raise ValueError(
            f"Invalid file path: {file_path}. Path traversal attempt detected."
        )

    return normalized_path


def format_issue(issue, context_lines, target_line):
    """
    Format a parsed issue into a human-readable format.
    :param issue: A dictionary containing issue details.
    :param context_lines: List of lines around the affected line.
    :param target_line: The line number of the affected issue.
    :return: A formatted string representing the issue.
    """
    taxonomies = ", ".join(
        [t.get("name", "Unknown Taxonomy") for t in issue.get("taxonomies", [])]
    )

    # Highlight the affected line
    context_str = "\n  ".join(
        f"    {Fore.BLUE + Style.BRIGHT + str(line_num) + Style.RESET_ALL if line_num == target_line else str(line_num)}: "
        f"    {Fore.MAGENTA + Style.BRIGHT + line_content + Style.RESET_ALL if line_num == target_line else line_content}"
        f"{Fore.RED + Style.BRIGHT + '        <-----' + Style.RESET_ALL if line_num == target_line else ''}"
        for line_num, line_content in context_lines
    )

    return (
        f"  File: {issue.get('file', 'Unknown File')}:{issue.get('line', 'Unknown Line')}\n"
        f"  Message: {issue.get('message', 'No message available')}\n"
        f"  Taxonomies: {taxonomies}\n"
        f"  Code: {issue.get('code', 'Unknown Code')}\n"
        f"  Severity: {issue.get('severity', 'Unknown Severity')} (Code: {issue.get('severityCode', 'N/A')})\n"
        f"  Server Issue #: {issue.get('id', 'Unknown')}\n"
        f"  Code Context:\n  {context_str}"
        f"{'-'*40}"
    )


def get_context_lines(file_path, target_line, context=2):
    """
    Get the target line and the specified number of lines before and after it from a file.
    :param file_path: Path to the file to read.
    :param target_line: Line number of the target issue.
    :param context: Number of lines before and after the target line to retrieve.
    :return: List of tuples with line numbers and line content.
    """
    sanitized_file_path = sanitize_path(file_path)  # Sanitize the file path
    try:
        with open(sanitized_file_path, "r") as file:
            lines = file.readlines()
            start_line = max(0, target_line - context - 1)
            end_line = min(len(lines), target_line + context)
            return [(i + 1, lines[i].strip()) for i in range(start_line, end_line)]
    except FileNotFoundError:
        return [("N/A", f"Error: File '{sanitized_file_path}' not found.")]
    except Exception as e:
        return [
            ("N/A", f"An error occurred while reading '{sanitized_file_path}': {e}")
        ]


def contains_keywords(context_lines, keywords):
    """
    Check if any of the provided keywords appear in the context lines.
    :param context_lines: List of tuples with line number and line content.
    :param keywords: List of keywords to search for in the code context.
    :return: (bool, str) Whether any keyword is found and the found keyword (if any).
    """
    for line_num, line_content in context_lines:
        for keyword in keywords:
            if keyword in line_content:
                return True, keyword
    return False, None


def is_existing_issue(issue):
    """
    Safe check for existing issues.
    """
    state = issue.get("state")
    is_system = issue.get("isSystem", False)

    # 1. FORMER_SERVER ignore )
    if state == "FORMER_SERVER":
        return True
    
    # 2. For EXISTING (Safety for new bugs)
    if state == "EXISTING" and is_system is True:
        return True

    return False

def issue_in_taxonomy(issue, taxonomies):
    """
    Check if the issue is part of the listed taxonomies
    :param issue: The issue
    :param taxonomies: List of taxonomies which should be considered for failure
    :return: (bool) Whether the issue has one of the listed taxonomies
    """
    # if issue has taxonomy taxonomy
    issue_taxonomies = issue.get("taxonomies")
    for issue_taxonomy in issue_taxonomies:
        issue_taxonomy_name = issue_taxonomy["name"].replace(" ", "_")
        if issue_taxonomy_name in taxonomies:
            return True
    return False


def process_klocwork_json(
    file_path,
    ignored_checks,
    ignored_keywords,
    include_taxonomies,
    output_file,
    fail_on_remaining,
):  # noqa: C901
    """
    Process the Klocwork JSON output file and print each issue in a formatted way.
    Filter issues based on ignored checks and keywords and save the filtered issues in a JSON file if output_file is provided.
    If `fail_on_remaining` is True and issues remain after filtering, exit with a non-zero status code.
    :param file_path: Path to the JSON file.
    :param ignored_checks: List of checks to ignore.
    :param ignored_keywords: List of keywords to search for in the code context and ignore.
    :param include_taxonomies: List of taxonomies to consider for failure
    :param output_file: Path to save the filtered JSON issues.
    :param fail_on_remaining: Whether to fail if there are any issues left after filtering.
    """
    sanitized_json_file_path = sanitize_path(file_path)  # Sanitize the input file path
    try:
        with open(sanitized_json_file_path, "r") as file:
            issues = json.load(file)

            # Ensure the issues are in the expected format
            if not isinstance(issues, list):
                print(
                    f"Error: Expected a list of issues in the JSON file, got {type(issues).__name__}."
                )
                return

            filtered_issues = []  # Store issues that pass all filters

            print("New Klocwork issues detected:\n")
            for issue in issues:
                # Look for if Ignore/Defer
                if issue.get("status") in IGNOREABLE_STATUS:
                    continue

                # Skip issues with ignored checks
                code = issue.get("code")
                if code in ignored_checks:
                    continue

                # Fetch the surrounding context lines from the affected file
                source_line = []
                # context_lines = []
                source_file_path = issue.get("file")
                source_line_number = issue.get("line")

                if not source_file_path or not isinstance(source_file_path, str):
                    print(
                        f"Error: Invalid or missing source file path for issue ID {issue.get('id', 'Unknown')}."
                    )
                    source_line = [("N/A", "Error: Invalid source file path.")]
                    # context_lines = [("N/A", "Error: Invalid source file path.")]
                elif not source_line_number or not isinstance(source_line_number, int):
                    print(
                        f"Error: Invalid or missing line number for issue ID {issue.get('id', 'Unknown')}."
                    )
                    source_line = [("N/A", "Error: Invalid line number.")]
                    # context_lines = [("N/A", "Error: Invalid line number.")]
                elif os.path.exists(sanitize_path(source_file_path)):
                    source_line = get_context_lines(
                        source_file_path, source_line_number, 0
                    )
                    # context_lines = get_context_lines(source_file_path, source_line_number)
                else:
                    source_line = [
                        (
                            "N/A",
                            f"Error: Source file '{source_file_path}' not found.",
                        )
                    ]
                    # context_lines = [("N/A", f"Error: Source file '{source_file_path}' not found.")]

                # Verify issue is new
                if is_existing_issue(issue):
                    print(
                        f"Issue #{issue.get('id', 'Unknown')} - already exists, skipping."
                    )
                    continue

                # Check if any of the ignored keywords appear in the source code
                keyword_found, found_keyword = contains_keywords(
                    source_line, ignored_keywords
                )
                if keyword_found:
                    print(
                        f"Issue #{issue.get('id', 'Unknown')} - Keyword '{found_keyword}' found, skipping."
                    )
                    continue

                # If taxonomies_to_fail_on provided
                if include_taxonomies:
                    issue_has_failing_taxonomy = issue_in_taxonomy(
                        issue, include_taxonomies
                    )
                    if not issue_has_failing_taxonomy:
                        print(
                            f"Issue #{issue.get('id', 'Unknown')} - Not part of the taxonomies to fail on, skipping."
                        )
                        continue

                # Add issue to filtered issues if no filters applied
                filtered_issues.append(issue)

            # Save filtered issues to the output file if specified
            if output_file:
                sanitized_output_file = sanitize_path(
                    output_file
                )  # Sanitize the output file path
                with open(sanitized_output_file, "w") as out_file:
                    json.dump(filtered_issues, out_file, indent=4)
                print(f"\nFiltered issues saved to '{sanitized_output_file}'.")

            ignored_issues = [item for item in issues if item not in filtered_issues]
            print(
                f"\nIgnoring {len(ignored_issues)} issues that have been filtered out..."
            )

            i = 0
            print("\n\n\n\n")
            for issue in filtered_issues:
                i += 1
                print(
                    f"Issue {i}:\n{format_issue(issue, get_context_lines(issue.get('file'), issue.get('line')), issue.get('line'))}"
                )
                # wait for user input to continue
                # input("Press Enter to continue...")

            # print the number of issues remaining after filtering
            print(f"\n{len(filtered_issues)} issues remaining after filtering.")

            # Handle the --fail option
            if fail_on_remaining and filtered_issues:
                print("\nIssues remaining after filtering, exiting with code 1.")
                sys.exit(1)  # Exit with non-zero status

    except FileNotFoundError:
        print(f"Error: JSON file '{sanitized_json_file_path}' not found.")
    except json.JSONDecodeError:
        print(
            f"Error: Failed to decode JSON from file '{sanitized_json_file_path}'. Make sure it's a valid JSON file."
        )
    except Exception as e:
        print(f"An unexpected error occurred: {e}")


def main():
    # Set up argument parser
    parser = argparse.ArgumentParser(description="Process Klocwork JSON output")
    parser.add_argument(
        "json_file", type=str, help="Path to the Klocwork JSON output file"
    )
    parser.add_argument(
        "--ignore",
        nargs="*",
        help="Checks to ignore (e.g., AUTOSAR.ADD.LITERAL)",
        default=[],
    )
    parser.add_argument(
        "--ignore-keywords",
        nargs="*",
        help="Keywords to ignore in code context (e.g., info_log)",
        default=[],
    )
    parser.add_argument(
        "--include-taxonomies",
        nargs="*",
        help="Taxonomies that should cause pipeline failure (replace spaces with _)",
        default=[],
    )
    parser.add_argument(
        "--output",
        type=str,
        help="Path to the output JSON file to save the filtered issues",
        default=None,
    )
    parser.add_argument(
        "--fail",
        action="store_true",
        help="Exit with a non-zero status code if there are any issues left after filtering",
    )

    # Parse arguments
    args = parser.parse_args()

    # Process the provided JSON file, passing the ignored checks, keywords, output file path, and fail flag
    process_klocwork_json(
        args.json_file,
        args.ignore,
        args.ignore_keywords,
        args.include_taxonomies,
        args.output,
        args.fail,
    )


if __name__ == "__main__":
    main()
