#!/bin/bash
set -e
source "$ROOTPATH"/scripts/common/env_setup.sh


source "$ROOTPATH"/scripts/common/global_var.sh

get_kanzi_app_release_version() {
    if [[ "$CI" == true && $MODIFY_KANZI_APP_VERSION != "" ]]; then
        echo "Getting kanzi_app version from the Triggered pipeline : MODIFY_KANZI_APP_VERSION"
        artifact_version=$MODIFY_KANZI_APP_VERSION
    else
        artifact_version=$(jq --raw-output '.kanzi_app.version' $simulink_models_artifact_config_file)
    fi

	echo "kanzi_app_release_version --> $artifact_version"
}

# Function to download kanzi_app artifacts from jfrog
dl_kanzi_app_release_artifacts() {
	echo "function: dl_kanzi_app_release_artifacts -----------------"
	artifact_name=$(jq --raw-output '.kanzi_app.name' $simulink_models_artifact_config_file)
	# artifact_version=$(jq --raw-output '.kanzi_app.version' $simulink_models_artifact_config_file)
	get_kanzi_app_release_version
	artifact_location=$(jq --raw-output '.kanzi_app.location' $simulink_models_artifact_config_file)

	artifact_dl_path=${artifact_location}/${artifact_name}:${artifact_version}.tar.gz

	echo "Downloading kanzi_app artifacts version - ${artifact_version} release -----------------"

	if [[ "$CI" == true ]]; then
		rt_download --flat $artifact_dl_path $ROOTPATH/out/artifacts.tar.gz --props version=$artifact_version
	else
		jfrog rt dl --flat --props version=$artifact_version $artifact_dl_path $ROOTPATH/out/artifacts.tar.gz
	fi
	mkdir -p "$ROOTPATH"/out/kanzi_app_artifacts
	tar -xzf "$ROOTPATH"/out/artifacts.tar.gz --directory "$ROOTPATH"/out/kanzi_app_artifacts
	rm -rf "$ROOTPATH"/out/artifacts.tar.gz

	rm -rf "$ROOTPATH"/out/kanzi_app_artifacts/application/bin/platform/{linux,win}

	# Remove dds_manager (libjlrdds.so) as we get this from model_integration
	# echo "--remove libjlrdds.so from kanzi_app_artifacts ----------"
	# rm -rf "$ROOTPATH"/out/kanzi_app_artifacts/application/bin/platform/qnx/release/lib/libjlrdds.so
}

dl_kanzi_app_release_artifacts

echo "-----copy kanzi_app_artifacts to out/kazi_app ---------"
cd "$ROOTPATH"/out
mkdir -p kanzi_app/bin
mkdir -p kanzi_app/lib

# Copy all the kzb, cfg, xml files from kanzi_app/bin/
cp kanzi_app_artifacts/application/bin/* kanzi_app/bin/ || echo "Warning: get_kanzi_app_release_artifacts: failed to copy kanzi_app_artifacts/app/bin"

# Copy Fonts Folder from kanzi_app/bin
cp -r kanzi_app_artifacts/application/bin/Fonts kanzi_app/ || echo "Warning: get_kanzi_app_release_artifacts: failed to copy kanzi_app_artifacts/Fonts"

# Copy the application_*.cfg files
cp kanzi_app_artifacts/application/bin/platform/qnx/application_*.cfg kanzi_app/bin/ || echo "Warning: get_kanzi_app_release_artifacts: failed to copy kanzi_app_artifacts/app/bin/platform/qnx/application_*.cfg"

# Copy the hmi_app binary
cp kanzi_app_artifacts/application/bin/platform/qnx/release/hmi_app kanzi_app/bin/ || echo "Warning: get_kanzi_app_release_artifacts: failed to copy kanzi_app_artifacts/app/bin/platform/qnx/release/hmi_app"

# Copy all the libraries (lib*.so)
find kanzi_app_artifacts/application/bin/platform/qnx/release -name "lib*.so*" -type f -exec cp {} kanzi_app/lib/ \;

rm -rf kanzi_app_artifacts
cd "$ROOTPATH"
