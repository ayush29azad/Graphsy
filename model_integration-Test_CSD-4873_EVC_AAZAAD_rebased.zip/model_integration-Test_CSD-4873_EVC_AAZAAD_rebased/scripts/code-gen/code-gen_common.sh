#!/bin/bash
############################################### To do #################################################################

# 1. All model build vs Certain model build : User input
# 2. Topic libs, proto libs everytime vs selected scenarios : User input
# 3. Python version issue (>3.0 <=3.9) : Validate 
# 4. Someip clients and servers for each model naming conventions : Modify dir structure

########################################### Codegen Environment validation #############################################

set -e

source "$ROOTPATH"/scripts/common/env_setup.sh
# ----------- Global variables --------
source "$ROOTPATH"/scripts/common/global_var.sh

# check if protoc exists in $PATH
if ! command -v protoc &> /dev/null
then
    echo "protoc could not be found"
    exit "$STATUS_NO_LIB"
else
    echo "protoc found"
fi

# check if fastddsgen exists in $PATH
if ! command -v fastddsgen &> /dev/null
then
    echo "fastddsgen could not be found"
    exit "$STATUS_NO_LIB"
else
    echo "fastddsgen found"
fi

command -v python3 >/dev/null 2>&1 && echo "Python 3 is installed" || (echo "Python 3 is not installed" && exit "$STATUS_NO_LIB")
# ############################################## Generate cpp code ######################################################

generate_idl_code () {
    echo "generate_idl_code ------------------------------- "
    # Generate cpp classes for idl files
    idl_dir=$ROOTPATH/model_ipc/dds_topics_idls
    idl_gen_dir=$idl_dir/gen
    rm -rf $idl_gen_dir/*
    mkdir -p $idl_gen_dir

    for idl_file in "$idl_dir"/*.idl;do
        cp "$idl_file" "$idl_gen_dir"
        cd "$idl_gen_dir"
        fastddsgen `basename "$idl_file"`
        rm `basename "$idl_file"`
        cd "$ROOTPATH"
        echo "generated code for file : `basename "$idl_file"`"
    done

    cp "$idl_gen_dir"/*.h "$ROOTPATH"/model_ipc/include/dds_topics_idls
    echo "generate_idl_code ----------succeeded--------------------- "
}

generate_idl_code

#------------------ model code gen --------
export MODEL_CONFIG_REPO_PATH=$model_config_path
#------ Generate common cmakelists -- for all topics & protos ------------
python3 "$ROOTPATH"/auto_codegen_scripts/common_cmake_gen.py
# ---------- Generate ipc code & cmakelists per model -------------
counter=1
displayOdometerTripComputer="displayOdometerTripComputer"

python3 "$ROOTPATH"/auto_codegen_scripts/main.py 
python3 $ROOTPATH/auto_codegen_scripts/gtest/gtest_main.py

# Copying non-generated gtest script to gtest folders of each model
# for model_name in ${models[@]};
# do
#   cp "${ROOTPATH}/${utils_repo}/gtest/GtestSomeipChannel.cpp" \
#     "${ROOTPATH}/${utils_repo}/gtest/GtestSomeipServiceConsumer.cpp" \
#     "$ROOTPATH"/model_ipc/models/"$model_name"_ert_rtw/gtest/
# done
