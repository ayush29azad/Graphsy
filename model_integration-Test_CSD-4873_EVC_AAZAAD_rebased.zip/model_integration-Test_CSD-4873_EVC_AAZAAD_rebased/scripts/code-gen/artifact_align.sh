
source "$ROOTPATH"/scripts/common/global_var.sh

alias cp='cp -rPf'

# -------- Gather all the models to be deployed -----------------
function gather_all_models_to_build()
{
    model_names=()
    model_names=$(jq --raw-output '.models[]' "$simulink_models_artifact_config_file")
}

gather_all_models_to_build
#--------------- Location of dependancies.manifest file----------------------
cp "$dependencies_manifest_file_path" "$ROOTPATH"/"$models_aligned_path"

#------------------- Copy process_config from model_grouping_strategy directory to /bin -----------------------------
echo "-------- Copy process_config from model_grouping_strategy directory to /bin ---------"
cp "$ROOTPATH"/model_grouping_strategy/*.json "$ROOTPATH"/bin

#------------- Align model specific artifacts --------------------
#shellcheck disable=SC2068
for model_name in ${model_names[@]};
do
    # ------ Align $model_name - model code from artifacts_fetched ------------ 
    echo "Align $model_name files from artifacts_fetched"

    # unzip the model
    ArchiveName="${model_name}_Code.zip"
    ArchivePath=$artifacts_fetched_path/$model_artifact_code_path/$ArchiveName
    ModelFilePath=$artifacts_fetched_path/$model_artifact_code_path/$model_name
    unzip -qq "$ArchivePath" -d "$ModelFilePath"
    sDirArchivePath=$ModelFilePath/sDirFiles.zip
    sDirFilesPath="$ModelFilePath"/sDirFiles
    unzip -qq "$sDirArchivePath" -d "$sDirFilesPath"

    # copy model_config to correct path
    mkdir -p "$ROOTPATH"/"$models_aligned_path"/modelConfig
    model_config_source_path="${sDirFilesPath}/modelConfig/${model_name}.json"
    cp "${model_config_source_path}" "$ROOTPATH"/"$models_aligned_path"/modelConfig/

    model_ert_rtw="${model_name}_ert_rtw"

    mkdir -p "$ROOTPATH"/"$models_aligned_path"/"$model_ert_rtw"
    mkdir -p "$ROOTPATH"/"$models_aligned_path"/"$model_ert_rtw"/gtest


    model_source_dir_artifact_fetched_path_absolute="${sDirFilesPath}/${model_ert_rtw}/"

    cp "$model_source_dir_artifact_fetched_path_absolute"/*.cpp "$ROOTPATH"/"$models_aligned_path"/"$model_ert_rtw"
    cp "$model_source_dir_artifact_fetched_path_absolute"/*.h "$ROOTPATH"/"$models_aligned_path"/"$model_ert_rtw"

    model_slprj_dir_artifact_fetched_path_absolute="${sDirFilesPath}/slprj/ert/_sharedutils"

    model_shared_util_dir="slprj/ert/_sharedutils"
    mkdir -p "$ROOTPATH"/"$models_aligned_path"/"$model_ert_rtw"/"$model_shared_util_dir"

    #copy all the file including .h and .cpp to the slprj folder which has been created inside every ModelName_ert_rtw
    cp "$model_slprj_dir_artifact_fetched_path_absolute"/* "$ROOTPATH"/"$models_aligned_path"/"$model_ert_rtw"/"$model_shared_util_dir"


    #copy extra file present in utils folder including .h and .cpp
    cp "$utils_repo"/*.h "$ROOTPATH"/"$models_aligned_path"/"$model_ert_rtw"/"$model_shared_util_dir"

done


#-----------Align proto, idl & mapping files-------------------------------
ipc_mapping_aligned_repo_path=$(jq --raw-output '.input_paths.ipc_mapping_path' "$generic_model_config_file")
mkdir -p "$ROOTPATH"/"$ipc_mapping_aligned_repo_path"


idls_aligned_repo_path=$(jq --raw-output '.input_paths.idls_folder' "$generic_model_config_file")

someip_interface_aligned_repo_path=$(jq --raw-output '.input_paths.proto_path' "$generic_model_config_file")

#To-Do: Save all the below paths in variable
echo "Align all models topic idls & mapping files" # To-Do: copy model specific idls
cp "$artifacts_fetched_path"/dds_artifacts/DI_ALL/IDL/*.idl "$ROOTPATH"/"$idls_aligned_repo_path"
# Remove hmi_topics
cp "$artifacts_fetched_path"/dds_artifacts/DI_ALL/mapping_json/*.json "$ROOTPATH"/"$ipc_mapping_aligned_repo_path"

echo "Align all someip service proto, json and mapping files" # To-Do: copy service specific files
cp "$artifacts_fetched_path"/someip_artifacts/protos/*/*.proto "$ROOTPATH"/"$someip_interface_aligned_repo_path"
cp "$artifacts_fetched_path"/someip_artifacts/protos/*/*.json "$ROOTPATH"/"$someip_interface_aligned_repo_path"

# TO-DO: temporary fix for copying corrected suspension_service from utils 
cp "$ROOTPATH"/utils/*.json "$ROOTPATH"/"$someip_interface_aligned_repo_path"

echo "Align IPC_Mapping files"
# copy service mapping files
cp "$artifacts_fetched_path"/someip_artifacts/mapping_json/* "$ROOTPATH"/"$ipc_mapping_aligned_repo_path"
# cp $utils_repo/temp/IPCMapping/* $ROOTPATH/$ipc_mapping_aligned_repo_path

#----------Copy DI_ALL_topics_mapping.json and ds_direct.xml for DDSFuzzer code generation-----------------------
cp "$artifacts_fetched_path"/dds_artifacts/DI_ALL/mapping_json/DI_ALL_topics_mapping.json "$ROOTPATH"/test/DDSFuzzer
cp "$artifacts_fetched_path"/dds_artifacts/DI_ALL/xml/ds_direct.xml "$ROOTPATH"/test/DDSFuzzer

rm -rf "$artifacts_fetched_path"
tree -L 3

#----------Add json_name entry to Vsomeip IPC Mapping files-----------------------
source "$ROOTPATH"/scripts/code-gen/add_json_name_to_IPC.sh
add_json_name_to_IPC_mapping  "$ROOTPATH/$ipc_mapping_aligned_repo_path" "$model_someip_service_config_file"
echo "---------------artifact_align succeded----------------------------------------"
