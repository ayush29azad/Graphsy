#!/bin/bash
mkdir -p execution/bin
mkdir -p execution/lib
cp bin/* execution/bin
cp bin/val_vsomeip_servers/* execution/bin
cp bin/mockvals/* execution/bin
cp lib/dds_topics/* execution/lib
cp lib/models/* execution/lib
cp lib/proto_libs/* execution/lib
cp lib/workexecutorthread/* execution/lib
cp lib/jlrdds/* execution/lib
