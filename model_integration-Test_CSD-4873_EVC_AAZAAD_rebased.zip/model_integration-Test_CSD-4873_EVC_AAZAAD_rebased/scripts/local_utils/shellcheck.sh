#!/usr/bin/env bash

# This script runs a linter over all the shell scripts in the repository.

set -eo pipefail

# Ignore backslash warning on scripts
export SHELLCHECK_OPTS="-e SC1117 -e SC1090 -e SC2038"

if [[ -z "${1}" ]]
then
  PROJECT_DIR=$(cd "$(dirname "$0")/.."; pwd)
else
  PROJECT_DIR=$(cd "$1"; pwd)
fi

cd "${PROJECT_DIR}"


# Run shellcheck on all .sh files in source control
if git ls-files | grep -E ".sh$"; then
  git ls-files \
    | grep -E ".sh$" \
    | xargs shellcheck
fi

echo success
