#!/bin/bash
set -e

source "$ROOTPATH"/scripts/common/env_setup.sh

alias cp='cp -rPf'

# --------------------Fetch & Align Base Artifacts------------------
echo "artifact_fetch for qnx build - (download_artifacts.py prebuilts_qnx.yml) -----------"
python3 "${ROOTPATH}"/common-infrastructure/common-ci-scripts/scripts/download_artifacts.py "${ROOTPATH}"/dependencies_config/prebuilts_qnx.yml

#Aligning base artifacts
mkdir -p "${ROOTPATH}"/lib/fastdds
cp "${ROOTPATH}"/base-artifacts/fastdds/lib/* "${ROOTPATH}"/lib/fastdds/
cp "${ROOTPATH}"/base-artifacts/fastdds/include/* "${ROOTPATH}"/model_ipc/include/

mkdir -p "${ROOTPATH}"/lib/jsoncpp
cp "${ROOTPATH}"/base-artifacts/jsoncpp/lib/lib* "${ROOTPATH}"/lib/jsoncpp/
cp -r "${ROOTPATH}"/base-artifacts/jsoncpp/include/jsoncpp/json "${ROOTPATH}"/model_ipc/include/
