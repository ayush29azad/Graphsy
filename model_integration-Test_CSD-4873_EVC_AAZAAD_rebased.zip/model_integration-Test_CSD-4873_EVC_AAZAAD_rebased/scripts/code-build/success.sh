#!/bin/bash

echo -e "\nCongratulations!!!, @$(git config user.name)! Code build success! Ignite your coding spirit, conquer challenges, and make your mark on programming.\n"
echo "██╗   ██╗ █████╗ ██╗     ██╗███╗   ██╗██████╗ ███████╗██████╗ "
echo "╚██╗ ██╔╝██╔══██╗██║     ██║████╗  ██║██╔══██╗██╔════╝██╔══██╗"
echo " ╚████╔╝ ███████║██║     ██║██╔██╗ ██║██║  ██║█████╗  ██████╔╝"
echo "  ╚██╔╝  ██╔══██║██║     ██║██║╚██╗██║██║  ██║██╔══╝  ██╔══██╗"
echo "   ██║   ██║  ██║███████╗██║██║ ╚████║██████╔╝███████╗██║  ██║"
echo "   ╚═╝   ╚═╝  ╚═╝╚══════╝╚═╝╚═╝  ╚═══╝╚═════╝ ╚══════╝╚═╝  ╚═╝"
