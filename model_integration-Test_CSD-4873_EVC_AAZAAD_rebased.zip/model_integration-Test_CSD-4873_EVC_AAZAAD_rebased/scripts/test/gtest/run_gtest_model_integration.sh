#!/bin/bash
set -e

source "$ROOTPATH"/scripts/common/env_setup.sh
cmake -S "$ROOTPATH"/test/unit/ -B "$ROOTPATH"/test/unit/build -Wno-dev
cmake --build "$ROOTPATH"/test/unit/build -- -j `nproc`
cd "$ROOTPATH"/test/unit/build
cp "$ROOTPATH"/utils/someip_id_mapping.json "$ROOTPATH"/test/unit/build
cp "$ROOTPATH"/utils/dummyMapping.json "$ROOTPATH"/test/unit/build

ctest --output-on-failure -j1

make coverage 

cd -
mkdir -p "$ROOTPATH"/Gtest_reports
cp -r "$ROOTPATH"/test/unit/build/out/* "$ROOTPATH"/Gtest_reports

mkdir -p "$ROOTPATH"/Gtest_reports/Gtest/
find "${ROOTPATH}/test/unit/build" -type d -name jsonreports -exec cp -r {} "${ROOTPATH}/Gtest_reports/Gtest/" \;
set +e
