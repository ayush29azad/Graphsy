# cccm_launcher_config
This config is passed to launcher to launch multiple models on different threads under a same process.
