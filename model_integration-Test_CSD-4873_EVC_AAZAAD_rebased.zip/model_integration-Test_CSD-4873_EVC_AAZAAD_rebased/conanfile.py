#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from conans import ConanFile
from conan.tools.scm.git import Git
from conan.tools.cmake import CMake, CMakeToolchain, CMakeDeps
import os
from conan.tools.files import collect_libs, update_conandata
import time
from conan.tools.files import copy

class ModelIntegrationConan(ConanFile):
    name = "model_integration"
    description = "Model Integration"
    license = "Copyright © Jaguar Land Rover 2023"

    settings = "os", "compiler", "build_type", "arch"
    generators = "cmake_find_package", "CMakeToolchain", "cmake_paths", "VirtualRunEnv"

    url = "https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration.git"
    # Export your util file so it is available during packaging
    # exports_sources = ["utils/ml_APIs_mapping.json"]
    options = {
        "shared": [True, False],
        "dlt" : ["enabled", "disabled"],
        "golden": [True, False],
        "enable_testing": [True, False]
    }
    
    default_options = {
        "shared": True,
        "dlt" : "enabled",
        "golden": False,
        "enable_testing": False
    }

    requires = (
        "dds_manager/v4.4.1-2@jlrcccm/stable",
        "workexecutorthread/v2.13.0@jlrcccm/stable",
        "jsoncpp/1.9.5@jlrcccm/prebuilt",
        "dds_idls/v30.1.0@jlrcccm/stable",
        "someip_interface/v18.8.0@jlrcccm/dev",
        "non_safety_models_static_libs/26.15.0@jlrcccm/dev",
        "vsomeip/3.4.10@jlrcccm/prd",
        "gtest/1.14.0",
        "jlr_early_conf/1.3.1-7-g8b4d640@jlrcccm/dev",
        "model_launcher_interface/v1.5.0@jlrcccm/stable"
    )

    def configure(self):
        self.options["fmt"].header_only = True

        if self.settings.os == "Windows":
            self.options.dlt = "disabled"

        if self.options.dlt == "enabled":
            print("DLT LOGGING ENABLED")
            if self.settings.os == "Neutrino":
                self.options["dlt-daemon"].qnx_system = True
                self.options["dlt-daemon"].systemd = False
        else :
            print("DLT LOGGING DISABLED")
            self.options["dds_manager"].dlt = "disabled"
            self.options["workexecutorthread"].dlt = "disabled"

        self.options["vsomeip"].ENABLE_MULTIPLE_ROUTING_MANAGERS = 1

    def export(self):
        git = Git(self, folder=self.recipe_folder)
        ci_url = git.get_remote_url()
        commit = git.get_commit()
        update_conandata(self, {"sources": {"commit": commit, "ci_url": ci_url}})

    def source(self):
        sources = self.conan_data["sources"]
        # clear source folder if anything present
        self.run(f"rm -rf {self.source_folder}/*")
        git = Git(self, folder=self.source_folder)
        try:
            git.fetch_commit(sources["ci_url"], sources["commit"])
        except:
            git.fetch_commit(self.url, sources["commit"])

    def build_requirements(self):
        if self.settings.arch == "x86_64" and self.settings.os == "Linux":
            self.tool_requires("cmake/3.30.5")
 
    def requirements(self):
        if self.options.dlt == "enabled":
            self.requires("logging-api/0.0.64@jlrcccm/stable")


    def imports(self):
        self.copy("*json", dst="input/IPCMapping", src=(self.deps_cpp_info["someip_interface"].bin_paths[0]+"/IPCMapping/"))
        self.copy("*", dst="input/protos", src=(self.deps_cpp_info["someip_interface"].bin_paths[0]+"/protos/"))
        self.copy("*json", dst="input/IPCMapping", src=(self.deps_cpp_info["model_launcher_interface"].bin_paths[0]+"/IPCMapping/"))
        self.copy("*", dst="input/protos", src=(self.deps_cpp_info["model_launcher_interface"].bin_paths[0]+"/protos/"))
        self.copy("*json", dst="input/IPCMapping", src=os.path.join(self.deps_cpp_info["dds_idls"].build_paths[0],"json"))
        self.copy("*xml", dst="input/xml", src=os.path.join(self.deps_cpp_info["dds_idls"].build_paths[0],"xml"))
        self.copy("*json", dst="input/modelConfig", src=os.path.join(self.deps_cpp_info["non_safety_models_static_libs"].build_paths[0],"modelConfig"))


    def generate(self):
        tc = CMakeToolchain(self)
        tc.variables["BUILD_SHARED_LIBS"] = self.options.shared
        tc.variables["CONAN_CHANNEL"] = self.channel

        if self.options.dlt == "enabled":
            tc.variables["ENABLE_DLT_LOGGING"] = "ON"

        if self.options.enable_testing and not self.options.golden:
            tc.variables["BUILD_TESTS"] = "ON"

        if self.options.golden:
            tc.variables["ENABLE_GOLDEN_MODEL"] = "ON"

        tc.variables["release_version"] = self.version
        tc.generate()

        deps = CMakeDeps(self)
        # make it such that find_package(fastrtps) works in cmakelists.
        # Ideally we should update the fastdds conan package to use the 
        # cmake_file_name fastrtps instead of fastdds. But right now, there
        # are other packages that depend on fastdds conan package that could 
        # break. It is safer to do it here for now
        #
        # The reason to do it is because in fastdds 2.x.x the Find Module name
        # is fastrtps when building with just cmake. And we should strive to 
        # align to that. It only changes in fastdds 3.x.x . So a consumers 
        # CMakeLists should just work with find_package(fastrtps)
        deps.set_property('fastdds-prebuilt',"cmake_file_name","fastdds")
        deps.generate()


    def build(self):
        # copy(self,"ml_APIs_mapping.json", dst=os.path.join(self.source_folder, "input/IPCMapping"), src=os.path.join(self.source_folder,"./utils/") )
        start_time = time.time()
        cmake = CMake(self)
        cmake.verbose = False
        cmake.configure()
        cmake.build()

        if self.options.enable_testing or self.options.golden:
            cmake.test()
            if not self.options.golden:
                cmake.build(target="coverage")

        end_time = time.time()
        print(f"Time taken for conan build: {end_time - start_time} seconds")

    def package(self):
        cmake = CMake(self)
        cmake.install()

        self.copy("lib*", dst="lib", src=self.deps_cpp_info["dds_manager"].lib_paths[0], symlinks=True)
        self.copy("lib*", dst="lib", src=self.deps_cpp_info["workexecutorthread"].lib_paths[0], symlinks=True)
        self.copy("lib*", dst="lib", src=self.deps_cpp_info["dds_idls"].lib_paths[0], symlinks=True)
        self.copy("lib*", dst="lib", src=self.deps_cpp_info["someip_interface"].lib_paths[0], symlinks=True)
        self.copy("lib*", dst="lib", src=self.deps_cpp_info["jlr_early_conf"].lib_paths[0], symlinks=True)
        self.copy("lib*", dst="lib", src=self.deps_cpp_info["model_launcher_interface"].lib_paths[0], symlinks=True)


        if self.settings.build_type == "Debug":
            self.copy("lib*", dst="lib", src=self.deps_cpp_info["protobuf"].lib_paths[0], symlinks=True)

        if self.settings.arch == "armv8" and self.settings.os == "Neutrino":
            # prebuilt libs
            self.copy("lib*", dst="lib", src=self.deps_cpp_info["fastdds-prebuilt"].lib_paths[0], symlinks=True)
            self.copy("lib*", dst="lib", src=self.deps_cpp_info["fast-cdr-prebuilt"].lib_paths[0], symlinks=True)
            self.copy("lib*", dst="lib", src=self.deps_cpp_info["jsoncpp"].lib_paths[0], symlinks=True)
            self.copy("lib*", dst="lib", src=self.deps_cpp_info["jlr_early_conf"].lib_paths[0], symlinks=True)

        if self.settings.build_type == "Release":
            if self.settings.os == "Linux":
                strip_cmd = "strip"
            elif self.settings.os == "Neutrino":
                strip_cmd = f"{os.environ['QNX_HOST']}/usr/bin/ntoaarch64-strip"

            for subdir in ["lib", "bin"]:
                target_dir = os.path.join(self.package_folder, subdir)
                for root, _, files in os.walk(target_dir):
                    for file in files:
                        filepath = os.path.join(root, file)
                        if file.endswith("json") or file.endswith("xml") or os.path.islink(filepath):
                            continue
                        self.output.info(f"Stripping {filepath}")
                        self.run(f"{strip_cmd} {filepath}")

    def package_info(self):
        self.cpp_info.libs = collect_libs(self)
