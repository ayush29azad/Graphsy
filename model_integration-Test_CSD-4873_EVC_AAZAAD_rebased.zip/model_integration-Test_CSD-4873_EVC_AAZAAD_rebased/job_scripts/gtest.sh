#!/bin/bash

set -exo pipefail

source `pwd`/scripts/common/env_setup.sh
PROJECT_DIR=$(cd "$(dirname "$0")/.."; pwd)
export PROJECT_DIR=$PROJECT_DIR
echo $PROJECT_DIR

if [ "$#" -ne 2 ]
then
    echo "version or channel not provided"
    echo "using version=VERSION_UNSPECIFIED and channel=testing"
    export version=VERSION_UNSPECIFIED
    export channel=testing
else
    export version=$1
    export channel=$2
fi

if [[ -z $CI ]]
then
   LINUX_RELEASE_PROFILE="common-infrastructure/conan/profile/linux-x86_64-release"
   LINUX_DEBUG_PROFILE="common-infrastructure/conan/profile/linux-x86_64-debug"
fi

echo "version=$version"
echo "channel=$channel"

package=model_integration/$version@jlrcccm/$channel
echo "package=$package"

${PROJECT_DIR}/common-infrastructure/scripts/init-build-dir

mkdir -p /dev/shmem || true
# Link /dev/shm to /dev/shmem if not already linked
ln -s /dev/shm /dev/shmem || true

if [[ -z $CI ]]; then
    rm -rf ${PROJECT_DIR}/{build,output} && mkdir -p ${PROJECT_DIR}/build 
fi
conan install -if=${PROJECT_DIR}/build -of=${PROJECT_DIR}/build -pr:h=${PROJECT_DIR}/${LINUX_RELEASE_PROFILE} \
     -pr:b=${PROJECT_DIR}/${LINUX_RELEASE_PROFILE} --build=missing --no-imports -o enable_testing=True ${PROJECT_DIR} $package
conan imports ${PROJECT_DIR} -if=${PROJECT_DIR}/build -imf=${PROJECT_DIR}
conan build -bf=${PROJECT_DIR}/build -sf=${PROJECT_DIR} ${PROJECT_DIR} -pf=linux_artifacts/Release


BUILD_FOLDER_PATH=${PROJECT_DIR}/build
if [[ -d ${BUILD_FOLDER_PATH}/out ]]; then
    mkdir -p $PROJECT_DIR/Gtest_reports/Gtest
    cp -rf ${BUILD_FOLDER_PATH}/test/unit/jsonreports ${PROJECT_DIR}/Gtest_reports/Gtest/
    cp -rPf ${BUILD_FOLDER_PATH}/out/* $PROJECT_DIR/Gtest_reports

    if [[ "$CI" == true ]]; then
        source ${UTILS_PATH}/artifactory_utils.sh
        FILE_NAME="GTest_Reports_${version}.tar.gz"
        tar -czf ${FILE_NAME} Gtest_reports
        rt_upload --target-props "version=${version}" "${PROJECT_DIR}/${FILE_NAME}" ${GTEST_RT_LOCATION}/${FILE_NAME}
        echo "Gtest Report files uploaded to artifactory: ${GTEST_RT_LOCATION}/${FILE_NAME}"
    fi
    rm -rf ${BUILD_FOLDER_PATH}/out
fi

if [[ -n $CI ]]; then
  echo "👉 View Interactive Coverage Report here:"
  echo "${CI_PROJECT_URL}/-/jobs/${CI_JOB_ID}/artifacts/Gtest_reports/coverage.html"
fi

if [[ -z ${CI} ]] ; then
    chmod +x "${ROOTPATH}"/scripts/code-build/success.sh && "${ROOTPATH}"/scripts/code-build/success.sh
fi
