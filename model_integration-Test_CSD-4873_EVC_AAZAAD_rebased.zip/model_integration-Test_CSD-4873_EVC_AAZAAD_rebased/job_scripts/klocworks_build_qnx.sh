#!/bin/bash

set -exo pipefail

source `pwd`/scripts/common/env_setup.sh
PROJECT_DIR=$(cd "$(dirname "$0")/.."; pwd)
export PROJECT_DIR=$PROJECT_DIR
echo $PROJECT_DIR


export version=${NEXT_VERSION}
export channel=${CHANNEL}

echo "version=$version"
echo "channel=$channel"

package=model_integration/$version@jlrcccm/$channel
echo "package=$package"

if [[ -z $CI ]]
then
   QNX_BASE=`pwd`/sdp
   QNX_RELEASE_PROFILE="$PROJECT_DIR/common-infrastructure/conan/profile/qnx-7.1-release"
   QNX_DEBUG_PROFILE="$PROJECT_DIR/common-infrastructure/conan/profile/qnx-7.1-debug"
fi

source "${QNX_BASE}/qnxsdp-env.sh"

${PROJECT_DIR}/common-infrastructure/scripts/init-build-dir

# Local QNX Release build
rm -rf ${PROJECT_DIR}/{build,output} && mkdir -p ${PROJECT_DIR}/build 
conan install -if=${PROJECT_DIR}/build -of=${PROJECT_DIR}/build -pr:h=${QNX_RELEASE_PROFILE} \
  -pr:b=${LINUX_RELEASE_PROFILE} --build=missing --no-imports ${PROJECT_DIR} $package
conan imports ${PROJECT_DIR} -if=${PROJECT_DIR}/build -imf=${PROJECT_DIR}
conan build -bf=${PROJECT_DIR}/build -sf=${PROJECT_DIR} ${PROJECT_DIR} -pf=qnx_artifacts/Release
conan package -bf=${PROJECT_DIR}/build -sf=${PROJECT_DIR} -pf=qnx_artifacts/Release ${PROJECT_DIR}
