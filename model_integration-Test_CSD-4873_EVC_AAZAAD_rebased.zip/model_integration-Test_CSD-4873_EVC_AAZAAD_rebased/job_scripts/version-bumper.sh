#!/bin/bash
set -e
export channel="dev"
if [[ $CI_COMMIT_REF_NAME == "$DEVELOPMENT_BRANCH" || $CI_COMMIT_REF_NAME == "$MAIN_BRANCH" || $CI_COMMIT_REF_NAME =~ $BRANCH_REGEX ]]; then
  # install_packages

  semantic-release --dry-run > semantic_log.txt 2>&1
  cat semantic_log.txt

  NEXT_TAG_VERSION=$( (cat semantic_log.txt | grep 'The next release version is' | sed -n 's/.*version is \([^ ]*\).*/\1/p' ) || echo "" )
  if [[ -z $NEXT_TAG_VERSION ]]; then
    export NEXT_VERSION=`git tag -l "v[0-9]*" | sort -r --version-sort | head -n 1`
  else
    export NEXT_VERSION=v${NEXT_TAG_VERSION}
  fi

  if [[ $CI_COMMIT_REF_NAME == "$MAIN_BRANCH" ]]; then
    export channel="stable"
  fi
else
  export NEXT_VERSION=`echo $CI_COMMIT_REF_NAME | grep -Eo 'DIN[-,_]([0-9])+|INF[-,_]([0-9])+|CSD[-,_]([0-9])+' | head -1 || echo ""`
fi

if [[ $TRIGGER_MODEL_INTEGRATION == "true" ]]; then
  echo "Triggered when TRIGGER_MODEL_INTEGRATION == true"
  NEXT_VERSION="${NEXT_VERSION}_trigger_e2e"
fi

echo "The upcoming version is ${NEXT_VERSION}"
echo "NEXT_VERSION=${NEXT_VERSION}" > version.env
echo "CHANNEL=${channel}" >> version.env

cat version.env

set +e
