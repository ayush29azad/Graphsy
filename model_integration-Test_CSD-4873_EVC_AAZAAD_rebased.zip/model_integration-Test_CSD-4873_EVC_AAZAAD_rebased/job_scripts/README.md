# cccm\_model\_integration/job\_scripts

This folder contains scripts of some jobs ran in .gitlab-ci.yml. These scripts can be run on both pipeline as well for local development (verify which docker to run certain script in).

common.sh: This script is sourced before each job script in this folder to setup some common configuration.
All the script need to be ran from the parent folder.
