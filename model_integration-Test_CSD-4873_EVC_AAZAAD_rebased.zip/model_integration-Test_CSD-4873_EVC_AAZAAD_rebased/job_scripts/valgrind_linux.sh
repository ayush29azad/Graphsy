#!/bin/bash

PROJECT_DIR=`pwd`

# 1. Setup Environment
apt-get update && apt-get install valgrind -y

if [[ -z $CI ]]
then
   LINUX_RELEASE_PROFILE="common-infrastructure/conan/profile/linux-x86_64-release"
fi

package="model_integration/$(git tag --sort=-creatordate | head -n 1)@jlrcccm/dev"
conan install -if=${PROJECT_DIR}/build-linux -of=${PROJECT_DIR}/build-linux -pr:h=${PROJECT_DIR}/${LINUX_RELEASE_PROFILE} \
     -pr:b=${PROJECT_DIR}/${LINUX_RELEASE_PROFILE} --build=missing --no-imports ${PROJECT_DIR} $package

source $PROJECT_DIR/build-linux/conanrun.sh 
cd $PROJECT_DIR/linux_artifacts
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:`pwd`/lib
cd bin/
cp $PROJECT_DIR/utils/someip_id_mapping.json /bin
mv val_vsomeip_servers/* . 2>/dev/null || true
mkdir -p valgrind_out

# 2. Launch ALL SomeIP Servers in Background
echo "Starting SomeIP Servers..."
./energymanagement_service_server > /dev/null &  
./featureconfig_userapps_service_server > /dev/null &  
./lifecycle_userapps_vlca_service_server > /dev/null &  
./lighting_service_server > /dev/null &  
./odometer_service_server > /dev/null &  
./rollingcount_service_server > /dev/null &  
./propulsion_service_server > /dev/null &  
./steering_service_server > /dev/null &  
./vehiclespeed_service_server > /dev/null &  
./suspension_service_server > /dev/null &
SERVER_PIDS=$! # Isse last server ka milta hai, behtar hai pkill use karna baad mein

sleep 5 # Wait for servers to initialize

# 3. Launch Models under Valgrind (as per your new list)
echo "Launching Models under Valgrind..."



valgrind --leak-check=full --show-leak-kinds=all --track-origins=yes --log-file=valgrind_out/MD01.txt \
./model_launcher --models vehicleLifecycle displayOdometerTripComputer messageCentre batteryStateOfChargeDisp chargingInfo --dlt_id MD01 --vid 10 --cwriter> /dev/null &
PID1=$!

valgrind --leak-check=full --show-leak-kinds=all --track-origins=yes --log-file=valgrind_out/MD02.txt \
./model_launcher --models clockDisplay gaugeSpeedometer doorStatus steeringWheelSwitch indFlashing outsideTempFrostInd --dlt_id MD02 --vid 10 --cwriter> /dev/null &
PID2=$!

valgrind --leak-check=full --show-leak-kinds=all --track-origins=yes --log-file=valgrind_out/MD03.txt \
./model_launcher --models gauges displayZoneFeature indExtLights telltaleService --dlt_id MD03 --vid 10 --cwriter> /dev/null &
PID3=$!


valgrind --leak-check=full --show-leak-kinds=all --track-origins=yes --log-file=valgrind_out/MD04.txt \
./model_launcher --models statusTPMS staticDisplayConfig transientInfo messageCentreData miscTelltales --dlt_id MD04 --vid 10 --cwriter> /dev/null &
PID4=$!

echo "Collecting logs for 150 seconds..."
sleep 150

echo "Stopping models gracefully..."
kill -2 $PID1 $PID2 $PID3 $PID4

sleep 15 

kill $PID1 $PID2 $PID3 $PID4 2>/dev/null

# 6. Copy Reports
mkdir -p $PROJECT_DIR/valgrind_reports
cp valgrind_out/*.txt $PROJECT_DIR/valgrind_reports/
echo "Done. Reports copied to valgrind_reports/"
