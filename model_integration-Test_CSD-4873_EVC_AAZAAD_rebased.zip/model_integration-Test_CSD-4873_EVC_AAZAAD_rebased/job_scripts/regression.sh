#!/bin/bash

export ROOTPATH=$(cd "$(dirname "$0")/../" && pwd)

# Define paths
FEATURE_DIR="$ROOTPATH/test/regression_testing"
OUTPUT_FILE="$ROOTPATH/test_file"
OUTPUT_FOLDER="$ROOTPATH/unchanged_features"

# Check if FEATURE_DIR exists
if [ ! -d "$FEATURE_DIR" ]; then
    echo "❌ ERROR: Directory $FEATURE_DIR does not exist."
    exit 1
fi

# Prepare output
> "$OUTPUT_FILE"
rm -rf "$OUTPUT_FOLDER"
mkdir -p "$OUTPUT_FOLDER"

# Find all .feature files in the target directory
CURRENT_FEATURES=$(find "$FEATURE_DIR" -type f -name "*.feature")

for FILE in $CURRENT_FEATURES; do
    RELATIVE_PATH="${FILE#$ROOTPATH/}"  # Strip ROOTPATH prefix for Git comparison
    FILENAME=$(basename "$FILE") # Extract just the filename
    
    echo $RELATIVE_PATH
    # Check if the file exists in origin/main
    if git ls-tree -r "origin/main" --name-only | grep -Fxq "$RELATIVE_PATH"; then
        echo "yay"
        # Check if the file content is unchanged
        if ! git diff origin/main -- "$RELATIVE_PATH" | grep -q .; then            
            # Use the FILENAME variable to get the desired output path
            echo "$FILENAME" >> "$OUTPUT_FILE"
            
            # Copy the file to the top-level of the output folder
            cp "$FILE" "$OUTPUT_FOLDER/$FILENAME"
        fi
    fi
done

echo "✅ Unchanged feature files saved in $OUTPUT_FOLDER and listed in $OUTPUT_FILE"
