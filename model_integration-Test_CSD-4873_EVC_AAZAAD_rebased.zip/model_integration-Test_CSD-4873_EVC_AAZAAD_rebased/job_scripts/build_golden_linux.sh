#!/bin/bash

set -exo pipefail

source `pwd`/scripts/common/env_setup.sh
PROJECT_DIR=$(cd "$(dirname "$0")/.."; pwd)
export PROJECT_DIR=$PROJECT_DIR
echo $PROJECT_DIR

#shellcheck disable=SC2034

if [ "$#" -ne 2 ]
then
    echo "version or channel not provided"
    echo "using version=VERSION_UNSPECIFIED and channel=testing"
    export version=VERSION_UNSPECIFIED
    export channel=testing
else
    export version=$1
    export channel=$2
fi

if [[ -z $CI ]]
then
   LINUX_RELEASE_PROFILE="common-infrastructure/conan/profile/linux-x86_64-release"
   LINUX_DEBUG_PROFILE="common-infrastructure/conan/profile/linux-x86_64-debug"
fi

echo "version=$version"
echo "channel=$channel"

package=model_integration/$version@jlrcccm/$channel
echo "package=$package"

${PROJECT_DIR}/common-infrastructure/scripts/init-build-dir

if [[ -n $CI ]]
then
    conan create ${PROJECT_DIR} $package \
        -pr:h=${PROJECT_DIR}/${LINUX_RELEASE_PROFILE} -pr:b=${PROJECT_DIR}/${LINUX_RELEASE_PROFILE} \
        --build=missing --build=model_integration -o golden=True

    BUILD_FOLDER_PATH=$(conan info $package -o golden=True -pr:h=${PROJECT_DIR}/${LINUX_RELEASE_PROFILE} -pr:b=${PROJECT_DIR}/${LINUX_RELEASE_PROFILE} --only=build_folder --paths | grep build_folder | grep model_integration | awk '{print $NF}')
    if [[ -d ${BUILD_FOLDER_PATH}/out ]]; then
        mkdir -p $PROJECT_DIR/Gtest_reports/Gtest
        cp -rf ${BUILD_FOLDER_PATH}/test/unit/jsonreports ${PROJECT_DIR}/Gtest_reports/Gtest/
        cp -rPf ${BUILD_FOLDER_PATH}/out/* $PROJECT_DIR/Gtest_reports
    fi
else
    rm -rf ${PROJECT_DIR}/{build-golden,output} && mkdir -p ${PROJECT_DIR}/build-golden 
    conan install -if=${PROJECT_DIR}/build-golden -of=${PROJECT_DIR}/build-golden -pr:h=${PROJECT_DIR}/${LINUX_RELEASE_PROFILE} \
     -pr:b=${PROJECT_DIR}/${LINUX_RELEASE_PROFILE} --build=missing --no-imports -o golden=True ${PROJECT_DIR} $package
    conan imports ${PROJECT_DIR} -if=${PROJECT_DIR}/build-golden -imf=${PROJECT_DIR}
    conan build -bf=${PROJECT_DIR}/build-golden -sf=${PROJECT_DIR} ${PROJECT_DIR} -pf=linux_artifacts/Release
    conan package -bf=${PROJECT_DIR}/build-golden -sf=${PROJECT_DIR} -pf=linux_artifacts/Release ${PROJECT_DIR}
fi

# if [[ -n $CI ]]
# then
#     echo "Running in pipeline"
#     conan upload $package --all -r jlr-cccm -c --force
# fi
