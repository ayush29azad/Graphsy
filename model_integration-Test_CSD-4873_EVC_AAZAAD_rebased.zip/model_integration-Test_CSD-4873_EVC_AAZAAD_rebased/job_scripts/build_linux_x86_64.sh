#!/bin/bash

set -exo pipefail

source `pwd`/scripts/common/env_setup.sh
PROJECT_DIR=$(cd "$(dirname "$0")/.."; pwd)
export PROJECT_DIR=$PROJECT_DIR
echo $PROJECT_DIR

if [ "$#" -ne 2 ]
then
    echo "version or channel not provided"
    echo "using version=VERSION_UNSPECIFIED and channel=testing"
    export version=VERSION_UNSPECIFIED
    export channel=testing
else
    export version=$1
    export channel=$2
fi

if [[ -z $CI ]]
then
   LINUX_RELEASE_PROFILE="common-infrastructure/conan/profile/linux-x86_64-release"
   LINUX_DEBUG_PROFILE="common-infrastructure/conan/profile/linux-x86_64-debug"
fi

echo "version=$version"
echo "channel=$channel"

package=model_integration/$version@jlrcccm/$channel
echo "package=$package"

${PROJECT_DIR}/common-infrastructure/scripts/init-build-dir

if [[ -n $CI ]]
then
    # Release profile
    conan create ${PROJECT_DIR} $package \
        -pr:h=${PROJECT_DIR}/${LINUX_RELEASE_PROFILE} -pr:b=${PROJECT_DIR}/${LINUX_RELEASE_PROFILE} \
        --build=missing --build=model_integration

    BUILD_FOLDER_PATH=$(conan info $package --profile=${PROJECT_DIR}/${LINUX_RELEASE_PROFILE} --only=build_folder --paths | grep build_folder | grep model_integration | awk '{print $NF}')
    mkdir -p ${PROJECT_DIR}/autogen_output
    cp -rPf $BUILD_FOLDER_PATH/output/* ${PROJECT_DIR}/autogen_output

    PACKAGE_PATH=$(conan info $package --profile=${PROJECT_DIR}/${LINUX_RELEASE_PROFILE} --only=package_folder --paths | grep package_folder | grep model_integration | awk '{print $NF}')
    mkdir -p $PROJECT_DIR/linux_artifacts
    cp -rPf $PACKAGE_PATH/{bin,lib} $PROJECT_DIR/linux_artifacts/

    # Debug profile
    conan create ${PROJECT_DIR} $package \
        -pr:h=${PROJECT_DIR}/${LINUX_DEBUG_PROFILE} -pr:b=${PROJECT_DIR}/${LINUX_RELEASE_PROFILE} \
        --build=missing --build=model_integration -s jlr_early_conf:build_type=Release
else
    # Release profile
    rm -rf ${PROJECT_DIR}/{build-release,output} && mkdir -p ${PROJECT_DIR}/build-release 
    conan install -if=${PROJECT_DIR}/build-release -of=${PROJECT_DIR}/build-release \
        -pr:h=${PROJECT_DIR}/${LINUX_RELEASE_PROFILE} -pr:b=${PROJECT_DIR}/${LINUX_RELEASE_PROFILE} \
        --build=missing --no-imports ${PROJECT_DIR} $package
    conan imports ${PROJECT_DIR} -if=${PROJECT_DIR}/build-release -imf=${PROJECT_DIR}
    conan build -bf=${PROJECT_DIR}/build-release -sf=${PROJECT_DIR} ${PROJECT_DIR} -pf=linux_artifacts/Release
    conan package -bf=${PROJECT_DIR}/build-release -sf=${PROJECT_DIR} -pf=linux_artifacts/Release ${PROJECT_DIR}

    # Debug profile
    rm -rf ${PROJECT_DIR}/{build-debug,output} && mkdir -p ${PROJECT_DIR}/build-debug 
    conan install -if=${PROJECT_DIR}/build-debug -of=${PROJECT_DIR}/build-debug -pr:h=${PROJECT_DIR}/${LINUX_DEBUG_PROFILE} \
         -pr:b=${PROJECT_DIR}/${LINUX_RELEASE_PROFILE} --build=missing --no-imports ${PROJECT_DIR} $package -s jlr_early_conf:build_type=Release
    conan imports ${PROJECT_DIR} -if=${PROJECT_DIR}/build-debug -imf=${PROJECT_DIR}
    conan build -bf=${PROJECT_DIR}/build-debug -sf=${PROJECT_DIR} ${PROJECT_DIR} -pf=linux_artifacts/Debug
    conan package -bf=${PROJECT_DIR}/build-debug -sf=${PROJECT_DIR} -pf=linux_artifacts/Debug ${PROJECT_DIR}
fi


if [[ -n $CI ]]
then
    echo "Running in pipeline"
    if conan search $package -r jlr-cccm > /dev/null 2>&1; then
        echo "Removing old Linux conan packages"
        conan remove $package -r jlr-cccm -q "os=Linux and arch=x86_64" --force
    fi
    conan upload $package --all -r jlr-cccm -c --force
fi

if [[ -z ${CI} ]] ; then
    chmod +x "${ROOTPATH}"/scripts/code-build/success.sh && "${ROOTPATH}"/scripts/code-build/success.sh
fi
